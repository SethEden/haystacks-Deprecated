"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _ruleBroker = _interopRequireDefault(require("../brokers/ruleBroker.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("../constants/business.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var num = _interopRequireWildcard(require("../constants/numeric.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _data = _interopRequireDefault(require("./data.js"));

var _path = _interopRequireDefault(require("path"));

var _fnc$cinitStack$fnc$c;

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // structures.stack.


var namespacePrefix = wr1.cstructures + bas.cDot + baseFileName + bas.cDot;
/**
 * @function initStack
 * @description Initializes the stack with the provided namespace.
 * @param {string} stackNameSpace The namespace the Stack array should be created under.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/01
 */

function initStack(stackNameSpace) {
  var functionName = initStack.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstackNameSpaceIs + stackNameSpace);

  if (_data["default"][stackNameSpace] === undefined) {
    _data["default"][stackNameSpace] = [];
  } else {
    // WARNING: Stack:
    // ALREADY exists!
    console.log(num.c1 + bas.cSpace + msg.cWarningStackColon + stackNameSpace + msg.cAlreadyExists);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function clearStack
 * @description Clears all contents of the stack so it can start fresh. It does not delete the stack completely!
 * @param {string} stackNameSpace The namespace for the stack that should be cleared.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/01
 */

function clearStack(stackNameSpace) {
  var functionName = clearStack.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstackNameSpaceIs + stackNameSpace);

  if (_data["default"][stackNameSpace] !== undefined) {
    _data["default"][stackNameSpace] = [];
  } else {
    // WARNING: Stack:
    // does not exists!
    console.log(num.c2 + bas.cSpace + msg.cWarningStackColon + stackNameSpace + msg.cdoesNotExist);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function push
 * @description Pushes some data on the stack identified by the namespace input parameter.
 * @param {string} stackNameSpace The namespace of the stack that should be used to push the data onto.
 * @param {string|integer|booelan|object|array} value The data that should be pushed on the stack.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/01
 */

function push(stackNameSpace, value) {
  var functionName = push.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstackNameSpaceIs + stackNameSpace);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cvalueIs + JSON.stringify(value));

  if (_data["default"][stackNameSpace] !== undefined) {
    _data["default"][stackNameSpace].push(value);
  } else {
    // WARNING: Stack:
    // does not exists!
    console.log(num.c3 + bas.cSpace + msg.cWarningStackColon + stackNameSpace + msg.cdoesNotExist);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function pop
 * @description Pops some data off the stack identified by the namespace input parameter.
 * @param {string} stackNameSpace The namespace of the stack that should be used to pop the data and return it.
 * @return {string|integer|boolean|object|array} Whatever data was stored at the top of the stack.
 * @author Seth Hollingsead
 * @date 2022/02/01
 */

function pop(stackNameSpace) {
  var functionName = pop.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstackNameSpaceIs + stackNameSpace);

  var returnData;

  if (_data["default"][stackNameSpace] !== undefined) {
    if (_data["default"][stackNameSpace].length === 0) {
      // WARNING: Stack:
      // is empty!
      returnData = msg.cWarningStackColon + stackNameSpace + bas.cisEmpty;
      console.log(returnData);
    } else {
      returnData = _data["default"][stackNamespace].pop();
    }
  } else {
    // WARNING: Stack:
    // does not exists!
    console.log(num.c4 + bas.cSpace + msg.cWarningStackColon + stackNameSpace + msg.cdoesNotExist);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + JSON.stringify(returnData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function isEmpty
 * @description Dtermines if the stack specified by the namespace parameter is empty or not empty.
 * @param {string} stackNamespace The namespace of the stack that should be checked if it is empty or not empty.
 * @return {boolean} True or False to indicate if the specified stack is empty or not empty.
 * @author Seth Hollingsead
 * @date 2022/02/01
 */

function isEmpty(stackNamespace) {
  var functionName = isEmpty.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstackNameSpaceIs + stackNameSpace);

  var returnData = false;

  if (_data["default"][stackNamespace] !== undefined) {
    if (_data["default"][stackNamespace].length === 0) {
      returnData = true;
    }
  } else {
    // WARNING: Stack:
    // does not exists!
    console.log(num.c5 + bas.cSpace + msg.cWarningStackColon + stackNameSpace + msg.cdoesNotExist);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function length
 * @description Gets the length of the stack specified by the namespace parameter.
 * @param {string} stackNameSpace The namespace of the stack that should return a length property.
 * @return {integer} A value that represents a count of the number of entities on the specified stack.
 * @author Seth Hollingsead
 * @date 2022/02/01
 */

function length(stackNameSpace) {
  var functionName = length.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstackNameSpaceIs + stackNameSpace);

  var returnData = -1;

  if (_data["default"][stackNameSpace] !== undefined) {
    returnData = _data["default"][stackNameSpace].length;
  } else {
    // WARNING: Stack:
    // does not exists!
    console.log(num.c6 + bas.cSpace + msg.cWarningStackColon + stackNameSpace + msg.cdoesNotExist);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function contains
 * @description Dtermines if the specified stack contains the specified value.
 * @param {string} stackNameSpace The namespace of the stack that should be searched for the specified value.
 * @param {string|integer|object|array} value The value/object that should be searched to see if it exists on the specified stack or does not exist.
 * @return {boolean} True or False to indicate if the value/object exists or does not exist.
 * @author Seth Hollingsead
 * @date 2022/02/01
 */

function contains(stackNameSpace, value) {
  var functionName = contains.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstackNameSpaceIs + stackNameSpace);

  var returnData = false;
  var containsRule = [];
  containsRule[0] = biz.cdoesArrayContainCharacter;

  if (_data["default"][stackNameSpace] !== undefined) {
    returnData = _ruleBroker["default"].processRules(value, _data["default"][stackNameSpace], containsRule);
  } else {
    // WARNING: Stack:
    // does not exists!
    console.log(num.c7 + bas.cSpace + msg.cWarningStackColon + stackNameSpace + msg.cdoesNotExist);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function print
 * @description Prints out the stack as specified by the namespace input parameter.
 * @param {string} stackNameSpace The namespace that should be used to print out the contents of the stack on the D-data structure.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/01
 */

function print(stackNameSpace) {
  var functionName = contains.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstackNameSpaceIs + stackNameSpace);

  if (_data["default"][stackNameSpace] !== undefined) {
    // Contents of the stack namespace:
    console.log(msg.cContentsOfTheStackNamespace + stackNameSpace + sys.cSpaceIsColonSpace + JSON.stringify(_data["default"][stackNameSpace]));
  } else {
    // WARNING: Stack:
    // does not exists!
    console.log(num.c8 + bas.cSpace + msg.cWarningStackColon + stackNameSpace + msg.cdoesNotExist);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;

var _default = (_fnc$cinitStack$fnc$c = {}, _defineProperty(_fnc$cinitStack$fnc$c, fnc.cinitStack, function (stackNameSpace) {
  return initStack(stackNameSpace);
}), _defineProperty(_fnc$cinitStack$fnc$c, fnc.cclearStack, function (stackNameSpace) {
  return clearStack(stackNameSpace);
}), _defineProperty(_fnc$cinitStack$fnc$c, fnc.cpush, function (stackNameSpace, value) {
  return push(stackNameSpace, value);
}), _defineProperty(_fnc$cinitStack$fnc$c, fnc.cpop, function (stackNameSpace) {
  return pop(stackNameSpace);
}), _defineProperty(_fnc$cinitStack$fnc$c, fnc.cisEmpty, function (stackNamespace) {
  return isEmpty(stackNameSpace);
}), _defineProperty(_fnc$cinitStack$fnc$c, fnc.clength, function (stackNameSpace) {
  return length(stackNameSpace);
}), _defineProperty(_fnc$cinitStack$fnc$c, fnc.ccontains, function (stackNameSpace, value) {
  return contains(stackNameSpace, value);
}), _defineProperty(_fnc$cinitStack$fnc$c, fnc.cprint, function (stackNameSpace) {
  return print(stackNameSpace);
}), _fnc$cinitStack$fnc$c);

exports["default"] = _default;