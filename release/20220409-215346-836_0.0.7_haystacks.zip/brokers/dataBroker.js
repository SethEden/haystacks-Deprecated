"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _ruleBroker = _interopRequireDefault(require("./ruleBroker.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("../constants/business.constants.js"));

var cfg = _interopRequireWildcard(require("../constants/configuration.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var gen = _interopRequireWildcard(require("../constants/generic.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _configurator = _interopRequireDefault(require("../executrix/configurator.js"));

var _fileOperations = _interopRequireDefault(require("../executrix/fileOperations.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _path = _interopRequireDefault(require("path"));

var _fnc$cscanDataPath$fn;

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // brokers.dataBroker.


var namespacePrefix = wr1.cbrokers + bas.cDot + baseFileName + bas.cDot;
/**
 * @function scanDataPath
 * @description Scans the specified path and returns a collection
 * of all the files contained recursively within that path and all sub-folders.
 * @param {string} dataPath The path that should be recursively scanned for files in all the folders.
 * @return {array<string>} An array of strings that each have the full path and file name
 * at all levels of the specified path including sub-folders.
 * @author Seth Hollingsead
 * @date 2021/10/15
 */

function scanDataPath(dataPath) {
  var functionName = scanDataPath.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`dataPath is: ${dataPath}`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataPathIs + dataPath);

  var rules = [];
  var filesFound = [];
  rules[0] = biz.cswapBackSlashToForwardSlash; // console.log(`execute business rules: ${JSON.stringify(rules)}`);

  dataPath = _ruleBroker["default"].processRules(dataPath, '', rules); // console.log(`dataPath after business rules processing is: ${dataPath}`);

  filesFound = _fileOperations["default"].readDirectoryContents(dataPath);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfilesFoundIs + JSON.stringify(filesFound));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function); // console.log(`filesFound is: ${JSON.stringify(filesFound)}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return filesFound;
}

;
/**
 * @function findUniversalDebugConfigSetting
 * @description Determines if there is any True setting for the debug settings
 * in either the application system config or the framework system config files.
 * @param {array<string>} appConfigFilesToLoad The list of files for the app config files.
 * @param {array<string>} frameworkConfigFilesToLoad The list of files for the framework config files.
 * @return {boolean} A True or False value to indicate if debug setting value is set in
 * either the app config system file or the framework config system file.
 * @author Seth Hollingsead
 * @date 2022/01/18
 */

function findUniversalDebugConfigSetting(appConfigFilesToLoad, frameworkConfigFilesToLoad) {
  var functionName = findUniversalDebugConfigSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`appConfigFilesToLoad is: ${JSON.stringify(appConfigFilesToLoad)}`);
  // console.log(`frameworkConfigFilesToLoad is: ${JSON.stringify(frameworkConfigFilesToLoad)}`);

  var universalDebugConfigSetting = false;
  var appConfigDebugSetting = false;
  var frameworkConfigDebugSetting = false;
  appConfigDebugSetting = findIndividualDebugConfigSetting(appConfigFilesToLoad);
  frameworkConfigDebugSetting = findIndividualDebugConfigSetting(frameworkConfigFilesToLoad);

  if (appConfigDebugSetting === true || frameworkConfigDebugSetting === true) {
    universalDebugConfigSetting = true;
  } // console.log(`universalDebugConfigSetting is: ${universalDebugConfigSetting}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return universalDebugConfigSetting;
}

;
/**
 * @function findIndividualDebugConfigSetting
 * @description Finds if a debugSetting is set for a particular set of config files.
 * @param {array<string>} filesToLoad A list of files that should be searched for
 * a system config file and then for a debugSetting in that file.
 * @return {boolean} A True or False value to indicate what the value of
 * the debug setting is for the set of system config files.
 * @author Seth Hollingsead
 * @date 2022/01/18
 */

function findIndividualDebugConfigSetting(filesToLoad) {
  var functionName = findIndividualDebugConfigSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`filesToLoad is: ${JSON.stringify(filesToLoad)}`);

  var individualDebugConfigSetting = false;
  var foundSystemData = false;
  var systemConfigFileName = sys.csystemConfigFileName; // 'framework.system.json';

  var applicationConfigFileName = sys.capplicationConfigFileName; // 'application.system.json';

  var multiMergedData = {};
  var systemDotDebugSettings = wr1.csystem + bas.cDot + cfg.cdebugSettings;

  for (var i = 0; i < filesToLoad.length; i++) {
    var fileToLoad = filesToLoad[i]; // console.log('fileToLoad is: ' + fileToLoad);

    if (fileToLoad.includes(systemConfigFileName) || fileToLoad.includes(applicationConfigFileName)) {
      var dataFile = preprocessJsonFile(fileToLoad);
      multiMergedData[wr1.csystem] = {};
      multiMergedData[wr1.csystem] = dataFile;
      foundSystemData = true;
    }

    if (foundSystemData === true) {
      break;
    }
  }

  if (multiMergedData[wr1.csystem]) {
    if (multiMergedData[wr1.csystem][systemDotDebugSettings]) {
      individualDebugConfigSetting = true;
    }
  } // console.log(`individualDebugConfigSetting is: ${individualDebugConfigSetting}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return individualDebugConfigSetting;
}

;
/**
 * @function loadAllCsvData
 * @description Loads al of the contents of all files and  folders and sub-folders at the specified path and builds a list of files to load,
 * then loads them accordingly in the D.contextName_fileName.
 * @param {array<string>} filesToLoad The data structure containing all of the files to load data from.
 * @param {string} contextName The context name that should be used when adding data to the D data structure.
 * @return {object} The data in a JSON object after it was loaded from the file.
 * @author Seth Hollingsead
 * @date 2022/01/27
 */

function loadAllCsvData(filesToLoad, contextName) {
  var functionName = loadAllCsvData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // filesToLoad is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfilesToLoadIs + JSON.stringify(filesToLoad)); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var rules = [];
  var fileExtensionRules = [];
  var parsedDataFile;
  rules[1] = biz.cgetFileNameFromPath;
  rules[2] = biz.cremoveFileExtensionFromFileName;
  fileExtensionRules[0] = biz.cgetFileExtension;
  fileExtensionRules[1] = biz.cremoveDotFromFileExtension;

  for (var i = 0; i < filesToLoad.length; i++) {
    var fileToLoad = filesToLoad[i]; // File to load is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cFileToLoadIs + fileToLoad); // NOTE: We still need a filename to use as a context for the page data that we just loaded.
    // A context name will be composed of the input context name wtih the file name we are processing
    // which tells us where we will put the data in the D[contextName] sub-structure.


    var fileExtension = _ruleBroker["default"].processRules(fileToLoad, '', fileExtensionRules); // fileExtension is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfileExtensionIs + fileExtension);

    if (fileExtension === gen.ccsv || fileExtension === gen.cCsv || fileExtension === gen.cCSV) {
      // execute business rules:
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cexecuteBusienssRulesColon + JSON.stringify(rules)); // This next line is commented out because it was resulting in colors_colors, which didn't make any sense.
      // contextName = contextName + bas.cUnderscore + ruleBroker.processRules(fileToLoad, '', rules);
      // contextName is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

      var dataFile = _fileOperations["default"].getCsvData(fileToLoad); // loaded file data is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cloadedFileDataIs + JSON.stringify(dataFile));

      parsedDataFile = processCsvData(dataFile, contextName);
    } // End-if (fileExtension === gen.ccsv || fileExtension === gen.cCsv || fileExtension === gen.cCSV)

  } // End-for (let i = 0; i < filesToLoad.length; i++)
  // parsedDataFile is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cparsedDataFileIs + JSON.stringify(parsedDataFile));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return parsedDataFile;
}

;
/**
 * @function loadedAllXmlData
 * @description Loads all the context of all files and folders and sub-folders at the specified apth and builds a list of files to load,
 * then loads them accordingly in the D.contextName_fileName.
 * @param {array<string>} filesToLoad The data structure containing all of the files to load data from.
 * @param {string} contextName The context name that should be used when adding data to the D data structure.
 * @return {object} A JSON object that contains all of the data that was loaded and parsed from all the input files list.
 * @author Seth Hollingsead
 * @date 2022/01/27
 */

function loadAllXmlData(filesToLoad, contextName) {
  var functionName = loadAllXmlData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // filesToLoad is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfilesToLoadIs + JSON.stringify(filesToLoad)); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var j = 0;
  var multiMergedData = {};
  var parsedDataFile = {};
  var fileNameRules = [];
  var fileExtensionRules = [];
  var filePathRules = [];
  fileNameRules[0] = biz.cgetFileNameFromPath;
  fileNameRules[1] = biz.cremoveFileExtensionFromFileName;
  filePathRules[0] = biz.cswapDoubleForwardSlashToSingleForwardSlash;
  fileExtensionRules[0] = biz.cgetFileExtension;
  fileExtensionRules[1] = biz.cremoveDotFromFileExtension;

  for (var i = 0; i < filesToLoad.length; i++) {
    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_ithLoop + i);

    var fileToLoad = filesToLoad[i]; // execute busienss rules:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cexecuteBusinessRulesColon + JSON.stringify(filePathRules));

    fileToLoad = _ruleBroker["default"].processRules(fileToLoad, '', filePathRules); // File to load is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cFileToLoadIs + fileToLoad); // NOTE: We still need a filename to use as a cotnext for the page data that we just loaded.
    // A context name will be composed of the input context name with the file name we are processing
    // wich tells us where we wll ptu the data in the D[contextName] sub-structure.


    var fileExtension = _ruleBroker["default"].processRules(fileToLoad, '', fileExtensionRules); // fileExtension is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfileExtensionIs + fileExtension);

    if (fileExtension === gen.cxml || fileExtension === gen.cXml || fileExtension === gen.cXML) {
      // execute business rules:
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cexecuteBusinessRulesColon + JSON.stringify(fileNameRules));

      contextName = contextName + bas.cUnderscore + _ruleBroker["default"].processRules(fileToLoad, '', fileNameRules); // contextName is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

      var dataFile = _fileOperations["default"].getXmlData(fileToLoad); // loaded file data is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cloadedFileDataIs + JSON.stringify(dataFile)); // BEGIN PROCESSING ADDITIONAL DATA


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_PROCESSING_ADDITIONAL_DATA);

      if (j === 0) {
        j++;
        multiMergedData = dataFile;
      } else {
        j++;
        multiMergedData = mergeData(multiMergedData, wr1.cPage, '', dataFile);
      } // DONE PROCESSING ADDITIONAL DATA


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cDONE_PROCESSING_ADDITIONAL_DATA); // MERGED data is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cMERGED_dataIs + JSON.stringify(multiMergedData));

      dataFile = {};
    } // End-if (fileExtension === gen.cxml || fileExtension === gen.cXml || fileExtension === gen.cXML)


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_ithLoop + i);
  } // End-for (let i = 0; i < filesToLoad.length; i++)


  parsedDataFile = {}; // Clear it, so we can re-assign it to the merged locator data or whatever kind of data it is from all files.

  parsedDataFile = processXmlData(multiMergedData, contextName); // parsedDataFile contents are:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cparsedDataFileContentsAre + JSON.stringify(parsedDataFile));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return parsedDataFile;
}

;
/**
 * @function loadAllJsonData
 * @description Loads all the contents of all files and folders and sub-folders at the specified path and builds a list of files to load,
 * then loads them accordingly in the D.contextName.
 * @param {array<string>} filesToLoad The data structure containing all of the files to load data from.
 * @param {string} contextName The context name that should be used when adding data to the D-data structure.
 * @return {object} A JSON object that contains all fo the data that was loaded and parsed from all the input files list.
 * @author Seth Hollingsead
 * @date 2021/10/15
 */

function loadAllJsonData(filesToLoad, contextName) {
  var functionName = loadAllJsonData.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`filesToLoad is: ${JSON.stringify(filesToLoad)}`);
  // console.log(`contextName is: ${contextName}`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // filesToLoad is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfilesToLoadIs + JSON.stringify(filesToLoad)); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var foundSystemData = false;
  var systemConfigFileName = sys.csystemConfigFileName; // 'framework.system.json';

  var applicationConfigFileName = sys.capplicationConfigFileName; // 'application.system.json';

  var multiMergedData = {};
  var parsedDataFile = {}; // Before we load all configuration data we need to FIRST load all the system configuration settings.
  // There will be a system configuration setting that will tell us if we need to load the debug setngs or not.

  for (var i = 0; i < filesToLoad.length; i++) {
    var fileToLoad = filesToLoad[i]; // console.log('fileToLoad is: ' + fileToLoad);

    if (fileToLoad.includes(systemConfigFileName) || fileToLoad.includes(applicationConfigFileName)) {
      var dataFile = preprocessJsonFile(fileToLoad); // NOTE: In this case we have just loaded either the framework configuration data or the application configuration data,
      // and nothing else. So we can just assign the data to the multiMergedData.
      // We will need to merge all the other files,
      // but there will be a setting here we should examin to determine if the rest of the data should even be loadd or not.
      // We will have a new setting that determines if all the extra debug settings should be loaded or not.
      // This way the application performance can be seriously optimized to greater levels of lean performance.
      // Adding all that extra debugging cnfiguration settings can affect load times, and application performance to a much lesser degree.

      multiMergedData[wr1.csystem] = {};
      multiMergedData[wr1.csystem] = dataFile;
      foundSystemData = true;
    }

    if (foundSystemData === true) {
      break;
    }
  } // Now we need to determine if we should load the rest of the data.


  if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cdebugSettings) === true) {
    for (var j = 0; j < filesToLoad.length; j++) {
      var _fileToLoad = filesToLoad[j];

      if (!_fileToLoad.includes(systemConfigFileName) && !_fileToLoad.includes(applicationConfigFileName) && _fileToLoad.toUpperCase().includes(gen.cDotJSON) && !_fileToLoad.toLowerCase().includes(wr1.cmetadata + gen.cDotjson)) {
        var _dataFile = preprocessJsonFile(_fileToLoad); // console.log('dataFile to merge is: ' + JSON.stringify(dataFile));


        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataFileToMergeIs + JSON.stringify(_dataFile));

        if (!multiMergedData[cfg.cdebugSettings]) {
          multiMergedData[cfg.cdebugSettings] = {};
          multiMergedData[cfg.cdebugSettings] = _dataFile;
        } else {
          Object.assign(multiMergedData[cfg.cdebugSettings], _dataFile);
        }
      }
    }
  }

  parsedDataFile = multiMergedData; // console.log(`parsedDataFile is: ${JSON.stringify(parsedDataFile)}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cparsedDataFileIs + JSON.stringify(parsedDataFile));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return parsedDataFile;
}

;
/**
 * @function processCsvData
 * @description Processes all of the CSV data into a usable format and executes any additional processing rules.
 * @param {object} data A JSON object that contains all of the data loaded from a CSV file.
 * @param {string} contextName The name that should be used when adding the objects to the D data structure for data-sharing.
 * @return {object} A parsed and cleaned up JSON object where all of the CSV data is collated and organized and cleaned up ready for use.
 * @author Seth Hollingsead
 * @date 2022/01/27
 */

function processCsvData(data, contextName) {
  var functionName = processCsvData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // input data is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(data)); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var parsedData = extractDataFromPapaParseObject(data, contextName);
  var dataCatagory = getDataCatagoryFromContextName(contextName); // dataCatagory is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataCatagoryIs + dataCatagory);

  var dataCatagoryDetailName;

  if (contextName.includes(wr1.cWorkflow)) {
    // Processing a workflow
    Object.assign(_data["default"][wr1.cWorkflow], parsedData[contextName]);
  } else if (contextName.includes(wr1.ccolors)) {
    _data["default"][wr1.ccolors] = {};
    Object.assign(_data["default"][wr1.ccolors], parsedData);
  } else {
    // Processing all other kinds of files.
    if (typeof _data["default"][dataCatagory] !== 'undefined' && _data["default"][dataCatagory]) {
      Object.assign(_data["default"][dataCatagory], parsedData);
      mergeData(_data["default"], dataCatagory, '', 0, parsedData);
    } else {
      _data["default"][dataCatagory] = {};
      Object.assign(_data["default"][dataCatagory], parsedData);
      mergeData(_data["default"], dataCatagory, '', 0, parsedData);
    }
  } // fully parsed data is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfullyParsedDataIs + JSON.stringify(parsedData)); // D final merge is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cD_finalMergeIs + JSON.stringify(_data["default"]));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return parsedData;
}

;
/**
 * @function processXmlData
 * @description Does some final processing on JSON data loaded from an XML file,
 * converting the data into a usable format and executes any additional data processing rules.
 * @param {object} data A JSON object that contains all of the data loaded from a XML file.
 * @param {string} contextName The name that should be used when adding the objects to the D data structure for data-sharing.
 * @return {object} A parsed and cleaned up JSON object where all of the XML data is collated and organized and cleaned up ready for use.
 * @author Seth Hollingsead
 * @date 2022/02/22
 */

function processXmlData(data, contextName) {
  var functionName = processXmlData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // input data is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(data)); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var dataCatagory = getDataCatagoryFromContextName(contextName); // dataCatagory is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataCatagoryIs + dataCatagory);

  var parsedDataFile = {};

  if (dataCatagory === sys.cCommandsAliases) {
    parsedDataFile[sys.cCommandsAliases] = {};
    parsedDataFile[sys.cCommandsAliases][wr1.cCommands] = {};

    for (var i = 0; i < data[sys.cCommandsAliases][wr1.cCommand].length; i++) {
      var command = data[sys.cCommandsAliases][wr1.cCommand][i][bas.cDollar];
      parsedDataFile[sys.cCommandsAliases][wr1.cCommands][command.Name] = command;
    } // End-for (let i = 0; i < data[sys.cCommandAliases][wr1.cCommand].length; i++)

  } else if (dataCatagory === sys.cCommandWorkflows) {
    // End-if (dataCatagory === sys.cCommandsAliases)
    parsedDataFile[sys.cCommandWorkflows] = {};
    parsedDataFile[sys.cCommandWorkflows][wr1.cWorkflows] = {};

    for (var j = 0; j < data[sys.cCommandWorkflows][wr1.cWorkflow].length; j++) {
      var workflow = data[sys.cCommandWorkflows][wr1.cWorkflow][j][bas.cDollar];
      parsedDataFile[sys.cCommandWorkflows][wr1.cWorkflows][workflow.Name] = workflow;
    } // End-for (let j = 0; j < data[sys.cCommandWorkflows][wr1.cWorkflow].length; j++)

  } // End-else-if (dataCatagory === sys.cCommandWorkflows)
  // parsedDataFile is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cparsedDataFileIs + JSON.stringify(parsedDataFile));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return parsedDataFile;
}

;
/**
 * @function preprocessJsonFile
 * @description Load all of the data from a single JSON data file.
 * @param {string} fileToLoad The fully qualified path to the file that should be loaded.
 * @return {object} The JSON data object that was loaded from the specified JSON data file.
 * @author Seth Hollingsead
 * @date 2021/10/15
 */

function preprocessJsonFile(fileToLoad) {
  var functionName = preprocessJsonFile.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`fileToLoad is: ${JSON.stringify(fileToLoad)}`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfileToLoadIs + JSON.stringify(fileToLoad));

  var filePathRules = [];
  filePathRules[0] = biz.cswapDoubleForwardSlashToSingleForwardSlash; // console.log(`execute business rules: ${JSON.stringify(filePathRules)}`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cexecuteBusinessRules + JSON.stringify(filePathRules));

  var finalFileToLoad = _ruleBroker["default"].processRules(fileToLoad, '', filePathRules);

  var dataFile = _fileOperations["default"].getJsonData(finalFileToLoad);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataFileIs + JSON.stringify(dataFile));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function); // console.log(`dataFile is: ${JSON.stringify(dataFile)}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return dataFile;
}

;
/**
 * @function writeJsonDataToFile
 * @description This is a wrapper function for fileOperations.writeJsonData.
 * @param {string} fileToSaveTo The full path to the file that should have the data written to it.
 * @param {object} dataToWriteOut The JSON data that should be written out to the specified JSON file.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/03/11
 */

function writeJsonDataToFile(fileToSaveTo, dataToWriteOut) {
  var functionName = writeJsonDataToFile.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfileToSaveToIs + fileToSaveTo);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataToWriteOutIs + JSON.stringify(dataToWriteOut));

  _fileOperations["default"].writeJsonData(_path["default"].resolve(fileToSaveTo), dataToWriteOut);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function setupDataStorage
 * @description Does the initial setup of data storage on the D data structure.
 * @return {void} Nothing to return.
 * @author Seth Hollingsead
 * @date 2022/01/20
 */

function setupDataStorage() {
  var functionName = storeData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _data["default"][sys.cDataStorage] = {};

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function storeData
 * @description Stores some data in a data storage hive on the D data structure, under a caller specified sub-data storage hie name.
 * @param {string} dataStorageContextName The sub-data storage hive under-which the data should be stored.
 * @param {string|boolean|integer|float|array|object} dataToStore The data that should be stored, in any format.
 * @return {boolean} A True or False to indicate if the data storage was successful or not.
 * @author Seth Hollingsead
 * @date 2022/01/20
 */

function storeData(dataStorageContextName, dataToStore) {
  var functionName = storeData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // dataStorageContextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataStorageContextNameIs + dataStorageContextName); // data To Store is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataToStoreIs + JSON.stringify(dataToStore));

  var returnData = false;
  _data["default"][sys.cDataStorage][dataStorageContextName] = {};
  _data["default"][sys.cDataStorage][dataStorageContextName] = dataToStore;
  returnData = true;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function getData
 * @description Gets some data from a caller specified sub-data storage hive name.
 * @param {string} dataStorageContextName The sub-data storage hive which should be retrieved.
 * @return {object} the data that is found, if any at the specified location on the data storage hive.
 * @author Seth Hollingsead
 * @date 2022/01/20
 */

function getData(dataStorageContextName) {
  var functionName = storeData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // dataStorageContextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataStorageContextNameIs + dataStorageContextName);

  var returnData = false;

  if (_data["default"][sys.cDataStorage][dataStorageContextName] !== null && !!_data["default"][sys.cDataStorage][dataStorageContextName]) {
    returnData = _data["default"][sys.cDataStorage][dataStorageContextName];
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function clearData
 * @description Clears out all of the data stored in the DataStorage data hive of the D data structure,
 * or a particular stored data element if a contextName is provided.
 * @param {string} dataStorageContextName (OPTIONAL) The sub-data storage hive which should be cleared.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/01/20
 */

function clearData(dataStorageContextName) {
  var functionName = clearData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // dataStorageContextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataStorageContextNameIs + dataStorageContextName);

  if (_data["default"][sys.cDataStorage][dataStorageContextName] !== null && !!_data["default"][sys.cDataStorage][dataStorageContextName] && dataStorageContextName !== '') {
    _data["default"][sys.cDataStorage][dataStorageContextName] = {};
  } else {
    _data["default"][sys.cDataStorage] = {};
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function initializeConstantsValidationData
 * @description Initializes the constants validation data structure.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/03/22
 */

function initializeConstantsValidationData() {
  var functionName = initializeConstantsValidationData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _data["default"][sys.cConstantsValidationData] = {};
  _data["default"][sys.cConstantsValidationData][sys.cConstantsShortNames] = {};
  _data["default"][sys.cConstantsValidationData][sys.cConstantsFileNames] = {};
  _data["default"][sys.cConstantsValidationData][sys.cConstantsPrefix] = {};
  _data["default"][sys.cConstantsValidationData][sys.cConstantsFilePaths] = {};
  _data["default"][sys.cConstantsValidationData][sys.cConstantsPhase1ValidationMessages] = {};
  _data["default"][sys.cConstantsValidationData][sys.cConstantsPhase2ValidationMessages] = {};

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function addConstantsValidationData
 * @description Adds a library of constants vaidation data to the existing constants vaidation data.
 * @param {array<array<string,object>>} constantLibraryData The array of data that should be added to the validation data et for the purpose of validation.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/03/22
 */

function addConstantsValidationData(constantLibraryData) {
  var functionName = addConstantsValidationData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // constantLibraryData is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cconstantLibraryDataIs + JSON.stringify(constantLibraryData));

  for (var key1 in constantLibraryData[sys.cConstantsValidationData]) {
    if (constantLibraryData[sys.cConstantsValidationData].hasOwnProperty(key1)) {
      if (key1 === sys.cConstantsFilePaths || key1 === sys.cConstantsPhase1ValidationMessages || key1 === sys.cConstantsPhase2ValidationMessages || key1 === sys.cConstantsShortNames || key1 === sys.cConstantsFileNames || key1 === sys.cConstantsPrefix) {
        addDeeplyNestedConstantsValidationData(key1, constantLibraryData[sys.cConstantsValidationData][key1]);
      } else {
        var data1 = constantLibraryData[sys.cConstantsValidationData][key1];
        _data["default"][sys.cConstantsValidationData][key1] = [];
        Object.assign(_data["default"][sys.cConstantsValidationData][key1], data1);
      }
    } // End-if (constantLibraryData[sys.cConstantsValidationData].hasOwnProperty(key1))

  } // End-for (let key1 in constantLibraryData[sys.cConstantsValidationData])


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function addDeeplyNestedConstantsValidationData
 * @description Adds all the constants validation auxilary data that is deeply nested inside sub-data structures to the main D-data structure.
 * Such as file paths, and validation messages.
 * @param {string} contextName The name that should be used when accessing and alo adding the data to the D-data structure.
 * @param {array<array<string,object>>} deeplyNestedData The actual data that should be added.
 * @author Seth Hollingsead
 * @date 2022/03/22
 */

function addDeeplyNestedConstantsValidationData(contextName, deeplyNestedData) {
  var functionName = addDeeplyNestedConstantsValidationData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName); // deeplyNestedData is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdeeplyNestedDataIs + JSON.stringify(deeplyNestedData));

  var d_dataStructureConstantsFilePaths = _data["default"][sys.cConstantsValidationData][contextName];

  for (var key2 in deeplyNestedData) {
    if (deeplyNestedData.hasOwnProperty(key2)) {
      var data2 = deeplyNestedData[key2];
      _data["default"][sys.cConstantsValidationData][contextName][key2] = data2;
    }
  } // End-for (let key2 in deeplyNestedData)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function getDataCatagoryFromContextName
 * @description Gets the data catagory, given the context name.
 * @param {string} contextName The context name which will be something like Applicatino_xxxx or Script_nnnn or Command_yyyy
 * @return {string} The string before the first cUnderscore (Application, Script, Command, etc).
 * @author Seth Hollingsead
 * @date 2022/01/27
 */

function getDataCatagoryFromContextName(contextName) {
  var functionName = getDataCatagoryFromContextName.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var rules = [];
  var dataCatagory = '';
  rules[0] = biz.cgetDataCatagoryFromDataContextName; // execute business rules:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cexecuteBusinessRulesColon + JSON.stringify(rules));

  dataCatagory = _ruleBroker["default"].processRules(contextName, '', rules); // dataCatagory is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataCatagoryIs + dataCatagory);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return dataCatagory;
}

;
/**
 * @function getDataCatagoryDtailNameFromContextName
 * @description Gets the data catagory detail name, given the context name.
 * @param {string} contextName The name which will be somethinglike Command_ApiPost or Script_ApiMacroX.
 * @return {string} The string afer the first cUnderscore (ApiPost or ApiMacroX).
 * @author Seth Hollingsead
 * @date 2022/01/27
 */

function getDataCatagoryDetailNameFromContextName(contextName) {
  var functionName = getDataCatagoryFromContextName.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var rules = [];
  var dataCatagoryDetailName = '';
  rules[0] = biz.cgetDataCatagoryDetailNameFromDataContextName; // execute busienss rules:

  _loggers["default"].consoleLog(namesapcePrefix + functionName, msg.cexecuteBusinessRulesColon + JSON.stringify(rules));

  dataCatagoryDetailName = _ruleBroker["default"].processRules(contextName, '', rules); // dataCatagoryDetailsName is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataCatagoryDetailsNameIs + dataCatagoryDetailName);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return dataCatagoryDetailName;
}

;
/**
 * @function extractDataFromPapaParseObject
 * @description Extracts the parsed data from the papa parse data object.
 * @param {object} data Contains the full contents of the papaparse data object, for which we need to get data out of.
 * @param {string} contextName The name of the context either Command, Macro from which data should be retrieved.
 * @return {object} The fully parsed data that we intend to use for the application.
 * @author Seth Hollingsead
 * @date 2022/01/27
 */

function extractDataFromPapaParseObject(data, contextName) {
  var functionName = extractDataFromPapaParseObject.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // input data is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(data)); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var cleanKeysRules = [];
  var tempData = {};
  var validDataAdded = false;

  if (contextName === wr1.ccolors) {
    contextName = sys.cColorData;
  } // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  tempData[contextName] = {};
  cleanKeysRules[0] = biz.ccleanCarriageReturnFromString;
  var highLevelDataCount = Object.keys(data[wr1.cdata]).length;

  for (var i = 0; i <= highLevelDataCount; i++) {
    validDataAdded = false;
    var lowLevelTempData = {};

    if (contextName === sys.cColorData) {
      var colorName = '';

      for (var key in data[wr1.cdata][i]) {
        validDataAdded = true;

        var newKey = _ruleBroker["default"].processRules(key, '', cleanKeysRules);

        if (key === sys.cColorName) {
          colorName = data[wr1.cdata][i][key];
        }

        lowLevelTempData[newKey] = _ruleBroker["default"].processRules(data[wr1.cdata][i][key], '', cleanKeysRules);
      } // End-for (let key in data[wr1.cdata][i])


      if (validDataAdded === true) {
        tempData[contextName][colorName] = {};

        if (i === 0) {
          tempData[contextName][colorName] = lowLevelTempData;
        } else {
          Object.assign(tempData[contextName][colorName], lowLevelTempData);
        }
      } // End-if (validDataAdded === true)

    } else {
      // Else-clause (contextName === sys.cColorData)
      for (var _key in data[wr1.cdata][i]) {
        validDataAdded = true;

        var _newKey = _ruleBroker["default"].processRules(_key, '', cleanKeysRules);

        lowLevelTempData[_newKey] = _ruleBroker["default"].processRules(data[wr1.cdata][i][_key], '', cleanKeysRules);
      } // End-for (let key in data[wr1.cdata][i])


      if (validDataAdded === true) {
        tempData[contextName][i] = {};

        if (i === 0) {
          tempData[contextName][i] = lowLevelTempData;
        } else {
          Object.assign(tempData[contextName][i], lowLevelTempData);
        }
      } // End-if (validDataAdded === true)

    } // End-else

  } // End-for (let i = 0; i <= highLevelDataCount; i++)
  // tempData is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ctempDataIs + JSON.stringify(tempData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return tempData;
}

;
/**
 * @function mergeData
 * @description Merge data with the D data structure for the specified data catagory and optional name.
 * @param {object} targetData The target data object where the dataToMerge should be merged with.
 * @param {string} dataCatagory Command or Script to indicate what catagory the test data should be used as.
 * @param {string} pageName (Optional) The name of the page where the data should be merged under. Pass as empty string if nothing.
 * @param {object} dataToMerge The data to be merged.
 * @return {object} A merged set of data combining all of the original data plus all of the additional data from the dataToMerge data set.
 * @author Seth Hollingsead
 * @date 2022/01/27
 */

function mergeData(targetData, dataCatagory, pageName, dataToMerge) {
  var functionName = mergeData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // targetData is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ctargetDataIs + JSON.stringify(targetData)); // dataCatagory is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataCatagoryIs + dataCatagory); // pageName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpageNameIs + pageName); // data to Merge is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataToMergeIs + JSON.stringify(dataToMerge));

  var dataToMergeElementCount = getDataElementCount(dataToMerge, '', ''); // dataToMergeElementCount is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataToMergeElementCountIs + dataToMergeElementCount);

  if (dataToMergeElementCount === 1) {
    // dataToMergeElementCoutn is 1
    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataToMergeElementCountIs1); // check if the pageName is not an empty string


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccheckIfThePageNameIsNotAnEmptyString);

    if (pageName !== '') {
      // pageName is not an empty string
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpageNameIsNotAnEmptyString); // Check if the dataCatagory is an emptys string or not


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cCheckIfTheDataCatagoryIsAnEmptyStringOrNot);

      if (dataCatagory !== '') {
        // dataCatagory is not an empty string!
        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataCatagoryIsNotAnEmptyString);

        Object.assign(targetData[dataCatagory][pageName], dataToMerge);
      } else {
        // dataCatagory IS an empty sring!
        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataCatagoryIsAnEmptyString); // data to Merge is:


        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataToMergeIs + JSON.stringify(dataToMerge)); // targetData content is:


        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ctargetDataContentIs + JSON.stringify(targetData));

        Object.assign(targetData[pageName], dataToMerge); // after attempt to merge, results are:

        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.caferAttemptToMergeResultsAre); // Merged data is:


        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cMergedDataIs + JSON.stringify(dataToMerge)); // targetData content is:


        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ctargetDataContentIs + JSON.stringify(targetData));
      }
    } else {
      // pageName is an empty string
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpageNameIsAnEmptyString);

      if (targetData[dataCatagory] === undefined) {
        targetData[dataCatagory] = {}; // Make sure to create a landing place for it, before we attempt to dump the data over there.
      } // Otherwise it will just throw an error.


      Object.assign(targetData[dataCatagory], dataToMerge);
    }
  } else {
    // Caught the special case that we are merging a flat list.
    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cCaughtTheSpecialCaseThatWeAreMergingFlatList); // targetData content is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ctargetDataContentIs + JSON.stringify(targetData));

    for (var key in dataToMerge) {
      // inside the for-loop
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinsideTheForLoop); // key is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ckeyIs + key); // pageName is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpageNameIs + pageName);

      targetData[pageName][key] = dataToMerge[key];
    } // End-for (let key in dataToMerge)

  } // target data is modified in the input pass-by-reference variable content is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ctargetDataIsModifiedInTheInputPassByReferenceVariableContentIs + JSON.stringify(targetData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return targetData;
}

;
/**
 * @function getDataElement
 * @description Gets the named value from the data object then cleans it from any carriage return characters.
 * @param {object} dataObject The data object with all data.
 * @param {string} pageName The name of the page where the data should be found.
 * @param {string} elementName The name of the data element that should be found for the given page.
 * @return {string} The data element with all carriage return characters removed from it.
 * @author Seth Hollingsead
 * @date 2022/01/28
 */

function getDataElement(dataObject, pageName, elementName) {
  var functionName = getDataElement.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // dataObject value is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataObjectValueIs + JSON.stringify(dataObject)); // pageName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpageNameIs + pageName); // elementName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.celementNameIs + elementName);

  var returnData = dataObject[pageName][elementName];
  var rules = [];
  rules[0] = biz.ccleanCarriageReturnFromString; // execute business rules:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cexecuteBusinessRulesColon + JSON.stringify(rules));

  returnData = _ruleBroker["default"].processRules(returnData, '', rules);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function getDataElementCount
 * @description Gets the count of the number of elements that match a given patern,
 * if an empty string is passed in for the pattern then the count of the collection is returned with no pattern matching.
 * @param {object} dataObject The data map with all data.
 * @param {string} pageName The name of the page were the data shoudl be found.
 * @param {string} elementNamePattern A string containing a pattern that should be matched in the object collection,
 * to establish a count of elements that match this pattern.
 * @return {integer} A count of either the number of data elements in the object collection,
 * or a count for the number of data elements that match a pattern that is passed in.
 * @author Seth Hollingsead
 * @date 2022/01/28
 */

function getDataElementCount(dataObject, pageName, elementNamePattern) {
  var functionName = getDataElementCount.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // dataObject is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataObjectIs + JSON.stringify(dataObject)); // pageName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpageNameIs + pageName); // elementNamePattern is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.celementNamePatternIs + elementNamePattern);

  var elementCollection;
  var elementCount = 0;

  if (pageName === '') {
    elementCollection = dataObject;
  } else {
    elementCollection = dataObject[pageName];
  }

  if (!elementNamePattern || elementNamePattern === '') {
    elementCount = Object.keys(elementCollection).length;
  } else {
    for (var key in elementCollection) {
      if (elementCollection.hasOwnProperty(key)) {
        if (key.includes(elementNamePattern)) {
          elementCount++;
        }
      } // End-if (elementCollection.hasOwnProperty(key))

    } // End-for (let key in elementCollection)

  } // elementCount is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.celementCountIs + elementCount);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return elementCount;
}

;

var _default = (_fnc$cscanDataPath$fn = {}, _defineProperty(_fnc$cscanDataPath$fn, fnc.cscanDataPath, function (dataPath) {
  return scanDataPath(dataPath);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cfindUniversalDebugConfigSetting, function (appConfigFilesToLoad, frameworkConfigFilesToLoad) {
  return findUniversalDebugConfigSetting(appConfigFilesToLoad, frameworkConfigFilesToLoad);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cloadAllCsvData, function (filesToLoad, contextName) {
  return loadAllCsvData(filesToLoad, contextName);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cloadAllXmlData, function (filesToLoad, contextName) {
  return loadAllXmlData(filesToLoad, contextName);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cloadAllJsonData, function (filesToLoad, contextName) {
  return loadAllJsonData(filesToLoad, contextName);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cprocessCsvData, function (data, contextName) {
  return processCsvData(data, contextName);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cpreprocessJsonFile, function (fileToLoad) {
  return preprocessJsonFile(fileToLoad);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cwriteJsonDataToFile, function (fileToSaveTo, dataToWriteOut) {
  return writeJsonDataToFile(fileToSaveTo, dataToWriteOut);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.csetupDataStorage, function () {
  return setupDataStorage();
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cstoreData, function (dataStorageContextName, dataToStore) {
  return storeData(dataStorageContextName, dataToStore);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cgetData, function (dataStorageContextName) {
  return getData(dataStorageContextName);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cclearData, function (dataStorageContextName) {
  return clearData(dataStorageContextName);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.cinitializeConstantsValidationData, function () {
  return initializeConstantsValidationData();
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.caddConstantsValidationData, function (constantLibraryData) {
  return addConstantsValidationData(constantLibraryData);
}), _defineProperty(_fnc$cscanDataPath$fn, fnc.caddDeeplyNestedConstantsValidationData, function (contextName, deeplyNestedData) {
  return addDeeplyNestedConstantsValidationData(contextName, deeplyNestedData);
}), _fnc$cscanDataPath$fn);

exports["default"] = _default;