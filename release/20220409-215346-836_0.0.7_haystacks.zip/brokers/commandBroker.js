"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _ruleBroker = _interopRequireDefault(require("./ruleBroker.js"));

var _commandsLibrary = _interopRequireDefault(require("../commandsBlob/commandsLibrary.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("../constants/business.constants.js"));

var cfg = _interopRequireWildcard(require("../constants/configuration.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var gen = _interopRequireWildcard(require("../constants/generic.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var num = _interopRequireWildcard(require("../constants/numeric.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _configurator = _interopRequireDefault(require("../executrix/configurator.js"));

var _lexical = _interopRequireDefault(require("../executrix/lexical.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _timers = _interopRequireDefault(require("../executrix/timers.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _stack = _interopRequireDefault(require("../structures/stack.js"));

var _path = _interopRequireDefault(require("path"));

var _fnc$cbootStrapComman;

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // brokers.commandBroker.


var namespacePrefix = wr1.cbrokers + bas.cDot + baseFileName + bas.cDot;
/**
 * @function bootStrapCommands
 * @description Captures all of the commands string-to-function cal map data inthe commandsLibrary and migrates that dat a to the D-data structure.
 * This is important now because we are going to allow the clinet to define their own commands seperate from the system defined commands.
 * So we need a way to merge al the cient defned and system defined commands into one location.
 * Then the command broker will execute commands rom the D-Data structure and not the commands library per-say.
 * This will allow the system to expand much more dynamically and even be user-defined & flexible to client needs.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/02
 */

function bootStrapCommands() {
  var functionName = bootStrapCommands.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _commandsLibrary["default"].initCommandsLibrary();

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function addClientCommands
 * @description Merges client defined commands with the system defined commands.
 * @param {array<object>} clientCommands The client rules that should be merged with the system rules.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/02
 */

function addClientCommands(clientCommands) {
  var functionName = addClientCommands.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // Object.assign(D[wr1.cCommands], clientCommands);
  // D[wr1.cCommands] = {...D[wr1.cCommands], Object.keys(clientCommands): clientCommands[Object.keys(clientCommands)]};


  for (var _i = 0, _Object$entries = Object.entries(clientCommands); _i < _Object$entries.length; _i++) {
    var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
        key = _Object$entries$_i[0],
        value = _Object$entries$_i[1];

    // console.log('%%%%%%%%%%%%%%%%%% ---- >>>>>>>>> key is: ' + key);
    _data["default"][wr1.cCommands] = _objectSpread(_objectSpread({}, _data["default"][wr1.cCommands]), {}, _defineProperty({}, "".concat(key), value));
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function getValidCommand
 * @description Parses the command string and returns an array that can be used to
 * enqueue or execute that command. Useful for determining if a command is a valid command and
 * working with multiple levels of delimiters for nested command calls, looking up a command alias, etc...
 * @param {string} commandString The command string that should be parsed for a valid command.
 * @param {string} commandDelimiter The delimiter that should be used to parse the command line.
 * @return {boolean|string} False if the command is not valid, otherwise it returns the command string.
 * @author Seth Hollingsead
 * @date 2022/02/02
 */

function getValidCommand(commandString, commandDelimiter) {
  var functionName = getValidCommand.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // cmmandString is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringIs + commandString); // commandDelimiter is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandDelimiterIs + commandDelimiter);

  var returnData = false;
  var foundValidCommand = false;
  var foundSomeCommandArgs = false;
  var commandToExecute, commandArgs;
  var commandArgsDelimiter = commandDelimiter;

  if (commandDelimiter === null || commandDelimiter !== commandDelimiter || commandDelimiter === undefined) {
    commandArgsDelimiter = bas.cSpace;
  }

  if (commandString && commandString.includes(commandArgsDelimiter) === true) {
    foundSomeCommandArgs = true;
    commandArgs = commandString.split(commandArgsDelimiter);
    commandToExecute = commandArgs[0];
  } else {
    commandToExecute = commandString;
  } // commandString is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringIs + commandString); // commandToExecute is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandToExecuteIs + commandToExecute);

  if (commandString) {
    if (_data["default"][wr1.cCommands][commandToExecute] !== undefined) {
      foundValidCommand = true;
      returnData = commandToExecute;
    } else {
      // else-clause if (D[wr1.cCommands][commandToExecute] !== undefined)
      // else-clause looking for command aliases.
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.celseClauseLookingForCommandAliases); // NOTE: It could be that the user entered a command alias, so we will need to search through all of the command aliases,
      // to see if we can find a match, then get the actual command that should be executed.


      var allCommandAliases = _data["default"][sys.cCommandsAliases][wr1.cCommands]; // allCommandAliases is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.callCommandAliasesIs + JSON.stringify(allCommandAliases));

      loop1: for (var _i2 = 0, _Object$entries2 = Object.entries(allCommandAliases); _i2 < _Object$entries2.length; _i2++) {
        var _Object$entries2$_i = _slicedToArray(_Object$entries2[_i2], 2),
            key = _Object$entries2$_i[0],
            value = _Object$entries2$_i[1];

        // Iterate through all of the command aliases and see if we can find a
        // command alias that matches the command the user is trying to execute.
        var currentCommand = value;

        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccurrentCommandIs + JSON.stringify(currentCommand));

        var aliasList = currentCommand[wr1.cAliases];
        var arrayOfAliases = aliasList.split(bas.cComa);

        loop2: for (var j = 0; j < arrayOfAliases.length; j++) {
          var currentAlias = arrayOfAliases[j];

          if (commandToExecute === currentAlias || commandToExecute === bas.cDash + currentAlias || commandToExecute === bas.cDoubleDash + currentAlias || commandToExecute === bas.cForwardSlash + currentAlias || commandToExecute === bas.cBackSlash + currentAlias || commandToExecute.toUpperCase() === currentAlias.toUpperCase() || commandToExecute.toUpperCase() === bas.cDash + currentAlias.toUpperCase() || commandToExecute.toUpperCase() === bas.cDoubleDash + currentAlias.toUpperCase() || commandToExecute.toUpperCase() === bas.cForwardSlash + currentAlias.toUpperCase() || commandToExecute.toUpperCase() === bas.cBackSlash + currentAlias.toUpperCase() || commandToExecute.toLowerCase() === currentAlias.toLowerCase() || commandToExecute.toLowerCase() === bas.cDash + currentAlias.toLowerCase() || commandToExecute.toLowerCase() === bas.cdoubleDash + currentAlias.toLowerCase() || commandToExecute.toLowerCase() === bas.cForwardSlash + currentAlias.toLowerCase() || commandToExecute.toLowerCase() === bas.cBackSlash + currentAlias.toLowerCase()) {
            foundValidCommand = true; // commandToExecute before the Alias is:

            _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandToExecuteBeforeTheAliasIs + commandToExecute);

            commandToExecute = currentCommand[wr1.cName]; // commandToExecute after the Alias is:

            _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandToExecuteAfterTheAliasIs + commandToExecute);

            break loop1;
          }
        } // End-for (let j = 0; j < arrayOfAliases.length; j++)

      } // End-for (let i = 0; i < allCmmandAliases.length; i++)


      if (foundValidCommand === true) {
        if (_data["default"][wr1.cCommands][commandToExecute] !== undefined) {
          returnData = commandToExecute;
        } else {
          // WARNING: The specified command:
          // does not exist, please try again!
          console.log(msg.cWarningTheSpecifiedCommand + commandToExecute + msg.cdoesNotExistPleaseTryAgain + bas.cSpace + num.c1);
        }
      } else {
        // WARNING: The specified command:
        // does not exist, please try again!
        console.log(msg.cWarningTheSpecifiedCommand + commandToExecute + msg.cdoesNotExistPleaseTryAgain + bas.cSpace + num.c2);
      }
    } // End-else

  } else {
    // Looks like the user entered something undefined: Pop the standard error message:
    // WARNING: The specified command:
    // does not exist, please try again!
    console.log(msg.cWarningTheSpecifiedCommand + commandToExecute + msg.cdoesNotExistPleaseTryAgain);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + JSON.stringify(returnData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function getCommandArgs
 * @description Gets the arguments of the current command.
 * @param {string} commandString The command string that should be parsed fro command argumnts.
 * @param {string} commandDelimiter The delimiter that should be used to parse the command line.
 * @return {array<boolean|string|integer>} Any array of arguments, some times these might actually be nested command calls.
 * @author Seth Hollingsead
 * @date 2022/02/02
 */

function getCommandArgs(commandString, commandDelimiter) {
  var functionName = getCommandArgs.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // cmmandString is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringIs + commandString); // commandDelimiter is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandDelimiterIs + commandDelimiter);

  var returnData = false;
  var foundValidCommand = false;
  var commandArgsDelimiter = commandDelimiter;
  var isOddRule = [];
  var replaceCharacterAtIndexRule = [];
  var replaceTildesWithSingleQuoteRule = [];
  var stringLiteralCommandDelimiterAdded = false;
  isOddRule[0] = biz.cisOdd;
  replaceCharacterAtIndexRule[0] = biz.creplaceCharacterAtIndex;
  replaceTildesWithSingleQuoteRule[0] = biz.creplaceCharacterWithCharacter;

  var secondaryCommandArgsDelimiter = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cSecondaryCommandDelimiter);

  if (commandDelimiter === null || commandDelimiter !== commandDelimiter || commandDelimiter === undefined) {
    commandArgsDelimiter = bas.cSpace;
  }

  if (commandString.includes(commandArgsDelimiter) === true) {
    // NOTE: All commands that enqueue or execute commands need to pass through this function.
    // There is a case where the user might pass a string with spaces or other code/syntax.
    // So we need to split first by single character string delimiters and parse the
    // non-string array elements to parse command arguments without accidently parsing string literal values as command arguments.
    if (commandString.includes(bas.cBackTickQuote) === true) {
      // commandString contains either a singleQuote or a backTickQuote
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringContainsEitherSingleQuoteOrBackTickQuote);

      var preSplitCommandString;

      if (commandString.includes(bas.cBackTickQuote) === true) {
        // commandString contaisn a singleQuote!
        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringContainsSingleQuote); // NOTE: We cannot actually just replace ach single quote, we need to tag each single quote in pairs of 2.
        // The first one should be post-tagged, i.e. replace "'" with "'~" and the second should be pre-tagged i.e. replace "'" with "~'".
        // Then if there are more single quotes, the thirst post-tagged, i.e. replace "'" with "'~", etc...


        var numberOfSingleQuotes = commandString.split(bas.cBackTickQuote).length - 1; // Determine if the number of single quotes is odd or even?
        // About to call the rule broker to process on the number of single quotes and determien if it-be even or odd.

        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cgetCommandArgsMessage1 + sys.cgetCommandArgsMessage2);

        if (numberOfSingleQuotes >= 2 && _ruleBroker["default"].processRules(numberOfSingleQuotes, '', isOddRule) === false) {
          // numberOfSingleQuotes is >= 2 & the numberOfSingleQuotes is EVEN! YAY!
          _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cnumberOfSingleQuotesIsEven);

          var indexOfStringDelimiter;

          for (var i = 0; i < numberOfSingleQuotes; i++) {
            // Iterate over each one and if they are even or odd we will change how we replace ach single quote character as described above.
            if (i === 0) {
              // Get the index of the first string delimiter.
              indexOfStringDelimiter = commandString.indexOf(bas.cBackTickQuote, 0); // First index is:

              _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cFirstIndexIs + indexOfStringDelimiter); // commandString.replace(bas.cBackTickQuote, bas.cBackTickQuote + bas.cTilde);
              // Rather than use the above, we will make a business rule o replace at index, the above replaces all isntances and we don't want that!


              commandString = _ruleBroker["default"].processRules(commandString, [indexOfStringDelimiter, bas.cBackTickQuote + bas.cTilde], replaceCharacterAtIndexRule);
              stringLiteralCommandDelimiterAdded = true; // commandString after taggng the first string delimiter:

              _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringAfterTaggingTheFirstStringDelimiter + commandString);
            } else {
              indexOfStringDelimiter = commandString.indexOf(bas.cBackTickQuote, indexOfStringDelimiter + 1); // Additional index is:

              _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cAdditionalIndexIs + indexOfStringDelimiter); // Determine if it is odd or even.
              // NOTE: We start our count with 0 which would technically be our odd, then 1 should be even, but 1 is an odd number, so the logic here should actually be backwards.
              // an even value for "i" would be the odd i-th delimier value.


              if (_ruleBroker["default"].processRules(i.toString(), '', isOddRule) === true) {
                // We are on the odd index, 1, 3, 5, etc...
                // odd index
                _loggers["default"].consoleLog(namespacePrefix + functionName, msg.coddIndex);

                commandString = _ruleBroker["default"].processRules(commandString, [indexOfStringDelimiter, bas.cTilde + bas.cBackTickQuote], replaceCharacterAtIndexRule);
                stringLiteralCommandDelimiterAdded = true; // commandString after tagging an odd string delimiter:

                _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringAfterTaggingAnOddStringDelimiter + commandString);
              } else {
                // We are on the even index 2, 4, 6, etc...
                // even index
                _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cevenIndex);

                commandString = _ruleBroker["default"].processRules(commandString, [indexOfStringDelimiter, bas.cBackTickQuote + bas.cTilde], replaceCharacterAtIndexRule);
                stringLiteralCommandDelimiterAdded = true; // commandString after tagging an even string delimiter:

                _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringAfterTaggingAnEvenStringDelimiter + commandString);
              }
            }
          } // End-for (let i = 0; i < numberOfSingleQuotes; i++)


          preSplitCommandString = commandString.split(bas.cBackTickQuote); // Now we can check which segments of the array contain our Tilde character, since we used that to tag our signle quotes.
          // And the array element that contains the Tilde tag we wil not split.
          // Ultimately everything needs to be returned as an array, make sure we trim the array elements so we don't get any empty array elements.
          // preSpitCommandString is:

          _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpreSplitCommandStringIs + JSON.stringify(preSplitCommandString));

          for (var j = 0; j < preSplitCommandString.length; j++) {
            var preSplitCommandStringElement = preSplitCommandString[j];
            preSplitCommandStringElement = preSplitCommandStringElement.trim(); // Make sure to get rid of any white space on the ends of the string.

            var postSplitCommandString = void 0;

            if (j === 0) {
              // Make sure we re-initialize our return value to an array, since it was set first to a boolean value.
              returnData = [];
            }

            if (preSplitCommandStringElement.includes(bas.cTilde) === false) {
              postSplitCommandString = preSplitCommandStringElement.split(commandArgsDelimiter);

              for (var k = 0; k < postSplitCommandString.length; k++) {
                if (postSplitCommandString[k] !== '') {
                  // postSplitCommandString[k] is:
                  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpostSplitCommandStringIs + JSON.stringify(postSplitCommandString[k]));

                  returnData.push(postSplitCommandString[k]);

                  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + JSON.stringify(returnData));
                } // End-if (postSplitCommandString[k] !== '')

              } // End-for (let k = 0; k < postSplitCommandString.length; k++)


              postSplitCommandString = []; // Clear it for the next time around the loop.
            } else {
              // NOTE: We cannot just push the quoted string array back onto the array. Well we might be able to,
              // but if the last character on the last element of the returnData array is a secondaryCommandArgsDelimiter
              // then we need to just append our string to that array element, after we remove the tilde string tags,
              // and replace them with our signle quotes again.
              if (returnData[returnData.length - 1].slice(-1) === secondaryCommandArgsDelimiter) {
                preSplitCommandStringElement = _ruleBroker["default"].processRules(preSpitCommandStringElement, [/~/g, bas.cBackTickQuote], replaceTildesWithSingleQuoteRule);
                returnData[returnData.length - 1] = returnData[returnData.length - 1] + preSplitCommandStringElement;
              } else {
                // preSplitCommandSringElement is:
                _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpreSplitCommandStringElementIs + JSON.stringify(preSplitCommandStringElement));

                returnData.push(preSplitCommandStringElement); // Add the string now.
              }

              _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + JSON.stringify(returnData));
            }
          } // End-for (let j = 0; j < preSplitCommandString.length; j++)

        } // End-if (numberOfSingleQuotes >= 2 && ruleBroker.processRules(numberOfSingleQuotes, '', isOddRule) === false)

      } // End-if (commandString.includes(bas.cBackTickQuote) === true)
      // We might need much additional logic to manage the case that the string contains multiple levels of commands with strings....in that case:
      // The command system will probably need to implement a re-assignment of the string delimiter, also using the bas.cBackTickQuote.
      // I have started to lay out some of that logic above, but we are FAR from it, and there isn't any business need for it right now.
      // So I will handle that case if & when I come to it.

    } else {
      // Doing a straight split of the commandString:
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cDoingStraightSplitCommandString + commandString);

      returnData = commandString.split(commandArgsDelimiter);

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + JSON.stringify(returnData));
    }
  } // End-if (commandString.includes(commandArgsDelimiter) === true)


  if (stringLiteralCommandDelimiterAdded === true) {
    // This means we need to remove some bas.cTilde from one or more of the command args.
    _lexical["default"].removeStringLiteralTagsFromArray(returnData);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + JSON.stringify(returnData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function executeCommand
 * @description Takes a command string with all its associated arguments, data & meta-data.
 * This function will parse all of that out of the command lien variable that is passed in.
 * And finally pass all of that data on the execution of the actual command.
 * @param {string} commandString The command to execute along with all the associated command arguments, data & meta-data.
 * @return {boolean} A True or False value to indicate if the application should exit or not exit.
 * @author Seth Hollingsead
 * @date 2022/02/02
 */

function executeCommand(commandString) {
  // Here we need to do all of the parsing for the command.
  // Might be a good idea to rely on busness rules to do much of the parsing for us!
  // Also don't forget this is where we will need to implement the command performance
  // trackng & command results processing such as pass-fail,
  // so that when a chain of commands has completed execution we can evaluate command statistics and metrics.
  var functionName = executeCommand.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // commandString is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringIs + commandString);

  var returnData = false;
  var commandToExecute = getValidCommand(commandString, _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cprimaryCommandDelimiter)); // commandToExecute is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandToExecuteIs + commandToExecute);

  var commandArgs = getCommandArgs(commandString, _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cprimaryCommandDelimiter)); // commandArgs is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandArgsIs + commandArgs);

  var commandMetricsEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableCommandPerformanceMetrics);

  var commandStartTime = '';
  var commandEndTime = '';
  var commandDeltaTime = '';

  if (commandMetricsEnabled === true) {
    // Here we will capture the start time of the command we are about to execute.
    // After executing we wil capture the end time and then
    // compute the difference to determine how many milliseconds it took to run the command.
    commandStartTime = _timers["default"].getNowMoment(gen.cYYYYMMDD_HHmmss_SSS); // Cmmand Start time is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cCommandStartTimeIs + commandStartTime);
  } // End-if (commandMetricsEnabled === true)


  if (commandToExecute !== false && commandArgs !== false) {
    // console.log('commandToExecute is: ' + commandToExecute);
    returnData = _data["default"][wr1.cCommands][commandToExecute](commandArgs, '');
  } else if (commandToExecute !== false && commandArgs === false) {
    // This could be a command without any arguments.
    returnData = _data["default"][wr1.cCommands][commandToExecute]('', '');
  } else {
    // This command does not exist, nothing to execute, but we don't want the application to exit.
    // An error message should have already been thrown, but we should throw another one here.
    // WARNING: Command does not exist, please enter a valid command and try again!
    console.log(msg.cexecuteCommandMessage1);
    returnData = true;
  }

  if (commandMetricsEnabled === true && commandToExecute !== '' && commandToExecute !== false) {
    var performanceTrackingObject = {};
    commandEndTime = _timers["default"].getNowMoment(gen.cYYYYMMDD_HHmmss_SSS); // Command End time is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cCommandEndTimeIs + commandEndTime); // Now compute the delta tme so we know how long it took to run that command.


    commandDeltaTime = _timers["default"].computeDeltaTime(commandStartTime, commandEndTime); // Command run-time is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cCommandRunTimeIs + commandDeltaTime); // Check to make sure the command performance tracking stack exists or does not exist.


    if (_data["default"][cfg.ccommandsPerformanceTrackingStack] === undefined) {
      _stack["default"].initStack(cfg.ccommandsPerformanceTrackingStack);
    }

    if (_data["default"][cfg.ccommandNamesPerformanceTrackingStack] === undefined) {
      _stack["default"].initStack(cfg.ccommandNamesPerformanceTrackingStack);
    }

    performanceTrackingObject = {
      Name: commandToExecute,
      RunTime: commandDeltaTime
    };

    if (_stack["default"].contains(cfg.ccommandNamesPerformanceTrackingStack, commandToExecute) === false) {
      _stack["default"].push(cfg.ccommandNamesPerformanceTrackingStack, commandToExecute);
    }

    _stack["default"].push(cfg.ccommandsPerformanceTrackingStack, performanceTrackingObject); // stack.print(cfg.ccommandNamesPerformanceTrackingStack);
    // stack.print(cfg.ccommandsPerformanceTrackingStack);

  } // End-if (commandMetricsEnabled === true && commandToExecute !== '' && commandToExecute !== false)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + JSON.stringify(returnData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;

var _default = (_fnc$cbootStrapComman = {}, _defineProperty(_fnc$cbootStrapComman, fnc.cbootStrapCommands, function () {
  return bootStrapCommands();
}), _defineProperty(_fnc$cbootStrapComman, fnc.caddClientCommands, function (clientCommands) {
  return addClientCommands(clientCommands);
}), _defineProperty(_fnc$cbootStrapComman, fnc.cgetValidCommand, function (commandString, commandDelimiter) {
  return getValidCommand(commandString, commandDelimiter);
}), _defineProperty(_fnc$cbootStrapComman, fnc.cgetCommandArgs, function (commandString, commandDelimiter) {
  return getCommandArgs(commandString, commandDelimiter);
}), _defineProperty(_fnc$cbootStrapComman, fnc.cexecuteCommand, function (commandString) {
  return executeCommand(commandString);
}), _fnc$cbootStrapComman);

exports["default"] = _default;