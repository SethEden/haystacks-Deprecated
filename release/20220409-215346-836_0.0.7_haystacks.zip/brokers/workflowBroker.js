"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _path = _interopRequireDefault(require("path"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // brokers.workflowBroker.


var namespacePrefix = wr1.cbrokers + bas.cDot + baseFileName + bas.cDot;
/**
 * @function getWorkflow
 * @description Given the name of the workflow that is being requested,
 * get that workflow from the D-data structure workflows data hive.
 * @param {string} workflowName The name of the workflow we should get workflow data for.
 * @return {string|boolean} The workflow value, which ideally would be a list of commands and command parameters.
 * False if no workflow by the specified name was found.
 * @author Seth Hollingsead
 * @date 2022/02/04
 */

function getWorkflow(workflowName) {
  var functionName = getWorkflow.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // workflowName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cworkflowNameIs + workflowName);

  var workflowValue = false;
  var arrayOfWorkflows = _data["default"][sys.cCommandWorkflows][wr1.cWorkflows]; // Code to print all the workflows for debugging.
  // console.log('arrayOfWorkflows is: ' + JSON.stringify(arrayOfWorkflows));
  // for (let i = 0; i < arrayOfWorkflows.length; i++) {
  //   let currentWorkflow = arrayOfWorkflows[i];
  //   // currentWorkflow is:
  //   loggers.consoleLog(namespacePrefix + functionName, msg.ccurrentWorkflowIs + JSON.stringify(currentWorkflow));
  //   if (currentWorkflow[wr1.cName] === workflowName) {
  //     workflowValue = currentWorkflow[wr1.cValue];
  //     // workflowValue is:
  //     loggers.consoleLog(namespacePrefix + functionName, msg.cwokflowValueIs + JSON.stringify(workflowValue));
  //     break;
  //   } // End-if (currentWorkflow[wr1.cName] === workflowName)
  // } // End-for (let i = 0; i < arrayOfWorkflows.length; i++)

  if (arrayOfWorkflows[workflowName] !== undefined) {
    var currentWorkflow = arrayOfWorkflows[workflowName];

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccurrentWorkflowIs + JSON.stringify(currentWorkflow));

    if (currentWorkflow[wr1.cName] === workflowName) {
      workflowValue = currentWorkflow[wr1.cValue]; // workflowValue is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cwokflowValueIs + JSON.stringify(workflowValue));
    }
  } // workflowValue is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cworkflowValueIs + workflowValue);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return workflowValue;
}

;

var _default = _defineProperty({}, fnc.cgetWorkflow, function (workflowName) {
  return getWorkflow(workflowName);
});

exports["default"] = _default;