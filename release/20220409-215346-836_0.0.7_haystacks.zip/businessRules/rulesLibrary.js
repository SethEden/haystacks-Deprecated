"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _arrayParsing = _interopRequireDefault(require("./rules/arrayParsing.js"));

var _characterGeneration = _interopRequireDefault(require("./rules/characterGeneration.js"));

var _mathOperations = _interopRequireDefault(require("./rules/mathOperations.js"));

var _stringGeneration = _interopRequireDefault(require("./rules/stringGeneration.js"));

var _stringParsing = _interopRequireDefault(require("./rules/stringParsing.js"));

var _stringParsingUtilities = _interopRequireDefault(require("./rules/stringParsingUtilities.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("../constants/business.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _path = _interopRequireDefault(require("path"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // businessRules.rulesLibrary.


var namespacePrefix = sys.cbusinessRules + bas.cDot + baseFileName + bas.cDot;
/**
 * @function initRulesLibrary
 * @description Initializes the business rules function data structure on D.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/10/27
 * @NOTE Please be aware that the Commands and BusinessRules data fields in the
 * D-data structure are going to display as empty when printing out the D-data structure even when using JSON.stringify().
 * This is because the functions cannot really be serialized in any way. It actually kind of makes sense,
 * but could be really confusing if you are struggling, trying to debug commands or business rules that do not appear to exist.
 */

function initRulesLibrary() {
  var _D$sys$cbusinessRules;

  var functionName = initRulesLibrary.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);

  _data["default"][sys.cbusinessRules] = {};
  _data["default"][sys.cbusinessRules] = (_D$sys$cbusinessRules = {}, _defineProperty(_D$sys$cbusinessRules, biz.cecho, function (inputData, inputMetaData) {
    return console.log(JSON.stringify(inputData));
  }), _defineProperty(_D$sys$cbusinessRules, biz.creplaceCharacterWithCharacter, function (inputData, inputMetaData) {
    return _arrayParsing["default"].replaceCharacterWithCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cconvertCamelCaseStringToArray, function (inputData, inputMetaData) {
    return _arrayParsing["default"].convertCamelCaseStringToArray(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetWordsArrayFromString, function (inputData, inputMetaData) {
    return _arrayParsing["default"].getWordsArrayFromString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crecombineStringArrayWithSpaces, function (inputData, inputMetaData) {
    return _arrayParsing["default"].recombineStringArrayWithSpaces(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cconvertArrayToCamelCaseString, function (inputData, inputMetaData) {
    return _arrayParsing["default"].convertArrayToCamelCaseString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdoesArrayContainLowerCaseConsolidatedString, function (inputData, inputMetaData) {
    return _arrayParsing["default"].doesArrayContainLowerCaseConsolidatedString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdoesArrayContainCharacter, function (inputData, inputMetaData) {
    return _arrayParsing["default"].doesArrayContainCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cremoveCharacterFromArray, function (inputData, inputMetaData) {
    return _arrayParsing["default"].removeCharacterFromArray(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cascertainMatchingElements, function (inputData, inputMetaData) {
    return _arrayParsing["default"].ascertainMatchingElements(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdoesArrayContainFilename, function (inputData, inputMetaData) {
    return _arrayParsing["default"].doesArrayContainFilename(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.creadDirectoryContents, function (inputData, inputMetaData) {
    return _arrayParsing["default"].readDirectoryContents(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetLengthOfLongestStringInArray, function (inputData, inputMetaData) {
    return _arrayParsing["default"].getLengthOfLongestStringInArray(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.csearchForPatternsInStringArray, function (inputData, inputMetaData) {
    return _arrayParsing["default"].searchForPatternsInStringArray(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cvalidatePatternsThatNeedImplementation, function (inputData, inputMetaData) {
    return _arrayParsing["default"].validatePatternsThatNeedImplementation(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.csolveLehmerCode, function (inputData, inputMetaData) {
    return _arrayParsing["default"].solveLehmerCode(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crecursiveArrayExpansion, function (inputData, inputMetaData) {
    return _arrayParsing["default"].recursiveArrayExpansion(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetLehmerCodeValue, function (inputData, inputMetaData) {
    return _arrayParsing["default"].getLehmerCodeValue(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.carraysAreEqual, function (inputData, inputMetaData) {
    return _arrayParsing["default"].arraysAreEqual(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cstoreData, function (inputData, inputMetaData) {
    return _arrayParsing["default"].storeData(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetStoredData, function (inputData, inputMetaData) {
    return _arrayParsing["default"].getStoredData(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisObjectEmpty, function (inputData, inputMetaData) {
    return _arrayParsing["default"].isObjectEmpty(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisArrayEmpty, function (inputData, inputMetaData) {
    return _arrayParsing["default"].isArrayEmpty(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisObject, function (inputData, inputMetaData) {
    return _arrayParsing["default"].isObject(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisArray, function (inputData, inputMetaData) {
    return _arrayParsing["default"].isArray(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisArrayOrObject, function (inputData, inputMetaData) {
    return _arrayParsing["default"].isArrayOrObject(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisNonZeroLengthArray, function (inputData, inputMetaData) {
    return _arrayParsing["default"].isNonZeroLengthArray(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.carrayDeepClone, function (inputData, inputMetaData) {
    return _arrayParsing["default"].arrayDeepClone(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.creplaceCharacterAtIndex, function (inputData, inputMetaData) {
    return _arrayParsing["default"].replaceCharacterAtIndex(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateCommandAliases, function (inputData, inputMetaData) {
    return _arrayParsing["default"].generateCommandAliases(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.caggregateCommandArguments, function (inputData, inputMetaData) {
    return _arrayParsing["default"].aggregateCommandArguments(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetFileAndPathListForPath, function (inputData, inputMetaData) {
    return _arrayParsing["default"].getFileAndPathListForPath(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cparseColorRangeInputs, function (inputData, inputMetaData) {
    return _arrayParsing["default"].parseColorRangeInputs(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateMixedCaseLetterOrSpecialCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateMixedCaseLetterOrSpecialCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateUpperCaseLetterOrSpecialCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateUpperCaseLetterOrSpecialCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateLowerCaseLetterOrSpecialCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateLowerCaseLetterOrSpecialCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateMixedCaseAlphaNumericCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateMixedCaseAlphaNumericCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateUpperCaseAlphaNumericCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateUpperCaseAlphaNumericCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateLowerCaseAlphaNumericCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateLowerCaseAlphaNumericCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateNumericCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateNumericCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateSpecialCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateSpecialCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateNumberInRange, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateNumberInRange(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateBooleanValue, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateBooleanValue(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateMixedCaseAlphabeticCharacter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateMixedCaseAlphabeticCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateLowerCaseLetter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateLowerCaseLetter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.crandomlyGenerateUpperCaseLetter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].randomlyGenerateUpperCaseLetter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cconvertNumberToUpperCaseLetter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].convertNumberToUpperCaseLetter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cconvertNumberToLowerCaseLetter, function (inputData, inputMetaData) {
    return _characterGeneration["default"].convertNumberToLowerCaseLetter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.chex2rgbConversion, function (inputData, inputMetaData) {
    return _mathOperations["default"].hex2rgbConversion(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisOdd, function (inputData, inputMetaData) {
    return _mathOperations["default"].isOdd(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisEven, function (inputData, inputMetaData) {
    return _mathOperations["default"].isEven(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomMixedCaseTextByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomMixedCaseTextByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomUpperCaseTextByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomUpperCaseTextByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomLowerCaseTextByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomLowerCaseTextByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomMixedCaseTextWithSpecialCharactersByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomMixedCaseTextWithSpecialCharactersByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomUpperCaseTextWithSpecialCharactersByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomUpperCaseTextWithSpecialCharactersByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomLowerCaseTextWithSpecialCharactersByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomLowerCaseTextWithSpecialCharactersByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomMixedCaseAlphaNumericCodeByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomMixedCaseAlphaNumericCodeByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomUpperCaseAlphaNumericCodeByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomUpperCaseAlphaNumericCodeByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomLowerCaseAlphaNumericCodeByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomLowerCaseAlphaNumericCodeByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomNumericCodeByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomNumericCodeByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomMixedCaseAlphaNumericCodeWithSpecialCharactersByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomMixedCaseAlphaNumericCodeWithSpecialCharactersByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomUpperCaseAlphaNumericCodeWithSpecialCharactersByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomUpperCaseAlphaNumericCodeWithSpecialCharactersByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomLowerCaseAlphaNumericCodeWithSpecialCharactersByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomLowerCaseAlphaNumericCodeWithSpecialCharactersByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomSpecialCharacterCodeByLength, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomSpecialCharacterCodeByLength(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateValidEmail, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateValidEmail(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateInvalidEmail, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateInvalidEmail(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomBrightColor, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomBrightColor(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomDarkColor, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomDarkColor(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgenerateRandomColor, function (inputData, inputMetaData) {
    return _stringGeneration["default"].generateRandomColor(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.csingleQuoteSwapAfterEquals, function (inputData, inputMetaData) {
    return _stringParsing["default"].singleQuoteSwapAfterEquals(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cswapForwardSlashToBackSlash, function (inputData, inputMetaData) {
    return _stringParsing["default"].swapForwardSlashToBackSlash(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cswapBackSlashToForwardSlash, function (inputData, inputMetaData) {
    return _stringParsing["default"].swapBackSlashToForwardSlash(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cswapDoubleForwardSlashToSingleForwardSlash, function (inputData, inputMetaData) {
    return _stringParsing["default"].swapDoubleForwardSlashToSingleForwardSlash(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cswapDoubleBackSlashToSingleBackSlash, function (inputData, inputMetaData) {
    return _stringParsing["default"].swapDoubleBackSlashToSingleBackSlash(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetUserNameFromEmail, function (inputData, inputMetaData) {
    return _stringParsing["default"].getUserNameFromEmail(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.creplaceSpacesWithPlus, function (inputData, inputMetaData) {
    return _stringParsing["default"].replaceSpacesWithPlus(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.creplaceColonWithUnderscore, function (inputData, inputMetaData) {
    return _stringParsing["default"].replaceColonWithUnderscore(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.ccleanCarriageReturnFromString, function (inputData, inputMetaData) {
    return _stringParsing["default"].cleanCarriageReturnFromString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cconvertStringToLowerCase, function (inputData, inputMetaData) {
    return _stringParsing["default"].convertStringToLowerCase(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cconvertStringToUpperCase, function (inputData, inputMetaData) {
    return _stringParsing["default"].convertStringToUpperCase(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetFileNameFromPath, function (inputData, inputMetaData) {
    return _stringParsing["default"].getFileNameFromPath(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetFileExtension, function (inputData, inputMetaData) {
    return _stringParsing["default"].getFileExtension(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cremoveDotFromFileExtension, function (inputData, inputMetaData) {
    return _stringParsing["default"].removeDotFromFileExtension(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cremoveFileExtensionFromFileName, function (inputData, inputMetaData) {
    return _stringParsing["default"].removeFileExtensionFromFileName(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetValueFromAssignmentOperationString, function (inputData, inputMetaData) {
    return _stringParsing["default"].getValueFromAssignmentOperationString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.caggregateNumericalDifferenceBetweenTwoStrings, function (inputData, inputMetaData) {
    return _stringParsing["default"].aggregateNumericalDifferenceBetweenTwoStrings(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.ccountCamelCaseWords, function (inputData, inputMetaData) {
    return _stringParsing["default"].countCamelCaseWords(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdoesStringContainAcronym, function (inputData, inputMetaData) {
    return _stringParsing["default"].doesStringContainAcronym(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.ccountDelimiterInString, function (inputData, inputMetaData) {
    return _stringParsing["default"].countDelimiterInString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdetermineWordDelimiter, function (inputData, inputMetaData) {
    return _stringParsing["default"].determineWordDelimiter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetWordCountInString, function (inputData, inputMetaData) {
    return _stringParsing["default"].getWordCountInString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdoesStringContainUpperCaseCharacter, function (inputData, inputMetaData) {
    return _stringParsing["default"].doesStringContainUpperCaseCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdoesStringContainLowerCaseCharacter, function (inputData, inputMetaData) {
    return _stringParsing["default"].doesStringContainLowerCaseCharacter(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisFirstCharacterLowerCase, function (inputData, inputMetaData) {
    return _stringParsing["default"].isFirstCharacterLowerCase(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisFirstCharacterUpperCase, function (inputData, inputMetaData) {
    return _stringParsing["default"].isFirstCharacterUpperCase(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisStringList, function (inputData, inputMetaData) {
    return _stringParsing["default"].isStringList(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisStringCamelCase, function (inputData, inputMetaData) {
    return _stringParsing["default"].isStringCamelCase(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cmapWordToCamelCaseWord, function (inputData, inputMetaData) {
    return _stringParsing["default"].mapWordToCamelCaseWord(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.csimplifyAndConsolidateString, function (inputData, inputMetaData) {
    return _stringParsing["default"].simplifyAndConsolidateString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.ccompareSimplifiedAndConsolidatedStrings, function (inputData, inputMetaData) {
    return _stringParsing["default"].compareSimplifiedAndConsolidatedStrings(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cascertainMatchingFilenames, function (inputData, inputMetaData) {
    return _stringParsing["default"].ascertainMatchingFilenames(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cvalidateConstantsDataValidation, function (inputData, inputMetaData) {
    return _stringParsing["default"].validateConstantsDataValidation(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdetermineConstantsContextQualifiedPrefix, function (inputData, inputMetaData) {
    return _stringParsing["default"].determineConstantsContextQualifiedPrefix(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdetermineSuggestedConstantsValidationLineOfCode, function (inputData, inputMetaData) {
    return _stringParsing["default"].determineSuggestedConstantsValidationLineOfCode(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cvalidateConstantsDataValidationLineItemName, function (inputData, inputMetaData) {
    return _stringParsing["default"].validateConstantsDataValidationLineItemName(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdoesConstantExist, function (inputData, inputMetaData) {
    return _stringParsing["default"].doesConstantExist(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetConstantType, function (inputData, inputMetaData) {
    return _stringParsing["default"].getConstantType(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetConstantActualValue, function (inputData, inputMetaData) {
    return _stringParsing["default"].getConstantActualValue(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetConstantName, function (inputData, inputMetaData) {
    return _stringParsing["default"].getConstantName(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cfindConstantName, function (inputData, inputMetaData) {
    return _stringParsing["default"].findConstantName(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisConstantTypeValid, function (inputData, inputMetaData) {
    return _stringParsing["default"].isConstantTypeValid(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cconvertConstantTypeToConstantPrefix, function (inputData, inputMetaData) {
    return _stringParsing["default"].convertConstantTypeToConstantPrefix(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cconstantsOptimizedFulfillmentSystem, function (inputData, inputMetaData) {
    return _stringParsing["default"].constantsOptimizedFulfillmentSystem(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cconstantsFulfillmentSystem, function (inputData, inputMetaData) {
    return _stringParsing["default"].constantsFulfillmentSystem(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cvalidateConstantsDataValues, function (inputData, inputMetaData) {
    return _stringParsing["default"].validateConstantsDataValues(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisValidCommandNameString, function (inputData, inputMetaData) {
    return _stringParsing["default"].isValidCommandNameString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisConstantValid, function (inputData, inputMetaData) {
    return _stringParsing["default"].isConstantValid(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.ccountDuplicateCommandAliases, function (inputData, inputMetaData) {
    return _stringParsing["default"].countDuplicateCommandAliases(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetDataCatagoryFromDataContextName, function (inputData, inputMetaData) {
    return _stringParsing["default"].getDataCatagoryFromDataContextName(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetDataCatagoryDetailNameFromDataContextName, function (inputData, inputMetaData) {
    return _stringParsing["default"].getDataCatagoryDetailNameFromDataContextName(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetKeywordNameFromDataContextName, function (inputData, inputMetaData) {
    return _stringParsing["default"].getKeywordNameFromDataContextName(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cremoveXnumberOfFoldersFromEndOfPath, function (inputData, inputMetaData) {
    return _stringParsing["default"].removeXnumberOfFoldersFromEndOfPath(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetFirstTopLevelFolderFromPath, function (inputData, inputMetaData) {
    return _stringParsing["default"].getFirstTopLevelFolderFromPath(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cloadDataFile, function (inputData, inputMetaData) {
    return _stringParsing["default"].loadDataFile(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.csaveDataFile, function (inputData, inputMetaData) {
    return _stringParsing["default"].saveDataFile(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.csupportedFileFormatsAre, function (inputData, inputMetaData) {
    return _stringParsing["default"].supportedFileFormatsAre(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.ccopyAllFilesAndFoldersFromFolderToFolder, function (inputData, inputMetaData) {
    return _stringParsing["default"].copyAllFilesAndFoldersFromFolderToFolder(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetAttributeName, function (inputData, inputMetaData) {
    return _stringParsing["default"].getAttributeName(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetAttributeValue, function (inputData, inputMetaData) {
    return _stringParsing["default"].getAttributeValue(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.ccleanCommandInput, function (inputData, inputMetaData) {
    return _stringParsing["default"].cleanCommandInput(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cgetNowMoment, function (inputData, inputMetaData) {
    return _stringParsing["default"].getNowMoment(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.ccreateZipArchive, function (inputData, inputMetaData) {
    return _stringParsing["default"].createZipArchive(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cparseSystemRootPath, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].parseSystemRootPath(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cstringToDataType, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].stringToDataType(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cstringToBoolean, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].stringToBoolean(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cdetermineObjectDataType, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].determineObjectDataType(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisBoolean, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].isBoolean(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisInteger, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].isInteger(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisFloat, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].isFloat(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cisString, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].isString(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.creplaceDoublePercentWithMessage, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].replaceDoublePercentWithMessage(inputData, inputMetaData);
  }), _defineProperty(_D$sys$cbusinessRules, biz.cutilitiesReplaceCharacterWithCharacter, function (inputData, inputMetaData) {
    return _stringParsingUtilities["default"].utilitiesReplaceCharacterWithCharacter(inputData, inputMetaData);
  }), _D$sys$cbusinessRules); // console.log(`END ${namespacePrefix}${functionName} function`);
}

;

var _default = _defineProperty({}, fnc.cinitRulesLibrary, function () {
  return initRulesLibrary();
});

exports["default"] = _default;