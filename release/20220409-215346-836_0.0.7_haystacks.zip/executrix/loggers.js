"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _ruleBroker = _interopRequireDefault(require("../brokers/ruleBroker.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("../constants/business.constants.js"));

var clr = _interopRequireWildcard(require("../constants/color.constants.js"));

var cfg = _interopRequireWildcard(require("../constants/configuration.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var gen = _interopRequireWildcard(require("../constants/generic.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _colorizer = _interopRequireDefault(require("./colorizer.js"));

var _configurator = _interopRequireDefault(require("./configurator.js"));

var _fileOperations = _interopRequireDefault(require("./fileOperations.js"));

var _timers = _interopRequireDefault(require("./timers.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _chalk = _interopRequireDefault(require("chalk"));

var _path = _interopRequireDefault(require("path"));

var _fnc$cconsoleLog$fnc$;

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // executrix.loggers.


var namespacePrefix = wr1.cexecutrix + bas.cDot + baseFileName + bas.cDot;
/**
 * @function consoleLog
 * @description Compares the class path to a series of configuration settings to determine
 * if we should log to the console or not.
 * Also can provisionally log to a log file as well since the console
 * is technically a transient data output.
 * @NOTE When it comes to dumping large amounts of data out of a script the console will not do,
 * And dumping data to an output log file is critical to debuggin certain tests and workflows.
 * @param {string} classPath The class path for the caller of this function file.function or class.method.
 * @param {string} message The message or data contents that should be dumped to the output.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/12/27
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function consoleLog(classPath, message) {
  var functionName = consoleLog.name;

  if (Object.keys(_data["default"]).length !== 0 && message !== undefined) {
    // Make sure we don't log anything if we haven't yet loaded the configuration data.
    var consoleLogEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cconsoleLogEnabled);

    if (consoleLogEnabled === true) {
      // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
      // console.log(`classPath is: ${classPath}`);
      // console.log(`message is: ${message}`);
      // let logFile = configurator.getConfigurationSetting(wr1.csystem, cfg.cclientRootPath);
      // if (logFile !== undefined) {
      //   logFile = logFile + bas.cDoubleForwardSlash + wr1.clogs;
      //   // console.log(`Logfile before path.resolve is: ${logFile}`);
      //   logFile = path.resolve(logFile);
      //   // console.log(`Logfile after path.resolve is: ${logFile}`);
      //   logFile = logFile + bas.cDoubleForwardSlash + configurator.getConfigurationSetting(wr1.csystem, cfg.clogFileName);
      //   logFile = path.resolve(logFile);
      //   // console.log(`logFile after adding the log filename: ${logFile}`);
      // }
      var logFile = getLogFileNameAndPath();
      var debugFunctionSetting = false;
      var debugFileSetting = false;
      var debugSetting = false;
      var outputMessage = '';
      var configurationName = '';
      var configurationNamespace = ''; // console.log('Determine if there is a configuration setting for the class path.');

      configurationName = _configurator["default"].processConfigurationNameRules(classPath); // console.log(`configurationName is: ${configurationName}`);

      configurationNamespace = _configurator["default"].processConfigurationNamespaceRules(classPath); // console.log(`configurationNamespace is: ${configurationNamespace}`);

      debugFunctionSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + configurationNamespace, configurationName); // console.log(`debugFunctionSetting is: ${debugFunctionSetting}`);

      debugFileSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + configurationNamespace, ''); // console.log(`debugFileSetting is: ${debugFileSetting}`);

      if (debugFunctionSetting || debugFileSetting) {
        debugSetting = true;
      } // console.log(`debugSetting is: ${debugSetting}`);
      // console.log('DONE attempting to get the configuration setting for the class path, now check if it is not undefined and true');


      if (logFile !== undefined && (logFile.toUpperCase().includes(gen.cLOG) || logFile.toUpperCase().includes(gen.cTXT))) {
        consoleLogProcess(debugSetting, logFile, classPath, message, true);
      } else {
        // No text log file specified, proceed with the same process for console only.
        consoleLogProcess(debugSetting, undefined, classPath, message, false);
      } // console.log(`END ${namespacePrefix}${functionName} function`);

    } // end-if (consoleLogEnabled === true)

  } else if (message === undefined) {
    // end-if (Object.keys(D).length !== 0 && message !== undefined)
    console.log(msg.cWarningMessageIsUndefined);
    console.log(msg.cclassPathIs + classPath);
  }
}

;
/**
 * @function consoleTableLog
 * @description Prints out a table with the data provided in the input tableDataArray.
 * @param {string} classPath The class path for the caller of this function file.function or class.method.
 * @param {array<object>} tableData An array of objects that should be printed to the console as if it was data.
 * @param {array<string>} columnNames An array of column names that should be used when outputting the table.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/22
 */

function consoleTableLog(classPath, tableData, columnNames) {
  var functionName = consoleTableLog.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`classPath is: ${classPath}`);
  // console.log(`tableData is: ${JSON.stringify(tableData)}`);
  // console.log(`columnNames is: ${JSON.stringify(columnNames)}`);

  console.table(tableData, columnNames); // console.log(`END ${namespacePrefix}${functionName} function`);
}

;
/**
 * @function constantsValidationSummaryLog
 * @description Displays a constants log validation summary pass-fail results depending on the appropriate settings flag, which is passed in by the caller.
 * @param {string} message The message that should be displayed, if the setting determines taht it should be displayed.
 * @param {boolean} passFail True or False to indicate if the pas or fail message should be displayed to the console log.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/03/29
 */

function constantsValidationSummaryLog(message, passFail) {
  var functionName = constantsValidationSummaryLog.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`message is: ${message}`);
  // console.log(`passFail is: ${passFail}`);

  var outputMessage = '';

  var blackColorArray = _colorizer["default"].getNamedColorData(clr.cBlack, [0, 0, 0]);

  var greenColorArray = _colorizer["default"].getNamedColorData(clr.cGreen, [0, 255, 0]);

  var redColorArray = _colorizer["default"].getNamedColorData(clr.cRed, [255, 0, 0]);

  if (passFail === true) {
    if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cdisplaySummaryConstantsValidationPassMessages) === true) {
      outputMessage = wr1.cPASSED + bas.cSpace + bas.cDoubleDash + bas.cSpace + message + bas.cSpace + bas.cDoubleDash + bas.cSpace + wr1.cPASSED; // `PASSED -- ${message} -- PASSED`;

      outputMessage = _colorizer["default"].colorizeMessageSimple(outputMessage, blackColorArray, true);
      outputMessage = _colorizer["default"].colorizeMessageSimple(outputMessage, greenColorArray, false);
      console.log(outputMessage);
    }
  } else {
    // passFail === false
    if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cdisplaySummaryConstantsVaidationFailMessages) === true) {
      outputMessage = wr1.cFAILED + bas.cSpace + bas.cDoubleDash + bas.cSpace + message + bas.cSpace + bas.cDoubleDash + bas.cSpace + wr1.cFAILED; // `FAILED -- ${message} -- FAILED`;

      outputMessage = _colorizer["default"].colorizeMessageSimple(outputMessage, blackColorArray, true);
      outputMessage = _colorizer["default"].colorizeMessageSimple(outputMessage, redColorArray, false);
      console.log(outputMessage);
    }
  } // console.log(`END ${namespacePrefix}${functionName} function`);

}

;
/**
 * @function consoleLogProcess
 * @description A function that will print a message to a log file and the console, or just the console.
 * The output depends on if there was a txt/log file specified or not.
 * @param {boolean} debugSetting A TRUE or FALSE value to indicate if the log action is enabled or not.
 * @param {string} logFile The path to the log file where the message should be logged.
 * @param {string} classPath The class path for the caller of this function file.function or class.method.
 * @param {string} message The message or data contents that should be dumped to the output (log file and/or console).
 * @param {boolean} loggingToFileAndConsole A TRUE or FALSE value to indicate if the log should be done to the specified log file and the console.
 * If no log file is specified by the caller/settings system then this will be FALSE and only the console will be logged.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/10/27
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function consoleLogProcess(debugSetting, logFile, classPath, message, loggingToFileAndConsole) {
  var functionName = consoleLogProcess.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`debugSetting is: ${debugSetting}`);
  // console.log(`logFile is: ${logFile}`);
  // console.log(`classPath is: ${classPath}`);
  // console.log(`message is: ${message}`);
  // console.log(`loggingToFileAndConsole is: ${loggingToFileAndConsole}`);

  var outputMessage = '';
  var messageIsValid = false;

  if (debugSetting !== undefined && debugSetting === true) {
    // console.log('The debugSetting is not undefined and also true.');
    outputMessage = parseClassPath(logFile, classPath, message); // console.log(`outputMessage is: ${outputMessage}`);
    // console.log(`message is: ${message}`);

    messageIsValid = validMessage(outputMessage, message);

    if (messageIsValid === true) {
      console.log(outputMessage);
    }

    if (messageIsValid === true && loggingToFileAndConsole === true) {
      printMessageToFile(logFile, outputMessage); // console.log('DONE printing the message to the logFile');
    }
  } else if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cdebugTestExhaustive) === true) {
    // console.log('else-block the debugTestExhaustive setting is true!');
    // TODO: Add rule here to replace double percent with message/class-path.
    // Debug Exhaustive is probably not the best, we might want to consider another configuration setting to
    // enable or disable the console specifically. Right now there is no real business need for it.
    // If you really wanted to disable it just comment it out here.
    console.log(outputMessage);

    if (loggingToFileAndConsole === true) {
      printMessageToFile(logFile, outputMessage); // console.log('done printing the message to the log file.');
    }
  } // console.log('Past all of the if-else-if-else blocks of code.');
  // console.log(`END ${namespacePrefix}${functionName} function`);

}

;
/**
 * @function validMessage
 * @description Looks at the parsed/processed output message and the original message
 * to determine if the message is a valid message to dump to the console and/or the log file (if specified).
 * @param {string|integer|boolean|object} outputMessage The message that has been parsed/processed.
 * @param {string|integer|boolean|object} originalMessage The original message passed in before processing/parsing.
 * @return {boolean} A TRUE or FALSE to indicate if the output message should be dumped to the log file and/or the console.
 * @author Seth Hollingsead
 * @date 2021/10/27
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function validMessage(outputMessage, originalMessage) {
  var functionName = validMessage.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`outputMessage is: ${outputMessage}`);
  // console.log(`originalMessage is: ${originalMessage}`);

  var returnData = false; // This first if-condition catches the case that the output message has already
  // been parsed and modified according to the class path.

  if (outputMessage !== false && outputMessage !== originalMessage) {
    returnData = true;
  } else if (outputMessage !== false && outputMessage.includes(bas.cDoublePercent) === false) {
    // This else-if condition catches the case that the caller just wants to dump a generic message,
    // that doesn't have a class-path designation.
    returnData = true;
  } else if (outputMessage !== false && outputMessage.includes(msg.cActualColonDoublePercent) === true) {
    // This else-if condition catches the special case that the caller wants to dump constants validation generic data to the console.
    // that doesn't have a class-path designation.
    returnData = true;
  } // console.log(`returnData is: ${returnData}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnData;
}

;
/**
 * @function parseClassPath
 * @description Parses the class path and message pulling it apart for logging and looking at custom debug settings.
 * @param {string} logFile The file name and path to the log file where the data should be printed.
 * @param {string} classPath The class path for the caller of this function file.function or class.method.
 * @param {string} message The message or data contents that should be dumped to the output.
 * @return {string} Returns the message that should be printed out to the console and logged to the log file.
 * @author Seth Hollingsead
 * @date 2021/10/27
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function parseClassPath(logFile, classPath, message) {
  var functionName = parseClassPath.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`logFile is: ${logFile}`);
  // console.log(`classPath is: ${classPath}`);
  // console.log(`message is: ${message}`);

  var configurationName = '';
  var configurationNamespace = '';
  var debugFunctionsSetting = false;
  var debugFilesSetting = false;
  var classPathArray = {};
  var returnData = '';
  configurationName = _configurator["default"].processConfigurationNameRules(classPath); // console.log(`configurationName is: ${configurationName}`);

  configurationNamespace = _configurator["default"].processConfigurationNamespaceRules(classPath); // console.log(`configurationNamespace is: ${configurationNamespace}`);
  // printMessageToFile(logFile, `Getting configuration setting value for: debugFunctions|${className}.${classFunctionName}`);
  // console.log(`Getting configuration setting value for: ${configurationNamespace}.${configurationName}`);

  debugFunctionsSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + configurationNamespace, configurationName); // printMessageToFile(logFile, `debugFunctionsSetting is: ${debugFunctionsSetting}`);
  // console.log(`debugFunctionsSetting is: ${debugFunctionsSetting}`);

  debugFilesSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + configurationNamespace, ''); // printMessageToFile(logFile, `debugFilesSetting is: ${debugFilesSetting}`);
  // console.log(`debugFilesSetting is: ${debugFilesSetting}`);

  if (debugFunctionsSetting || debugFilesSetting) {
    // TODO: Implement the colorizing of the message here.
    message = _colorizer["default"].colorizeMessage(message, configurationNamespace, configurationName, debugFilesSetting, debugFunctionsSetting, false); // if (message.includes(bas.cDoublePercent)) {
    //   let myNameSpace = configurationNamespace + bas.cDot + configurationName;
    //   // console.log('message is: ' + message);
    //   // console.log('myNameSpace is: ' + myNameSpace);
    //   // console.log('rules is: ' + JSON.stringify(rules));
    //   // NOTE: Calling this directly is an anti-pattern, but it is necessary at this time because of a circular dependency with loggers.
    //   // We will need to refactor the business rules to accept a callback function that does the logging.
    //   // Essentially we will need to use a dependency injection design pattern to prevent the chance of a circular dependency.
    //   // message = stringParsingUtilities.replaceDoublePercentWithMessage(message, [bas.cDoublePercent, myNameSpace]);
    //   message = ruleBroker.processRules(message, [bas.cDoublePercent, myNameSpace], rules);
    // }
    // console.log('setting the returnData to the message: ' + message);

    returnData = message;
  } else if (debugFunctionsSetting === undefined && debugFilesSetting === undefined || debugFunctionsSetting === undefined && debugFilesSetting === false || debugFunctionsSetting === false && debugFilesSetting === undefined || debugFunctionsSetting === false && debugFilesSetting === false) {
    // console.log('Something is undefined && false or some combination of both, return false');
    returnData = false;
  } else {
    // TODO: Implement the colorizing of the message here.
    message = _colorizer["default"].colorizeMessage(message, className, functionName, undefined, undefined, true);
    returnData = message;
  } // console.log(`returnData is: ${returnData}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnData;
}

;
/**
 * @function getLogFileNameAndPath
 * @description Determines, using configuration settings what the log file name and path should be.
 * @return {string} The full path and file name for the log file.
 * @author Seth Hollingsead
 * @date 2022/03/11
 */

function getLogFileNameAndPath() {
  var functionName = getLogFileNameAndPath.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);

  var returnData = '';

  var logFile = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cclientRootPath);

  if (logFile !== undefined) {
    logFile = logFile + bas.cDoubleForwardSlash + wr1.clogs; // console.log(`Logfile before path.resolve is: ${logFile}`);

    logFile = _path["default"].resolve(logFile); // console.log(`Logfile after path.resolve is: ${logFile}`);

    logFile = logFile + bas.cDoubleForwardSlash + _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.clogFileName);
    logFile = _path["default"].resolve(logFile); // console.log(`logFile after adding the log filename: ${logFile}`);
  }

  returnData = logFile; // console.log(`returnData is: ${returnData}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);

  return returnData;
}

;
/**
 * @function printMessageToFile
 * @description Prints a message to a log/text file.
 * @param {string} file The file path and file name where message data should be printed.
 * @param {string} message The message that should be logged to the log file if the specified flag is true.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/10/27
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function printMessageToFile(file, message) {
  var functionName = printMessageToFile.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`file is: ${file}`);
  // console.log(`message is: ${message}`);

  var dateTimeStamp = '';

  if (!file.includes('undefined')) {
    // NOTE: This usage of the string undefined, must be hard-coded here.
    // '!file.includes(undefined)'
    // console.log(msg.cprintMessageToFile01);
    if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.clogFileEnabled) === true) {
      // console.log('LogFileEnabled = true');
      if (message) {// TODO: Once the colorizer is setup, remove the colorizer font styles from the string.
      }

      if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cincludeDateTimeStampInLogFiles) === true) {
        // Individual messages need to have a time stamp on them. So lets sign the message with a time stamp.
        dateTimeStamp = _timers["default"].getNowMoment(gen.cYYYY_MM_DD_HH_mm_ss_SSS); // console.log(`dateTimeStamp is: ${dateTimeStamp}`);

        message = "".concat(dateTimeStamp, ": ").concat(message);
      }

      _fileOperations["default"].appendMessageToFile(file, message);
    } else {
      // 'ERROR: Failure to log to file: '
      console.log(msg.cprintMessageToFile02 + file);
    }
  } else {// 'ERROR: Log File includes undefined.'
    // console.log(msg.cprintMessageToFile03);
  } // console.log(`END ${namespacePrefix}${functionName} function`);

}

;

var _default = (_fnc$cconsoleLog$fnc$ = {}, _defineProperty(_fnc$cconsoleLog$fnc$, fnc.cconsoleLog, function (classPath, message) {
  return consoleLog(classPath, message);
}), _defineProperty(_fnc$cconsoleLog$fnc$, fnc.cconsoleTableLog, function (classPath, tableData, columnNames) {
  return consoleTableLog(classPath, tableData, columnNames);
}), _defineProperty(_fnc$cconsoleLog$fnc$, fnc.cconstantsValidationSummaryLog, function (message, passFail) {
  return constantsValidationSummaryLog(message, passFail);
}), _defineProperty(_fnc$cconsoleLog$fnc$, fnc.cgetLogFileNameAndPath, function () {
  return getLogFileNameAndPath();
}), _defineProperty(_fnc$cconsoleLog$fnc$, fnc.cprintMessageToFile, function (file, message) {
  return printMessageToFile(file, message);
}), _fnc$cconsoleLog$fnc$);

exports["default"] = _default;