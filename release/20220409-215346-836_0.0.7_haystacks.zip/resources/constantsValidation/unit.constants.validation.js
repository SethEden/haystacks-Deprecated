"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.unitConstantsValidation = void 0;

var unt = _interopRequireWildcard(require("../../constants/unit.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file unit.constants.validation.js
 * @module unit.constants.validation
 * @description Contains all validations for unit & unit conversion constants.
 * Also included are validations for units of measurement, units of time, etc...
 * @requires module:unit.constants
 * @author Seth Hollingsead
 * @date 2022/03/21
 * @copyright Copyright © 2022-… by Seth Hollingsead. All rights reserved
 */
// Internal imports

/**
 * @function unitConstantsValidation
 * @description Initializes the unit constants vaidation data objects array.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/03/21
 */
var unitConstantsValidation = [// Units of Measure
{
  Name: 'cFemto',
  Actual: unt.cFemto,
  Expected: 'Femto'
}, {
  Name: 'cPico',
  Actual: unt.cPico,
  Expected: 'Pico'
}, {
  Name: 'cNano',
  Actual: unt.cNano,
  Expected: 'Nano'
}, {
  Name: 'cMicro',
  Actual: unt.cMicro,
  Expected: 'Micro'
}, {
  Name: 'cMill',
  Actual: unt.cMill,
  Expected: 'Mill'
}, {
  Name: 'cMilli',
  Actual: unt.cMilli,
  Expected: 'Milli'
}, // Units of Time
{
  Name: 'csecond',
  Actual: unt.csecond,
  Expected: 'second'
}, {
  Name: 'cSecond',
  Actual: unt.cSecond,
  Expected: 'Second'
}, {
  Name: 'cSeconds',
  Actual: unt.cSeconds,
  Expected: 'Seconds'
}, {
  Name: 'cMinute',
  Actual: unt.cMinute,
  Expected: 'Minute'
}, {
  Name: 'cMinutes',
  Actual: unt.cMinutes,
  Expected: 'Minutes'
}, {
  Name: 'cHour',
  Actual: unt.cHour,
  Expected: 'Hour'
}, {
  Name: 'cHours',
  Actual: unt.cHours,
  Expected: 'Hours'
}, {
  Name: 'cDay',
  Actual: unt.cDay,
  Expected: 'Day'
}, {
  Name: 'cDays',
  Actual: unt.cDays,
  Expected: 'Days'
}, {
  Name: 'cWeek',
  Actual: unt.cWeek,
  Expected: 'Week'
}, {
  Name: 'cWeeks',
  Actual: unt.cWeeks,
  Expected: 'Weeks'
}, {
  Name: 'cMonth',
  Actual: unt.cMonth,
  Expected: 'Month'
}, {
  Name: 'cMonths',
  Actual: unt.cMonths,
  Expected: 'Months'
}, {
  Name: 'cYear',
  Actual: unt.cYear,
  Expected: 'Year'
}, {
  Name: 'cYears',
  Actual: unt.cYears,
  Expected: 'Years'
}, {
  Name: 'cDecade',
  Actual: unt.cDecade,
  Expected: 'Decade'
}, {
  Name: 'cDecades',
  Actual: unt.cDecades,
  Expected: 'Decades'
}, {
  Name: 'ccent',
  Actual: unt.ccent,
  Expected: 'cent'
}, {
  Name: 'cCent',
  Actual: unt.cCent,
  Expected: 'Cent'
}, {
  Name: 'cCentur',
  Actual: unt.cCentur,
  Expected: 'Centur'
}, {
  Name: 'cCentury',
  Actual: unt.cCentury,
  Expected: 'Century'
}, {
  Name: 'cCenturies',
  Actual: unt.cCenturies,
  Expected: 'Centuries'
}, {
  Name: 'cMillennium',
  Actual: unt.cMillennium,
  Expected: 'Millennium'
}, {
  Name: 'cMillenniums',
  Actual: unt.cMillenniums,
  Expected: 'Millenniums'
}, {
  Name: 'cNanoSecond',
  Actual: unt.cNanoSecond,
  Expected: 'NanoSecond'
}, {
  Name: 'cNanoSeconds',
  Actual: unt.cNanoSeconds,
  Expected: 'NanoSeconds'
}, {
  Name: 'cMicroSecond',
  Actual: unt.cMicroSecond,
  Expected: 'MicroSecond'
}, {
  Name: 'cMicroSeconds',
  Actual: unt.cMicroSeconds,
  Expected: 'MicroSeconds'
}, {
  Name: 'cMilliSecond',
  Actual: unt.cMilliSecond,
  Expected: 'MilliSecond'
}, {
  Name: 'cMilliSeconds',
  Actual: unt.cMilliSeconds,
  Expected: 'MilliSeconds'
}, {
  Name: 'cPicoSecond',
  Actual: unt.cPicoSecond,
  Expected: 'PicoSecond'
}, {
  Name: 'cPicoSeconds',
  Actual: unt.cPicoSeconds,
  Expected: 'PicoSeconds'
}, {
  Name: 'cFemtoSecond',
  Actual: unt.cFemtoSecond,
  Expected: 'FemtoSecond'
}, {
  Name: 'cFemtoSeconds',
  Actual: unt.cFemtoSeconds,
  Expected: 'FemtoSeconds'
} // Unit Conversions
// Miles to Km
// Celcius to Ferinheight
// Liters to Gallons
];
exports.unitConstantsValidation = unitConstantsValidation;