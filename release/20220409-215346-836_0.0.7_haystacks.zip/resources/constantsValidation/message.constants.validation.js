"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.messageConstantsVaidation = void 0;

var msg = _interopRequireWildcard(require("../../constants/message.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file message.constants.validation.js
 * @module message.constants.validation
 * @description Contains all validation for the system messages.
 * @requires module:message.constants
 * @author Seth Hollingsead
 * @date 2022/03/20
 * @copyright Copyright © 2022-… by Seth Hollingsead. All rights reserved
 */
// Internal imports

/**
 * @function messageConstantsValidation
 * @description Initializes the message constants validation data objects array.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/03/20
 */
var messageConstantsVaidation = [// Logging Constants
{
  Name: 'cBEGIN_Function',
  Actual: msg.cBEGIN_Function,
  Expected: 'BEGIN %% Function'
}, {
  Name: 'cEND_Function',
  Actual: msg.cEND_Function,
  Expected: 'END %% Function'
}, {
  Name: 'cinputData',
  Actual: msg.cinputData,
  Expected: 'inputData'
}, {
  Name: 'cInputData',
  Actual: msg.cInputData,
  Expected: 'InputData'
}, {
  Name: 'cinputMetaData',
  Actual: msg.cinputMetaData,
  Expected: 'inputMetaData'
}, {
  Name: 'cInputMetaData',
  Actual: msg.cInputMetaData,
  Expected: 'InputMetaData'
}, {
  Name: 'cinputDataIs',
  Actual: msg.cinputDataIs,
  Expected: 'inputData is: '
}, {
  Name: 'cinputMetaDataIs',
  Actual: msg.cinputMetaDataIs,
  Expected: 'inputMetaData is: '
}, {
  Name: 'creturnDataIs',
  Actual: msg.creturnDataIs,
  Expected: 'returnData is: '
}, // System Messages
// WARNING: No .env file found! Going to default to the DEVELOPMENT ENVIRONMENT!
{
  Name: 'cApplicationWarningMessage1a',
  Actual: msg.cApplicationWarningMessage1a,
  Expected: 'WARNING: No .Env File found! '
}, {
  Name: 'cApplicationWarningMessage1b',
  Actual: msg.cApplicationWarningMessage1b,
  Expected: 'Going to default to the DEVELOPMENT ENVIRONMENT!'
}, {
  Name: 'cCharacterGenerationMessage1',
  Actual: msg.cCharacterGenerationMessage1,
  Expected: 'typeToGenerate is: '
}, {
  Name: 'cCharacterGenerationMessage2',
  Actual: msg.cCharacterGenerationMessage2,
  Expected: 'Generate a number.'
}, {
  Name: 'cCharacterGenerationMessage3',
  Actual: msg.cCharacterGenerationMessage3,
  Expected: 'Generate a random upper case or lower case letter.'
}, {
  Name: 'cCharacterGenerationMessage4',
  Actual: msg.cCharacterGenerationMessage4,
  Expected: 'Generate a special character.'
}, {
  Name: 'cCharacterGenerationMessage5',
  Actual: msg.cCharacterGenerationMessage5,
  Expected: 'DEFAULT: Generate a random upper case or lower case letter.'
}, {
  Name: 'cMathOperationsMessage1',
  Actual: msg.cMathOperationsMessage1,
  Expected: 'bigInteger is: '
}, {
  Name: 'cnumberOfCharactersToGenerateIs',
  Actual: msg.cnumberOfCharactersToGenerateIs,
  Expected: 'numberOfCharactersToGenerate is: '
}, {
  Name: 'cgenerateSpecialCharactersIs',
  Actual: msg.cgenerateSpecialCharactersIs,
  Expected: 'generateSpecialCharacters is: '
}, {
  Name: 'callowableSpecialCharactersIs',
  Actual: msg.callowableSpecialCharactersIs,
  Expected: 'allowableSpecialCharacters is: '
}, {
  Name: 'cspecifiedSuffixAndDomainIs',
  Actual: msg.cspecifiedSuffixAndDomainIs,
  Expected: 'specifiedSuffixAndDomain is: '
}, {
  Name: 'cfailureModeIs',
  Actual: msg.cfailureModeIs,
  Expected: 'failureMode is: '
}, {
  Name: 'cprefixIs',
  Actual: msg.cprefixIs,
  Expected: 'prefix is: '
}, {
  Name: 'csuffixIs',
  Actual: msg.csuffixIs,
  Expected: 'suffix is: '
}, {
  Name: 'cWithoutTheAtSymbol',
  Actual: msg.cWithoutTheAtSymbol,
  Expected: 'Without the @ symbol.'
}, {
  Name: 'cWithoutThePrefix',
  Actual: msg.cWithoutThePrefix,
  Expected: 'Without the prefix.'
}, {
  Name: 'cWithoutTheSuffix',
  Actual: msg.cWithoutTheSuffix,
  Expected: 'Without the suffix.'
}, {
  Name: 'cWithoutTheAtSymbolAndPrefix',
  Actual: msg.cWithoutTheAtSymbolAndPrefix,
  Expected: 'Without the @ and prefix.'
}, {
  Name: 'cDEFAULTWithoutTheAtSymbolAndPrefix',
  Actual: msg.cDEFAULTWithoutTheAtSymbolAndPrefix,
  Expected: 'DEFAULT: Without the @ and prefix.'
}, {
  Name: 'cdomainNameIs',
  Actual: msg.cdomainNameIs,
  Expected: 'domainName is: '
}, {
  Name: 'cnumberOfPrefixCharactersIs',
  Actual: msg.cnumberOfPrefixCharactersIs,
  Expected: 'numberOfPrefixCharacters is: '
}, {
  Name: 'cnumberOfSuffixCharactersIs',
  Actual: msg.cnumberOfSuffixCharactersIs,
  Expected: 'numberOfSuffixCharacters is: '
}, {
  Name: 'cWithoutTheDotSymbol',
  Actual: msg.cWithoutTheDotSymbol,
  Expected: 'Without the . symbol.'
}, {
  Name: 'cWithoutTheAtAndDotSymbols',
  Actual: msg.cWithoutTheAtAndDotSymbols,
  Expected: 'Without the @ and . symbols.'
}, {
  Name: 'cWithoutTheDomainName',
  Actual: msg.cWithoutTheDomainName,
  Expected: 'Without the domain name.'
}, {
  Name: 'cWithoutTheAtSymbolAndDomainName',
  Actual: msg.cWithoutTheAtSymbolAndDomainName,
  Expected: 'Without the @ and domain name.'
}, {
  Name: 'cWithoutTheDotAndDomainName',
  Actual: msg.cWithoutTheDotAndDomainName,
  Expected: 'Without the . and domain name.'
}, {
  Name: 'cWithoutTheAtSymbolDotAndDomainName',
  Actual: msg.cWithoutTheAtSymbolDotAndDomainName,
  Expected: 'Without the @, . and domain name.'
}, {
  Name: 'cWithoutTheDotAndPrefix',
  Actual: msg.cWithoutTheDotAndPrefix,
  Expected: 'Without the . and prefix.'
}, {
  Name: 'cWithoutTheAtSymbolAndSuffix',
  Actual: msg.cWithoutTheAtSymbolAndSuffix,
  Expected: 'Without the @ and suffix.'
}, {
  Name: 'cWithoutTheDotAndSuffix',
  Actual: msg.cWithoutTheDotAndSuffix,
  Expected: 'Without the . and suffix.'
}, {
  Name: 'cWithoutTheAtSymbolDotAndPrefix',
  Actual: msg.cWithoutTheAtSymbolDotAndPrefix,
  Expected: 'Without the @, . and prefix.'
}, {
  Name: 'cWithoutTheAtSymbolDotAndSuffix',
  Actual: msg.cWithoutTheAtSymbolDotAndSuffix,
  Expected: 'Without the @, . and suffix.'
}, {
  Name: 'cWithoutTheAtSymbolDotPrefixAndSuffix',
  Actual: msg.cWithoutTheAtSymbolDotPrefixAndSuffix,
  Expected: 'Without the @, ., prefix and suffix.'
}, {
  Name: 'cWithoutThePrefixAndDomainName',
  Actual: msg.cWithoutThePrefixAndDomainName,
  Expected: 'Without the prefix and domain name.'
}, {
  Name: 'cWithoutTheSuffixAndDomainName',
  Actual: msg.cWithoutTheSuffixAndDomainName,
  Expected: 'Without the suffix and domain name.'
}, {
  Name: 'cWithoutThePrefixAndSuffix',
  Actual: msg.cWithoutThePrefixAndSuffix,
  Expected: 'Without the prefix and suffix.'
}, {
  Name: 'cWithoutThePrefixSuffixAndDomainName',
  Actual: msg.cWithoutThePrefixSuffixAndDomainName,
  Expected: 'Without the prefix, suffix and domain name.'
}, {
  Name: 'cWithoutTheAtSymbolPrefixAndDomainName',
  Actual: msg.cWithoutTheAtSymbolPrefixAndDomainName,
  Expected: 'Without the @, prefix and domain name.'
}, {
  Name: 'cWithoutTheDotPrefixAndDomainName',
  Actual: msg.cWithoutTheDotPrefixAndDomainName,
  Expected: 'Without the ., prefix and domain name.'
}, {
  Name: 'cWithoutTheAtSymbolSuffixAndDomainName',
  Actual: msg.cWithoutTheAtSymbolSuffixAndDomainName,
  Expected: 'Without the @, suffix and domain name.'
}, {
  Name: 'cWithoutTheDotSuffixAndDomainName',
  Actual: msg.cWithoutTheDotSuffixAndDomainName,
  Expected: 'Without the ., suffix and domain name.'
}, {
  Name: 'cWithoutTheAtSymbolPrefixSuffixAndDomainName',
  Actual: msg.cWithoutTheAtSymbolPrefixSuffixAndDomainName,
  Expected: 'Without the @, prefix, suffix and domain name.'
}, {
  Name: 'cWithoutTheDotPrefixSuffixAndDomainName',
  Actual: msg.cWithoutTheDotPrefixSuffixAndDomainName,
  Expected: 'Without the ., prefix, suffix and domain name.'
}, {
  Name: 'cWithoutThePrefixSuffixAndAtSymbol',
  Actual: msg.cWithoutThePrefixSuffixAndAtSymbol,
  Expected: 'Without the prefix, suffix and @.'
}, {
  Name: 'cWithoutThePrefixSuffixAndDot',
  Actual: msg.cWithoutThePrefixSuffixAndDot,
  Expected: 'Without the prefix, suffix and ..'
}, {
  Name: 'cIndexOfTheSpace',
  Actual: msg.cIndexOfTheSpace,
  Expected: 'Index of the '
}, {
  Name: 'cisResolvingAs',
  Actual: msg.cisResolvingAs,
  Expected: 'is resolving as: '
}, {
  Name: 'cparsedStringSpaceTerm',
  Actual: msg.cparsedStringSpaceTerm,
  Expected: 'parsedString term'
}, {
  Name: 'cstring1Is',
  Actual: msg.cstring1Is,
  Expected: 'string1 is: '
}, {
  Name: 'cstring2Is',
  Actual: msg.cstring2Is,
  Expected: 'string2 is: '
}, {
  Name: 'cvariation0ValueIs',
  Actual: msg.cvariation0ValueIs,
  Expected: 'variation0 value is: '
}, {
  Name: 'cvariation1ValueIs',
  Actual: msg.cvariation1ValueIs,
  Expected: 'variation1 value is: '
}, {
  Name: 'ciValueIs',
  Actual: msg.ciValueIs,
  Expected: 'i value is: '
}, {
  Name: 'cjValueIs',
  Actual: msg.cjValueIs,
  Expected: 'j value is: '
}, {
  Name: 'cdeletionCostIs',
  Actual: msg.cdeletionCostIs,
  Expected: 'deletionCost is: '
}, {
  Name: 'cinsertionCostIs',
  Actual: msg.cinsertionCostIs,
  Expected: 'insertionCost is: '
}, {
  Name: 'csubstitutionCostIs',
  Actual: msg.csubstitutionCostIs,
  Expected: 'substitutionCost is: '
}, {
  Name: 'ccamelCaseWordCountIs',
  Actual: msg.ccamelCaseWordCountIs,
  Expected: 'camelCaseWordCount is: '
}, {
  Name: 'ccontainsAcronymIs',
  Actual: msg.ccontainsAcronymIs,
  Expected: 'containsAcronym is: '
}, {
  Name: 'cspacesCountIs',
  Actual: msg.cspacesCountIs,
  Expected: 'spacesCount is: '
}, {
  Name: 'cperiodCountIs',
  Actual: msg.cperiodCountIs,
  Expected: 'periodCount is: '
}, {
  Name: 'cdashCountIs',
  Actual: msg.cdashCountIs,
  Expected: 'dashCount is: '
}, {
  Name: 'cunderscoreCountIs',
  Actual: msg.cunderscoreCountIs,
  Expected: 'underscoreCount is: '
}, {
  Name: 'cplusCountIs',
  Actual: msg.cplusCountIs,
  Expected: 'plusCount is: '
}, {
  Name: 'cpercentCountIs',
  Actual: msg.cpercentCountIs,
  Expected: 'percentCount is: '
}, {
  Name: 'cstringDeltaValueIs',
  Actual: msg.cstringDeltaValueIs,
  Expected: 'stringDelta value is: '
}, {
  Name: 'cFilenamesMatch',
  Actual: msg.cFilenamesMatch,
  Expected: 'Filenames match'
}, {
  Name: 'cFilenamesDoNotMatch',
  Actual: msg.cFilenamesDoNotMatch,
  Expected: 'Filenames do not match'
}, {
  Name: 'cconstantsLineIs',
  Actual: msg.cconstantsLineIs,
  Expected: 'constantsLine is: '
}, {
  Name: 'cArrayElementsMatch',
  Actual: msg.cArrayElementsMatch,
  Expected: 'Array elements match'
}, {
  Name: 'cArrayElementsDoNotMatch',
  Actual: msg.cArrayElementsDoNotMatch,
  Expected: 'Array elements do not match'
}, {
  Name: 'clineArray2Is',
  Actual: msg.clineArray2Is,
  Expected: 'lineArray[2] is: '
}, {
  Name: 'cSuggestedLineOfCodeIs',
  Actual: msg.cSuggestedLineOfCodeIs,
  Expected: 'Suggested line of code is: '
}, {
  Name: 'cErrorUnknownConstantFile',
  Actual: msg.cErrorUnknownConstantFile,
  Expected: 'ERROR: Unknown constant file.'
}, {
  Name: 'cconstantsTypesKeysIs',
  Actual: msg.cconstantsTypesKeysIs,
  Expected: 'constantsTypesKeys is: '
}, {
  Name: 'cconstantTypeKeyIs',
  Actual: msg.cconstantTypeKeyIs,
  Expected: 'constantTypeKey is: '
}, {
  Name: 'cconstantTypeValuesIs',
  Actual: msg.cconstantTypeValuesIs,
  Expected: 'constantTypeValues is: '
}, {
  Name: 'cconstantsKeysIs',
  Actual: msg.cconstantsKeysIs,
  Expected: 'constantsKeys is: '
}, {
  Name: 'cconstantKeyIs',
  Actual: msg.cconstantKeyIs,
  Expected: 'constantKey is: '
}, {
  Name: 'cconstantActualValueIs',
  Actual: msg.cconstantActualValueIs,
  Expected: 'constantActualValue is: '
}, {
  Name: 'cconstantNameIs',
  Actual: msg.cconstantNameIs,
  Expected: 'constantName is: '
}, {
  Name: 'cconstantValueIs',
  Actual: msg.cconstantValueIs,
  Expected: 'constantValue is: '
}, {
  Name: 'cdeltaLengthIs',
  Actual: msg.cdeltaLengthIs,
  Expected: 'deltaLength is: '
}, {
  Name: 'crecursiveSubStringIs',
  Actual: msg.crecursiveSubStringIs,
  Expected: 'recursiveSubString is: '
}, {
  Name: 'cmaxStringLengthIs',
  Actual: msg.cmaxStringLengthIs,
  Expected: 'maxStringLength is: '
}, {
  Name: 'cminStringLengthIs',
  Actual: msg.cminStringLengthIs,
  Expected: 'minStringLength is: '
}, {
  Name: 'ccurrentMasterStringArrayElementIs',
  Actual: msg.ccurrentMasterStringArrayElementIs,
  Expected: 'currentMasterStringArrayElement is: '
}, {
  Name: 'cConstantDoesNotExist',
  Actual: msg.cConstantDoesNotExist,
  Expected: 'Constant does NOT exist: '
}, {
  Name: 'cConstantDoesExist',
  Actual: msg.cConstantDoesExist,
  Expected: 'Constant does exist: '
}, {
  Name: 'cBEGIN_ithLoop',
  Actual: msg.cBEGIN_ithLoop,
  Expected: 'BEGIN i-th loop: '
}, {
  Name: 'cBEGIN_ithIteration',
  Actual: msg.cBEGIN_ithIteration,
  Expected: 'BEGIN i-th iteration: '
}, {
  Name: 'cBEGIN_jthLoop',
  Actual: msg.cBEGIN_jthLoop,
  Expected: 'BEGIN j-th loop: '
}, {
  Name: 'cBEGIN_kthIteration',
  Actual: msg.cBEGIN_kthIteration,
  Expected: 'BEGIN k-th iteration: '
}, {
  Name: 'cEND_ithLoop',
  Actual: msg.cEND_ithLoop,
  Expected: 'END i-th loop: '
}, {
  Name: 'cEND_ithIteration',
  Actual: msg.cEND_ithIteration,
  Expected: 'END i-th iteration: '
}, {
  Name: 'cEND_jthLoop',
  Actual: msg.cEND_jthLoop,
  Expected: 'END j-th loop: '
}, {
  Name: 'cEND_kthIteration',
  Actual: msg.cEND_kthIteration,
  Expected: 'END k-th iteration: '
}, {
  Name: 'ccurrentCommandIs',
  Actual: msg.ccurrentCommandIs,
  Expected: 'currentCommand is: '
}, {
  Name: 'caliasListIs',
  Actual: msg.caliasListIs,
  Expected: 'aliasList is: '
}, {
  Name: 'ccurrentAliasIs',
  Actual: msg.ccurrentAliasIs,
  Expected: 'currentAlias is: '
}, {
  Name: 'cduplicateAliasCountIs',
  Actual: msg.cduplicateAliasCountIs,
  Expected: 'duplicateAliasCount is: '
}, {
  Name: 'cduplicateCommandAliasIs',
  Actual: msg.cduplicateCommandAliasIs,
  Expected: 'duplicate command alias is: '
}, {
  Name: 'ccommandWordAliasesBeforeChangeIs',
  Actual: msg.ccommandWordAliasesBeforeChangeIs,
  Expected: 'commandWordAliases BEFORE CHANGE is: '
}, {
  Name: 'ccommandWordAliasesAfterChangeIs',
  Actual: msg.ccommandWordAliasesAfterChangeIs,
  Expected: 'commandWordAliasesArray AFTER CHANGE is: '
}, {
  Name: 'cmasterCommandWordAlisesArrayIs',
  Actual: msg.cmasterCommandWordAlisesArrayIs,
  Expected: 'masterCommandWordAliasesArray is: '
}, {
  Name: 'cmasterArrayIndexIs',
  Actual: msg.cmasterArrayIndexIs,
  Expected: 'masterArrayIndex is: '
}, {
  Name: 'cCommandAliasesAre',
  Actual: msg.cCommandAliasesAre,
  Expected: 'Command Aliases are: '
}, {
  Name: 'cexpandedLehmerCodeArrayIs',
  Actual: msg.cexpandedLehmerCodeArrayIs,
  Expected: 'expandedLehmerCodeArray is: '
}, {
  Name: 'cindexOfExpansionIs',
  Actual: msg.cindexOfExpansionIs,
  Expected: 'indexOfExpansion is: '
}, {
  Name: 'carrayToBeExpandedIs',
  Actual: msg.carrayToBeExpandedIs,
  Expected: 'arrayToBeExpanded is: '
}, {
  Name: 'climitOfExpansionIs',
  Actual: msg.climitOfExpansionIs,
  Expected: 'limitOfExpansion is: '
}, {
  Name: 'cpushingLehmerCodeArray1ToReturnDataValue',
  Actual: msg.cpushingLehmerCodeArray1ToReturnDataValue,
  Expected: 'pushing LehmerCodeArray1 to returnData value: '
}, {
  Name: 'creturnDataAfterPushIs',
  Actual: msg.creturnDataAfterPushIs,
  Expected: 'returnData after push is: '
}, {
  Name: 'creturnDataAfterLevel1Is',
  Actual: msg.creturnDataAfterLevel1Is,
  Expected: 'returnData after level 1 is: '
}, {
  Name: 'carrayToBeExpandedDotLengthIs',
  Actual: msg.carrayToBeExpandedDotLengthIs,
  Expected: 'arrayToBeExpanded.length is: '
}, {
  Name: 'creturnDataDotLengthIs',
  Actual: msg.creturnDataDotLengthIs,
  Expected: 'returnData.length is: '
}, {
  Name: 'creturnDataBeforePopIs',
  Actual: msg.creturnDataBeforePopIs,
  Expected: 'returnData BEFORE POP is: '
}, {
  Name: 'creturnDataAfterPopIs',
  Actual: msg.creturnDataAfterPopIs,
  Expected: 'returnData AFTER POP is: '
}, {
  Name: 'cmasterTempReturnDataBeforeRecursiveCallIs',
  Actual: msg.cmasterTempReturnDataBeforeRecursiveCallIs,
  Expected: 'masterTempReturnData BEFORE recursive call is: '
}, {
  Name: 'ctempReturnData1Is',
  Actual: msg.ctempReturnData1Is,
  Expected: 'tempReturnData1 is: '
}, {
  Name: 'ctempReturnData1DotLengthIs',
  Actual: msg.ctempReturnData1DotLengthIs,
  Expected: 'tempReturnData1.length is: '
}, {
  Name: 'cpushingTempReturnData1Kvalue',
  Actual: msg.cpushingTempReturnData1Kvalue,
  Expected: 'pushing tempReturnData1[k] value: '
}, {
  Name: 'cmasterTempReturnDataAfterRecursiveCallIs',
  Actual: msg.cmasterTempReturnDataAfterRecursiveCallIs,
  Expected: 'masterTempReturnData AFTER recursive call is: '
}, {
  Name: 'clookupIndexIs',
  Actual: msg.clookupIndexIs,
  Expected: 'lookupIndex is: '
}, {
  Name: 'clookupValueIs',
  Actual: msg.clookupValueIs,
  Expected: 'lookupValue is: '
}, {
  Name: 'cDataCatagoryShouldBe',
  Actual: msg.cDataCatagoryShouldBe,
  Expected: 'Data Catagory should be: '
}, {
  Name: 'cDataCatagoryDetailNameShouldBe',
  Actual: msg.cDataCatagoryDetailNameShouldBe,
  Expected: 'Data Catagory Detail Name should be: '
}, {
  Name: 'cKeywordNameShouldBe',
  Actual: msg.cKeywordNameShouldBe,
  Expected: 'Keyword Name should be: '
}, {
  Name: 'cpathElementIs',
  Actual: msg.cpathElementIs,
  Expected: 'pathElement is: '
}, {
  Name: 'ccaseIEqual0',
  Actual: msg.ccaseIEqual0,
  Expected: 'case: i = 0'
}, {
  Name: 'ccasePathElementEqual',
  Actual: msg.ccasePathElementEqual,
  Expected: 'case: pathElement = '
}, {
  Name: 'ccaseElse',
  Actual: msg.ccaseElse,
  Expected: 'case else'
}, {
  Name: 'creturnDataSoFarIs',
  Actual: msg.creturnDataSoFarIs,
  Expected: 'returnData so far is: '
}, {
  Name: 'cpathArrayIs',
  Actual: msg.cpathArrayIs,
  Expected: 'pathArray is: '
}, {
  Name: 'ccurrentPathElementIs',
  Actual: msg.ccurrentPathElementIs,
  Expected: 'current path element is: '
}, {
  Name: 'cAttemptingToLoadXmlData',
  Actual: msg.cAttemptingToLoadXmlData,
  Expected: 'Attempting to load XML data!'
}, {
  Name: 'cAttemptingToLoadCsvData',
  Actual: msg.cAttemptingToLoadCsvData,
  Expected: 'Attempting to load CSV data!'
}, {
  Name: 'cAttemptingToLoadJsonData',
  Actual: msg.cAttemptingToLoadJsonData,
  Expected: 'Attempting to load JSON data!'
}, {
  Name: 'cLoadedDataIs',
  Actual: msg.cLoadedDataIs,
  Expected: 'Loaded data is: '
}, {
  Name: 'cattributeArrayIs',
  Actual: msg.cattributeArrayIs,
  Expected: 'attributeArray is: '
}, {
  Name: 'cattributeArray0Is',
  Actual: msg.cattributeArray0Is,
  Expected: 'attributeArray[0] is: '
}, {
  Name: 'cattributeArray1Is',
  Actual: msg.cattributeArray1Is,
  Expected: 'attributeArray[1] is: '
}, {
  Name: 'carrayIs',
  Actual: msg.carrayIs,
  Expected: 'array is: '
}, {
  Name: 'cvalueIs',
  Actual: msg.cvalueIs,
  Expected: 'value is: '
}, {
  Name: 'cmyFunctionIs',
  Actual: msg.cmyFunctionIs,
  Expected: 'myFunction is: '
}, {
  Name: 'carrayInputObjectIsNotAnArray',
  Actual: msg.carrayInputObjectIsNotAnArray,
  Expected: 'array input object is not an array.'
}, {
  Name: 'cTheValueWasFoundInTheArray',
  Actual: msg.cTheValueWasFoundInTheArray,
  Expected: 'The value was found in the array.'
}, {
  Name: 'cTheValueWasNotFoundInTheArray',
  Actual: msg.cTheValueWasNotFoundInTheArray,
  Expected: 'The value was NOT found in the array.'
}, {
  Name: 'coriginalStringIs',
  Actual: msg.coriginalStringIs,
  Expected: 'originalString is: '
}, {
  Name: 'cindexIs',
  Actual: msg.cindexIs,
  Expected: 'index is: '
}, {
  Name: 'creplacementIs',
  Actual: msg.creplacementIs,
  Expected: 'replacement is: '
}, {
  Name: 'cDEPLOY_APPLICATION',
  Actual: msg.cDEPLOY_APPLICATION,
  Expected: 'DEPLOY_APPLICATION'
}, {
  Name: 'cRELEASE_APPLICATION',
  Actual: msg.cRELEASE_APPLICATION,
  Expected: 'RELEASE_APPLICATION'
}, {
  Name: 'cReleaseFailed',
  Actual: msg.cReleaseFailed,
  Expected: 'Release failed'
}, {
  Name: 'caggregateCommandStringIs',
  Actual: msg.caggregateCommandStringIs,
  Expected: 'aggregateCommandString is: '
}, {
  Name: 'cmetaDataParametersIs',
  Actual: msg.cmetaDataParametersIs,
  Expected: 'metaDataParameters is: '
}, {
  Name: 'cmetaDataParametersLengthIs',
  Actual: msg.cmetaDataParametersLengthIs,
  Expected: 'metaDataParameters length is: '
}, {
  Name: 'cmetaDataPathAndFilenameIs',
  Actual: msg.cmetaDataPathAndFilenameIs,
  Expected: 'metaDataPathAndFilename is: '
}, {
  Name: 'cpathAndFilenameIs',
  Actual: msg.cpathAndFilenameIs,
  Expected: 'pathAndFilename is: '
}, {
  Name: 'ccontentsAre',
  Actual: msg.ccontentsAre,
  Expected: 'contents are: '
}, {
  Name: 'ccontentsOfDare',
  Actual: msg.ccontentsOfDare,
  Expected: 'contents of D are: '
}, {
  Name: 'cBEGIN_theIthIterationOfInputDataArray',
  Actual: msg.cBEGIN_theIthIterationOfInputDataArray,
  Expected: 'BEGIN the i-th iteration of the inputData array. i is: '
}, {
  Name: 'ccurrentRuleIs',
  Actual: msg.ccurrentRuleIs,
  Expected: 'currentRule is: '
}, {
  Name: 'crulesIs',
  Actual: msg.crulesIs,
  Expected: 'rules is: '
}, {
  Name: 'cruleInputDataIs',
  Actual: msg.cruleInputDataIs,
  Expected: 'ruleInputData is: '
}, {
  Name: 'cruleInputMetaData',
  Actual: msg.cruleInputMetaData,
  Expected: 'ruleInputMetaData is: '
}, {
  Name: 'cBusinessRuleStartTimeIs',
  Actual: msg.cBusinessRuleStartTimeIs,
  Expected: 'Business Rule Start time is: '
}, {
  Name: 'cBusinessRuleEndTimeIs',
  Actual: msg.cBusinessRuleEndTimeIs,
  Expected: 'Business Rule End time is: '
}, {
  Name: 'cBusinessRuleRunTimeIs',
  Actual: msg.cBusinessRuleRunTimeIs,
  Expected: 'BusinessRule run-time is: '
}, {
  Name: 'ccommandStringBeforeAttemptedDelimiterSwapIs',
  Actual: msg.ccommandStringBeforeAttemptedDelimiterSwapIs,
  Expected: 'commandString before attempted delimiter swap is: '
}, {
  Name: 'creplaceCharacterWithCharacterRuleIs',
  Actual: msg.creplaceCharacterWithCharacterRuleIs,
  Expected: 'replaceCharacterWithCharacterRule is: '
}, {
  Name: 'cRuleOutputIs',
  Actual: msg.cRuleOutputIs,
  Expected: 'Rule output is: '
}, {
  Name: 'ccamelCaseCommandNameArrayIs',
  Actual: msg.ccamelCaseCommandNameArrayIs,
  Expected: 'camelCaseCommandNameArray is: '
}, {
  Name: 'ccurrentCommandWordIs',
  Actual: msg.ccurrentCommandWordIs,
  Expected: 'current commandWord is: '
}, {
  Name: 'cPARSER_ERROR',
  Actual: msg.cPARSER_ERROR,
  Expected: 'PARSER ERROR: '
}, {
  Name: 'ccommandAliasDataStructureIs',
  Actual: msg.ccommandAliasDataStructureIs,
  Expected: 'commandAliasDataStructure is: '
}, {
  Name: 'cuserDefinedConstantIs',
  Actual: msg.cuserDefinedConstantIs,
  Expected: 'userDefinedConstant is: '
}, {
  Name: 'cwordCountIs',
  Actual: msg.cwordCountIs,
  Expected: 'wordCount is: '
}, {
  Name: 'cwordsArrayIs',
  Actual: msg.cwordsArrayIs,
  Expected: 'wordsArray is: '
}, {
  Name: 'cOptimizedConstantDefinitionForWord',
  Actual: msg.cOptimizedConstantDefinitionForWord,
  Expected: 'Optimized constant definition for word: '
}, {
  Name: 'cuserDefinedConstantListIs',
  Actual: msg.cuserDefinedConstantListIs,
  Expected: 'userDefinedConstantList is: '
}, {
  Name: 'cuserDefinedConstantListContainsComas',
  Actual: msg.cuserDefinedConstantListContainsComas,
  Expected: 'userDefinedConstantList contains comas'
}, {
  Name: 'cuserDefinedConstantsListArrayIs',
  Actual: msg.cuserDefinedConstantsListArrayIs,
  Expected: 'userDefinedConstantsListArray is: '
}, {
  Name: 'cuserDefinedConstantsListDoesNotContainComas',
  Actual: msg.cuserDefinedConstantsListDoesNotContainComas,
  Expected: 'userDefinedConstantList DOES NOT contain comas'
}, {
  Name: 'ccommonPatternsArrayIs',
  Actual: msg.ccommonPatternsArrayIs,
  Expected: 'commonPatternsArray is: '
}, {
  Name: 'cbusinessRuleCounterIs',
  Actual: msg.cbusinessRuleCounterIs,
  Expected: 'businessRuleCounter is: '
}, {
  Name: 'cbusinessRulePerformanceSumIs',
  Actual: msg.cbusinessRulePerformanceSumIs,
  Expected: 'businessRulePerformanceSum is: '
}, {
  Name: 'cDoneBusinessRulePerformanceSumIs',
  Actual: msg.cDoneBusinessRulePerformanceSumIs,
  Expected: 'DONE! businessRulePerformanceSum is: '
}, {
  Name: 'caverageIs',
  Actual: msg.caverageIs,
  Expected: 'average is: '
}, {
  Name: 'cbusinessRulePerformanceStdSumIs',
  Actual: msg.cbusinessRulePerformanceStdSumIs,
  Expected: 'businessRulePerformanceStdSum is: '
}, {
  Name: 'cDoneBusinessRulePerformanceStdSumIs',
  Actual: msg.cDoneBusinessRulePerformanceStdSumIs,
  Expected: 'DONE! businessRulePerformanceStdSum is: '
}, {
  Name: 'cstandardDevIs',
  Actual: msg.cstandardDevIs,
  Expected: 'standardDev is: '
}, {
  Name: 'ccommandCounterIs',
  Actual: msg.ccommandCounterIs,
  Expected: 'commandCounter is: '
}, {
  Name: 'ccommandPerformanceSumIs',
  Actual: msg.ccommandPerformanceSumIs,
  Expected: 'commandPerformanceSum is: '
}, {
  Name: 'cDoneCommandPerformanceSumIs',
  Actual: msg.cDoneCommandPerformanceSumIs,
  Expected: 'DONE! commandPerformanceSum is: '
}, {
  Name: 'ccommandPerformanceStdSumIs',
  Actual: msg.ccommandPerformanceStdSumIs,
  Expected: 'commandPerformanceStdSum is: '
}, {
  Name: 'cDoneCommandPerformanceStdSumIs',
  Actual: msg.cDoneCommandPerformanceStdSumIs,
  Expected: 'DONE! commandPerformanceStdSum is: '
}, {
  Name: 'ccolorKeysIs',
  Actual: msg.ccolorKeysIs,
  Expected: 'colorKeys is: '
}, {
  Name: 'ccurrentColorNameIs',
  Actual: msg.ccurrentColorNameIs,
  Expected: 'currentColorName is: '
}, {
  Name: 'ccurrentColorObjectIs',
  Actual: msg.ccurrentColorObjectIs,
  Expected: 'currentColorObject is: '
}, {
  Name: 'ccurrentColorHexValueIs',
  Actual: msg.ccurrentColorHexValueIs,
  Expected: 'currentColorHexValue is: '
}, {
  Name: 'cruleOutputIs',
  Actual: msg.cruleOutputIs,
  Expected: 'ruleOutput is: '
}, {
  Name: 'cBeginPhase1ConstantsValidation',
  Actual: msg.cBeginPhase1ConstantsValidation,
  Expected: 'BEGIN Phase 1 Constants Validation'
}, {
  Name: 'cEndPhase1ConstantsValidation',
  Actual: msg.cEndPhase1ConstantsValidation,
  Expected: 'END Phase 1 Constants Validation'
}, {
  Name: 'cBeginPhase2ConstantsValidation',
  Actual: msg.cBeginPhase2ConstantsValidation,
  Expected: 'BEGIN Phase 2 Constants Validation'
}, {
  Name: 'cEndPhase2ConstantsValidation',
  Actual: msg.cEndPhase2ConstantsValidation,
  Expected: 'END Phase 2 Constants Validation'
}, {
  Name: 'cconstantsPathIs',
  Actual: msg.cconstantsPathIs,
  Expected: 'constantsPath is: '
}, {
  Name: 'cresolvedConstantsPath_BasicIs',
  Actual: msg.cresolvedConstantsPath_BasicIs,
  Expected: 'resolvedConstantsPath_Basic is: '
}, {
  Name: 'cresolvedConstantsPath_BusinessIs',
  Actual: msg.cresolvedConstantsPath_BusinessIs,
  Expected: 'resolvedConstantsPath_Business is: '
}, {
  Name: 'cresolvedConstantsPath_ColorIs',
  Actual: msg.cresolvedConstantsPath_ColorIs,
  Expected: 'resolvedConstantsPath_Color is: '
}, {
  Name: 'cresolvedConstantsPath_CommandIs',
  Actual: msg.cresolvedConstantsPath_CommandIs,
  Expected: 'resolvedConstantsPath_Command is: '
}, {
  Name: 'cresolvedConstantsPath_ConfigurationIs',
  Actual: msg.cresolvedConstantsPath_ConfigurationIs,
  Expected: 'resolvedConstantsPath_Configuration is: '
}, {
  Name: 'cresolvedConstantsPath_CountryIs',
  Actual: msg.cresolvedConstantsPath_CountryIs,
  Expected: 'resolvedConstantsPath_Country is: '
}, {
  Name: 'cresolvedConstantsPath_ElementIs',
  Actual: msg.cresolvedConstantsPath_ElementIs,
  Expected: 'resolvedConstantsPath_Element is: '
}, {
  Name: 'cresolvedConstantsPath_FunctionIs',
  Actual: msg.cresolvedConstantsPath_FunctionIs,
  Expected: 'resolvedConstantsPath_Function is: '
}, {
  Name: 'cresolvedConstantsPath_GenericIs',
  Actual: msg.cresolvedConstantsPath_GenericIs,
  Expected: 'resolvedConstantsPath_Generic is: '
}, {
  Name: 'cresolvedConstantsPath_IsotopeIs',
  Actual: msg.cresolvedConstantsPath_IsotopeIs,
  Expected: 'resolvedConstantsPath_Isotope is: '
}, {
  Name: 'cresolvedConstantsPath_KnotIs',
  Actual: msg.cresolvedConstantsPath_KnotIs,
  Expected: 'resolvedConstantsPath_Knot is: '
}, {
  Name: 'cresolvedConstantsPath_LanguageIs',
  Actual: msg.cresolvedConstantsPath_LanguageIs,
  Expected: 'resolvedConstantsPath_Language is: '
}, {
  Name: 'cresolvedConstantsPath_MessageIs',
  Actual: msg.cresolvedConstantsPath_MessageIs,
  Expected: 'resolvedConstantsPath_Message is: '
}, {
  Name: 'cresolvedConstantsPath_NumericIs',
  Actual: msg.cresolvedConstantsPath_NumericIs,
  Expected: 'resolvedConstantsPath_Numeric is: '
}, {
  Name: 'cresolvedConstantsPath_PhonicIs',
  Actual: msg.cresolvedConstantsPath_PhonicIs,
  Expected: 'resolvedConstantsPath_Phonic is: '
}, {
  Name: 'cresolvedConstantsPath_ShapeIs',
  Actual: msg.cresolvedConstantsPath_ShapeIs,
  Expected: 'resolvedConstantsPath_Shape is: '
}, {
  Name: 'cresolvedConstantsPath_SystemIs',
  Actual: msg.cresolvedConstantsPath_SystemIs,
  Expected: 'resolvedConstantsPath_System is: '
}, {
  Name: 'cresolvedConstantsPath_UnitIs',
  Actual: msg.cresolvedConstantsPath_UnitIs,
  Expected: 'resolvedConstantsPath_Unit is: '
}, {
  Name: 'cresolvedConstantsPath_Word1Is',
  Actual: msg.cresolvedConstantsPath_Word1Is,
  Expected: 'resolvedConstantsPath_Word1 is: '
}, {
  Name: 'cBasicConstantsPhase1Validation',
  Actual: msg.cBasicConstantsPhase1Validation,
  Expected: 'Basic Constants Phase 1 Validation'
}, {
  Name: 'cBusinessConstantsPhase1Validation',
  Actual: msg.cBusinessConstantsPhase1Validation,
  Expected: 'Business Constants Phase 1 Validation'
}, {
  Name: 'cColorConstantsPhase1Validation',
  Actual: msg.cColorConstantsPhase1Validation,
  Expected: 'Color Constants Phase 1 Validation'
}, {
  Name: 'cCommandConstantsPhase1Validation',
  Actual: msg.cCommandConstantsPhase1Validation,
  Expected: 'Command Constants Phase 1 Validation'
}, {
  Name: 'cConfigurationConstantsPhase1Validation',
  Actual: msg.cConfigurationConstantsPhase1Validation,
  Expected: 'Configuration Constants Phase 1 Validation'
}, {
  Name: 'cCountryConstantsPhase1Validation',
  Actual: msg.cCountryConstantsPhase1Validation,
  Expected: 'Country Constants Phase 1 Validation'
}, {
  Name: 'cElementConstantsPhase1Validation',
  Actual: msg.cElementConstantsPhase1Validation,
  Expected: 'Element Constants Phase 1 Validation'
}, {
  Name: 'cFunctionConstantsPhase1Validation',
  Actual: msg.cFunctionConstantsPhase1Validation,
  Expected: 'Function Constants Phase 1 Validation'
}, {
  Name: 'cGenericConstantsPhase1Validation',
  Actual: msg.cGenericConstantsPhase1Validation,
  Expected: 'Generic Constants Phase 1 Validation'
}, {
  Name: 'cIsotopeConstantsPhase1Validation',
  Actual: msg.cIsotopeConstantsPhase1Validation,
  Expected: 'Isotope Constants Phase 1 Validation'
}, {
  Name: 'cKnotConstantsPhase1Validation',
  Actual: msg.cKnotConstantsPhase1Validation,
  Expected: 'Knot Constants Phase 1 Validation'
}, {
  Name: 'cLanguageConstantsPhase1Validation',
  Actual: msg.cLanguageConstantsPhase1Validation,
  Expected: 'Language Constants Phase 1 Validation'
}, {
  Name: 'cMessageConstantsPhase1Validation',
  Actual: msg.cMessageConstantsPhase1Validation,
  Expected: 'Message Constants Phase 1 Validation'
}, {
  Name: 'cNumericConstantsPhase1Validation',
  Actual: msg.cNumericConstantsPhase1Validation,
  Expected: 'Numeric Constants Phase 1 Validation'
}, {
  Name: 'cPhonicConstantsPhase1Validation',
  Actual: msg.cPhonicConstantsPhase1Validation,
  Expected: 'Phonic Constants Phase 1 Validation'
}, {
  Name: 'cShapeConstantsPhase1Validation',
  Actual: msg.cShapeConstantsPhase1Validation,
  Expected: 'Shape Constants Phase 1 Validation'
}, {
  Name: 'cSystemConstantsPhase1Validation',
  Actual: msg.cSystemConstantsPhase1Validation,
  Expected: 'System Constants Phase 1 Validation'
}, {
  Name: 'cUnitConstantsPhase1Validation',
  Actual: msg.cUnitConstantsPhase1Validation,
  Expected: 'Unit Constants Phase 1 Validation'
}, {
  Name: 'cWord1ConstantsPhase1Validation',
  Actual: msg.cWord1ConstantsPhase1Validation,
  Expected: 'Word1 Constants Phase 1 Validation'
}, {
  Name: 'cBasicConstantsPhase2Validation',
  Actual: msg.cBasicConstantsPhase2Validation,
  Expected: 'Basic Constants Phase 2 Validation'
}, {
  Name: 'cBusinessConstantsPhase2Validation',
  Actual: msg.cBusinessConstantsPhase2Validation,
  Expected: 'Business Constants Phase 2 Validation'
}, {
  Name: 'cColorConstantsPhase2Validation',
  Actual: msg.cColorConstantsPhase2Validation,
  Expected: 'Color Constants Phase 2 Validation'
}, {
  Name: 'cCommandConstantsPhase2Validation',
  Actual: msg.cCommandConstantsPhase2Validation,
  Expected: 'Command Constants Phase 2 Validation'
}, {
  Name: 'cConfigurationConstantsPhase2Validation',
  Actual: msg.cConfigurationConstantsPhase2Validation,
  Expected: 'Configuration Constants Phase 2 Validation'
}, {
  Name: 'cCountryConstantsPhase2Validation',
  Actual: msg.cCountryConstantsPhase2Validation,
  Expected: 'Country Constants Phase 2 Validation'
}, {
  Name: 'cElementConstantsPhase2Validation',
  Actual: msg.cElementConstantsPhase2Validation,
  Expected: 'Element Constants Phase 2 Validation'
}, {
  Name: 'cFunctionConstantsPhase2Validation',
  Actual: msg.cFunctionConstantsPhase2Validation,
  Expected: 'Function Constants Phase 2 Validation'
}, {
  Name: 'cGenericConstantsPhase2Validation',
  Actual: msg.cGenericConstantsPhase2Validation,
  Expected: 'Generic Constants Phase 2 Validation'
}, {
  Name: 'cIsotopeConstantsPhase2Validation',
  Actual: msg.cIsotopeConstantsPhase2Validation,
  Expected: 'Isotope Constants Phase 2 Validation'
}, {
  Name: 'cKnotConstantsPhase2Validation',
  Actual: msg.cKnotConstantsPhase2Validation,
  Expected: 'Knot Constants Phase 2 Validation'
}, {
  Name: 'cLanguageConstantsPhase2Validation',
  Actual: msg.cLanguageConstantsPhase2Validation,
  Expected: 'Language Constants Phase 2 Validation'
}, {
  Name: 'cMessageConstantsPhase2Validation',
  Actual: msg.cMessageConstantsPhase2Validation,
  Expected: 'Message Constants Phase 2 Validation'
}, {
  Name: 'cNumericConstantsPhase2Validation',
  Actual: msg.cNumericConstantsPhase2Validation,
  Expected: 'Numeric Constants Phase 2 Validation'
}, {
  Name: 'cPhonicConstantsPhase2Validation',
  Actual: msg.cPhonicConstantsPhase2Validation,
  Expected: 'Phonic Constants Phase 2 Validation'
}, {
  Name: 'cShapeConstantsPhase2Validation',
  Actual: msg.cShapeConstantsPhase2Validation,
  Expected: 'Shape Constants Phase 2 Validation'
}, {
  Name: 'cSystemConstantsPhase2Validation',
  Actual: msg.cSystemConstantsPhase2Validation,
  Expected: 'System Constants Phase 2 Validation'
}, {
  Name: 'cUnitConstantsPhase2Validation',
  Actual: msg.cUnitConstantsPhase2Validation,
  Expected: 'Unit Constants Phase 2 Validation'
}, {
  Name: 'cWord1ConstantsPhase2Validation',
  Actual: msg.cWord1ConstantsPhase2Validation,
  Expected: 'Word1 Constants Phase 2 Validation'
}, {
  Name: 'ccommandStringIs',
  Actual: msg.ccommandStringIs,
  Expected: 'commandString is: '
}, {
  Name: 'ccommandDelimiterIs',
  Actual: msg.ccommandDelimiterIs,
  Expected: 'commandDelimiter is: '
}, {
  Name: 'ccommandToExecuteBeforeTheAliasIs',
  Actual: msg.ccommandToExecuteBeforeTheAliasIs,
  Expected: 'commandToExecute before the Alias is: '
}, {
  Name: 'ccommandToExecuteAfterTheAliasIs',
  Actual: msg.ccommandToExecuteAfterTheAliasIs,
  Expected: 'commandToExecute after the Alias is: '
}, {
  Name: 'cWarningTheSpecifiedCommand',
  Actual: msg.cWarningTheSpecifiedCommand,
  Expected: 'WARNING: The specified command: '
}, {
  Name: 'cdoesNotExistPleaseTryAgain',
  Actual: msg.cdoesNotExistPleaseTryAgain,
  Expected: ' does not exist, please try again!'
}, {
  Name: 'ccommandStringContainsEitherSingleQuoteOrBackTickQuote',
  Actual: msg.ccommandStringContainsEitherSingleQuoteOrBackTickQuote,
  Expected: 'commandString contains either a singleQuote or a backTickQuote'
}, {
  Name: 'ccommandStringContainsSingleQuote',
  Actual: msg.ccommandStringContainsSingleQuote,
  Expected: 'commandString contains a singleQuote!'
}, {
  Name: 'cnumberOfSingleQuotesIsEven',
  Actual: msg.cnumberOfSingleQuotesIsEven,
  Expected: 'numberOfSingleQuotes is >= 2 & the numberOfSingleQuotes is EVEN! YAY!'
}, {
  Name: 'cFirstIndexIs',
  Actual: msg.cFirstIndexIs,
  Expected: 'First index is: '
}, {
  Name: 'ccommandStringAfterTaggingTheFirstStringDelimiter',
  Actual: msg.ccommandStringAfterTaggingTheFirstStringDelimiter,
  Expected: 'commandString after tagging the first string delimiter: '
}, {
  Name: 'cAdditionalIndexIs',
  Actual: msg.cAdditionalIndexIs,
  Expected: 'Additional index is: '
}, {
  Name: 'coddIndex',
  Actual: msg.coddIndex,
  Expected: 'odd index'
}, {
  Name: 'cevenIndex',
  Actual: msg.cevenIndex,
  Expected: 'even index'
}, {
  Name: 'ccommandStringAfterTaggingAnOddStringDelimiter',
  Actual: msg.ccommandStringAfterTaggingAnOddStringDelimiter,
  Expected: 'commandString after tagging an odd string delimiter: '
}, {
  Name: 'ccommandStringAfterTaggingAnEvenStringDelimiter',
  Actual: msg.ccommandStringAfterTaggingAnEvenStringDelimiter,
  Expected: 'commandString after tagging an even string delimiter: '
}, {
  Name: 'cpreSplitCommandStringIs',
  Actual: msg.cpreSplitCommandStringIs,
  Expected: 'preSplitCommandString is: '
}, {
  Name: 'cpostSplitCommandStringIs',
  Actual: msg.cpostSplitCommandStringIs,
  Expected: 'postSplitCommandString[k] is: '
}, {
  Name: 'cpreSplitCommandStringElementIs',
  Actual: msg.cpreSplitCommandStringElementIs,
  Expected: 'preSplitCommandStringElement is: '
}, {
  Name: 'cDoingStraightSplitCommandString',
  Actual: msg.cDoingStraightSplitCommandString,
  Expected: 'Doing a straight split of the commandString: '
}, {
  Name: 'cCommandStartTimeIs',
  Actual: msg.cCommandStartTimeIs,
  Expected: 'Command Start time is: '
}, {
  Name: 'cCommandEndTimeIs',
  Actual: msg.cCommandEndTimeIs,
  Expected: 'Command End time is: '
}, {
  Name: 'cCommandRunTimeIs',
  Actual: msg.cCommandRunTimeIs,
  Expected: 'Command run-time is: '
}, {
  Name: 'ccommandAliasesFilePathConfigurationNameIs',
  Actual: msg.ccommandAliasesFilePathConfigurationNameIs,
  Expected: 'commandAliasesFilePathConfigurationName is: '
}, {
  Name: 'ccommandIs',
  Actual: msg.ccommandIs,
  Expected: 'command is: '
}, {
  Name: 'ccommandToExecuteIs',
  Actual: msg.ccommandToExecuteIs,
  Expected: 'commandToExecute is: '
}, {
  Name: 'ccommandArgsIs',
  Actual: msg.ccommandArgsIs,
  Expected: 'commandArgs is: '
}, {
  Name: 'celseClauseLookingForCommandAliases',
  Actual: msg.celseClauseLookingForCommandAliases,
  Expected: 'else-clause looking for command aliases.'
}, {
  Name: 'callCommandAliasesIs',
  Actual: msg.callCommandAliasesIs,
  Expected: 'allCommandAliases is: '
}, {
  Name: 'ccontextNameIs',
  Actual: msg.ccontextNameIs,
  Expected: 'contextName is: '
}, {
  Name: 'callXmlDataIs',
  Actual: msg.callXmlDataIs,
  Expected: 'allXmlData is: '
}, {
  Name: 'cdataPathConfigurationNameIs',
  Actual: msg.cdataPathConfigurationNameIs,
  Expected: 'dataPathConfigurationName is: '
}, {
  Name: 'cdataPathIs',
  Actual: msg.cdataPathIs,
  Expected: 'dataPath is: '
}, {
  Name: 'cfilesFoundIs',
  Actual: msg.cfilesFoundIs,
  Expected: 'filesFound is: '
}, {
  Name: 'cfileToLoadIs',
  Actual: msg.cfileToLoadIs,
  Expected: 'fileToLoad is: '
}, {
  Name: 'cfilesToLoadIs',
  Actual: msg.cfilesToLoadIs,
  Expected: 'filesToLoad is: '
}, {
  Name: 'cdataFileToMergeIs',
  Actual: msg.cdataFileToMergeIs,
  Expected: 'dataFile to merge is: '
}, {
  Name: 'cparsedDataFileIs',
  Actual: msg.cparsedDataFileIs,
  Expected: 'parsedDataFile is: '
}, {
  Name: 'cexecuteBusinessRules',
  Actual: msg.cexecuteBusinessRules,
  Expected: 'execute business rules: '
}, {
  Name: 'cdataFileIs',
  Actual: msg.cdataFileIs,
  Expected: 'dataFile is: '
}, {
  Name: 'cmergedDataIs',
  Actual: msg.cmergedDataIs,
  Expected: 'mergedData is: '
}, {
  Name: 'cdebugConfigurationSettingValueIs',
  Actual: msg.cdebugConfigurationSettingValueIs,
  Expected: 'debugConfigurationSettingValue is: '
}, {
  Name: 'cclientRootPathIs',
  Actual: msg.cclientRootPathIs,
  Expected: 'clientRootPath is: '
}, {
  Name: 'cappConfigResourcesPathIs',
  Actual: msg.cappConfigResourcesPathIs,
  Expected: 'appConfigResourcesPath is: '
}, {
  Name: 'cappConfigReferencePathIs',
  Actual: msg.cappConfigReferencePathIs,
  Expected: 'appConfigReferencePath is: '
}, {
  Name: 'cclientMetaDataPathIs',
  Actual: msg.cclientMetaDataPathIs,
  Expected: 'clientMetaDataPath is: '
}, {
  Name: 'cclientCommandAliasesPathIs',
  Actual: msg.cclientCommandAliasesPathIs,
  Expected: 'clientCommandAliasesPath is: '
}, {
  Name: 'cclientWorkflowsPathIs',
  Actual: msg.cclientWorkflowsPathIs,
  Expected: 'clientWorkflowsPath is: '
}, {
  Name: 'cframeworkRootPathIs',
  Actual: msg.cframeworkRootPathIs,
  Expected: 'frameworkRootPath is: '
}, {
  Name: 'cappConfigPathIs',
  Actual: msg.cappConfigPathIs,
  Expected: 'appConfigPath is: '
}, {
  Name: 'cframeworkResourcesPathIs',
  Actual: msg.cframeworkResourcesPathIs,
  Expected: 'frameworkResourcesPath is: '
}, {
  Name: 'cframeworkFullMetaDataPathIs',
  Actual: msg.cframeworkFullMetaDataPathIs,
  Expected: 'frameworkFullMetaDataPath is: '
}, {
  Name: 'cframeworkConfigPathIs',
  Actual: msg.cframeworkConfigPathIs,
  Expected: 'frameworkConfigPath is: '
}, {
  Name: 'cframeworkCommandAliasesPathIs',
  Actual: msg.cframeworkCommandAliasesPathIs,
  Expected: 'frameworkCommandAliasesPath is: '
}, {
  Name: 'cframeworkWorkflowsPathIs',
  Actual: msg.cframeworkWorkflowsPathIs,
  Expected: 'frameworkWorkflowsPath is: '
}, {
  Name: 'ccommandAliasesPathIs',
  Actual: msg.ccommandAliasesPathIs,
  Expected: 'commandAliasesPath is: '
}, {
  Name: 'cworkflowPathIs',
  Actual: msg.cworkflowPathIs,
  Expected: 'workflowPath is: '
}, {
  Name: 'cALL_DATA_IS',
  Actual: msg.cALL_DATA_IS,
  Expected: 'ALL DATA IS: '
}, {
  Name: 'cAllLoadedDataIs',
  Actual: msg.cAllLoadedDataIs,
  Expected: 'All loaded data is: '
}, {
  Name: 'cconfigDataIs',
  Actual: msg.cconfigDataIs,
  Expected: 'configData is: '
}, {
  Name: 'cERROR',
  Actual: msg.cERROR,
  Expected: 'ERROR: '
}, {
  Name: 'cErrorInvalidAccessTo',
  Actual: msg.cErrorInvalidAccessTo,
  Expected: 'ERROR: Invalid access to: '
}, {
  Name: 'crootPathIs',
  Actual: msg.crootPathIs,
  Expected: 'rootPath is: '
}, {
  Name: 'caskIs',
  Actual: msg.caskIs,
  Expected: 'ask is: '
}, {
  Name: 'cINPUT',
  Actual: msg.cINPUT,
  Expected: 'INPUT: '
}, {
  Name: 'cinputIs',
  Actual: msg.cinputIs,
  Expected: 'input is: '
}, {
  Name: 'cstartTimeIs',
  Actual: msg.cstartTimeIs,
  Expected: 'startTime is: '
}, {
  Name: 'cendTimeIs',
  Actual: msg.cendTimeIs,
  Expected: 'endTime is: '
}, {
  Name: 'cdeltaTimeResultIs',
  Actual: msg.cdeltaTimeResultIs,
  Expected: 'deltaTimeResult is: '
}, {
  Name: 'cclientConfigurationIs',
  Actual: msg.cclientConfigurationIs,
  Expected: 'clientConfiguration is: '
}, ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
{
  Name: 'cloadedAndMergedDataAllFilesIs',
  Actual: msg.cloadedAndMergedDataAllFilesIs,
  Expected: 'loadedAndMergedDataAllFiles is: '
}, {
  Name: 'cloadedAndMergedDataAllFilesContentsAre',
  Actual: msg.cloadedAndMergedDataAllFilesContentsAre,
  Expected: 'loadedAndMergedDataAllFiles contents are: '
}, {
  Name: 'ccommandWorkflowFilePathConfigurationNameIs',
  Actual: msg.ccommandWorkflowFilePathConfigurationNameIs,
  Expected: 'commandWorkflowFilePathConfigurationName is: '
}, {
  Name: 'ccontentsOfDataStructreIs',
  Actual: msg.ccontentsOfDataStructreIs,
  Expected: 'contents of D-data structure is: '
}, {
  Name: 'cclientBusinessRulesAre',
  Actual: msg.cclientBusinessRulesAre,
  Expected: 'clientBusinessRules are: '
}, {
  Name: 'cclientCommandsAre',
  Actual: msg.cclientCommandsAre,
  Expected: 'clientCommands are: '
}, {
  Name: 'ccommandAliasesPathConfigNameIs',
  Actual: msg.ccommandAliasesPathConfigNameIs,
  Expected: 'commandAliasesPathConfigName is: '
}, {
  Name: 'cresolvedSystemCommandsAliasesPathIs',
  Actual: msg.cresolvedSystemCommandsAliasesPathIs,
  Expected: 'resolvedSystemCommandsAliasesPath is: '
}, {
  Name: 'cresolvedClientCommandsAliasesPathIs',
  Actual: msg.cresolvedClientCommandsAliasesPathIs,
  Expected: 'resolvedClientCommandsAliasesPath is: '
}, {
  Name: 'cresolvedCustomCommandsAliasesPathIs',
  Actual: msg.cresolvedCustomCommandsAliasesPathIs,
  Expected: 'resolvedCustomCommandsAliasesPath is: '
}, {
  Name: 'cworkflowPathConfigurationNameIs',
  Actual: msg.cworkflowPathConfigurationNameIs,
  Expected: 'workflowPathConfigurationName is: '
}, {
  Name: 'cresolvedSystemWorkflowsPathIs',
  Actual: msg.cresolvedSystemWorkflowsPathIs,
  Expected: 'resolvedSystemWorkflowsPath is: '
}, {
  Name: 'cresolvedClientWorkflowsPathIs',
  Actual: msg.cresolvedClientWorkflowsPathIs,
  Expected: 'resolvedClientWorkflowsPath is: '
}, {
  Name: 'cresolvedCustomWorkflowsPathIs',
  Actual: msg.cresolvedCustomWorkflowsPathIs,
  Expected: 'resolvedCustomWorkflowsPath is: '
}, {
  Name: 'cbusinessRuleIs',
  Actual: msg.cbusinessRuleIs,
  Expected: 'businessRule is: '
}, {
  Name: 'cruleInputIs',
  Actual: msg.cruleInputIs,
  Expected: 'ruleInput is: '
}, {
  Name: 'cruleMetaDataIs',
  Actual: msg.cruleMetaDataIs,
  Expected: 'ruleMetaData is: '
}, {
  Name: 'cconfigurationNamespaceIs',
  Actual: msg.cconfigurationNamespaceIs,
  Expected: 'configurationNamespace is: '
}, {
  Name: 'cconfigurationNameIs',
  Actual: msg.cconfigurationNameIs,
  Expected: 'configurationName is: '
}, {
  Name: 'cconfigurationValueIs',
  Actual: msg.cconfigurationValueIs,
  Expected: 'configurationValue is: '
}, {
  Name: 'creturnConfiguraitonValueIs',
  Actual: msg.creturnConfiguraitonValueIs,
  Expected: 'returnConfigurationValue is: '
}, {
  Name: 'cattributeJsonStringIs',
  Actual: msg.cattributeJsonStringIs,
  Expected: 'attributeJsonString is: '
}, {
  Name: 'cappAttributeNameIs',
  Actual: msg.cappAttributeNameIs,
  Expected: 'appAttributeName is: '
}, {
  Name: 'cappAttributeValueIs',
  Actual: msg.cappAttributeValueIs,
  Expected: 'appAttributeValue is: '
}, {
  Name: 'cexecuteBusinessRulesColon',
  Actual: msg.cexecuteBusinessRulesColon,
  Expected: 'execute business rules: '
}, {
  Name: 'cdataPathAfterBusinessRulesProcessingIs',
  Actual: msg.cdataPathAfterBusinessRulesProcessingIs,
  Expected: 'dataPath after business rules processing is: '
}, {
  Name: 'cFileToLoadIs',
  Actual: msg.cFileToLoadIs,
  Expected: 'File to load is: '
}, {
  Name: 'cfileExtensionIs',
  Actual: msg.cfileExtensionIs,
  Expected: 'fileExtension is: '
}, {
  Name: 'cexecuteBusienssRulesColon',
  Actual: msg.cexecuteBusienssRulesColon,
  Expected: 'executeBusinessRules: '
}, {
  Name: 'cloadedFileDataIs',
  Actual: msg.cloadedFileDataIs,
  Expected: 'loaded file data is: '
}, {
  Name: 'cBEGIN_PROCESSING_ADDITIONAL_DATA',
  Actual: msg.cBEGIN_PROCESSING_ADDITIONAL_DATA,
  Expected: 'BEGIN PROCESSING ADDITIONAL DATA'
}, {
  Name: 'cDONE_PROCESSING_ADDITIONAL_DATA',
  Actual: msg.cDONE_PROCESSING_ADDITIONAL_DATA,
  Expected: 'DONE PROCESSING ADDITIONAL DATA'
}, {
  Name: 'cMERGED_dataIs',
  Actual: msg.cMERGED_dataIs,
  Expected: 'MERGED data is: '
}, {
  Name: 'cparsedDataFileContentsAre',
  Actual: msg.cparsedDataFileContentsAre,
  Expected: 'parsedDataFile contents are: '
}, {
  Name: 'cdataCatagoryIs',
  Actual: msg.cdataCatagoryIs,
  Expected: 'dataCatagory is: '
}, {
  Name: 'cfullyParsedDataIs',
  Actual: msg.cfullyParsedDataIs,
  Expected: 'fully parsed data is: '
}, {
  Name: 'cD_finalMergeIs',
  Actual: msg.cD_finalMergeIs,
  Expected: 'D final merge is: '
}, {
  Name: 'cdataStorageContextNameIs',
  Actual: msg.cdataStorageContextNameIs,
  Expected: 'dataStorageContextName is: '
}, {
  Name: 'cdataToStoreIs',
  Actual: msg.cdataToStoreIs,
  Expected: 'dataToStore is: '
}, {
  Name: 'cdataCatagoryDetailsNameIs',
  Actual: msg.cdataCatagoryDetailsNameIs,
  Expected: 'dataCatagoryDetailsName is: '
}, {
  Name: 'ctempDataIs',
  Actual: msg.ctempDataIs,
  Expected: 'tempData is: '
}, {
  Name: 'ctargetDataIs',
  Actual: msg.ctargetDataIs,
  Expected: 'targetData is: '
}, {
  Name: 'cpageNameIs',
  Actual: msg.cpageNameIs,
  Expected: 'pageName is: '
}, {
  Name: 'cdataToMergeIs',
  Actual: msg.cdataToMergeIs,
  Expected: 'data to Merge is: '
}, {
  Name: 'cdataToMergeElementCountIs',
  Actual: msg.cdataToMergeElementCountIs,
  Expected: 'dataToMergeElementCount is: '
}, {
  Name: 'cdataToMergeElementCountIs1',
  Actual: msg.cdataToMergeElementCountIs1,
  Expected: 'dataToMergeElementCount is: 1'
}, {
  Name: 'ccheckIfThePageNameIsNotAnEmptyString',
  Actual: msg.ccheckIfThePageNameIsNotAnEmptyString,
  Expected: 'check if the pageName is not an empty string'
}, {
  Name: 'cpageNameIsNotAnEmptyString',
  Actual: msg.cpageNameIsNotAnEmptyString,
  Expected: 'pageName is not an empty string'
}, {
  Name: 'cCheckIfTheDataCatagoryIsAnEmptyStringOrNot',
  Actual: msg.cCheckIfTheDataCatagoryIsAnEmptyStringOrNot,
  Expected: 'Check if the dataCatagory is an empty string or not'
}, {
  Name: 'cdataCatagoryIsNotAnEmptyString',
  Actual: msg.cdataCatagoryIsNotAnEmptyString,
  Expected: 'dataCatagory is not an empty string!'
}, {
  Name: 'cdataCatagoryIsAnEmptyString',
  Actual: msg.cdataCatagoryIsAnEmptyString,
  Expected: 'dataCatagory IS an empty string!'
}, {
  Name: 'ctargetDataContentIs',
  Actual: msg.ctargetDataContentIs,
  Expected: 'targetData content is: '
}, {
  Name: 'cafterAttemptToMergeResultsAre',
  Actual: msg.cafterAttemptToMergeResultsAre,
  Expected: 'after attempt to merge, results are: '
}, {
  Name: 'cMergedDataIs',
  Actual: msg.cMergedDataIs,
  Expected: 'Merged data is: '
}, {
  Name: 'cpageNameIsAnEmptyString',
  Actual: msg.cpageNameIsAnEmptyString,
  Expected: 'pageName is an empty string'
}, {
  Name: 'cCaughtTheSpecialCaseThatWeAreMergingFlatList',
  Actual: msg.cCaughtTheSpecialCaseThatWeAreMergingFlatList,
  Expected: 'Caught the special case that we are merging a flat list.'
}, {
  Name: 'cinsideTheForLoop',
  Actual: msg.cinsideTheForLoop,
  Expected: 'inside the for-loop'
}, {
  Name: 'ckeyIs',
  Actual: msg.ckeyIs,
  Expected: 'key is: '
}, {
  Name: 'ctargetDataIsModifiedInTheInputPassByReferenceVariableContentIs',
  Actual: msg.ctargetDataIsModifiedInTheInputPassByReferenceVariableContentIs,
  Expected: 'targetData is modified in the input pass-by-reference variable content is: '
}, {
  Name: 'cdataObjectValueIs',
  Actual: msg.cdataObjectValueIs,
  Expected: 'dataObject value is: '
}, {
  Name: 'celementNameIs',
  Actual: msg.celementNameIs,
  Expected: 'elementName is: '
}, {
  Name: 'cdataObjectIs',
  Actual: msg.cdataObjectIs,
  Expected: 'dataObject is: '
}, {
  Name: 'celementNamePatternIs',
  Actual: msg.celementNamePatternIs,
  Expected: 'elementNamePattern is: '
}, {
  Name: 'celementCountIs',
  Actual: msg.celementCountIs,
  Expected: 'elementCount is: '
}, {
  Name: 'cERROR_Colon',
  Actual: msg.cERROR_Colon,
  Expected: 'ERROR: '
}, {
  Name: 'cfileAndPathToLoadFromIs',
  Actual: msg.cfileAndPathToLoadFromIs,
  Expected: 'file and path to load from is: '
}, {
  Name: 'cDoneLoadingDataFrom',
  Actual: msg.cDoneLoadingDataFrom,
  Expected: 'DONE loading data from: '
}, {
  Name: 'cfileAndPathToWriteDataToIs',
  Actual: msg.cfileAndPathToWriteDataToIs,
  Expected: 'file and path to write data to is: '
}, {
  Name: 'cdataToWriteIs',
  Actual: msg.cdataToWriteIs,
  Expected: 'data to write is: '
}, {
  Name: 'cDataWasWrittenToTheFile',
  Actual: msg.cDataWasWrittenToTheFile,
  Expected: 'Data was written to the file: '
}, {
  Name: 'cPathThatShouldBeScannedIs',
  Actual: msg.cPathThatShouldBeScannedIs,
  Expected: 'Path that should be scanned is: '
}, {
  Name: 'cfilesFoundAre',
  Actual: msg.cfilesFoundAre,
  Expected: 'files found are: '
}, {
  Name: 'cdirectorIs',
  Actual: msg.cdirectorIs,
  Expected: 'directory is: '
}, {
  Name: 'cdirectoryPathIs',
  Actual: msg.cdirectoryPathIs,
  Expected: 'directoryPath is: '
}, {
  Name: 'csourceFolderIs',
  Actual: msg.csourceFolderIs,
  Expected: 'sourceFolder is: '
}, {
  Name: 'cdestinationFolderIs',
  Actual: msg.cdestinationFolderIs,
  Expected: 'destinationFolder is: '
}, {
  Name: 'ccopySuccessIs',
  Actual: msg.ccopySuccessIs,
  Expected: 'copySuccess is: '
}, {
  Name: 'ccurrentVersionIs',
  Actual: msg.ccurrentVersionIs,
  Expected: 'current version is: '
}, {
  Name: 'creleasedArchiveFilesListIs',
  Actual: msg.creleasedArchiveFilesListIs,
  Expected: 'released archive files list is: '
}, {
  Name: 'cfileIs',
  Actual: msg.cfileIs,
  Expected: 'file is: '
}, {
  Name: 'cfileNameIs',
  Actual: msg.cfileNameIs,
  Expected: 'fileName is: '
}, {
  Name: 'creleaseFilesListIs',
  Actual: msg.creleaseFilesListIs,
  Expected: 'release files list is: '
}, {
  Name: 'creleaseDateTimeStampIs',
  Actual: msg.creleaseDateTimeStampIs,
  Expected: 'release date-time stamp is: '
}, {
  Name: 'creleaseFileNameIs',
  Actual: msg.creleaseFileNameIs,
  Expected: 'release fileName is: '
}, {
  Name: 'cDoneWritingTheZipFile',
  Actual: msg.cDoneWritingTheZipFile,
  Expected: 'Done writing the zip file: '
}, {
  Name: 'cSetTheReturnPackageSuccessFlagToTrue',
  Actual: msg.cSetTheReturnPackageSuccessFlagToTrue,
  Expected: 'Set the return packageSuccess flag to TRUE'
}, {
  Name: 'ccurrentVersionAlreadyReleased',
  Actual: msg.ccurrentVersionAlreadyReleased,
  Expected: 'current version already released'
}, {
  Name: 'cpackageSuccessIs',
  Actual: msg.cpackageSuccessIs,
  Expected: 'packageSuccess is: '
}, {
  Name: 'cRootPathBeforeProcessingIs',
  Actual: msg.cRootPathBeforeProcessingIs,
  Expected: 'RootPath before processing is: '
}, {
  Name: 'cRootPathAfterProcessingIs',
  Actual: msg.cRootPathAfterProcessingIs,
  Expected: 'RootPath after processing is: '
}, {
  Name: 'cSourceIs',
  Actual: msg.cSourceIs,
  Expected: 'source is: '
}, {
  Name: 'ctargetIs',
  Actual: msg.ctargetIs,
  Expected: 'target is: '
}, {
  Name: 'cErrorCouldNotCopyFile',
  Actual: msg.cErrorCouldNotCopyFile,
  Expected: 'ERROR: Could not copy file: '
}, {
  Name: 'cErrorCouldNotCreateFolder',
  Actual: msg.cErrorCouldNotCreateFolder,
  Expected: 'ERROR: Could not create folder: '
}, {
  Name: 'csuccessfulCopyIs',
  Actual: msg.csuccessfulCopyIs,
  Expected: 'successfulCopy is: '
}, {
  Name: 'cErrorCouldNotCopyFolderContents',
  Actual: msg.cErrorCouldNotCopyFolderContents,
  Expected: 'ERROR: Could not copy folder contents: '
}, {
  Name: 'cargumentValueIs',
  Actual: msg.cargumentValueIs,
  Expected: 'argumentValue is: '
}, {
  Name: 'cconsolidatedArgumentModeIs',
  Actual: msg.cconsolidatedArgumentModeIs,
  Expected: 'consolidatedArgumentMode is: '
}, {
  Name: 'cPushingArgumentValueToReturnDataAsArrayElement',
  Actual: msg.cPushingArgumentValueToReturnDataAsArrayElement,
  Expected: 'Pushing the argumentValue to the returnData as an array element'
}, {
  Name: 'cargumentValueLengthGreaterThanZero',
  Actual: msg.cargumentValueLengthGreaterThanZero,
  Expected: 'argumentValue.length > 0'
}, {
  Name: 'cCallingAnalyzeArgumentIndexIs',
  Actual: msg.cCallingAnalyzeArgumentIndexIs,
  Expected: 'Calling analyzeArgumentIndex is: '
}, {
  Name: 'cReturnArgumentValueSameAsItWasPassedIn',
  Actual: msg.cReturnArgumentValueSameAsItWasPassedIn,
  Expected: 'Return the argumentValue the same as it was passed in.'
}, {
  Name: 'cCheckIfThereAreBracketsOrNoBrackets',
  Actual: msg.cCheckIfThereAreBracketsOrNoBrackets,
  Expected: 'Check if there are brackets or no brackets.'
}, {
  Name: 'cBracketsWereFound',
  Actual: msg.cBracketsWereFound,
  Expected: 'Brackets were found'
}, {
  Name: 'cCheckIfThereIsRegularExpressionOrNot',
  Actual: msg.cCheckIfThereIsRegularExpressionOrNot,
  Expected: 'Check if there is a Regular Expression or not.'
}, {
  Name: 'cRegularExpressionWasFound',
  Actual: msg.cRegularExpressionWasFound,
  Expected: 'A regular expression was found!'
}, {
  Name: 'cNoRegExpFound',
  Actual: msg.cNoRegExpFound,
  Expected: 'NO RegExp found!'
}, {
  Name: 'cBracketsAreFound',
  Actual: msg.cBracketsAreFound,
  Expected: 'Brackets ARE found!'
}, {
  Name: 'cNoSecondaryCommandArgumentDelimiters',
  Actual: msg.cNoSecondaryCommandArgumentDelimiters,
  Expected: 'NO secondary command argument delimiters.'
}, {
  Name: 'cregularExpressionIs',
  Actual: msg.cregularExpressionIs,
  Expected: 'regular expression is: '
}, {
  Name: 'cregExValueIs',
  Actual: msg.cregExValueIs,
  Expected: 'regExValue is: '
}, {
  Name: 'cregularExpressionFlagsAre',
  Actual: msg.cregularExpressionFlagsAre,
  Expected: 'regular expression flags are: '
}, {
  Name: 'cregExFlagsIs',
  Actual: msg.cregExFlagsIs,
  Expected: 'regExFlags is: '
}, {
  Name: 'cargumentValueContainsTheDelimiterLetsSplitIt',
  Actual: msg.cargumentValueContainsTheDelimiterLetsSplitIt,
  Expected: 'argumentValue contains the delimiter, lets split it!'
}, {
  Name: 'cargumentValueAfterAttemptingToRemoveOpenBracketFromAllArrayElementsIs',
  Actual: msg.cargumentValueAfterAttemptingToRemoveOpenBracketFromAllArrayElementsIs,
  Expected: 'argumentValue after attempting to remove a open bracket from all array elements is: '
}, {
  Name: 'cargumentValueAfterAttemptingToRemoveCloseBracketFromAllArrayElementsIs',
  Actual: msg.cargumentValueAfterAttemptingToRemoveCloseBracketFromAllArrayElementsIs,
  Expected: 'argumentValue after attempting to remove a close bracket from all array elements is: '
}, {
  Name: 'csecondaryCommandArgsDelimiterIs',
  Actual: msg.csecondaryCommandArgsDelimiterIs,
  Expected: 'secondaryCommandArgsDelimiter is: '
}, {
  Name: 'cargumentArrayIs',
  Actual: msg.cargumentArrayIs,
  Expected: 'argumentArray is: '
}, {
  Name: 'cformattingIs',
  Actual: msg.cformattingIs,
  Expected: 'formatting is: '
}, {
  Name: 'cdeltaTimeIs',
  Actual: msg.cdeltaTimeIs,
  Expected: 'deltaTime is: '
}, {
  Name: 'cformatIs',
  Actual: msg.cformatIs,
  Expected: 'format is: '
}, {
  Name: 'creturnDeltaTimeIs',
  Actual: msg.creturnDeltaTimeIs,
  Expected: 'returnDeltaTime is: '
}, {
  Name: 'csleepTimeIs',
  Actual: msg.csleepTimeIs,
  Expected: 'sleepTime is: '
}, {
  Name: 'cworkflowNameIs',
  Actual: msg.cworkflowNameIs,
  Expected: 'workflowName is: '
}, {
  Name: 'ccurrentWorkflowIs',
  Actual: msg.ccurrentWorkflowIs,
  Expected: 'currentWorkflow is: '
}, {
  Name: 'cworkflowValueIs',
  Actual: msg.cworkflowValueIs,
  Expected: 'workflowValue is: '
}, {
  Name: 'cdataHivePathArrayIs',
  Actual: msg.cdataHivePathArrayIs,
  Expected: 'dataHivePathArray is: '
}, {
  Name: 'ccontentsOfLeafDataHiveElementIs',
  Actual: msg.ccontentsOfLeafDataHiveElementIs,
  Expected: 'contents of leafDataHiveElement is: '
}, {
  Name: 'centryIs',
  Actual: msg.centryIs,
  Expected: 'entry is: '
}, {
  Name: 'cattributeValueIs',
  Actual: msg.cattributeValueIs,
  Expected: 'attributeValue is: '
}, {
  Name: 'ckey1Is',
  Actual: msg.ckey1Is,
  Expected: 'key1 is: '
}, {
  Name: 'ckey2Is',
  Actual: msg.ckey2Is,
  Expected: 'key2 is: '
}, {
  Name: 'centityIs',
  Actual: msg.centityIs,
  Expected: 'entity is: '
}, {
  Name: 'cqueueNameSpaceIs',
  Actual: msg.cqueueNameSpaceIs,
  Expected: 'queueNameSpace is: '
}, {
  Name: 'cstackNameSpaceIs',
  Actual: msg.cstackNameSpaceIs,
  Expected: 'stackNameSpace is: '
}, {
  Name: 'cWarningStackColon',
  Actual: msg.cWarningStackColon,
  Expected: 'WARNING: Stack: '
}, {
  Name: 'cAlreadyExists',
  Actual: msg.cAlreadyExists,
  Expected: ' ALREADY exist!'
}, {
  Name: 'cdoesNotExist',
  Actual: msg.cdoesNotExist,
  Expected: ' does not exist!'
}, {
  Name: 'cisEmpty',
  Actual: msg.cisEmpty,
  Expected: ' is empty!'
}, {
  Name: 'cContentsOfTheStackNamespace',
  Actual: msg.cContentsOfTheStackNamespace,
  Expected: 'Contents of the stack namespace: '
}, {
  Name: 'cwordDelimiterIs',
  Actual: msg.cwordDelimiterIs,
  Expected: 'wordDelimiter is: '
}, {
  Name: 'cstringContainsAcronymIs',
  Actual: msg.cstringContainsAcronymIs,
  Expected: 'stringContainsAcronym is: '
}, {
  Name: 'cErrorZipPackageReleaseFailed',
  Actual: msg.cErrorZipPackageReleaseFailed,
  Expected: 'ERROR: Zip package release failed: '
}, {
  Name: 'cminimumColorRangeIs',
  Actual: msg.cminimumColorRangeIs,
  Expected: 'minimumColorRange is: '
}, {
  Name: 'cmaximumColorRangeIs',
  Actual: msg.cmaximumColorRangeIs,
  Expected: 'maximumColorRange is: '
}, {
  Name: 'callSystemConstantsValidationDataIs',
  Actual: msg.callSystemConstantsValidationDataIs,
  Expected: 'allSystemConstantsValidationData is: '
}, {
  Name: 'callClientConstantsValidationDataIs',
  Actual: msg.callClientConstantsValidationDataIs,
  Expected: 'allClientConstantsValidationData is: '
}, {
  Name: 'cconstantLibraryDataIs',
  Actual: msg.cconstantLibraryDataIs,
  Expected: 'constantLibraryData is: '
}, {
  Name: 'cclientValidationDataIs',
  Actual: msg.cclientValidationDataIs,
  Expected: 'clientValidationData is: '
}, {
  Name: 'carrayValidationDataIs',
  Actual: msg.carrayValidationDataIs,
  Expected: 'arrayValidationData is: '
}, {
  Name: 'cfilesListLimitIs',
  Actual: msg.cfilesListLimitIs,
  Expected: 'filesListLimit is: '
}, {
  Name: 'cenableLimitIs',
  Actual: msg.cenableLimitIs,
  Expected: 'enableLimit is: '
}, {
  Name: 'cfilesLimitIs',
  Actual: msg.cfilesLimitIs,
  Expected: 'filesLimit is: '
}, {
  Name: 'cinputDataRightBeforeProcessingIs',
  Actual: msg.cinputDataRightBeforeProcessingIs,
  Expected: 'inputData right before processing is: '
}, {
  Name: 'cnumberIs',
  Actual: msg.cnumberIs,
  Expected: 'number is: '
}, {
  Name: 'capplicationMetaDataPathAndFilenameIs',
  Actual: msg.capplicationMetaDataPathAndFilenameIs,
  Expected: 'applicationMetaDataPathAndFilename is: '
}, {
  Name: 'cframeworkMetaDataPathAndFilenameIs',
  Actual: msg.cframeworkMetaDataPathAndFilenameIs,
  Expected: 'frameworkMetaDataPathAndFilename is: '
}, {
  Name: 'capplicationMetaDataIs',
  Actual: msg.capplicationMetaDataIs,
  Expected: 'applicationMetaData is: '
}, {
  Name: 'cframeworkMetaDataIs',
  Actual: msg.cframeworkMetaDataIs,
  Expected: 'frameworkMetaData is: '
}, {
  Name: 'cApplicationNameIs',
  Actual: msg.cApplicationNameIs,
  Expected: 'ApplicationName is: '
}, {
  Name: 'cApplicationVersionNumberIs',
  Actual: msg.cApplicationVersionNumberIs,
  Expected: 'ApplicationVersionNumber is: '
}, {
  Name: 'cApplicationDescriptionIs',
  Actual: msg.cApplicationDescriptionIs,
  Expected: 'ApplicationDescription is: '
}, {
  Name: 'cFrameworkNameIs',
  Actual: msg.cFrameworkNameIs,
  Expected: 'FrameworkName is: '
}, {
  Name: 'cFrameworkVersionNumberIs',
  Actual: msg.cFrameworkVersionNumberIs,
  Expected: 'FrameworkVersionNumber is: '
}, {
  Name: 'cFrameworkDescriptionIs',
  Actual: msg.cFrameworkDescriptionIs,
  Expected: 'FrameworkDescription is: '
}, {
  Name: 'csessionDateTimeStampIs',
  Actual: msg.csessionDateTimeStampIs,
  Expected: 'sessionDateTimeStamp is: '
}, {
  Name: 'clogFileNameIs',
  Actual: msg.clogFileNameIs,
  Expected: 'logFileName is: '
}, {
  Name: 'cprimaryCommandDelimiterIs',
  Actual: msg.cprimaryCommandDelimiterIs,
  Expected: 'primaryCommandDelimiter is: '
}, {
  Name: 'csecondaryCommandDelimiterIs',
  Actual: msg.csecondaryCommandDelimiterIs,
  Expected: 'secondaryCommandDelimiter is: '
}, {
  Name: 'ctertiaryCommandDelimiterIs',
  Actual: msg.ctertiaryCommandDelimiterIs,
  Expected: 'tertiaryCommandDelimiter is: '
}, {
  Name: 'ccommandSequencerCommandToEnqueueIs',
  Actual: msg.ccommandSequencerCommandToEnqueueIs,
  Expected: 'commandSequencer Command To Enqueue is: '
}, {
  Name: 'cWarningMessageIsUndefined',
  Actual: msg.cWarningMessageIsUndefined,
  Expected: 'WARNING: message is undefined'
}, {
  Name: 'cclassPathIs',
  Actual: msg.cclassPathIs,
  Expected: 'classPath is: '
}, {
  Name: 'cargsArrayContainsRegEx1Is',
  Actual: msg.cargsArrayContainsRegEx1Is,
  Expected: 'argsArrayContainsRegEx1 is: '
}, {
  Name: 'cargsArrayContainsRegEx2Is',
  Actual: msg.cargsArrayContainsRegEx2Is,
  Expected: 'argsArrayContainsRegEx2 is: '
}, {
  Name: 'cargsArrayContainsColonIs',
  Actual: msg.cargsArrayContainsColonIs,
  Expected: 'argsArrayContainsColon is: '
}, {
  Name: 'cfileToSaveToIs',
  Actual: msg.cfileToSaveToIs,
  Expected: 'fileToSaveTo is: '
}, {
  Name: 'cdataToWriteOutIs',
  Actual: msg.cdataToWriteOutIs,
  Expected: 'dataToWriteOut is: '
}, {
  Name: 'clogFilePathAndNameIs',
  Actual: msg.clogFilePathAndNameIs,
  Expected: 'logFilePathAndName is: '
}, {
  Name: 'cmetaDataOutputIs',
  Actual: msg.cmetaDataOutputIs,
  Expected: 'metaDataOutput is: '
}, {
  Name: 'callCommandAliasesDataIs',
  Actual: msg.callCommandAliasesDataIs,
  Expected: 'allCommandAliasesData is: '
}, {
  Name: 'cresolvedFrameworkConstantsPathActualIs',
  Actual: msg.cresolvedFrameworkConstantsPathActualIs,
  Expected: 'resolvedFrameworkConstantsPathActual is: '
}, {
  Name: 'cresolvedClientConstantsPathActualIs',
  Actual: msg.cresolvedClientConstantsPathActualIs,
  Expected: 'resolvedClientConstantsPathActual is: '
}, {
  Name: 'cframeworkConstantsValidationDataIs',
  Actual: msg.cframeworkConstantsValidationDataIs,
  Expected: 'frameworkConstantsValidationData is: '
}, {
  Name: 'capplicationConstantsValidationDataIs',
  Actual: msg.capplicationConstantsValidationDataIs,
  Expected: 'applicationConstantsValidationData is: '
}, {
  Name: 'cActualColonDoublePercent',
  Actual: msg.cActualColonDoublePercent,
  Expected: '"Actual": "%%",'
}, {
  Name: 'callCommandWorkflowsDataIs',
  Actual: msg.callCommandWorkflowsDataIs,
  Expected: 'allCommandWorkflowsData is: '
}, {
  Name: 'csourceDestinationArrayIs',
  Actual: msg.csourceDestinationArrayIs,
  Expected: 'sourceDestinationArray is: '
}, {
  Name: 'cfilterArrayIs',
  Actual: msg.cfilterArrayIs,
  Expected: 'filterArray is: '
}, {
  Name: 'csuccessfulCopyIs',
  Actual: msg.csuccessfulCopyIs,
  Expected: 'successfulCopy is: '
}, {
  Name: 'cCaptureSessionDateTimeStampLogFileName',
  Actual: msg.cCaptureSessionDateTimeStampLogFileName,
  Expected: 'Capture the session date-time-stamp so we can determine a log file name.'
}, {
  Name: 'cProcessRulesWarningSomeRulesDoNotExist',
  Actual: msg.cProcessRulesWarningSomeRulesDoNotExist,
  Expected: 'WARNING: Some rules do not exist: '
}, // WARNING: Mixed string. Cannot determine what delimiter should be used to break up the string into words.
{
  Name: 'cDetermineWordDelimiterMessage1',
  Actual: msg.cDetermineWordDelimiterMessage1,
  Expected: 'WARNING: Mixed string. '
}, {
  Name: 'cDetermineWordDelimiterMessage2',
  Actual: msg.cDetermineWordDelimiterMessage2,
  Expected: 'Cannot determine what delimiter should '
}, {
  Name: 'cDetermineWordDelimiterMessage3',
  Actual: msg.cDetermineWordDelimiterMessage3,
  Expected: 'be used to break up the '
}, {
  Name: 'cDetermineWordDelimiterMessage4',
  Actual: msg.cDetermineWordDelimiterMessage4,
  Expected: 'string into words.'
}, // WARNING: Mixed string. Cannot determine how words are delimited in the string. Unable to count words.
{
  Name: 'cGetWordCountInStringMessage1',
  Actual: msg.cGetWordCountInStringMessage1,
  Expected: 'WARNING: Mixed string. '
}, {
  Name: 'cGetWordCountInStringMessage2',
  Actual: msg.cGetWordCountInStringMessage2,
  Expected: 'Cannot determine how words are delimited '
}, {
  Name: 'cGetWordCountInStringMessage3',
  Actual: msg.cGetWordCountInStringMessage3,
  Expected: 'in the string. Unable to count words.'
}, // WARNING: Mixed string. Cannot get words from the string. Unable to determine words.
{
  Name: 'cGetWordsArrayFromStringMessage1',
  Actual: msg.cGetWordsArrayFromStringMessage1,
  Expected: 'WARNING: Mixed string. '
}, {
  Name: 'cGetWordsArrayFromStringMessage2',
  Actual: msg.cGetWordsArrayFromStringMessage2,
  Expected: 'Cannot get words from the string. '
}, {
  Name: 'cGetWordsArrayFromStringMessage3',
  Actual: msg.cGetWordsArrayFromStringMessage3,
  Expected: 'Unable to determine words.'
}, // Please enter a named command where the first word starts with a lower case letter and all other words in the named command start with an upper case letter:
{
  Name: 'cCommandNamePrompt1',
  Actual: msg.cCommandNamePrompt1,
  Expected: 'Please enter a named command where '
}, {
  Name: 'cCommandNamePrompt2',
  Actual: msg.cCommandNamePrompt2,
  Expected: 'the first word starts with a '
}, {
  Name: 'cCommandNamePrompt3',
  Actual: msg.cCommandNamePrompt3,
  Expected: 'lower case letter and all other '
}, {
  Name: 'cCommandNamePrompt4',
  Actual: msg.cCommandNamePrompt4,
  Expected: 'words in the named command start '
}, {
  Name: 'cCommandNamePrompt5',
  Actual: msg.cCommandNamePrompt5,
  Expected: 'with an upper case letter: '
}, // Please enter a list of command for the command word:
{
  Name: 'cCommandWordAliasPrompt1',
  Actual: msg.cCommandWordAliasPrompt1,
  Expected: 'Please enter a list of command '
}, {
  Name: 'cCommandWordAliasPrompt2',
  Actual: msg.cCommandWordAliasPrompt2,
  Expected: 'word abreviations/acronyms/aliases '
}, {
  Name: 'cCommandWordAliasPrompt3',
  Actual: msg.cCommandWordAliasPrompt3,
  Expected: 'for the command word: '
}, // Please enter a string you would like to define as a constant in the constants system:
{
  Name: 'cConstantPrompt1',
  Actual: msg.cConstantPrompt1,
  Expected: 'Please enter a string you would '
}, {
  Name: 'cConstantPrompt2',
  Actual: msg.cConstantPrompt2,
  Expected: 'like to define as a constant '
}, {
  Name: 'cConstantPrompt3',
  Actual: msg.cConstantPrompt3,
  Expected: 'in the constants system: '
}, // Please enter a coma separated list of strings you would like to define in the constants system:
{
  Name: 'cConstantsListPrompt1',
  Actual: msg.cConstantsListPrompt1,
  Expected: 'Please enter a coma separated list of '
}, {
  Name: 'cConstantsListPrompt2',
  Actual: msg.cConstantsListPrompt2,
  Expected: 'strings you would like to define in '
}, {
  Name: 'cConstantsListPrompt3',
  Actual: msg.cConstantsListPrompt3,
  Expected: 'the constants system: '
}, // Please enter a coma separated list of strings you would like to search for common patterns:
{
  Name: 'cConstantsListPatternSearchPrompt1',
  Actual: msg.cConstantsListPatternSearchPrompt1,
  Expected: 'Please enter a coma separated list of '
}, {
  Name: 'cConstantsListPatternSearchPrompt2',
  Actual: msg.cConstantsListPatternSearchPrompt2,
  Expected: 'strings you would like to search for '
}, {
  Name: 'cConstantsListPatternSearchPrompt3',
  Actual: msg.cConstantsListPatternSearchPrompt3,
  Expected: 'common patterns: '
}, // ERROR: Attempted to generate a suggested line of code to validate the constant, ' +
// 'but the constant is not formatted correctly, it should begin with a lower case "c". ' +
// 'Please reformat the constant correctly so a line of code can be generated for you.
{
  Name: 'cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage1',
  Actual: msg.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage1,
  Expected: 'ERROR: Attempted to generate a suggested '
}, {
  Name: 'cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage2',
  Actual: msg.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage2,
  Expected: 'line of code to validate the constant, '
}, {
  Name: 'cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage3',
  Actual: msg.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage3,
  Expected: 'but the constant is not formatted correctly, '
}, {
  Name: 'cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage4',
  Actual: msg.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage4,
  Expected: 'it should begin with a lower case "c". '
}, {
  Name: 'cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage5',
  Actual: msg.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage5,
  Expected: 'Please reformat the constant correctly so a '
}, {
  Name: 'cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage6',
  Actual: msg.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage6,
  Expected: 'line of code can be generated for you.'
}, {
  Name: 'cSearchForPatternsInStringArrayMessage1',
  Actual: msg.cSearchForPatternsInStringArrayMessage1,
  Expected: 'currentMasterStringArrayElement does not contain a space character'
}, // WARNING: The current string being searched contains a space character, we are going to skip comparison.
{
  Name: 'cSearchForPatternsInStringArrayMessage2',
  Actual: msg.cSearchForPatternsInStringArrayMessage2,
  Expected: 'WARNING: The current string being searched contains a space character, '
}, {
  Name: 'cSearchForPatternsInStringArrayMessage3',
  Actual: msg.cSearchForPatternsInStringArrayMessage3,
  Expected: 'we are going to skip comparison.'
}, {
  Name: 'cSearchForPatternsInStringArrayMessage4',
  Actual: msg.cSearchForPatternsInStringArrayMessage4,
  Expected: 'WARNING: InputData was not an array or had an empty array.'
}, // WARNING: No data to load, please specify a valid path & filename!
{
  Name: 'cLoadDataFileMessage1',
  Actual: msg.cLoadDataFileMessage1,
  Expected: 'WARNING: No data to load, '
}, {
  Name: 'cloadDataFileMessage2',
  Actual: msg.cloadDataFileMessage2,
  Expected: 'please specify a valid path & filename!'
}, {
  Name: 'cloadDataFileMessage3',
  Actual: msg.cloadDataFileMessage3,
  Expected: 'WARNING: Invalid file format, file formats supported are: '
}, {
  Name: 'csaveDataFileMessage1',
  Actual: msg.csaveDataFileMessage1,
  Expected: 'WARNING: No data to save, '
}, {
  Name: 'ccommandSequencerMessage1',
  Actual: msg.ccommandSequencerMessage1,
  Expected: 'WARNING: nominal.commandSequencer: The specified command was not found, '
}, {
  Name: 'ccommandSequencerMessage2',
  Actual: msg.ccommandSequencerMessage2,
  Expected: 'please enter a valid command and try again.'
}, {
  Name: 'cworkflowMessage1',
  Actual: msg.cworkflowMessage1,
  Expected: 'WARNING: nominal.workflow: The specified workflow: '
}, {
  Name: 'cworkflowMessage2',
  Actual: msg.cworkflowMessage2,
  Expected: ' was not found in either the system defined workflows, or client defined workflows.'
}, {
  Name: 'cworkflowMessage3',
  Actual: msg.cworkflowMessage3,
  Expected: ' Please enter a valid workflow name and try again.'
}, {
  Name: 'ccommandGeneratorMessage1',
  Actual: msg.ccommandGeneratorMessage1,
  Expected: 'After attempting to replace the secondaryCommandArgsDelimiter with the primaryCommandDelimiter commandString is: '
}, {
  Name: 'ccommandGeneratorMessage2',
  Actual: msg.ccommandGeneratorMessage2,
  Expected: 'After attempting to replace the tertiaryCommandDelimiter with the secondaryCommandArgsDelimiter commandString is: '
}, {
  Name: 'ccommandGeneratorMessage3',
  Actual: msg.ccommandGeneratorMessage3,
  Expected: 'WARNING: nominal.commandGenerator: Must enter a number greater than 0, number entered: '
}, {
  Name: 'ccommandGeneratorMessage4',
  Actual: msg.ccommandGeneratorMessage4,
  Expected: 'WARNING: nominal.commandGenerator: Number entered for the number of commands to generate is not a number: '
}, {
  Name: 'ccommandGeneratorMessage5',
  Actual: msg.ccommandGeneratorMessage5,
  Expected: 'WARNING: nominal.commandGenerator: The specified command: '
}, {
  Name: 'ccommandGeneratorMessage6',
  Actual: msg.ccommandGeneratorMessage6,
  Expected: ' was not found, please enter a valid command and try again.'
}, {
  Name: 'ccommandAliasGeneratorMessage1',
  Actual: msg.ccommandAliasGeneratorMessage1,
  Expected: 'Command can be called by passing parameters and bypass the prompt system.'
}, {
  Name: 'ccommandAliasGeneratorMessage2',
  Actual: msg.ccommandAliasGeneratorMessage2,
  Expected: 'EXAMPLE: {"constants":"c,const","Generator":"g,gen,genrtr","List":"l,lst"}'
}, {
  Name: 'ccommandAliasGeneratorMessage3',
  Actual: msg.ccommandAliasGeneratorMessage3,
  Expected: 'INVALID INPUT: Please enter a valid camel-case command name.'
}, {
  Name: 'ccommandAliasGeneratorMessage4',
  Actual: msg.ccommandAliasGeneratorMessage4,
  Expected: 'INVALID INPUT: Please enter a valid command word alias list.'
}, {
  Name: 'ccommandAliasGeneratorMessage5',
  Actual: msg.ccommandAliasGeneratorMessage5,
  Expected: 'INVALID COMMAND INPUT: Please enter valid command data when trying to call with parameters.'
}, {
  Name: 'cconstantsGeneratorMessage1',
  Actual: msg.cconstantsGeneratorMessage1,
  Expected: 'INVALID INPUT: Please enter a valid constant value that contains more than 4 characters.'
}, {
  Name: 'cconstantsGeneratorMessage2',
  Actual: msg.cconstantsGeneratorMessage2,
  Expected: 'WARNING: The constant has already been defined in the following library(ies): '
}, {
  Name: 'cconstantsGeneratorMessage3',
  Actual: msg.cconstantsGeneratorMessage3,
  Expected: 'The enableConstantsValidation flag is disabled. '
}, {
  Name: 'cconstantsGeneratorMessage4',
  Actual: msg.cconstantsGeneratorMessage4,
  Expected: 'Enable this flag in the configuration settings to activate this command.'
}, {
  Name: 'cconstantsGeneratorListMessage1',
  Actual: msg.cconstantsGeneratorListMessage1,
  Expected: 'INVALID INPUT: Please enter a valid constant list.'
}, {
  Name: 'cvalidateCommandAliasesMessage1',
  Actual: msg.cvalidateCommandAliasesMessage1,
  Expected: 'PASSED: All duplicate command aliases validation tests!'
}, {
  Name: 'cgetCommandArgsMessage1',
  Actual: msg.cgetCommandArgsMessage1,
  Expected: 'About to call the rule broker to process on the number of single quotes '
}, {
  Name: 'cgetCommandArgsMessage2',
  Actual: msg.cgetCommandArgsMessage2,
  Expected: 'and determine if it-be even or odd'
}, {
  Name: 'cexecuteCommandMessage1',
  Actual: msg.cexecuteCommandMessage1,
  Expected: 'WARNING: Command does not exist, please enter a valid command and try again!'
}, {
  Name: 'cparseBusinessRuleArgumentMessage1',
  Actual: msg.cparseBusinessRuleArgumentMessage1,
  Expected: 'WARNING: lexical.parseBusinessRuleArgument: Invalid combination of inputs to the lexical.parseBusinessRuleArgument function! '
}, {
  Name: 'cparseBusinessRuleArgumentMessage2',
  Actual: msg.cparseBusinessRuleArgumentMessage2,
  Expected: 'Please adjust inputs and try again.'
}, {
  Name: 'cprintDataHiveAttributesMessage1',
  Actual: msg.cprintDataHiveAttributesMessage1,
  Expected: 'Caught the case the user may have only specified a single data hive, '
}, {
  Name: 'cprintDataHiveAttributesMessage2',
  Actual: msg.cprintDataHiveAttributesMessage2,
  Expected: 'such as the configuration data hive.'
}, {
  Name: 'cprintDataHiveAttributesMessage3',
  Actual: msg.cprintDataHiveAttributesMessage3,
  Expected: 'ERROR: Please enter a valid name.space.attributeName for the system to print out attribute data from.'
}, {
  Name: 'cNothingToEcho',
  Actual: msg.cNothingToEcho,
  Expected: 'Nothing to echo.'
}, ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
{
  Name: 'cprompt01',
  Actual: msg.cprompt01,
  Expected: 'prompt01'
}, {
  Name: 'cprompt02',
  Actual: msg.cprompt02,
  Expected: 'prompt02'
}, {
  Name: 'cprompt03',
  Actual: msg.cprompt03,
  Expected: 'prompt03'
}, {
  Name: 'cprintMessageToFile01',
  Actual: msg.cprintMessageToFile01,
  Expected: 'printMessageToFile01'
}, {
  Name: 'cprintMessageToFile02',
  Actual: msg.cprintMessageToFile02,
  Expected: 'printMessageToFile02'
}, {
  Name: 'cprintMessageToFile03',
  Actual: msg.cprintMessageToFile03,
  Expected: 'printMessageToFile03'
} // Coded System Messages
// EXAMPLE:
// '!mergedData[wr1.csystem] && !D[wr1.csystem] === true'
];
exports.messageConstantsVaidation = messageConstantsVaidation;