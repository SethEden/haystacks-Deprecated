"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _commandBroker = _interopRequireDefault(require("../brokers/commandBroker.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _chiefData = _interopRequireDefault(require("../controllers/chiefData.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _queue = _interopRequireDefault(require("../structures/queue.js"));

var _path = _interopRequireDefault(require("path"));

var _fnc$cbootStrapComman;

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // controllers.chiefCommander.


var namespacePrefix = wr1.ccontrollers + bas.cDot + baseFileName + bas.cDot;
/**
 * @function bootStrapCommands
 * @description Initializes all of the commands and gets them added to the D-data structure.
 * @return {void}
 * @author Seth Holingsead
 * @date 2022/02/01
 */

function bootStrapCommands() {
  var functionName = bootStrapCommands.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _commandBroker["default"].bootStrapCommands();

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function addClientCommands
 * @description This is a wrapper function for calling the commandBroker.addClientCommands.
 * @param {object} clientCommands A map of client defined command names and client defined command function calls.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/17
 */

function addClientCommands(clientCommands) {
  var functionName = addClientCommands.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _commandBroker["default"].addClientCommands(clientCommands);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function loadCommandAliasesFromPath
 * @description Loads the command aliases XML file that is specified by the input.
 * The data is automatically saved on the D-data structure.
 * @param {string} commandAliasesFilePathConfigurationName The path and file name to the XML file that contains the command aliases definitions.
 * (Could be system command aliases or client command aliases)
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/02
 */

function loadCommandAliasesFromPath(commandAliasesFilePathConfigurationName) {
  var functionName = loadCommandAliasesFromPath.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // commandAliasesFilePathConfigurationName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandAliasesFilePathConfigurationNameIs + commandAliasesFilePathConfigurationName);

  var allCommandAliasesData = {};
  allCommandAliasesData = _chiefData["default"].setupAllXmlData(commandAliasesFilePathConfigurationName, sys.cCommandsAliases); // allCommandAliasesData is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.callCommandAliasesDataIs + JSON.stringify(allCommandAliasesData));

  if (_data["default"][sys.cCommandsAliases] === undefined) {
    // Make sure we only do this if it's undefined, otherwise we might wipe out previously loaded data.
    _data["default"][sys.cCommandsAliases] = {};
    _data["default"][sys.cCommandsAliases] = allCommandAliasesData[sys.cCommandsAliases];
  } else {
    var commandKeys = Object.keys(allCommandAliasesData[sys.cCommandsAliases][wr1.cCommands]);

    for (var i = 0; i < commandKeys.length; i++) {
      _data["default"][sys.cCommandsAliases][wr1.cCommands][commandKeys[i]] = allCommandAliasesData[sys.cCommandsAliases][wr1.cCommands][commandKeys[i]];
    } // End-for (let i = 0; i < allCommandAliasesData[sys.cCommandsAliases][wr1.cCommand].length; i++)

  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function enqueueCommand
 * @description Determines if the command queue has been setup or not,
 * if not then it is initialized, and the command is added to the command queue.
 * @param {string} command The command that should be added  to the command queue.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/02
 */

function enqueueCommand(command) {
  var functionName = enqueueCommand.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // command is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandIs + command);

  if (_data["default"][sys.cCommandQueue] === undefined) {
    _queue["default"].initQueue(sys.cCommandQueue);
  }

  _queue["default"].enqueue(sys.cCommandQueue, command);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function isCommandQueueEmpty
 * @description Deterines if the command queue is empty or not empty.
 * @return {boolean} A True or False value to indicate if the command queue is empty or not empty.
 * @author Seth Hollingsead
 * @date 2022/02/02
 */

function isCommandQueueEmpty() {
  var functionName = isCommandQueueEmpty.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  var returnData = false;
  returnData = _queue["default"].isEmpty(sys.cCommandQueue);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function processCommandQueue
 * @description Pulls the command from the front of the command queue and executes it using the commnad broker.
 * @return {boolean} A True or False value to indicate if the applicatino should exit or not exit.
 * @author Seth Hollingsead
 * @date 2022/02/02
 */

function processCommandQueue() {
  var functionName = processCommandQueue.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  var commandToExecute;
  var returnData;
  commandToExecute = _queue["default"].dequeue(sys.cCommandQueue); // commandToExecute is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandToExecuteIs + commandToExecute);

  returnData = _commandBroker["default"].executeCommand(commandToExecute);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;

var _default = (_fnc$cbootStrapComman = {}, _defineProperty(_fnc$cbootStrapComman, fnc.cbootStrapCommands, function () {
  return bootStrapCommands();
}), _defineProperty(_fnc$cbootStrapComman, fnc.caddClientCommands, function (clientCommands) {
  return addClientCommands(clientCommands);
}), _defineProperty(_fnc$cbootStrapComman, fnc.cloadCommandAliasesFromPath, function (commandAliasesFilePathConfigurationName) {
  return loadCommandAliasesFromPath(commandAliasesFilePathConfigurationName);
}), _defineProperty(_fnc$cbootStrapComman, fnc.cenqueueCommand, function (command) {
  return enqueueCommand(command);
}), _defineProperty(_fnc$cbootStrapComman, fnc.cisCommandQueueEmpty, function () {
  return isCommandQueueEmpty();
}), _defineProperty(_fnc$cbootStrapComman, fnc.cprocessCommandQueue, function () {
  return processCommandQueue();
}), _fnc$cbootStrapComman);

exports["default"] = _default;