"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _dataBroker = _interopRequireDefault(require("../brokers/dataBroker.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var cfg = _interopRequireWildcard(require("../constants/configuration.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _configurator = _interopRequireDefault(require("../executrix/configurator.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _path = _interopRequireDefault(require("path"));

var _fnc$csearchForUniver;

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // controllers.chiefData.


var namespacePrefix = wr1.ccontrollers + bas.cDot + baseFileName + bas.cDot;
/**
 * @function searchForUniversalDebugConfigSetting
 * @description Searches all of the config data files for a general solution to the
 * debugSettings configuration setting.
 * @param {string} appConfigPathName The name of the configuration setting
 * that has the path for the appConfigPath.
 * @param {string} frameworkConfigPathName The name of the configuration setting
 * that has the path for the frameworkConfigPath.
 * @param {string} contextName The context name that should be used when adding data to the D data structure.
 * @return {boolean} A True or False to indicate if the debugSettings was found to be
 * true in either of the configuration settings (appConfig Or frameworkConfig).
 * @NOTE Cannot use the loggers here, because dependency data will have never been loaded.
 */

function searchForUniversalDebugConfigSetting(appConfigPathName, frameworkConfigPathName, contextName) {
  var functionName = searchForUniversalDebugConfigSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`appConfigPathName is: ${appConfigPathName}`);
  // console.log(`frameworkConfigPathName is: ${frameworkConfigPathName}`);
  // console.log(`contextName is: ${contextName}`);

  var universalDebugConfigSetting = false;

  var appConfigDataPath = _configurator["default"].getConfigurationSetting(wr1.csystem, appConfigPathName);

  var frameworkConfigDataPath = _configurator["default"].getConfigurationSetting(wr1.csystem, frameworkConfigPathName);

  appConfigDataPath = _path["default"].resolve(appConfigDataPath);
  frameworkConfigDataPath = _path["default"].resolve(frameworkConfigDataPath);

  var appConfigFilesToLoad = _dataBroker["default"].scanDataPath(appConfigDataPath, contextName);

  var frameworkConfigFilesToLoad = _dataBroker["default"].scanDataPath(frameworkConfigDataPath, contextName);

  _configurator["default"].setConfigurationSetting(wr1.csystem, cfg.cappConfigFiles, appConfigFilesToLoad);

  _configurator["default"].setConfigurationSetting(wr1.csystem, cfg.cframeworkConfigFiles, frameworkConfigFilesToLoad);

  universalDebugConfigSetting = _dataBroker["default"].findUniversalDebugConfigSetting(appConfigFilesToLoad, frameworkConfigFilesToLoad);

  _configurator["default"].setConfigurationSetting(wr1.csystem, cfg.cdebugSettings, universalDebugConfigSetting); // console.log(`universalDebugConfigSetting is: ${universalDebugConfigSetting}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return universalDebugConfigSetting;
}

;
/**
 * @function getAndProcessCsvData
 * @description Loads the specified file, parses it and converts all the data to the appropriate fromat.
 * @param {string} pathAndFilename The path and file name of the CSV file that should be loaded and parsed into JSON objects.
 * @param {string} contextName The name that should be used when adding the objects to the D data structure for data-sharing.
 * @return {object} A parsed CSV JSON object where allthe values have been converted from their string representation into actual values of appropriate type.
 * @author Seth Hollingsead
 * @date 2022/02/17
 */

function getAndProcessCsvData(pathAndFilename, contextName) {
  var functionName = getAndProcessCsvData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // cpathAndFilename is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpathAndFilenameIs + pathAndFilename); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  pathAndFilename = _path["default"].resolve(pathAndFilename);

  var loadedData = _dataBroker["default"].getCsvData(pathAndFilename); // Now pre-process the data into a usable format, string-numbers to actual numbers, string-booleans to actual booleans, etc...


  var allLoadedData = _dataBroker["default"].getAndProcessCsvData(loadedData, contextName);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return allLoadedData;
}

;
/**
 * @function getAndProcessXmlData
 * @description Loads the specified file, parses it and converts all values into their appropriate data types.
 * @param {string} pathAndFilename The path and file name of the XML file that should be loaded and parsed into JSON objects.
 * @return {object} A parsed XML JSON object where all the values have been converted from their strign representation into actual values of appropriate type.
 * @author Seth Hollingsead
 * @date 2022/02/17
 */

function getAndProcessXmlData(pathAndFilename) {
  var functionName = getAndProcessXmlData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // pathAndFilename is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cpathAndFilenameIs + pathAndFilename);

  pathAndFilename = _path["default"].resolve(pathAndFilename);

  var allLoadedXmlData = _dataBroker["default"].getXmlData(pathAndFilename); // Now pre-process the data into a usable format, string-numbers to actual numbers, string-booleans to actual booleans, etc...


  var allXmlData = _dataBroker["default"].processXmlData(allLoadedXmlData); // allXmlData is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.callXmlDataIs + JSON.stringify(allXmlData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return allXmlData;
}

;
/**
 * @function setupAllCsvData
 * @description Sets up all of the specified CSV data.
 * @param {string} dataPathConfigurationName The name of the configuration setting that has the path we should search.
 * @param {string} contextName The context name that should be used when adding data to the D data structure.
 * @return {object} A JSON object that contains all of the data that was loaded from all the CSV files and merged together.
 * @author Seth Hollingsead
 * @date 2022/02/17
 */

function setupAllCsvData(dataPathConfigurationName, contextName) {
  var functionName = setupAllCsvData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // dataPathConfigurationName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataPathConfigurationNameIs + dataPathConfigurationName); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var loadedAndMergedDataAllFiles = {};

  var dataPath = _configurator["default"].getConfigurationSetting(wr1.csystem, dataPathConfigurationName);

  dataPath = _path["default"].resolve(dataPath); // dataPath is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataPathIs + dataPath);

  var filesToLoad = _dataBroker["default"].scanDataPath(dataPath); // filesToLoad is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfilesToLoadIs + JSON.stringify(filesToLoad));

  loadedAndMergedDataAllFiles = _dataBroker["default"].loadAllCsvData(filesToLoad, contextName); // loadedAndMergedDataAllFiles is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cloadedAndMergedDataAllFilesIs + JSON.stringify(loadedAndMergedDataAllFiles));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return loadedAndMergedDataAllFiles;
}

;
/**
 * @function setupAllXmlData
 * @description Sets up all of the specified XML data.
 * @param {string} dataPathConfigurationName The name of the configuration setting that has the path we should search.
 * @param {string} contextName The context name that should be used when addng data to the D data structure.
 * @return {object} A JSON object that contains all of the data that was loaded from all the XML files and merged together.
 * @author Seth Hollingsead
 * @date 2022/02/17
 */

function setupAllXmlData(dataPathConfigurationName, contextName) {
  var functionName = setupAllXmlData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // dataPathConfigurationName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataPathConfigurationNameIs + dataPathConfigurationName); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  var loadedAndMergedDataAllFiles = {};

  var dataPath = _configurator["default"].getConfigurationSetting(wr1.csystem, dataPathConfigurationName);

  dataPath = _path["default"].resolve(dataPath); // dataPath is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataPathIs + dataPath);

  var filesToLoad = _dataBroker["default"].scanDataPath(dataPath); // filesToLoad is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cfilesToLoadIs + JSON.stringify(filesToLoad));

  loadedAndMergedDataAllFiles = _dataBroker["default"].loadAllXmlData(filesToLoad, contextName); // loadedAndMergedDataAllFiles is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cloadedAndMergedDataAllFilesIs + JSON.stringify(loadedAndMergedDataAllFiles));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return loadedAndMergedDataAllFiles;
}

;
/**
 * @function setupAllJsonConfigData
 * @description Sets up all of the JSON data at the specified configuration path.
 * @param {string} dataPathConfigurationName The name of the configuration setting that has the path we should search.
 * @param {string} contextName The context name that should be used when adding data to the D data structure.
 * @return {object} A JSON object that contains all of the data that was loaded and merged together.
 * @author Seth Hollingsead
 * @date 2021/03/31
 * @NOTE Cannot use the loggers here, because dependency data will have never been loaded.
 */

function setupAllJsonConfigData(dataPathConfigurationName, contextName) {
  var functionName = setupAllJsonConfigData.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`dataPathConfigurationName is: ${dataPathConfigurationName}`);
  // console.log(`contextName is: ${contextName}`);

  var loadedAndMergedDataAllFiles = {};
  var filesToLoad = [];

  if (dataPathConfigurationName === sys.cappConfigPath) {
    filesToLoad = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cappConfigFiles);
  } else if (dataPathConfigurationName === sys.cframeworkConfigPath) {
    filesToLoad = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cframeworkConfigFiles);
  }

  loadedAndMergedDataAllFiles = _dataBroker["default"].loadAllJsonData(filesToLoad, contextName); // console.log(`loadedAndMergedDataAllFiles is: ${JSON.stringify(loadedAndMergedDataAllFiles)}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);

  return loadedAndMergedDataAllFiles;
}

;
/**
 * @function initializeConstantsValidationData
 * @description Calls the dataBroker to initialize the constants verification data structure.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/03/22
 */

function initializeConstantsValidationData() {
  var functionName = initializeConstantsValidationData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _dataBroker["default"].initializeConstantsValidationData();

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function addConstantsValidationData
 * @description Calls the dataBroker to ad constants validation data to the constants validation data structure.
 * @param {array<array<string,object>>} arrayValidationData An array of arrays that contains all of the constants library validation names and data objects.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/03/24
 */

function addConstantsValidationData(arrayValidationData) {
  var functionName = addConstantsValidationData.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // arrayValidationData is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.carrayValidationDataIs + JSON.stringify(arrayValidationData));

  _dataBroker["default"].addConstantsValidationData(arrayValidationData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;

var _default = (_fnc$csearchForUniver = {}, _defineProperty(_fnc$csearchForUniver, fnc.csearchForUniversalDebugConfigSetting, function (appConfigPathName, frameworkConfigPathName, contextName) {
  return searchForUniversalDebugConfigSetting(appConfigPathName, frameworkConfigPathName, contextName);
}), _defineProperty(_fnc$csearchForUniver, fnc.cgetAndProcessCsvData, function (pathAndFilename, contextName) {
  return getAndProcessCsvData(pathAndFilename, contextName);
}), _defineProperty(_fnc$csearchForUniver, fnc.cgetAndProcessXmlData, function (pathAndFilename) {
  return getAndProcessXmlData(pathAndFilename);
}), _defineProperty(_fnc$csearchForUniver, fnc.csetupAllCsvData, function (dataPathConfigurationName, contextName) {
  return setupAllCsvData(dataPathConfigurationName, contextName);
}), _defineProperty(_fnc$csearchForUniver, fnc.csetupAllXmlData, function (dataPathConfigurationName, contextName) {
  return setupAllXmlData(dataPathConfigurationName, contextName);
}), _defineProperty(_fnc$csearchForUniver, fnc.csetupAllJsonConfigData, function (dataPathConfigurationName, contextName) {
  return setupAllJsonConfigData(dataPathConfigurationName, contextName);
}), _defineProperty(_fnc$csearchForUniver, fnc.cinitializeConstantsValidationData, function () {
  return initializeConstantsValidationData();
}), _defineProperty(_fnc$csearchForUniver, fnc.caddConstantsValidationData, function (arrayValidationData) {
  return addConstantsValidationData(arrayValidationData);
}), _fnc$csearchForUniver);

exports["default"] = _default;