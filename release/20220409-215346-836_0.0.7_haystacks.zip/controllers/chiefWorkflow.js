"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _chiefData = _interopRequireDefault(require("./chiefData.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _path = _interopRequireDefault(require("path"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // controllers.chiefWorkflow.


var namespacePrefix = wr1.ccontrollers + bas.cDot + baseFileName + bas.cDot;
/**
 * @function loadCommandWorkflowsFromPath
 * @description Loads the command workflows XML file that is specified by the input.
 * @param {string} commandWorkflowFilePathConfigurationName The path and file name to the XML that contains the command workflows definitions.
 * (Could be system defined command workflows or client command defined command workflows)
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/04
 */

function loadCommandWorkflowsFromPath(commandWorkflowFilePathConfigurationName) {
  var functionName = loadCommandWorkflowsFromPath.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // commandWorkflowFilePathConfigurationName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandWorkflowFilePathConfigurationNameIs + commandWorkflowFilePathConfigurationName);

  var allCommandWorkflowsData = {};
  allCommandWorkflowsData = _chiefData["default"].setupAllXmlData(commandWorkflowFilePathConfigurationName, sys.cCommandWorkflows);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.callCommandWorkflowsDataIs + JSON.stringify(allCommandWorkflowsData));

  if (_data["default"][sys.cCommandWorkflows] === undefined) {
    // Make sure we only do this if it's undefined, otherwise we ight wipe out previously loaded data.
    _data["default"][sys.cCommandWorkflows] = {};
    _data["default"][sys.cCommandWorkflows] = allCommandWorkflowsData[sys.cCommandWorkflows];
  } else {
    // for (let i = 0; i < allCommandWorkflowsData[sys.cCommandWorkflows][wr1.cWorkflows].length; i++) {
    // D[sys.cCommandWorkflows][wr1.cWorkflows].push(allCommandWorkflowsData[sys.cCommandWorkflows][wr1.cWorkflows][i]);
    Object.assign(_data["default"][sys.cCommandWorkflows][wr1.cWorkflows], allCommandWorkflowsData[sys.cCommandWorkflows][wr1.cWorkflows]); // }
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;

var _default = _defineProperty({}, fnc.cloadCommandWorkflowsFromPath, function (commandWorkflowFilePathConfigurationName) {
  return loadCommandWorkflowsFromPath(commandWorkflowFilePathConfigurationName);
});

exports["default"] = _default;