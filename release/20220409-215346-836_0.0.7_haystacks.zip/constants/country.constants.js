"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cLibya = exports.cLiberia = exports.cLesotho = exports.cLebanon = exports.cLatvia = exports.cLaos = exports.cKyrgyzstan = exports.cKuwait = exports.cKiribati = exports.cKenya = exports.cKazakhstan = exports.cJordan = exports.cJapan = exports.cJamaica = exports.cItaly = exports.cIsrael = exports.cIreland = exports.cIraq = exports.cIran = exports.cIndonesia = exports.cIndia = exports.cIceland = exports.cHungary = exports.cHonduras = exports.cHolySee = exports.cHerzegovina = exports.cHaiti = exports.cGuyana = exports.cGuineaBissau = exports.cGuinea = exports.cGuatemala = exports.cGrenada = exports.cGreece = exports.cGhana = exports.cGermany = exports.cGeorgia = exports.cGambia = exports.cGabon = exports.cFrance = exports.cFinland = exports.cFiji = exports.cEthiopia = exports.cEswatini = exports.cEstonia = exports.cEritrea = exports.cEquatorialGuinea = exports.cElSalvador = exports.cEgypt = exports.cEcuador = exports.cDominicanRepublic = exports.cDominica = exports.cDjibouti = exports.cDenmark = exports.cDemocraticRepublicOfTheCongo = exports.cCzechia = exports.cCyprus = exports.cCuba = exports.cCroatia = exports.cCotedlvoire = exports.cCostaRica = exports.cCongo = exports.cComoros = exports.cColombia = exports.cChina = exports.cChile = exports.cChad = exports.cCentralAfricanRepublic = exports.cCanada = exports.cCameroon = exports.cCambodia = exports.cCaboVerde = exports.cBurundi = exports.cBurkinaFaso = exports.cBulgaria = exports.cBrunei = exports.cBrazil = exports.cBotswana = exports.cBosnia = exports.cBolivia = exports.cBhutan = exports.cBenin = exports.cBelize = exports.cBelgium = exports.cBelarus = exports.cBarbuda = exports.cBarbados = exports.cBangladesh = exports.cBahrain = exports.cBahamas = exports.cAzerbaijan = exports.cAustria = exports.cAustralia = exports.cArmenia = exports.cArgentina = exports.cAntigua = exports.cAngola = exports.cAndorra = exports.cAlgeria = exports.cAlbania = exports.cAfghanistan = void 0;
exports.cZimbabwe = exports.cZambia = exports.cYemen = exports.cVietnam = exports.cVenezuela = exports.cVanuatu = exports.cUzbekistan = exports.cUruguay = exports.cUnitedStatesOfAmerica = exports.cUnitedKingdom = exports.cUnitedArabEmirates = exports.cUkraine = exports.cUganda = exports.cTuvalu = exports.cTurkmenistan = exports.cTurkey = exports.cTunisia = exports.cTrinidadAndTabago = exports.cTonga = exports.cTogo = exports.cTimorLeste = exports.cThailand = exports.cTanzania = exports.cTajikistan = exports.cSyria = exports.cSwitzerland = exports.cSweden = exports.cSuriname = exports.cSudan = exports.cSriLanka = exports.cSpain = exports.cSouthSudan = exports.cSouthKorea = exports.cSouthAfrica = exports.cSomoa = exports.cSomalia = exports.cSolomonIslands = exports.cSlovenia = exports.cSlovakia = exports.cSingapore = exports.cSierraLeone = exports.cSeychelles = exports.cSerbia = exports.cSenegal = exports.cSaudiArabia = exports.cSaoTome = exports.cSanMarino = exports.cSaintVincent = exports.cSaintLucia = exports.cSaintKitts = exports.cRwanda = exports.cRussia = exports.cRomania = exports.cQatar = exports.cPrincipe = exports.cPortugal = exports.cPoland = exports.cPhilippines = exports.cPeru = exports.cParaguay = exports.cPapuaNewGuinea = exports.cPanama = exports.cPalestine = exports.cPalau = exports.cPakistan = exports.cOman = exports.cNorway = exports.cNorthMacedonia = exports.cNorthKorea = exports.cNigeria = exports.cNiger = exports.cNicaragua = exports.cNewZealand = exports.cNevis = exports.cNetherlands = exports.cNepal = exports.cNauru = exports.cNamibia = exports.cMyanmar = exports.cMozambique = exports.cMorocco = exports.cMontenegro = exports.cMongolia = exports.cMonaco = exports.cMoldova = exports.cMicronesia = exports.cMexico = exports.cMauritius = exports.cMauritania = exports.cMarshallIslands = exports.cMalta = exports.cMali = exports.cMaldives = exports.cMalaysia = exports.cMalawi = exports.cMadagascar = exports.cLuxembourg = exports.cLithuania = exports.cLiechtenstein = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var gen = _interopRequireWildcard(require("./generic.constants.js"));

var num = _interopRequireWildcard(require("./numeric.constants.js"));

var phn = _interopRequireWildcard(require("./phonic.constants.js"));

var unt = _interopRequireWildcard(require("./unit.constants.js"));

var wr1 = _interopRequireWildcard(require("./word1.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file country.constants
 * @module country.constants
 * @description Contains many re-usable country constants.
 * @requires module:basic.constants
 * @requires module:generic.constants
 * @requires module:numeric.constants
 * @requires module:phonic.constants
 * @requires module:unit.constants
 * @requires module:word1.constants
 * @author Seth Hollingsead
 * @date 2021/11/15
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// Countries
var cAfghanistan = bas.cAf + bas.cgh + bas.can + phn.cistan; // Afghanistan

exports.cAfghanistan = cAfghanistan;
var cAlbania = bas.cAl + bas.cba + phn.cnia; // Albania

exports.cAlbania = cAlbania;
var cAlgeria = bas.cAl + phn.cgeria; // Algeria

exports.cAlgeria = cAlgeria;
var cAndorra = wr1.cAnd + bas.cor + bas.cra; // Andorra

exports.cAndorra = cAndorra;
var cAngola = bas.cAn + bas.cgo + bas.cla; // Angola

exports.cAngola = cAngola;
var cAntigua = bas.cAn + bas.cti + phn.cgua; // Antigua

exports.cAntigua = cAntigua;
var cArgentina = gen.cArg + phn.cent + phn.cina; // Argentina

exports.cArgentina = cArgentina;
var cArmenia = bas.cAr + phn.cmen + bas.cia; // Armenia

exports.cArmenia = cArmenia;
var cAustralia = bas.cAu + bas.cst + phn.cral + bas.cia; // Australia

exports.cAustralia = cAustralia;
var cAustria = bas.cAu + bas.cst + phn.cria; // Austria

exports.cAustria = cAustria;
var cAzerbaijan = bas.cAz + bas.cer + bas.cba + bas.cij + bas.can; // Azerbaijan

exports.cAzerbaijan = cAzerbaijan;
var cBahamas = bas.cBa + bas.cha + phn.cmas; // Bahamas

exports.cBahamas = cBahamas;
var cBahrain = bas.cBa + bas.chr + phn.cain; // Bahrain

exports.cBahrain = cBahrain;
var cBangladesh = bas.cBa + bas.cng + bas.cla + bas.cde + bas.csh; // Bangladesh

exports.cBangladesh = cBangladesh;
var cBarbados = bas.cBa + bas.crb + wr1.c1a1d + bas.cos; // Barbados

exports.cBarbados = cBarbados;
var cBarbuda = bas.cBa + bas.crb + phn.cuda; // Barbuda

exports.cBarbuda = cBarbuda;
var cBelarus = bas.cBe + bas.cla + phn.crus; // Belarus

exports.cBelarus = cBelarus;
var cBelgium = bas.cBe + bas.clg + bas.ciu + bas.cm; // Belgium

exports.cBelgium = cBelgium;
var cBelize = bas.cBe + bas.cli + bas.cze; // Belize

exports.cBelize = cBelize;
var cBenin = bas.cBe + bas.cni + bas.cn; // Benin

exports.cBenin = cBenin;
var cBhutan = bas.cBh + bas.cut + bas.can; // Bhutan

exports.cBhutan = cBhutan;
var cBolivia = bas.cBo + bas.cli + phn.cvia; // Bolivia

exports.cBolivia = cBolivia;
var cBosnia = bas.cBo + bas.csn + bas.cia; // Bosnia

exports.cBosnia = cBosnia;
var cBotswana = bas.cBo + bas.cts + bas.cwa + bas.cna; // Botswana

exports.cBotswana = cBotswana;
var cBrazil = phn.cBra + bas.czi + bas.cl; // Brazil

exports.cBrazil = cBrazil;
var cBrunei = bas.cBr + bas.cun + bas.cei; // Brunei

exports.cBrunei = cBrunei;
var cBulgaria = bas.cBu + bas.clg + bas.car + bas.cia; // Bulgaria

exports.cBulgaria = cBulgaria;
var cBurkinaFaso = bas.cBu + bas.crk + phn.cina + bas.cFa + bas.cso; // BurkinaFaso

exports.cBurkinaFaso = cBurkinaFaso;
var cBurundi = bas.cBu + wr1.crun + bas.cdi; // Burundi

exports.cBurundi = cBurundi;
var cCotedlvoire = bas.cCo + bas.cte + bas.cSpace + bas.cd + bas.clv + bas.coi + bas.cre; // Cote dlvoire

exports.cCotedlvoire = cCotedlvoire;
var cCaboVerde = bas.cCa + bas.cbo + bas.cSpace + phn.cVer + bas.cde; // Cabo Verde

exports.cCaboVerde = cCaboVerde;
var cCambodia = bas.cCa + bas.cmb + bas.cod + bas.cia; // Cambodia

exports.cCambodia = cCambodia;
var cCameroon = bas.cCa + bas.cme + bas.cro + bas.con; // Cameroon

exports.cCameroon = cCameroon;
var cCanada = wr1.cCan + phn.cada; // Canada

exports.cCanada = cCanada;
var cCentralAfricanRepublic = wr1.cCentral + bas.cSpace + wr1.cAfrican + bas.cSpace + wr1.cRepublic; // Central African Republic

exports.cCentralAfricanRepublic = cCentralAfricanRepublic;
var cChad = bas.cCh + bas.ca + bas.cd; // Chad

exports.cChad = cChad;
var cChile = gen.cChi + bas.cle; // Chile

exports.cChile = cChile;
var cChina = gen.cChi + bas.cna; // China

exports.cChina = cChina;
var cColombia = phn.cCol + phn.comb + bas.cia; // Colombia

exports.cColombia = cColombia;
var cComoros = gen.cCom + bas.cor + bas.cos; // Comoros

exports.cComoros = cComoros;
var cCongo = bas.cC + phn.congo; // Congo

exports.cCongo = cCongo;
var cCostaRica = wr1.cCost + bas.ca + bas.cSpace + bas.cR + phn.cica; // Costa Rica

exports.cCostaRica = cCostaRica;
var cCroatia = bas.cCr + bas.coa + bas.cti + bas.ca; // Croatia

exports.cCroatia = cCroatia;
var cCuba = bas.cCu + bas.cba; // Cuba

exports.cCuba = cCuba;
var cCyprus = bas.cCy + bas.cpr + bas.cus; // Cyprus

exports.cCyprus = cCyprus;
var cCzechia = bas.cCz + bas.cec + bas.chi + bas.ca; // Czechia

exports.cCzechia = cCzechia;
var cDemocraticRepublicOfTheCongo = wr1.cDemocratic + bas.cSpace + wr1.cRepublic + bas.cSpace + bas.cof + bas.cSpace + wr1.cthe + bas.cSpace + cCongo; // Democratic Republic of the Congo

exports.cDemocraticRepublicOfTheCongo = cDemocraticRepublicOfTheCongo;
var cDenmark = bas.cDe + phn.cnmar + bas.ck; // Denmark

exports.cDenmark = cDenmark;
var cDjibouti = bas.cDj + bas.cib + wr1.cout + bas.ci; // Djibouti

exports.cDjibouti = cDjibouti;
var cDominica = bas.cDo + phn.cminica; // Dominica

exports.cDominica = cDominica;
var cDominicanRepublic = bas.cDo + phn.cminica + bas.cn + bas.cSpace + bas.cR + bas.cep + phn.cublic; // Dominican Republic

exports.cDominicanRepublic = cDominicanRepublic;
var cEcuador = bas.cEc + bas.cua + phn.cdor; // Ecuador

exports.cEcuador = cEcuador;
var cEgypt = bas.cEg + bas.cyp + bas.ct; // Egypt

exports.cEgypt = cEgypt;
var cElSalvador = bas.cEl + bas.cSpace + bas.cSa + bas.clv + phn.cador; // El Salvador

exports.cElSalvador = cElSalvador;
var cEquatorialGuinea = phn.cEqu + phn.cator + bas.cia + bas.cl + bas.cSpace + bas.cG + phn.cuinea; // Equatorial Guinea

exports.cEquatorialGuinea = cEquatorialGuinea;
var cEritrea = bas.cEr + bas.cit + phn.crea; // Eritrea

exports.cEritrea = cEritrea;
var cEstonia = bas.cEs + bas.cto + phn.cnia; // Estonia

exports.cEstonia = cEstonia;
var cEswatini = bas.cEs + bas.cwa + bas.cti + bas.cni; // Eswatini -- Formerly Swaziland

exports.cEswatini = cEswatini;
var cEthiopia = bas.cEt + bas.chi + bas.cop + bas.cia; // Ethiopia

exports.cEthiopia = cEthiopia;
var cFiji = bas.cFi + bas.cji; // Fiji

exports.cFiji = cFiji;
var cFinland = phn.cFin + bas.cla + bas.cnd; // Finland

exports.cFinland = cFinland;
var cFrance = phn.cFra + phn.cnce; // France

exports.cFrance = cFrance;
var cGabon = bas.cGa + bas.cbo + bas.cn; // Gabon

exports.cGabon = cGabon;
var cGambia = bas.cGa + phn.cmbia; // Gambia

exports.cGambia = cGambia;
var cGeorgia = bas.cGe + bas.cor + bas.cgi + bas.ca; // Georgia

exports.cGeorgia = cGeorgia;
var cGermany = bas.cGe + phn.crman + bas.cy; // Germany

exports.cGermany = cGermany;
var cGhana = bas.cGh + phn.cana; // Ghana

exports.cGhana = cGhana;
var cGreece = bas.cGr + bas.cee + bas.cce; // Greece

exports.cGreece = cGreece;
var cGrenada = bas.cGr + bas.cen + phn.cada; // Grenada

exports.cGrenada = cGrenada;
var cGuatemala = bas.cGu + phn.cate + phn.cmal + bas.ca; // Guatemala

exports.cGuatemala = cGuatemala;
var cGuinea = bas.cGu + phn.cinea; // Guinea

exports.cGuinea = cGuinea;
var cGuineaBissau = bas.cGu + phn.cinea + bas.cDash + bas.cBi + bas.css + bas.cau; // Guinea-Bissau

exports.cGuineaBissau = cGuineaBissau;
var cGuyana = bas.cGu + phn.cyan + bas.ca; // Guyana

exports.cGuyana = cGuyana;
var cHaiti = bas.cHa + phn.citi; // Haiti

exports.cHaiti = cHaiti;
var cHerzegovina = wr1.cHer + bas.cze + bas.cgo + bas.cvi + bas.cna; // Herzegovina

exports.cHerzegovina = cHerzegovina;
var cHolySee = bas.cHo + bas.cly + bas.cSpace + bas.cSe + bas.ce; // Holy See

exports.cHolySee = cHolySee;
var cHonduras = bas.cHo + bas.cnd + bas.cur + bas.cas; // Honduras

exports.cHonduras = cHonduras;
var cHungary = wr1.cHung + phn.cary; // Hungary

exports.cHungary = cHungary;
var cIceland = bas.cIc + phn.celand; // Iceland

exports.cIceland = cIceland;
var cIndia = bas.cIn + phn.cdia; // India

exports.cIndia = cIndia;
var cIndonesia = bas.cIn + wr1.cdone + phn.csia; // Indonesia

exports.cIndonesia = cIndonesia;
var cIran = bas.cIr + bas.can; // Iran

exports.cIran = cIran;
var cIraq = bas.cIr + bas.caq; // Iraq

exports.cIraq = cIraq;
var cIreland = bas.cIr + phn.celand; // Ireland

exports.cIreland = cIreland;
var cIsrael = bas.cIs + bas.cra + bas.cel; // Israel

exports.cIsrael = cIsrael;
var cItaly = bas.cIt + bas.cal + bas.cy; // Italy

exports.cItaly = cItaly;
var cJamaica = bas.cJa + bas.cma + phn.cica; // Jamaica

exports.cJamaica = cJamaica;
var cJapan = bas.cJa + bas.cpa + bas.cn; // Japan

exports.cJapan = cJapan;
var cJordan = bas.cJo + bas.crd + bas.can; // Jordan

exports.cJordan = cJordan;
var cKazakhstan = bas.cKa + bas.cza + bas.ckh + phn.cstan; // Kazakhstan

exports.cKazakhstan = cKazakhstan;
var cKenya = bas.cKe + bas.cny + bas.ca; // Kenya

exports.cKenya = cKenya;
var cKiribati = bas.cKi + bas.cri + bas.cba + bas.cti; // Kiribati

exports.cKiribati = cKiribati;
var cKuwait = bas.cKu + wr1.cwait; // Kuwait

exports.cKuwait = cKuwait;
var cKyrgyzstan = bas.cKy + bas.crg + bas.cyz + phn.cstan; // Kyrgyzstan

exports.cKyrgyzstan = cKyrgyzstan;
var cLaos = bas.cLa + bas.cos; // Laos

exports.cLaos = cLaos;
var cLatvia = bas.cLa + bas.ctv + bas.cia; // Latvia

exports.cLatvia = cLatvia;
var cLebanon = bas.cLe + bas.cba + phn.cnon; // Lebanon

exports.cLebanon = cLebanon;
var cLesotho = bas.cLe + bas.cso + bas.cth + bas.co; // Lesotho

exports.cLesotho = cLesotho;
var cLiberia = bas.cLi + bas.cbe + phn.cria; // Liberia

exports.cLiberia = cLiberia;
var cLibya = bas.cLi + bas.cby + bas.ca; // Libya

exports.cLibya = cLibya;
var cLiechtenstein = bas.cLi + bas.cec + bas.cht + bas.cen + phn.cste + bas.cin; // Liechtenstein

exports.cLiechtenstein = cLiechtenstein;
var cLithuania = wr1.cLit + bas.chu + phn.cania; // Lithuania

exports.cLithuania = cLithuania;
var cLuxembourg = bas.cLu + bas.cxe + bas.cmb + phn.cour + bas.cg; // Luxembourg

exports.cLuxembourg = cLuxembourg;
var cMadagascar = bas.cMa + bas.cda + bas.cga + bas.csc + bas.car; // Madagascar

exports.cMadagascar = cMadagascar;
var cMalawi = bas.cMa + bas.cla + bas.cwi; // Malawi

exports.cMalawi = cMalawi;
var cMalaysia = bas.cMa + phn.clay + phn.csia; // Malaysia

exports.cMalaysia = cMalaysia;
var cMaldives = bas.cMa + bas.cld + phn.cive + bas.cs; // Maldives

exports.cMaldives = cMaldives;
var cMali = bas.cMa + bas.cli; // Mali

exports.cMali = cMali;
var cMalta = bas.cMa + phn.clta; // Malta

exports.cMalta = cMalta;
var cMarshallIslands = bas.cMa + bas.crs + bas.cha + bas.cll + bas.cSpace + bas.cIs + bas.cla + phn.cnds; // Marshall Islands

exports.cMarshallIslands = cMarshallIslands;
var cMauritania = bas.cMa + bas.cur + bas.cit + phn.cania; // Mauritania

exports.cMauritania = cMauritania;
var cMauritius = bas.cMa + bas.cur + phn.citi + bas.cus; // Mauritius

exports.cMauritius = cMauritius;
var cMexico = bas.cMe + bas.cxi + bas.cco; // Mexico

exports.cMexico = cMexico;
var cMicronesia = unt.cMicro + phn.cnesia; // Micronesia

exports.cMicronesia = cMicronesia;
var cMoldova = bas.cMo + bas.cld + phn.cova; // Moldova

exports.cMoldova = cMoldova;
var cMonaco = bas.cMo + bas.cna + bas.cco; // Monaco

exports.cMonaco = cMonaco;
var cMongolia = bas.cMo + phn.cngo + phn.clia; // Mongolia

exports.cMongolia = cMongolia;
var cMontenegro = bas.cMo + bas.cnt + bas.cen + bas.ceg + bas.cro; // Montenegro

exports.cMontenegro = cMontenegro;
var cMorocco = bas.cMo + bas.cro + bas.ccc + bas.co; // Morocco

exports.cMorocco = cMorocco;
var cMozambique = bas.cMo + bas.cza + bas.cmb + bas.ciq + bas.cue; // Mozambique

exports.cMozambique = cMozambique;
var cMyanmar = bas.cMy + bas.can + phn.cmar; // Myanmar

exports.cMyanmar = cMyanmar;
var cNamibia = bas.cNa + bas.camai + phn.cbia; // Namibia

exports.cNamibia = cNamibia;
var cNauru = bas.cNa + phn.curu; // Nauru

exports.cNauru = cNauru;
var cNepal = bas.cNe + wr1.cpal; // Nepal

exports.cNepal = cNepal;
var cNetherlands = bas.cNe + phn.cther + bas.cla + phn.cnds; // Netherlands

exports.cNetherlands = cNetherlands;
var cNewZealand = wr1.cNew + bas.cSpace + bas.cZe + phn.cala + bas.cnd; // New Zealand

exports.cNewZealand = cNewZealand;
var cNevis = bas.cNe + bas.cvi + bas.cs; // Nevis

exports.cNevis = cNevis;
var cNicaragua = bas.cNi + phn.ccar + phn.cagua; // Nicaragua

exports.cNicaragua = cNicaragua;
var cNiger = bas.cNi + phn.cger; // Niger

exports.cNiger = cNiger;
var cNigeria = bas.cNi + phn.cgeria; // Nigeria

exports.cNigeria = cNigeria;
var cNorthKorea = bas.cNo + bas.crt + bas.ch + bas.cSpace + bas.cK + phn.corea; // North Korea

exports.cNorthKorea = cNorthKorea;
var cNorthMacedonia = bas.cNo + bas.crt + bas.ch + bas.cSpace + bas.cM + phn.cace + bas.cdo + phn.cnia; // North Macedonia

exports.cNorthMacedonia = cNorthMacedonia;
var cNorway = bas.cNo + bas.crw + bas.cay; // Norway

exports.cNorway = cNorway;
var cOman = bas.cOm + bas.can; // Oman

exports.cOman = cOman;
var cPakistan = bas.cPa + phn.ckistan; // Pakistan

exports.cPakistan = cPakistan;
var cPalau = wr1.cPal + bas.cau; // Palau

exports.cPalau = cPalau;
var cPalestine = wr1.cPal + phn.cest + phn.cine; // Palestine

exports.cPalestine = cPalestine;
var cPanama = bas.cPa + phn.cnam + bas.ca; // Panama

exports.cPanama = cPanama;
var cPapuaNewGuinea = wr1.cPapua + bas.cSpace + wr1.cNew + bas.cSpace + cGuinea; // Papua New Guinea

exports.cPapuaNewGuinea = cPapuaNewGuinea;
var cParaguay = phn.cPara + phn.cguay; // Paraguay

exports.cParaguay = cParaguay;
var cPeru = phn.cPer + bas.cu; // Peru

exports.cPeru = cPeru;
var cPhilippines = gen.cPhi + bas.cli + bas.cpp + phn.cine + bas.cs; // Philippines

exports.cPhilippines = cPhilippines;
var cPoland = bas.cPo + bas.cla + bas.cnd; // Poland

exports.cPoland = cPoland;
var cPortugal = wr1.cPort + bas.cug + bas.cal; // Portugal

exports.cPortugal = cPortugal;
var cPrincipe = phn.cPri + bas.cnc + bas.cip + bas.ce; // Principe

exports.cPrincipe = cPrincipe;
var cQatar = bas.cQa + phn.ctar; // Qatar

exports.cQatar = cQatar;
var cRomania = bas.cRo + wr1.cman + bas.cia; // Romania

exports.cRomania = cRomania;
var cRussia = bas.cRu + bas.css + bas.cia; // Russia

exports.cRussia = cRussia;
var cRwanda = bas.cRw + phn.canda; // Rwanda

exports.cRwanda = cRwanda;
var cSaintKitts = bas.cSa + phn.cint + bas.cSpace + bas.cKi + bas.ctt + bas.cs; // Saint Kitts

exports.cSaintKitts = cSaintKitts;
var cSaintLucia = bas.cSa + phn.cint + bas.cSpace + bas.cLu + bas.cci + bas.ca; // Saint Lucia

exports.cSaintLucia = cSaintLucia;
var cSaintVincent = bas.cSa + phn.cint + bas.cSpace + bas.cVi + phn.cnce + bas.cnt; // Saint Vincent

exports.cSaintVincent = cSaintVincent;
var cSomoa = bas.cSo + bas.cmo + bas.ca; // Somoa

exports.cSomoa = cSomoa;
var cSanMarino = gen.cSan + bas.cSpace + bas.cMa + bas.cri + bas.cno; // San Marino

exports.cSanMarino = cSanMarino;
var cSaoTome = bas.cSa + bas.co + bas.cSpace + bas.cT + phn.come; // Sao Tome

exports.cSaoTome = cSaoTome;
var cSaudiArabia = bas.cSa + bas.cud + bas.ci + bas.cSpace + bas.cA + bas.cra + phn.cbia; // Saudi Arabia

exports.cSaudiArabia = cSaudiArabia;
var cSenegal = bas.cSe + bas.cne + phn.cgal; // Senegal

exports.cSenegal = cSenegal;
var cSerbia = bas.cSe + bas.crb + bas.cia; // Serbia

exports.cSerbia = cSerbia;
var cSeychelles = bas.cSe + bas.cyc + bas.che + bas.cll + bas.ces; // Seychelles

exports.cSeychelles = cSeychelles;
var cSierraLeone = gen.cSierra + bas.cSpace + bas.cLe + num.cone; // Sierra Leone

exports.cSierraLeone = cSierraLeone;
var cSingapore = bas.cSi + phn.cnga + bas.cpo + bas.cre; // Singapore

exports.cSingapore = cSingapore;
var cSlovakia = bas.cSl + phn.cova + bas.cki + bas.ca; // Slovakia

exports.cSlovakia = cSlovakia;
var cSlovenia = bas.cSl + bas.cov + phn.cenia; // Slovenia

exports.cSlovenia = cSlovenia;
var cSolomonIslands = bas.cSo + bas.clo + phn.cmon + bas.cSpace + bas.cIs + bas.cla + phn.cnds; // Solomon Islands

exports.cSolomonIslands = cSolomonIslands;
var cSomalia = bas.cSo + phn.cmal + bas.cia; // Somalia

exports.cSomalia = cSomalia;
var cSouthAfrica = bas.cSo + bas.cut + bas.ch + bas.cSpace + bas.cA + phn.cfrica; // South Africa

exports.cSouthAfrica = cSouthAfrica;
var cSouthKorea = bas.cSo + bas.cut + bas.ch + bas.cSpace + bas.cK + phn.corea; // South Korea

exports.cSouthKorea = cSouthKorea;
var cSouthSudan = bas.cSo + bas.cut + bas.ch + bas.cSpace + bas.cS + phn.cudan; // South Sudan

exports.cSouthSudan = cSouthSudan;
var cSpain = bas.cSp + phn.cain; // Spain

exports.cSpain = cSpain;
var cSriLanka = bas.cSr + bas.ci + bas.cSpace + bas.cL + bas.can + bas.cka; // Sri Lanka

exports.cSriLanka = cSriLanka;
var cSudan = bas.cSu + phn.cdan; // Sudan

exports.cSudan = cSudan;
var cSuriname = bas.cSu + bas.cri + wr1.cname; // Suriname

exports.cSuriname = cSuriname;
var cSweden = bas.cSw + bas.ced + bas.cen; // Sweden

exports.cSweden = cSweden;
var cSwitzerland = bas.cSw + bas.cit + bas.cze + phn.crland; // Switzerland

exports.cSwitzerland = cSwitzerland;
var cSyria = bas.cSy + phn.cria; // Syria

exports.cSyria = cSyria;
var cTajikistan = bas.cTa + bas.cji + phn.ckistan; // Tajikistan

exports.cTajikistan = cTajikistan;
var cTanzania = bas.cTa + bas.cn + bas.cza + phn.cnia; // Tanzania

exports.cTanzania = cTanzania;
var cThailand = bas.cTh + phn.cail + phn.cand; // Thailand

exports.cThailand = cThailand;
var cTimorLeste = bas.cTi + bas.cmo + bas.cr + bas.cDash + bas.cL + phn.cest + bas.ce; // Timor-Leste

exports.cTimorLeste = cTimorLeste;
var cTogo = bas.cTo + bas.cgo; // Togo

exports.cTogo = cTogo;
var cTonga = bas.cTo + phn.cnga; // Tonga

exports.cTonga = cTonga;
var cTrinidadAndTabago = wr1.cTrinidad + bas.cSpace + wr1.cand + bas.cSpace + wr1.cTabago; // Trinidad and Tabago

exports.cTrinidadAndTabago = cTrinidadAndTabago;
var cTunisia = bas.cTu + bas.cni + phn.csia; // Tunisia

exports.cTunisia = cTunisia;
var cTurkey = bas.cTu + bas.crk + bas.cey; // Turkey

exports.cTurkey = cTurkey;
var cTurkmenistan = bas.cTu + bas.crk + phn.cmen + phn.cistan; // Turkmenistan

exports.cTurkmenistan = cTurkmenistan;
var cTuvalu = bas.cTu + phn.cval + bas.cu; // Tuvalu

exports.cTuvalu = cTuvalu;
var cUganda = bas.cUg + phn.canda; // Uganda

exports.cUganda = cUganda;
var cUkraine = bas.cUk + phn.crain + bas.ce; // Ukraine

exports.cUkraine = cUkraine;
var cUnitedArabEmirates = wr1.cUnited + bas.cSpace + wr1.cArab + bas.cSpace + wr1.cEmirates; // United Arab Emirates

exports.cUnitedArabEmirates = cUnitedArabEmirates;
var cUnitedKingdom = wr1.cUnited + bas.cSpace + bas.cKi + bas.cng + phn.cdom; // United Kingdom

exports.cUnitedKingdom = cUnitedKingdom;
var cUnitedStatesOfAmerica = wr1.cUnited + bas.cSpace + wr1.cStates + bas.cSpace + bas.cof + bas.cSpace + wr1.cAmerica; // United States of America

exports.cUnitedStatesOfAmerica = cUnitedStatesOfAmerica;
var cUruguay = bas.cUr + bas.cug + phn.cuay; // Uruguay

exports.cUruguay = cUruguay;
var cUzbekistan = bas.cUz + bas.cbe + phn.ckistan; // Uzbekistan

exports.cUzbekistan = cUzbekistan;
var cVanuatu = bas.cVa + bas.cnu + bas.cat + bas.cu; // Vanuatu

exports.cVanuatu = cVanuatu;
var cVenezuela = bas.cVe + bas.cne + bas.czu + phn.cela; // Venezuela

exports.cVenezuela = cVenezuela;
var cVietnam = bas.cVi + bas.cet + phn.cnam; // Vietnam

exports.cVietnam = cVietnam;
var cYemen = bas.cYe + phn.cmen; // Yemen

exports.cYemen = cYemen;
var cZambia = bas.cZa + phn.cmbia; // Zambia

exports.cZambia = cZambia;
var cZimbabwe = bas.cZi + bas.cmb + bas.cab + bas.cwe; // Zimbabwe

exports.cZimbabwe = cZimbabwe;