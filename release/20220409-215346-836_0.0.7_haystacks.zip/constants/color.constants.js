"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cruby = exports.crose = exports.cred = exports.cpurple = exports.cplum = exports.cplatnium = exports.cpink = exports.cpeach = exports.corange = exports.colive = exports.cmauve = exports.cmaroon = exports.cmagenta = exports.clime = exports.clilac = exports.clemon = exports.clavender = exports.cindigo = exports.cgrey = exports.cgreen = exports.cgray = exports.cgold = exports.cfuchsia = exports.cfandango = exports.cdrab = exports.ccyan = exports.ccrimson = exports.ccopper = exports.ccobalt = exports.ccherry = exports.ccadmium = exports.cbrown = exports.cblue = exports.cblack = exports.cbeige = exports.cazure = exports.caqua = exports.camethyst = exports.camber = exports.camaranth = exports.caero = exports.cYellow = exports.cWhite = exports.cViridian = exports.cViolet = exports.cVermilion = exports.cVanilla = exports.cUmber = exports.cTuscan = exports.cTurquoise = exports.cTitanium = exports.cTeal = exports.cTaupe = exports.cTangerine = exports.cTan = exports.cSilver = exports.cSienna = exports.cScarlet = exports.cSapphire = exports.cRuby = exports.cRose = exports.cRed = exports.cPurple = exports.cPlum = exports.cPlatnium = exports.cPink = exports.cPeach = exports.cOrange = exports.cOlive = exports.cMauve = exports.cMaroon = exports.cMagenta = exports.cLime = exports.cLilac = exports.cLemon = exports.cLavender = exports.cIndigo = exports.cGrey = exports.cGreen = exports.cGray = exports.cGold = exports.cFuchsia = exports.cFandango = exports.cDrab = exports.cCyan = exports.cCrimson = exports.cCopper = exports.cCobalt = exports.cCherry = exports.cCadmium = exports.cBrown = exports.cBlue = exports.cBlack = exports.cBeige = exports.cAzure = exports.cAqua = exports.cAmethyst = exports.cAmber = exports.cAmaranth = exports.cAero = void 0;
exports.cyellow = exports.cwhite = exports.cviridian = exports.cviolet = exports.cvermilion = exports.cvanilla = exports.cumber = exports.ctuscan = exports.cturquoise = exports.ctitanium = exports.cteal = exports.ctaupe = exports.ctangerine = exports.ctan = exports.csilver = exports.csienna = exports.cscarlet = exports.csapphire = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var phn = _interopRequireWildcard(require("./phonic.constants.js"));

var gen = _interopRequireWildcard(require("./generic.constants.js"));

var num = _interopRequireWildcard(require("./numeric.constants.js"));

var wr1 = _interopRequireWildcard(require("./word1.constants.js"));

var lng = _interopRequireWildcard(require("./language.constants.js"));

var ctr = _interopRequireWildcard(require("./country.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file color.constants.js
 * @module color.constants
 * @description Contains all named colors.
 * @requires module:basic.constants
 * @requires module:phonic.constants
 * @requires module:generic.constants
 * @requires module:numeric.constants
 * @requires module:word1.constants
 * @requires module:language.constants
 * @requires module:country.constants
 * @author Seth Hollingsead
 * @date 2022/02/21
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// NOTE: I changed e-x-p-o-r-t c-o-n-s-t => smuggle something,
// because the constants validation system is scanning these files looking for that keyword and
// if it finds it then it will use that line for vaidation purposes.
// So to reverse this, just do a find replace and chane // s.muggle soemthign back into the other e-x-p-o-r-t c-o-n-s-t string.
// The current state of the application doesn't need all of these, but future applications will most definately need them.
// So they are left here as a matter of future-proofing.
// Colors
// Primary Colors
var cred = bas.cr + bas.ced; // red

exports.cred = cred;
var cRed = bas.cR + bas.ced; // Red

exports.cRed = cRed;
var cgreen = bas.cg + phn.creen; // green

exports.cgreen = cgreen;
var cGreen = bas.cG + phn.creen; // Green

exports.cGreen = cGreen;
var cblue = bas.cb + phn.clue; // blue

exports.cblue = cblue;
var cBlue = bas.cB + phn.clue; // Blue
// Secondary Colors CMYK

exports.cBlue = cBlue;
var ccyan = bas.cc + phn.cyan; // cyan

exports.ccyan = ccyan;
var cCyan = bas.cC + phn.cyan; // Cyan

exports.cCyan = cCyan;
var cmagenta = bas.cm + bas.cag + phn.centa; // magenta

exports.cmagenta = cmagenta;
var cMagenta = bas.cM + bas.cag + phn.centa; // Magenta

exports.cMagenta = cMagenta;
var cyellow = wr1.cyell + bas.cow; // yellow

exports.cyellow = cyellow;
var cYellow = wr1.cYell + bas.cow; // Yellow

exports.cYellow = cYellow;
var cblack = bas.cb + wr1.clack; // black

exports.cblack = cblack;
var cBlack = bas.cB + wr1.clack; // Black

exports.cBlack = cBlack;
var cwhite = bas.cwh + phn.cite; // white

exports.cwhite = cwhite;
var cWhite = bas.cWh + phn.cite; // White

exports.cWhite = cWhite;
var corange = bas.cor + phn.cange; // orange

exports.corange = corange;
var cOrange = bas.cOr + phn.cange; // Orange
// Common Colors

exports.cOrange = cOrange;
var cbrown = bas.cbr + phn.cown; // brown

exports.cbrown = cbrown;
var cBrown = bas.cBr + phn.cown; // Brown

exports.cBrown = cBrown;
var cgrey = bas.cg + phn.crey; // grey

exports.cgrey = cgrey;
var cGrey = bas.cG + phn.crey; // Grey

exports.cGrey = cGrey;
var cgray = bas.cg + phn.cray; // gray

exports.cgray = cgray;
var cGray = bas.cG + phn.cray; // Gray

exports.cGray = cGray;
var cpink = bas.cp + phn.cink; // pink

exports.cpink = cpink;
var cPink = bas.cP + phn.cink; // Pink

exports.cPink = cPink;
var clavender = bas.cl + phn.cavender; // lavender

exports.clavender = clavender;
var cLavender = bas.cL + phn.cavender; // Lavender

exports.cLavender = cLavender;
var cpurple = bas.cp + phn.curple; // purple

exports.cpurple = cpurple;
var cPurple = bas.cP + phn.curple; // Purple

exports.cPurple = cPurple;
var cviolet = bas.cv + phn.ciolet; // violet

exports.cviolet = cviolet;
var cViolet = bas.cV + phn.ciolet; // Violet

exports.cViolet = cViolet;
var clilac = bas.cl + phn.cilac; // lilac

exports.clilac = clilac;
var cLilac = bas.cL + phn.cilac; // Lilac

exports.cLilac = cLilac;
var cmaroon = bas.cm + phn.caroon; // maroon

exports.cmaroon = cmaroon;
var cMaroon = bas.cM + phn.caroon; // Maroon

exports.cMaroon = cMaroon;
var crose = bas.cr + phn.cose; // rose

exports.crose = crose;
var cRose = bas.cR + phn.cose; // Rose

exports.cRose = cRose;
var cscarlet = bas.csc + bas.car + wr1.clet; // scarlet

exports.cscarlet = cscarlet;
var cScarlet = bas.cSc + bas.car + wr1.clet; // Scarlet

exports.cScarlet = cScarlet;
var cruby = bas.cr + phn.cuby; // ruby

exports.cruby = cruby;
var cRuby = bas.cR + phn.cuby; // Ruby

exports.cRuby = cRuby;
var cgold = bas.cg + wr1.cold; // gold

exports.cgold = cgold;
var cGold = bas.cG + wr1.cold; // Gold

exports.cGold = cGold;
var csilver = bas.cs + phn.cilver; // silver

exports.csilver = csilver;
var cSilver = bas.cS + phn.cilver; // Silver

exports.cSilver = cSilver;
var ccopper = bas.cc + phn.copper; // copper

exports.ccopper = ccopper;
var cCopper = bas.cC + phn.copper; // Copper

exports.cCopper = cCopper;
var ccobalt = bas.cc + phn.cobalt; // cobalt

exports.ccobalt = ccobalt;
var cCobalt = bas.cC + phn.cobalt; // Cobalt

exports.cCobalt = cCobalt;
var ctan = bas.cta + bas.cn; // tan

exports.ctan = ctan;
var cTan = bas.cTa + bas.cn; // Tan

exports.cTan = cTan;
var ctitanium = bas.cti + ctan + phn.cium; // titanium

exports.ctitanium = ctitanium;
var cTitanium = bas.cTi + ctan + phn.cium; // Titanium

exports.cTitanium = cTitanium;
var ccadmium = bas.cca + bas.cd + phn.cmium; // cadmium

exports.ccadmium = ccadmium;
var cCadmium = bas.cCa + bas.cd + phn.cmium; // Cadmium

exports.cCadmium = cCadmium;
var cplatnium = bas.cpl + bas.cat + phn.cnium; // platnium

exports.cplatnium = cplatnium;
var cPlatnium = bas.cPl + bas.cat + phn.cnium; // Platnium

exports.cPlatnium = cPlatnium;
var csapphire = wr1.csap + phn.cphire; // sapphire

exports.csapphire = csapphire;
var cSapphire = wr1.cSap + phn.cphire; // Sapphire

exports.cSapphire = cSapphire;
var cteal = bas.ct + phn.ceal; // teal

exports.cteal = cteal;
var cTeal = bas.cT + phn.ceal; // Teal

exports.cTeal = cTeal;
var ctaupe = bas.ct + phn.caupe; // taupe

exports.ctaupe = ctaupe;
var cTaupe = bas.cT + phn.caupe; // Taupe

exports.cTaupe = cTaupe;
var cdrab = bas.cd + phn.crab; // drab

exports.cdrab = cdrab;
var cDrab = bas.cD + phn.crab; // Drab

exports.cDrab = cDrab;
var cturquoise = bas.ctu + phn.crquoise; // turquoise

exports.cturquoise = cturquoise;
var cTurquoise = bas.cTu + phn.crquoise; // Turquoise

exports.cTurquoise = cTurquoise;
var ctangerine = ctan + phn.cgerine; // tangerine

exports.ctangerine = ctangerine;
var cTangerine = cTan + phn.cgerine; // Tangerine

exports.cTangerine = cTangerine;
var cumber = bas.cu + phn.cmber; // umber

exports.cumber = cumber;
var cUmber = bas.cU + phn.cmber; // Umber

exports.cUmber = cUmber;
var cvanilla = wr1.cvan + phn.cilla; // vanilla

exports.cvanilla = cvanilla;
var cVanilla = wr1.cVan + phn.cilla; // Vanilla

exports.cVanilla = cVanilla;
var caero = bas.ca + phn.cero; // aero

exports.caero = caero;
var cAero = bas.cA + phn.cero; // Aero

exports.cAero = cAero;
var caqua = bas.ca + phn.cqua; // aqua

exports.caqua = caqua;
var cAqua = bas.cA + phn.cqua; // Aqua

exports.cAqua = cAqua;
var camber = bas.ca + phn.cmber; // amber

exports.camber = camber;
var cAmber = bas.cA + phn.cmber; // Amber

exports.cAmber = cAmber;
var camethyst = bas.cam + phn.ceth + phn.cyst; // amethyst

exports.camethyst = camethyst;
var cAmethyst = bas.cAm + phn.ceth + phn.cyst; // Amethyst

exports.cAmethyst = cAmethyst;
var camaranth = bas.ca + phn.cmaranth; // amaranth

exports.camaranth = camaranth;
var cAmaranth = bas.cA + phn.cmaranth; // Amaranth

exports.cAmaranth = cAmaranth;
var cazure = bas.caz + phn.cure; // azure

exports.cazure = cazure;
var cAzure = bas.cAz + phn.cure; // Azure

exports.cAzure = cAzure;
var cbeige = bas.cbe + phn.cige; // beige

exports.cbeige = cbeige;
var cBeige = bas.cBe + phn.cige; // Beige

exports.cBeige = cBeige;
var ccherry = bas.cch + phn.cerry; // cherry

exports.ccherry = ccherry;
var cCherry = bas.cCh + phn.cerry; // Cherry

exports.cCherry = cCherry;
var ccrimson = bas.cc + phn.crimson; // crimson

exports.ccrimson = ccrimson;
var cCrimson = bas.cC + phn.crimson; // Crimson

exports.cCrimson = cCrimson;
var colive = bas.co + phn.clive; // olive

exports.colive = colive;
var cOlive = bas.cO + phn.clive; // Olive

exports.cOlive = cOlive;
var csienna = bas.cs + phn.cienna; // sienna

exports.csienna = csienna;
var cSienna = bas.cS + phn.cienna; // Sienna

exports.cSienna = cSienna;
var cfandango = bas.cf + phn.candango; // fandango

exports.cfandango = cfandango;
var cFandango = bas.cF + phn.candango; // Fandango

exports.cFandango = cFandango;
var cfuchsia = bas.cf + phn.cuchsia; // fuchsia

exports.cfuchsia = cfuchsia;
var cFuchsia = bas.cF + phn.cuchsia; // Fuchsia

exports.cFuchsia = cFuchsia;
var clime = bas.cl + phn.cime; // lime

exports.clime = clime;
var cLime = bas.cL + phn.cime; // Lime

exports.cLime = cLime;
var cindigo = bas.ci + phn.cndigo; // indigo

exports.cindigo = cindigo;
var cIndigo = bas.cI + phn.cndigo; // Indigo

exports.cIndigo = cIndigo;
var clemon = bas.cl + phn.cemon; // lemon

exports.clemon = clemon;
var cLemon = bas.cL + phn.cemon; // Lemon

exports.cLemon = cLemon;
var cmauve = bas.cm + phn.cauve; // mauve

exports.cmauve = cmauve;
var cMauve = bas.cM + phn.cauve; // Mauve

exports.cMauve = cMauve;
var cpeach = bas.cp + phn.ceach; // peach

exports.cpeach = cpeach;
var cPeach = bas.cP + phn.ceach; // Peach

exports.cPeach = cPeach;
var cplum = bas.cp + phn.clum; // plum

exports.cplum = cplum;
var cPlum = bas.cP + phn.clum; // Plum

exports.cPlum = cPlum;
var ctuscan = bas.ct + phn.cuscan; // tuscan

exports.ctuscan = ctuscan;
var cTuscan = bas.cT + phn.cuscan; // Tuscan

exports.cTuscan = cTuscan;
var cviridian = bas.cv + phn.ciridian; // viridian

exports.cviridian = cviridian;
var cViridian = bas.cV + phn.ciridian; // Viridian

exports.cViridian = cViridian;
var cvermilion = bas.cv + phn.cermilion; // vermilion

exports.cvermilion = cvermilion;
var cVermilion = bas.cV + phn.cermilion; // Vermilion
// Tertiary Named Colors
// https://en.wikipedia.org/wiki/List_of_colors:_A%E2%80%93F
// https://en.wikipedia.org/wiki/List_of_colors:_G%E2%80%93M
// https://en.wikipedia.org/wiki/List_of_colors:_N%E2%80%93Z
// smuggle something cAbsoluteZero = wr1.cAbsolute + num.cZero; // AbsoluteZero
// smuggle something cAcidGreen = wr1.cAcid + cGreen; // AcidGreen
// smuggle something cAeroBlue = cAero + cBlue; // AeroBlue
// smuggle something cAfricanViolet = wr1.cAfrican + cViolet; // AfricanViolet
// smuggle something cAirSuperiorityBlue = wr1.cAir + wr1.cSuperiority + cBlue; // AirSuperiorityBlue
// smuggle something cAliceBlue = wr1.cAlice + cBlue; // AliceBlue
// smuggle something cAlloyOrange = wr1.cAlloy + cOrange; // AlloyOrange
// smuggle something cAlmond = bas.cAl + phn.cmond; // Almond
// smuggle something cAmaranthMP = cAmaranth + bas.cMP; // AmaranthMP
// smuggle something cAmaranthPink = cAmaranth + cPink; // AmaranthPink
// smuggle something cAmaranthPurple = cAmaranth + cPurple; // AmaranthPurple
// smuggle something cAmaranthRed = cAmaranth + cRed; // AmaranthRed
// smuggle something cAmazon = bas.cAm + bas.caz + bas.con; // Amazon
// smuggle something cAmberSAEECE = cAmber + bas.cSA + bas.cEE + bas.cCE; // AmberSAEECE
// smuggle something cAndroidGreen = wr1.cAndroid + cGreen; // AndroidGreen
// smuggle something cAntiqueBrass = wr1.cAntique + wr1.cBrass; // AntiqueBrass
// smuggle something cAntiqueBronze = wr1.cAntique + wr1.cBronze; // AntiqueBronze
// smuggle something cAntiqueFuchsia = wr1.cAntique + cFuchsia; // AntiqueFuchsia
// smuggle something cAntiqueRuby = wr1.cAntique + cRuby; // AntiqueRuby
// smuggle something cAntiqueWhite = wr1.cAntique + cWhite; // AntiqueWhite
// smuggle something cAoEnglish = bas.cAo + lng.cEnglish; // AoEnglish
// smuggle something cAppleGreen = wr1.cApple + cGreen; // AppleGreen
// smuggle something cAquamarine = cAqua + phn.cmar + phn.cine; // Aquamarine
// smuggle something cArcticLime = wr1.cArctic + cLime; // ArcticLime
// smuggle something cArmyGreen = wr1.cArmy + cGreen; // ArmyGreen
// smuggle something cArtichoke = bas.cAr + phn.ctic + bas.cho + bas.cke; // Artichoke
// smuggle something cArylideYellow = wr1.cArylide + cYellow; // ArylideYellow
// smuggle something cAshGray = wr1.cAsh + cGray; // AshGray
// smuggle something cAsparagus = bas.cAs + phn.cpara + bas.cgu + bas.cs; // Asparagus
// smuggle something cAtomicTangerine = wr1.cAtomic + cTangerine; // AtomicTangerine
// smuggle something cAuburn = bas.cAu + bas.cbu + bas.crn; // Auburn
// smuggle something cAureolin = bas.cAu + bas.cre + phn.colin; // Aureolin
// smuggle something cAvocado = bas.cAv + bas.coc + phn.cado; // Avocado
// smuggle something cAzureWeb = cAzure + wr1.cWeb; // AzureWeb
// smuggle something cBabyBlue = wr1.cBaby + cBlue; // BabyBlue
// smuggle something cBabyBlueEyes = wr1.cBaby + cBlue + wr1.cEyes; // BabyBlueEyes
// smuggle something cBabyPink = wr1.cBaby + cPink; // BabyPink
// smuggle something cBabyPowder = wr1.cBaby + wr1.cPowder; // BabyPowder
// smuggle something cBakerMillerPink = wr1.cBaker + wr1.cMiller + cPink; // BakerMillerPink
// smuggle something cBananaMania = wr1.cBanana + wr1.cMania; // BananaMania
// smuggle something cBarbiePink = wr1.cBarbie + cPink; // BarbiePink
// smuggle something cBarnRed = wr1.cBarn + cRed; // BarnRed
// smuggle something cBattleshipGrey = wr1.cBattleship + cGrey; // BattleshipGrey
// smuggle something cBeauBlue = wr1.cBeau + cBlue; // BeauBlue
// smuggle something cBeaver = bas.cBe + phn.cave + bas.cr; // Beaver
// smuggle something cBDazzledBlue = bas.cB + wr1.cDazzled + cBlue; // BDazzledBlue
// smuggle something cBigDipORuby = wr1.cBig + bas.cDi + bas.cpO + cRuby; // BigDipORuby
// smuggle something cBisque = bas.cBi + bas.csq + bas.cue; // Bisque
// smuggle something cBistreBrown = wr1.cBistre + cBrown; // BistreBrown
// smuggle something cBitterLemon = wr1.cBitter + cLemon; // BitterLemon
// smuggle something cBitterLime = wr1.cBitter + cLime; // BitterLime
// smuggle something cBittersweet = wr1.cBittersweet; // Bittersweet
// smuggle something cBittersweetShimmer = wr1.cBittersweet + wr1.cShimmer; // BittersweetShimmer
// smuggle something cBlackBean = cBlack + wr1.cBean; // BlackBean
// smuggle something cBlackChocolate = cBlack + wr1.cChocolate; // BlackChocolate
// smuggle something cBlackCoffee = cBlack + wr1.cCoffee; // BlackCoffee
// smuggle something cBlackCoral = cBlack + wr1.cCoral; // BlackCoral
// smuggle something cBlackOlive = cBlack + cOlive; // BlackOlive
// smuggle something cBlackShadows = cBlack + wr1.cShadows; // BlackShadows
// smuggle something cBlanchedAlmond = wr1.cBlanched + bas.cAl + phn.cmond; // BlanchedAlmond
// smuggle something cBlastOffBronze = wr1.cBlast + gen.cOff + wr1.cBronze; // BlastOffBronze
// smuggle something cBleuDeFrance = bas.cBl + bas.ceu + bas.cDe + ctr.cFrance; // BleuDeFrance
// smuggle something cBlizzardBlue = wr1.cBlizzard + cBlue; // BlizzardBlue
// smuggle something cBlond = bas.cBl + phn.cond; // Blond
// smuggle something cBloodRed = wr1.cBlood + cRed; // BloodRed
// smuggle something cBlueCrayola = cBlue + wr1.cCrayola; // BlueCrayola
// smuggle something cBlueMunsell = cBlue + wr1.cMunsell; // BlueMunsell
// smuggle something cBlueNCS = cBlue + phn.cNCS; // BlueNCS
// smuggle something cBluePantone = cBlue + wr1.cPantone; // BluePantone
// smuggle something cBluePigment = cBlue + wr1.cPigment; // BluePigment
// smuggle something cBlueRYB = cBlue + phn.cRYB; // BlueRYB
// smuggle something cBlueBell = cBlue + wr1.cBell; // BlueBell
// smuggle something cBlueGray = cBlue + cGray; // BlueGray
// smuggle something cBlueGreen = cBlue + cGreen; // BlueGreen
// smuggle something cBlueGreenColorWheel = cBlue + cGreen + wr1.cColor + wr1.cWheel; // BlueGreenColorWheel
// smuggle something cBlueJeans = cBlue + wr1.cJeans; // BlueJeans
// smuggle something cBlueSapphire = cBlue + cSapphire; // BlueSapphire
// smuggle something cBlueViolet = cBlue + cViolet; // BlueViolet
// smuggle something cBlueVioletCrayola = cBlue + cViolet + wr1.cCrayola; // BlueVioletCrayola
// smuggle something cBlueVioletColorWheel = cBlue + cViolet + wr1.cColor + wr1.cWheel; // BlueVioletColorWheel
// smuggle something cBlueYonder = cBlue + wr1.cYonder; // BlueYonder
// smuggle something cBluetiful = cBlue + bas.cti + phn.cful; // Bluetiful
// smuggle something cBlush = wr1.cBlush; // Blush
// smuggle something cBole = bas.cBo + bas.cle; // Bole
// smuggle something cBone = bas.cBo + bas.cne; // Bone
// smuggle something cBottleGreen = wr1.cBottle + cGreen; // BottleGreen
// smuggle something cBrandy = phn.cBra + phn.cndy; // Brandy
// smuggle something cBrickRed = wr1.cBrick + cRed; // BrickRed
// smuggle something cBrightGreen = wr1.cBright + cGreen; // BrightGreen
// smuggle something cBrightLilac = wr1.cBright + cLilac; // BrightLilac
// smuggle something cBrightMaroon = wr1.cBright + cMaroon; // BrightMaroon
// smuggle something cBrightNavyBlue = wr1.cBright + wr1.cNavy + cBlue; // BrightNavyBlue
// smuggle something cBrightYellowCrayola = wr1.cBright + cYellow + wr1.cCrayola; // BrightYellowCrayola
// smuggle something cBrilliantRose = wr1.cBrilliant + cRose; // BrilliantRose
// smuggle something cBrinkPink = bas.cBr + phn.cink + cPink; // BrinkPink
// smuggle something cBritishRacingGreen = bas.cBr + phn.citi + bas.csh + wr1.cRacing + cGreen; // BritishRacingGreen
// smuggle something cBronze = wr1.cBronze; // Bronze
// smuggle something cBrownSugar = cBrown + wr1.cSugar; // BrownSugar
// smuggle something cBrunswickGreen = wr1.cBrunswick + cGreen; // BrunswickGreen
// smuggle something cBudGreen = wr1.cBud + cGreen; // BudGreen
// smuggle something cBuff = bas.cBu + bas.cff; // Buff
// smuggle something cBurgundy = bas.cBu + phn.crgundy; // Burgundy
// smuggle something cBurlywood = wr1.cBurly + wr1.cwood; // Burlywood
// smuggle something cBurnishedBrown = wr1.cBurnished + cBrown; // BurnishedBrown
// smuggle something cBurntOrange = wr1.cBurnt + cOrange; // BurntOrange
// smuggle something cBurntSienna = wr1.cBurnt + cSienna; // BurntSienna
// smuggle something cBurntUmber = wr1.cBurnt + cUmber; // BurntUmber
// smuggle something cByzantine = bas.cBy + bas.cza + bas.cnt + phn.cine; // Byzantine
// smuggle something cByzantium = wr1.cByzantium; // Byzantium
// smuggle something cCadet = wr1.cCadet; // Cadet
// smuggle something cCadetBlue = wr1.cCadet + cBlue; // CadetBlue
// smuggle something cCadetBlueCrayola = wr1.cCadet + cBlue + wr1.cCrayola; // CadetBlueCrayola
// smuggle something cCadetGrey = wr1.cCadet + cGrey; // CadetGrey
// smuggle something cCadmiumGreen = cCadmium + cGreen; // CadmiumGreen
// smuggle something cCadmiumOrange = cCadmium + cOrange; // CadmiumOrange
// smuggle something cCadmiumRed = cCadmium + cRed; // CadmiumRed
// smuggle something cCadmiumYellow = cCadmium + cYellow; // CadmiumYellow
// smuggle something cCafeAuLait = wr1.cCafe + bas.cAu + bas.cLa + bas.cit; // CafeAuLait
// smuggle something cCafeNoir = wr1.cCafe + bas.cNo + bas.cir; // CafeNoir
// smuggle something cCambridgeBlue = wr1.cCambridge + cBlue; // CambridgeBlue
// smuggle something cCameoPink = wr1.cCameo + cPink; // CameoPink
// smuggle something cCanary = wr1.cCan + phn.cary; // Canary
// smuggle something cCanaryYellow = wr1.cCan + phn.cary + cYellow; // CanaryYellow
// smuggle something cCandyAppleRed = wr1.cCan + bas.cdy + wr1.cApple + cRed; // CandyAppleRed
// smuggle something cCandyPink = wr1.cCan + bas.cdy + cPink; // CandyPink
// smuggle something cCapri = bas.cCa + phn.cpri; // Capri
// smuggle something cCaputMortuum = wr1.cCaput + wr1.cMortuum; // CaputMortuum
// smuggle something cCardinal = bas.cCa + bas.crd + phn.cinal; // Cardinal
// smuggle something cCaribbeanGreen = wr1.cCaribbean + cGreen; // CaribbeanGreen
// smuggle something cCarmine = wr1.cCarmine; // Carmine
// smuggle something cCarmineMP = wr1.cCarmine + bas.cMP; // CarmineMP
// smuggle something cCarnationPink = wr1.cCarnation + cPink; // CarnationPink
// smuggle something cCarnelian = bas.cCa + bas.crn + bas.cel + phn.cian; // Carnelian
// smuggle something cCarolinaBlue = bas.cCa + bas.cro + phn.clin + bas.caB + phn.clue; // CarolinaBlue
// smuggle something cCarrotOrange = wr1.cCarrot + cOrange; // CarrotOrange
// smuggle something cCastletonGreen = wr1.cCastleton + cGreen; // CastletonGreen
// smuggle something cCatawba = bas.cCa + bas.cta + bas.cwb + bas.ca; // Catawba
// smuggle something cCedarChest = wr1.cCedar + wr1.cChest; // CedarChest
// smuggle something cCeladon = wr1.cCeladon; // Celadon
// smuggle something cCeladonBlue = wr1.cCeladon + cBlue; // CeladonBlue
// smuggle something cCeladonGreen = wr1.cCeladon + cGreen; // CeladonGreen
// smuggle something cCeleste = phn.cCel + phn.cest + bas.ce; // Celeste
// smuggle something cCelticBlue = wr1.cCeltic + cBlue; // CelticBlue
// smuggle something cCerise = wr1.cCerise; // Cerise
// smuggle something cCerulean = bas.cCe + phn.crulean; // Cerulean
// smuggle something cCeruleanBlue = bas.cCe + phn.crulean + cBlue; // CeruleanBlue
// smuggle something cCeruleanFrost = bas.cCe + phn.crulean + wr1.cFrost; // CeruleanFrost
// smuggle something cCeruleanCrayola = bas.cCe + phn.crulean + wr1.cCrayola; // CeruleanCrayola
// smuggle something cCGBlue = bas.cCG + cBlue; // CGBlue
// smuggle something cCGRed = bas.cCG + cRed; // CGRed
// smuggle something cChampagne = bas.cCh + phn.campagne; // Champagne
// smuggle something cChampagnePink = bas.cCh + phn.campagne + cPink; // ChampagnePink
// smuggle something cCharcoal = wr1.cChar + bas.cco + bas.cal; // Charcoal
// smuggle something cCharlestonGreen = wr1.cCharleston + cGreen; // CharlestonGreen
// smuggle something cCharmPink = wr1.cCharm + cPink; // CharmPink
// smuggle something cChartreuseTraditional = wr1.cChartreuse + wr1.cTraditional; // ChartreuseTraditional
// smuggle something cChartreuseWeb = wr1.cChartreuse + wr1.cWeb; // ChartreuseWeb
// smuggle something cCherryBlossomPink = cCherry + wr1.cBlossom + cPink; // CherryBlossomPink
// smuggle something cChestnut = wr1.cChestnut; // Chestnut
// smuggle something cChinaPink = ctr.cChina + cPink; // ChinaPink
// smuggle something cChinaRose = ctr.cChina + cRose; // ChinaRose
// smuggle something cChineseRed = lng.cChinese + cRed; // ChineseRed
// smuggle something cChineseViolet = lng.cChinese + cViolet; // ChineseViolet
// smuggle something cChineseYellow = lng.cChinese + cYellow; // ChineseYellow
// smuggle something cChocolateTraditional = wr1.cChocolate + wr1.cTraditional; // ChocolateTraditional
// smuggle something cChocolateWeb = wr1.cChocolate + wr1.cWeb; // ChocolateWeb
// smuggle something cChromeYellow = wr1.cChrome + cYellow; // ChromeYellow
// smuggle something cCinereous = bas.cCi + bas.cne + bas.cre + phn.cous; // Cinereous
// smuggle something cCinnabar = bas.cCi + phn.cnna + bas.cba + bas.cr; // Cinnabar
// smuggle something cCinnamonSatin = wr1.cCinnamon + wr1.cSatin; // CinnamonSatin
// smuggle something cCitrine = bas.cCi + phn.ctri + bas.cne; // Citrine
// smuggle something cCitron = bas.cCi + bas.ctr + bas.con; // Citron
// smuggle something cClaret = bas.cCl + phn.care + bas.ct; // Claret
// smuggle something cCobaltBlue = cCobalt + cBlue; // CobaltBlue
// smuggle something cCocoaBrown = wr1.cCocoa + cBrown; // CocoaBrown
// smuggle something cCoffee = wr1.cCoffee; // Coffee
// smuggle something cColumbiaBlue = wr1.cColumbia + cBlue; // ColumbiaBlue
// smuggle something cCongoPink = ctr.cCongo + cPink; // CongoPink
// smuggle something cCoolGrey = wr1.cCool + cGrey; // CoolGrey
// smuggle something cCopperCrayola = cCopper + wr1.cCrayola; // CopperCrayola
// smuggle something cCopperPenny = cCopper + wr1.cPen + bas.cny; // CopperPenny
// smuggle something cCopperRed = cCopper + cRed; // CopperRed
// smuggle something cCopperRose = cCopper + cRose; // CopperRose
// smuggle something cCoquelicot = bas.cCo + phn.cque + phn.clic + bas.cot; // Coquelicot
// smuggle something cCoral = wr1.cCoral; // Coral
// smuggle something cCoralPink = wr1.cCoral + cPink; // CoralPink
// smuggle something cCordovan = phn.cCor + bas.cdo + wr1.cvan; // Cordovan
// smuggle something cCorn = phn.cCor + bas.cn; // Corn
// smuggle something cCornflowerBlue = phn.cCor + bas.cnf + wr1.clower + cBlue; // CornflowerBlue
// smuggle something cCornsilk = phn.cCor + bas.cns + phn.cilk; // Cornsilk
// smuggle something cCosmicCobalt = wr1.cCosmic + cCobalt; // CosmicCobalt
// smuggle something cCosmicLatte = wr1.cCosmic + wr1.cLatte; // CosmicLatte
// smuggle something cCoyoteBrown = wr1.cCoyote + cBrown; // CoyoteBrown
// smuggle something cCottonCandy = wr1.cCotton + wr1.cCan + bas.cdy; // CottonCandy
// smuggle something cCream = bas.cCr + phn.ceam; // Cream
// smuggle something cCrimsonUA = cCrimson + bas.cUA; // CrimsonUA
// smuggle something cCultured = bas.cCu + bas.clt + phn.cured; // Cultured
// smuggle something cCyanProcess = cCyan + wr1.cProcess; // CyanProcess
// smuggle something cCyberGrape = wr1.cCyber + bas.cGr + phn.cape; // CyberGrape
// smuggle something cCyberYellow = wr1.cCyber + cYellow; // CyberYellow
// smuggle something cCyclamen = bas.cCy + bas.ccl + phn.camen; // Cyclamen
// smuggle something cDarkBlueGray = wr1.cDark + cBlue + cGray; // DarkBlueGray
// smuggle something cDarkBrown = wr1.cDark + cBrown; // DarkBrown
// smuggle something cDarkByzantium = wr1.cDark + wr1.cByzantium; // DarkByzantium
// smuggle something cDarkCornflowerBlue = wr1.cDark + phn.cCor + bas.cnf + wr1.clower + cBlue; // DarkCornflowerBlue
// smuggle something cDarkCyan = wr1.cDark + cCyan; // DarkCyan
// smuggle something cDarkElectricBlue = wr1.cDark + wr1.cElectric + cBlue; // DarkElectricBlue
// smuggle something cDarkGoldenrod = wr1.cDark + cGold + bas.cen + bas.cro + bas.cd; // DarkGoldenrod
// smuggle something cDarkGreen = wr1.cDark + cGreen; // DarkGreen
// smuggle something cDarkGreenX11 = wr1.cDark + cGreen + bas.cX + num.c11; // DarkGreenX11
// smuggle something cDarkJungleGreen = wr1.cDark + bas.cJu + bas.cng + bas.cle + cGreen; // DarkJungleGreen
// smuggle something cDarkKhaki = wr1.cDark + wr1.cKhaki; // DarkKhaki
// smuggle something cDarkLava = wr1.cDark + bas.cLa + bas.cva; // DarkLava
// smuggle something cDarkLiver = wr1.cDark + wr1.cLiver; // DarkLiver
// smuggle something cDarkLiverHorses = wr1.cDark + wr1.cLiver + wr1.cHorses; // DarkLiverHorses
// smuggle something cDarkMagenta = wr1.cDark + cMagenta; // DarkMagenta
// smuggle something cDarkMossGreen = wr1.cDark + wr1.cMoss + cGreen; // DarkMossGreen
// smuggle something cDarkOliveGreen = wr1.cDark + cOlive + cGreen; // DarkOliveGreen
// smuggle something cDarkOrange = wr1.cDark + cOrange; // DarkOrange
// smuggle something cDarkOrchid = wr1.cDark + bas.cOr + phn.cchid; // DarkOrchid
// smuggle something cDarkPastelGreen = wr1.cDark + wr1.cPastel + cGreen; // DarkPastelGreen
// smuggle something cDarkPurple = wr1.cDark + cPurple; // DarkPurple
// smuggle something cDarkRed = wr1.cDark + cRed; // DarkRed
// smuggle something cDarkSalmon = wr1.cDark + bas.cSa + phn.clmon; // DarkSalmon
// smuggle something cDarkSeaGreen = wr1.cDark + wr1.cSea + cGreen; // DarkSeaGreen
// smuggle something cDarkSienna = wr1.cDark + cSienna; // DarkSienna
// smuggle something cDarkSkyBlue = wr1.cDark + wr1.cSky + cBlue; // DarkSkyBlue
// smuggle something cDarkSlateBlue = wr1.cDark + wr1.cSlate + cBlue; // DarkSlateBlue
// smuggle something cDarkSlateGray = wr1.cDark + wr1.cSlate + cGray; // DarkSlateGray
// smuggle something cDarkSpringGreen = wr1.cDark + wr1.cSpring + cGreen; // DarkSpringGreen
// smuggle something cDarkTurquoise = wr1.cDark + cTurquoise; // DarkTurquoise
// smuggle something cDarkViolet = wr1.cDark + cViolet; // DarkViolet
// smuggle something cDartmouthGreen = wr1.cDartmouth + cGreen; // DartmouthGreen
// smuggle something cDavysGrey = wr1.cDavys + cGrey; // DavysGrey
// smuggle something cDeepCerise = wr1.cDeep + wr1.cCerise; // DeepCerise
// smuggle something cDeepChampagne = wr1.cDeep + bas.cCh + phn.campagne; // DeepChampagne
// smuggle something cDeepChestnut = wr1.cDeep + wr1.cChestnut; // DeepChestnut
// smuggle something cDeepJungleGreen = wr1.cDeep + bas.cJu + bas.cng + bas.cle + cGreen; // DeepJungleGreen
// smuggle something cDeepPink = wr1.cDeep + cPink; // DeepPink
// smuggle something cDeepSaffron = wr1.cDeep + bas.cSa + phn.cffron; // DeepSaffron
// smuggle something cDeepSkyBlue = wr1.cDeep + wr1.cSky + cBlue; // DeepSkyBlue
// smuggle something cDeepSpaceSparkle = wr1.cDeep + wr1.cSpace + wr1.cSparkle; // DeepSpaceSparkle
// smuggle something cDeepTaupe = wr1.cDeep + cTaupe; // DeepTaupe
// smuggle something cDenim = bas.cDe + phn.cnim; // Denim
// smuggle something cDenimBlue = bas.cDe + phn.cnim + cBlue; // DenimBlue
// smuggle something cDesert = bas.cDe + phn.csert; // Desert
// smuggle something cDesertSand = bas.cDe + phn.csert + gen.cSan + bas.cd; // DesertSand
// smuggle something cDimGray = wr1.cDim + cGray; // DimGray
// smuggle something cDodgerBlue = wr1.cDodger + cBlue; // DodgerBlue
// smuggle something cDogwoodRose = wr1.cDogwood + cRose; // DogwoodRose
// smuggle something cDukeBlue = wr1.cDuke + cBlue; // DukeBlue
// smuggle something cDutchWhite = wr1.cDutch + cWhite; // DutchWhite
// smuggle something cEarthYellow = wr1.cEarth + cYellow; // EarthYellow
// smuggle something cEbony = wr1.cEbony; // Ebony
// smuggle something cEcru = bas.cEc + bas.cru; // Ecru
// smuggle something cEerieBlack = wr1.cEerie + cBlack; // EerieBlack
// smuggle something cEggplant = wr1.cEgg + bas.cpl + phn.cant; // Eggplant
// smuggle something cEggshell = wr1.cEgg + wr1.cshell; // Eggshell
// smuggle something cEgyptianBlue = ctr.cEgypt + phn.cian + cBlue; // EgyptianBlue
// smuggle something cElectricBlue = wr1.cElectric + cBlue; // ElectricBlue
// smuggle something cElectricGreen = wr1.cElectric + cGreen; // ElectricGreen
// smuggle something cElectricIndigo = wr1.cElectric + cIndigo; // ElectricIndigo
// smuggle something cElectricLime = wr1.cElectric + cLime; // ElectricLime
// smuggle something cElectricPurple = wr1.cElectric + cPurple; // ElectricPurple
// smuggle something cElectricViolet = wr1.cElectric + cViolet; // ElectricViolet
// smuggle something cEmerald = bas.cEm + phn.cerald; // Emerald
// smuggle something cEminence = bas.cEm + phn.cinen + bas.cce; // Eminence
// smuggle something cEnglishGreen = lng.cEnglish + cGreen; // EnglishGreen
// smuggle something cEnglishLavender = lng.cEnglish + cLavender; // EnglishLavender
// smuggle something cEnglishRed = lng.cEnglish + cRed; // EnglishRed
// smuggle something cEnglishVermillion = lng.cEnglish + phn.cVer + num.cmillion; // EnglishVermillion
// smuggle something cEnglishViolet = lng.cEnglish + cViolet; // EnglishViolet
// smuggle something cErin = bas.cEr + bas.cin; // Erin
// smuggle something cEtonBlue = wr1.cEton + cBlue; // EtonBlue
// smuggle something cFallow = bas.cFa + phn.cllow; // Fallow
// smuggle something cFaluRed = wr1.cFalu + cRed; // FaluRed
// smuggle something cFandangoPink = cFandango + cPink; // FandangoPink
// smuggle something cFashionFuchsia = wr1.cFashion + cFuchsia; // FashionFuchsia
// smuggle something cFawn = bas.cFa + bas.cwn; // Fawn
// smuggle something cFeldgrau = bas.cFe + bas.cld + bas.cgr + bas.cau; // Feldgrau
// smuggle something cFernGreen = wr1.cFern + cGreen; // FernGreen
// smuggle something cFieldDrab = wr1.cField + cDrab; // FieldDrab
// smuggle something cFieryRose = wr1.cFiery + cRose; // FieryRose
// smuggle something cFirebrick = wr1.cFire + wr1.cbrick; // Firebrick
// smuggle something cFireEngineRed = wr1.cFire + wr1.cEngine + cRed; // FireEngineRed
// smuggle something cFireOpal = wr1.cFire + bas.cOp + bas.cal; // FireOpal
// smuggle something cFlame = bas.cFl + phn.came; // Flame
// smuggle something cFlax = bas.cFl + bas.cax; // Flax
// smuggle something cFlirt = bas.cFl + bas.cir + bas.ct; // Flirt
// smuggle something cFloralWhite = wr1.cFloral + cWhite; // FloralWhite
// smuggle something cFluorescentBlue = wr1.cFluorescent + cBlue; // FluorescentBlue
// smuggle something cForestGreenCrayola = wr1.cForest + cGreen + wr1.cCrayola; // ForestGreenCrayola
// smuggle something cForestGreenTraditional = wr1.cForest + cGreen + wr1.cTraditional; // ForestGreenTraditional
// smuggle something cForestGreenWeb = wr1.cForest + cGreen + wr1.cWeb; // ForestGreenWeb
// smuggle something cFrenchBeige = lng.cFrench + cBeige; // FrenchBeige
// smuggle something cFrenchBistre = lng.cFrench + wr1.cBistre; // FrenchBistre
// smuggle something cFrenchBlue = lng.cFrench + cBlue; // FrenchBlue
// smuggle something cFrenchFuchsia = lng.cFrench + cFuchsia; // FrenchFuchsia
// smuggle something cFrenchLilac = lng.cFrench + cLilac; // FrenchLilac
// smuggle something cFrenchLime = lng.cFrench + cLime; // FrenchLime
// smuggle something cFrenchMauve = lng.cFrench + cMauve; // FrenchMauve
// smuggle something cFrenchPink = lng.cFrench + cPink; // FrenchPink
// smuggle something cFrenchRaspberry = lng.cFrench + bas.cRa + bas.csp + wr1.cberry; // FrenchRaspberry
// smuggle something cFrenchRose = lng.cFrench + cRose; // FrenchRose
// smuggle something cFrenchSkyBlue = lng.cFrench + wr1.cSky + cBlue; // FrenchSkyBlue
// smuggle something cFrenchViolet = lng.cFrench + cViolet; // FrenchViolet
// smuggle something cFrostbite = wr1.cFrost + wr1.cbite; // Frostbite
// smuggle something cFuchsiaCrayola = cFuchsia + wr1.cCrayola; // FuchsiaCrayola
// smuggle something cFuchsiaPurple = cFuchsia + cPurple; // FuchsiaPurple
// smuggle something cFuchsiaRose = cFuchsia + cRose; // FuchsiaRose
// smuggle something cFulvous = phn.cFul + bas.cvo + bas.cus; // Fulvous
// smuggle something cFuzzyWuzzy = wr1.cFuzzy + wr1.cWuzzy; // FuzzyWuzzy
// smuggle something cGainsboro = wr1.cGain + bas.csb + bas.cor + bas.co; // Gainsboro
// smuggle something cGamboge = bas.cGa + bas.cmb + bas.cog + bas.ce; // Gamboge
// smuggle something cGenericViridian = wr1.cGeneric + cViridian; // GenericViridian
// smuggle something cGhostWhite = wr1.cGhost + cWhite; // GhostWhite
// smuggle something cGlaucous = bas.cGl + bas.cau + bas.cco + bas.cus; // Glaucous
// smuggle something cGlossyGrape = wr1.cGlossy + bas.cGr + phn.cape; // GlossyGrape
// smuggle something cGOGreen = bas.cGO + cGreen; // GOGreen
// smuggle something cGoldMetallic = cGold + wr1.cMetallic; // GoldMetallic
// smuggle something cGoldWebGolden = cGold + wr1.cWeb + cGold + bas.cen; // GoldWebGolden
// smuggle something cGoldCrayola = cGold + wr1.cCrayola; // GoldCrayola
// smuggle something cGoldFusion = cGold + wr1.cFusion; // GoldFusion
// smuggle something cGoldenBrown = cGold + bas.cen + cBrown; // GoldenBrown
// smuggle something cGoldenPoppy = cGold + bas.cen + wr1.cPoppy; // GoldenPoppy
// smuggle something cGoldenYellow = cGold + bas.cen + cYellow; // GoldenYellow
// smuggle something cGoldenrod = cGold + bas.cen + bas.cro + bas.cd; // Goldenrod
// smuggle something cGraniteGray = wr1.cGranite + cGray; // GraniteGray
// smuggle something cGrannySmithApple = wr1.cGranny + wr1.cSmith + wr1.cApple; // GrannySmithApple
// smuggle something cGrayWeb = cGray + wr1.cWeb; // GrayWeb
// smuggle something cGrayX11 = cGray + bas.cX + num.c11; // GrayX11
// smuggle something cGreenCrayola = cGreen + wr1.cCrayola; // GreenCrayola
// smuggle something cGreenWeb = cGreen + wr1.cWeb; // GreenWeb
// smuggle something cGreenMunsell = cGreen + wr1.cMunsell; // GreenMunsell
// smuggle something cGreenNCS = cGreen + phn.cNCS; // GreenNCS
// smuggle something cGreenPantone = cGreen + wr1.cPantone; // GreenPantone
// smuggle something cGreenPigment = cGreen + wr1.cPigment; // GreenPigment
// smuggle something cGreenRYB = cGreen + phn.cRYB; // GreenRYB
// smuggle something cGreenBlue = cGreen + cBlue; // GreenBlue
// smuggle something cGreenBlueCrayola = cGreen + cBlue + wr1.cCrayola; // GreenBlueCrayola
// smuggle something cGreenCyan = cGreen + cCyan; // GreenCyan
// smuggle something cGreenLizard = cGreen + wr1.cLizard; // GreenLizard
// smuggle something cGreenSheen = cGreen + wr1.cSheen; // GreenSheen
// smuggle something cGreenYellow = cGreen + cYellow; // GreenYellow
// smuggle something cGreenYellowCrayola = cGreen + cYellow + wr1.cCrayola; // GreenYellowCrayola
// smuggle something cGrullo = bas.cGr + phn.cull + bas.co; // Grullo
// smuggle something cGunmetal = wr1.cGun + wr1.cmeta + bas.cl; // Gunmetal
// smuggle something cHanBlue = bas.cHa + bas.cnB + phn.clue; // HanBlue
// smuggle something cHanPurple = bas.cHa + bas.cnP + phn.curple; // HanPurple
// smuggle something cHansaYellow = bas.cHa + bas.cns + bas.caY + phn.cellow; // HansaYellow
// smuggle something cHarlequin = bas.cHa + bas.crl + phn.cequ + bas.cin; // Harlequin
// smuggle something cHarvestGold = wr1.cHarvest + cGold; // HarvestGold
// smuggle something cHeatWave = wr1.cHeat + wr1.cWave; // HeatWave
// smuggle something cHeliotrope = bas.cHe + bas.cli + bas.cot + bas.cro + bas.cpe; // Heliotrope
// smuggle something cHeliotropeGray = bas.cHe + bas.cli + bas.cot + bas.cro + bas.cpe + cGray; // HeliotropeGray
// smuggle something cHollywoodCerise = wr1.cHollywood + wr1.cCerise; // HollywoodCerise
// smuggle something cHoneydew = wr1.cHoney + wr1.cdew; // Honeydew
// smuggle something cHonoluluBlue = wr1.cHonolulu + cBlue; // HonoluluBlue
// smuggle something cHookersGreen = wr1.cHookers + cGreen; // HookersGreen
// smuggle something cHotMagenta = wr1.cHot + cMagenta; // HotMagenta
// smuggle something cHotPink = wr1.cHot + cPink; // HotPink
// smuggle something cHunterGreen = wr1.cHunter + cGreen; // HunterGreen
// smuggle something cIceberg = wr1.cIce + phn.cber + bas.cg; // Iceberg
// smuggle something cIcterine = bas.cIc + phn.cter + phn.cine; // Icterine
// smuggle something cIlluminatingEmerald = wr1.cIlluminating + bas.cEm + phn.cerald; // IlluminatingEmerald
// smuggle something cImperialRed = wr1.cImperial + cRed; // ImperialRed
// smuggle something cInchworm = bas.cIn + bas.cch + wr1.cworm; // Inchworm
// smuggle something cIndependence = wr1.cIndependence; // Independence
// smuggle something cIndiaGreen = gen.cIndia + cGreen; // IndiaGreen
// smuggle something cIndianRed = wr1.cIndian + cRed; // IndianRed
// smuggle something cIndianYellow = wr1.cIndian + cYellow; // IndianYellow
// smuggle something cIndigoDye = cIndigo + wr1.cDye; // IndigoDye
// smuggle something cInternationalOrangeAerospace = wr1.cInternational + cOrange + wr1.cAerospace; // InternationalOrangeAerospace
// smuggle something cInternationalOrangeEngineering = wr1.cInternational + cOrange + wr1.cEngineering; // InternationalOrangeEngineering
// smuggle something cInternationalOrangeGoldenGateBridge = wr1.cInternational + cOrange + cGold + bas.cen + wr1.cGate + wr1.cBridge; // InternationalOrangeGoldenGateBridge
// smuggle something cIris = bas.cIr + bas.cis; // Iris
// smuggle something cIrresistible = bas.cIr + phn.cres + phn.cist + bas.cib + bas.cle; // Irresistible
// smuggle something cIsabelline = bas.cIs + bas.cab + phn.cell + phn.cine; // Isabelline
// smuggle something cItalianSkyBlue = lng.cItalian + wr1.cSky + cBlue; // ItalianSkyBlue
// smuggle something cIvory = bas.cIv + bas.cor + bas.cy; // Ivory
// smuggle something cJade = bas.cJa + bas.cde; // Jade
// smuggle something cJapaneseCarmine = lng.cJapanese + wr1.cCarmine; // JapaneseCarmine
// smuggle something cJapaneseViolet = lng.cJapanese + cViolet; // JapaneseViolet
// smuggle something cJasmine = bas.cJa + bas.csm + phn.cine; // Jasmine
// smuggle something cJazzberryJam = wr1.cJazz + wr1.cberry + wr1.cJam; // JazzberryJam
// smuggle something cJet = bas.cJe + bas.ct; // Jet
// smuggle something cJonquil = bas.cJo + bas.cnq + bas.cui + bas.cl; // Jonquil
// smuggle something cJuneBud = gen.cJune + wr1.cBud; // JuneBud
// smuggle something cJungleGreen = bas.cJu + bas.cng + bas.cle + cGreen; // JungleGreen
// smuggle something cKellyGreen = wr1.cKelly + cGreen; // KellyGreen
// smuggle something cKeppel = bas.cKe + bas.cpp + bas.cel; // Keppel
// smuggle something cKeyLime = wr1.cKey + cLime; // KeyLime
// smuggle something cKhakiWeb = wr1.cKhaki + wr1.cWeb; // KhakiWeb
// smuggle something cKhakiX11 = wr1.cKhaki + bas.cX + num.c11; // KhakiX11
// smuggle something cKobe = bas.cKo + bas.cbe; // Kobe
// smuggle something cKobi = bas.cKo + bas.cbi; // Kobi
// smuggle something cKobicha = bas.cKo + bas.cbi + phn.ccha; // Kobicha
// smuggle something cKombuGreen = wr1.cKombu + cGreen; // KombuGreen
// smuggle something cKSUPurple = bas.cKS + bas.cUP + phn.curple; // KSUPurple
// smuggle something cLanguidLavender = wr1.cLanguid + cLavender; // LanguidLavender
// smuggle something cLapisLazuli = wr1.cLapis + wr1.cLazuli; // LapisLazuli
// smuggle something cLaserLemon = wr1.cLaser + cLemon; // LaserLemon
// smuggle something cLaurelGreen = wr1.cLaurel + cGreen; // LaurelGreen
// smuggle something cLava = bas.cLa + bas.cva; // Lava
// smuggle something cLavenderFloral = cLavender + wr1.cFloral; // LavenderFloral
// smuggle something cLavenderWeb = cLavender + wr1.cWeb; // LavenderWeb
// smuggle something cLavenderBlue = cLavender + cBlue; // LavenderBlue
// smuggle something cLavenderBlush = cLavender + wr1.cBlush; // LavenderBlush
// smuggle something cLavenderGray = cLavender + cGray; // LavenderGray
// smuggle something cLawnGreen = wr1.cLawn + cGreen; // LawnGreen
// smuggle something cLemonChiffon = cLemon + gen.cChi + bas.cff + bas.con; // LemonChiffon
// smuggle something cLemonCurry = cLemon + wr1.cCurry; // LemonCurry
// smuggle something cLemonGlacier = cLemon + wr1.cGlacier; // LemonGlacier
// smuggle something cLemonMeringue = cLemon + wr1.cMeringue; // LemonMeringue
// smuggle something cLemonYellow = cLemon + cYellow; // LemonYellow
// smuggle something cLemonYellowCrayola = cLemon + cYellow + wr1.cCrayola; // LemonYellowCrayola
// smuggle something cLiberty = bas.cLi + phn.cber + bas.cty; // Liberty
// smuggle something cLightBlue = wr1.cLight + cBlue; // LightBlue
// smuggle something cLightCoral = wr1.cLight + wr1.cCoral; // LightCoral
// smuggle something cLightCornflowerBlue = wr1.cLight + phn.cCor + bas.cnf + wr1.clower + cBlue; // LightCornflowerBlue
// smuggle something cLightCyan = wr1.cLight + cCyan; // LightCyan
// smuggle something cLightFrenchBeige = wr1.cLight + lng.cFrench + cBeige; // LightFrenchBeige
// smuggle something cLightGoldenrodYellow = wr1.cLight + cGold + bas.cen + bas.cro + bas.cd + cYellow; // LightGoldenrodYellow
// smuggle something cLightGray = wr1.cLight + cGray; // LightGray
// smuggle something cLightGreen = wr1.cLight + cGreen; // LightGreen
// smuggle something cLightOrange = wr1.cLight + cOrange; // LightOrange
// smuggle something cLightPeriwinkle = wr1.cLight + phn.cPer + bas.ciw + phn.cinkle; // LightPeriwinkle
// smuggle something cLightPink = wr1.cLight + cPink; // LightPink
// smuggle something cLightSalmon = wr1.cLight + bas.cSa + phn.clmon; // LightSalmon
// smuggle something cLightSeaGreen = wr1.cLight + wr1.cSea + cGreen; // LightSeaGreen
// smuggle something cLightSkyBlue = wr1.cLight + wr1.cSky + cBlue; // LightSkyBlue
// smuggle something cLightSlateGray = wr1.cLight + wr1.cSlate + cGray; // LightSlateGray
// smuggle something cLightSteelBlue = wr1.cLight + wr1.cSteel + cBlue; // LightSteelBlue
// smuggle something cLightYellow = wr1.cLight + cYellow; // LightYellow
// smuggle something cLilacLuster = cLilac + wr1.cLuster; // LilacLuster
// smuggle something cLimeColorWheel = cLime + wr1.cColor + wr1.cWheel; // LimeColorWheel
// smuggle something cLimeWeb = cLime + wr1.cWeb; // LimeWeb
// smuggle something cLimeGreen = cLime + cGreen; // LimeGreen
// smuggle something cLincolnGreen = wr1.cLincoln + cGreen; // LincolnGreen
// smuggle something cLinen = wr1.cLine + bas.cn; // Linen
// smuggle something cLion = bas.cLi + bas.con; // Lion
// smuggle something cLiseranPurple = wr1.cLiseran + cPurple; // LiseranPurple
// smuggle something cLittleBoyBlue = wr1.cLittle + wr1.cBoy + cBlue; // LittleBoyBlue
// smuggle something cLiver = wr1.cLiver; // Liver
// smuggle something cLiverDogs = wr1.cLiver + wr1.cDogs; // LiverDogs
// smuggle something cLiverOrgan = wr1.cLiver + wr1.cOrgan; // LiverOrgan
// smuggle something cLiverChestnut = wr1.cLiver + wr1.cChestnut; // LiverChestnut
// smuggle something cLivid = bas.cLi + phn.cvid; // Livid
// smuggle something cMacaroniAndCheese = wr1.cMacaroni + wr1.cAnd + wr1.cCheese; // MacaroniAndCheese
// smuggle something cMadderLake = wr1.cMadder + wr1.cLake; // MadderLake
// smuggle something cMagentaCrayola = cMagenta + wr1.cCrayola; // MagentaCrayola
// smuggle something cMagentaDye = cMagenta + wr1.cDye; // MagentaDye
// smuggle something cMagentaPantone = cMagenta + wr1.cPantone; // MagentaPantone
// smuggle something cMagentaProcess = cMagenta + wr1.cProcess; // MagentaProcess
// smuggle something cMagentaHaze = cMagenta + wr1.cHaze; // MagentaHaze
// smuggle something cMagicMint = wr1.cMagic + gen.cMin + bas.ct; // MagicMint
// smuggle something cMagnolia = bas.cMa + bas.cgn + bas.col + bas.cia; // Magnolia
// smuggle something cMahogany = bas.cMa + bas.cho + phn.cgan + bas.cy; // Mahogany
// smuggle something cMaize = bas.cMa + phn.cize; // Maize
// smuggle something cMaizeCrayola = bas.cMa + phn.cize + wr1.cCrayola; // MaizeCrayola
// smuggle something cMajorelleBlue = wr1.cMajorelle + cBlue; // MajorelleBlue
// smuggle something cMalachite = bas.cMa + phn.clac + phn.chite; // Malachite
// smuggle something cManatee = wr1.cMan + phn.cate + bas.ce; // Manatee
// smuggle something cMandarin = wr1.cMan + bas.cda + phn.crin; // Mandarin
// smuggle something cMango = wr1.cMan + bas.cgo; // Mango
// smuggle something cMangoTango = wr1.cMan + bas.cgo + gen.cTango; // MangoTango
// smuggle something cMantis = wr1.cMan + phn.ctis; // Mantis
// smuggle something cMardiGras = bas.cMa + bas.crd + bas.ciG + phn.cras; // MardiGras
// smuggle something cMarigold = bas.cMa + bas.cri + cgold; // Marigold
// smuggle something cMaroonCrayola = cMaroon + wr1.cCrayola; // MaroonCrayola
// smuggle something cMaroonWeb = cMaroon + wr1.cWeb; // MaroonWeb
// smuggle something cMaroonX11 = cMaroon + bas.cX + num.c11; // MaroonX11
// smuggle something cMauveTaupe = cMauve + cTaupe; // MauveTaupe
// smuggle something cMauvelous = cMauve + bas.clo + bas.cus; // Mauvelous
// smuggle something cMaximumBlue = wr1.cMaximum + cBlue; // MaximumBlue
// smuggle something cMaximumBlueGreen = wr1.cMaximum + cBlue + cGreen; // MaximumBlueGreen
// smuggle something cMaximumBluePurple = wr1.cMaximum + cBlue + cPurple; // MaximumBluePurple
// smuggle something cMaximumGreen = wr1.cMaximum + cGreen; // MaximumGreen
// smuggle something cMaximumGreenYellow = wr1.cMaximum + cGreen + cYellow; // MaximumGreenYellow
// smuggle something cMaximumPurple = wr1.cMaximum + cPurple; // MaximumPurple
// smuggle something cMaximumRed = wr1.cMaximum + cRed; // MaximumRed
// smuggle something cMaximumRedPurple = wr1.cMaximum + cRed + cPurple; // MaximumRedPurple
// smuggle something cMaximumYellow = wr1.cMaximum + cYellow; // MaximumYellow
// smuggle something cMaximumYellowRed = wr1.cMaximum + cYellow + cRed; // MaximumYellowRed
// smuggle something cMayGreen = gen.cMay + cGreen; // MayGreen
// smuggle something cMayaBlue = wr1.cMaya + cBlue; // MayaBlue
// smuggle something cMediumAquamarine = wr1.cMedium + cAqua + phn.cmar + phn.cine; // MediumAquamarine
// smuggle something cMediumBlue = wr1.cMedium + cBlue; // MediumBlue
// smuggle something cMediumCandyAppleRed = wr1.cMedium + wr1.cCan + bas.cdy + wr1.cApple + cRed; // MediumCandyAppleRed
// smuggle something cMediumCarmine = wr1.cMedium + wr1.cCarmine; // MediumCarmine
// smuggle something cMediumChampagne = wr1.cMedium + bas.cCh + phn.campagne; // MediumChampagne
// smuggle something cMediumOrchid = wr1.cMedium + bas.cOr + phn.cchid; // MediumOrchid
// smuggle something cMediumPurple = wr1.cMedium + cPurple; // MediumPurple
// smuggle something cMediumSeaGreen = wr1.cMedium + wr1.cSea + cGreen; // MediumSeaGreen
// smuggle something cMediumSlateBlue = wr1.cMedium + wr1.cSlate + cBlue; // MediumSlateBlue
// smuggle something cMediumSpringGreen = wr1.cMedium + wr1.cSpring + cGreen; // MediumSpringGreen
// smuggle something cMediumTurquoise = wr1.cMedium + cTurquoise; // MediumTurquoise
// smuggle something cMediumVioletRed = wr1.cMedium + cViolet + cRed; // MediumVioletRed
// smuggle something cMellowApricot = wr1.cMellow + wr1.cApricot; // MellowApricot
// smuggle something cMellowYellow = wr1.cMellow + cYellow; // MellowYellow
// smuggle something cMelon = bas.cMe + phn.clon; // Melon
// smuggle something cMetallicGold = wr1.cMetallic + cGold; // MetallicGold
// smuggle something cMetallicSeaweed = wr1.cMetallic + wr1.cSeaweed; // MetallicSeaweed
// smuggle something cMetallicSunburst = wr1.cMetallic + wr1.cSunburst; // MetallicSunburst
// smuggle something cMexicanPink = wr1.cMexican + cPink; // MexicanPink
// smuggle something cMiddleBlue = wr1.cMiddle + cBlue; // MiddleBlue
// smuggle something cMiddleBlueGreen = wr1.cMiddle + cBlue + cGreen; // MiddleBlueGreen
// smuggle something cMiddleBluePurple = wr1.cMiddle + cBlue + cPurple; // MiddleBluePurple
// smuggle something cMiddleGrey = wr1.cMiddle + cGrey; // MiddleGrey
// smuggle something cMiddleGreen = wr1.cMiddle + cGreen; // MiddleGreen
// smuggle something cMiddleGreenYellow = wr1.cMiddle + cGreen + cYellow; // MiddleGreenYellow
// smuggle something cMiddlePurple = wr1.cMiddle + cPurple; // MiddlePurple
// smuggle something cMiddleRed = wr1.cMiddle + cRed; // MiddleRed
// smuggle something cMiddleRedPurple = wr1.cMiddle + cRed + cPurple; // MiddleRedPurple
// smuggle something cMiddleYellow = wr1.cMiddle + cYellow; // MiddleYellow
// smuggle something cMiddleYellowRed = wr1.cMiddle + cYellow + cRed; // MiddleYellowRed
// smuggle something cMidnight = bas.cMi + bas.cdn + phn.cight; // Midnight
// smuggle something cMidnightBlue = bas.cMi + bas.cdn + phn.cight + cBlue; // MidnightBlue
// smuggle something cMidnightGreen = bas.cMi + bas.cdn + phn.cight + cGreen; // MidnightGreen
// smuggle something cMikadoYellow = wr1.cMikado + cYellow; // MikadoYellow
// smuggle something cMimiPink = wr1.cMimi + cPink; // MimiPink
// smuggle something cMindaro = gen.cMin + bas.cda + bas.cro; // Mindaro
// smuggle something cMing = gen.cMin + bas.cg; // Ming
// smuggle something cMinionYellow = wr1.cMinion + cYellow; // MinionYellow
// smuggle something cMint = gen.cMin + bas.ct; // Mint
// smuggle something cMintCream = gen.cMin + bas.ctC + phn.cream; // MintCream
// smuggle something cMintGreen = gen.cMin + bas.ctG + phn.creen; // MintGreen
// smuggle something cMistyMoss = wr1.cMisty + wr1.cMoss; // MistyMoss
// smuggle something cMistyRose = wr1.cMisty + cRose; // MistyRose
// smuggle something cModeBeige = wr1.cMode + cBeige; // ModeBeige
// smuggle something cMorningBlue = wr1.cMorning + cBlue; // MorningBlue
// smuggle something cMossGreen = wr1.cMoss + cGreen; // MossGreen
// smuggle something cMountainMeadow = wr1.cMountain + wr1.cMeadow; // MountainMeadow
// smuggle something cMountbattenPink = wr1.cMount + wr1.cbatten + cPink; // MountbattenPink
// smuggle something cMSUGreen = bas.cMS + bas.cUG + phn.creen; // MSUGreen
// smuggle something cMulberry = wr1.cMulberry; // Mulberry
// smuggle something cMulberryCrayola = wr1.cMulberry + wr1.cCrayola; // MulberryCrayola
// smuggle something cMustard = wr1.cMust + phn.card; // Mustard
// smuggle something cMyrtleGreen = wr1.cMyrtle + cGreen; // MyrtleGreen
// smuggle something cMystic = bas.cMy + phn.cstic; // Mystic
// smuggle something cMysticMaroon = bas.cMy + phn.cstic + cMaroon; // MysticMaroon
// smuggle something cNadeshikoPink = wr1.cNadeshiko + cPink; // NadeshikoPink
// smuggle something cNaplesYellow = wr1.cNaples + cYellow; // NaplesYellow
// smuggle something cNavajoWhite = wr1.cNavajo + cWhite; // NavajoWhite
// smuggle something cNavyBlue = wr1.cNavy + cBlue; // NavyBlue
// smuggle something cNavyBlueCrayola = wr1.cNavy + cBlue + wr1.cCrayola; // NavyBlueCrayola
// smuggle something cNeonBlue = wr1.cNeon + cBlue; // NeonBlue
// smuggle something cNeonCarrot = wr1.cNeon + wr1.cCarrot; // NeonCarrot
// smuggle something cNeonGreen = wr1.cNeon + cGreen; // NeonGreen
// smuggle something cNeonFuchsia = wr1.cNeon + cFuchsia; // NeonFuchsia
// smuggle something cNewYorkPink = wr1.cNew + wr1.cYork + cPink; // NewYorkPink
// smuggle something cNickel = bas.cNi + bas.cc + phn.ckel; // Nickel
// smuggle something cNonPhotoBlue = phn.cNon + wr1.cPhoto + cBlue; // NonPhotoBlue
// smuggle something cNyanza = bas.cNy + bas.can + bas.cza; // Nyanza
// smuggle something cOceanBlue = wr1.cOcean + cBlue; // OceanBlue
// smuggle something cOceanGreen = wr1.cOcean + cGreen; // OceanGreen
// smuggle something cOchre = bas.cOc + bas.chr + bas.ce; // Ochre
// smuggle something cOldBurgundy = wr1.cOld + bas.cBu + phn.crgundy; // OldBurgundy
// smuggle something cOldGold = wr1.cOld + cGold; // OldGold
// smuggle something cOldLace = wr1.cOld + wr1.cLace; // OldLace
// smuggle something cOldLavender = wr1.cOld + cLavender; // OldLavender
// smuggle something cOldMauve = wr1.cOld + cMauve; // OldMauve
// smuggle something cOldRose = wr1.cOld + cRose; // OldRose
// smuggle something cOldSilver = wr1.cOld + cSilver; // OldSilver
// smuggle something cOliveDrab3 = cOlive + cDrab + num.c3; // OliveDrab3
// smuggle something cOliveDrab7 = cOlive + cDrab + num.c7; // OliveDrab7
// smuggle something cOliveGreen = cOlive + cGreen; // OliveGreen
// smuggle something cOlivine = bas.cOl + bas.civ + phn.cine; // Olivine
// smuggle something cOnyx = bas.cOn + bas.cyx; // Onyx
// smuggle something cOpal = bas.cOp + bas.cal; // Opal
// smuggle something cOperaMauve = wr1.cOpera + cMauve; // OperaMauve
// smuggle something cOrangeCrayola = cOrange + wr1.cCrayola; // OrangeCrayola
// smuggle something cOrangePantone = cOrange + wr1.cPantone; // OrangePantone
// smuggle something cOrangeWeb = cOrange + wr1.cWeb; // OrangeWeb
// smuggle something cOrangePeel = cOrange + wr1.cPeel; // OrangePeel
// smuggle something cOrangeRed = cOrange + cRed; // OrangeRed
// smuggle something cOrangeRedCrayola = cOrange + cRed + wr1.cCrayola; // OrangeRedCrayola
// smuggle something cOrangeSoda = cOrange + wr1.cSoda; // OrangeSoda
// smuggle something cOrangeYellow = cOrange + cYellow; // OrangeYellow
// smuggle something cOrangeYellowCrayola = cOrange + cYellow + wr1.cCrayola; // OrangeYellowCrayola
// smuggle something cOrchid = bas.cOr + phn.cchid; // Orchid
// smuggle something cOrchidPink = bas.cOr + phn.cchid + cPink; // OrchidPink
// smuggle something cOrchidCrayola = bas.cOr + phn.cchid + wr1.cCrayola; // OrchidCrayola
// smuggle something cOuterSpaceCrayola = wr1.cOuter + wr1.cSpace + wr1.cCrayola; // OuterSpaceCrayola
// smuggle something cOutrageousOrange = wr1.cOutrageous + cOrange; // OutrageousOrange
// smuggle something cOxBlood = bas.cOx + wr1.cBlood; // OxBlood
// smuggle something cOxfordBlue = wr1.cOxford + cBlue; // OxfordBlue
// smuggle something cOUCrimsonRed = bas.cOU + cCrimson + cRed; // OUCrimsonRed
// smuggle something cPacificBlue = wr1.cPacific + cBlue; // PacificBlue
// smuggle something cPakistanGreen = ctr.cPakistan + cGreen; // PakistanGreen
// smuggle something cPalatinatePurple = wr1.cPalatinate + cPurple; // PalatinatePurple
// smuggle something cPaleAqua = wr1.cPale + cAqua; // PaleAqua
// smuggle something cPaleCerulean = wr1.cPale + bas.cCe + phn.crulean; // PaleCerulean
// smuggle something cPalePink = wr1.cPale + cPink; // PalePink
// smuggle something cPalePurplePantone = wr1.cPale + cPurple + wr1.cPantone; // PalePurplePantone
// smuggle something cPaleSilver = wr1.cPale + cSilver; // PaleSilver
// smuggle something cPaleSpringBud = wr1.cPale + wr1.cSpring + wr1.cBud; // PaleSpringBud
// smuggle something cPansyPurple = wr1.cPansy + cPurple; // PansyPurple
// smuggle something cPaoloVeroneseGreen = wr1.cPaolo + wr1.cVeronese + cGreen; // PaoloVeroneseGreen
// smuggle something cPapayaWhip = wr1.cPapaya + wr1.cWhip; // PapayaWhip
// smuggle something cParadisePink = wr1.cParadise + cPink; // ParadisePink
// smuggle something cParisGreen = wr1.cParis + cGreen; // ParisGreen
// smuggle something cPastelPink = wr1.cPastel + cPink; // PastelPink
// smuggle something cPatriarch = wr1.cPat + phn.cria + phn.crch; // Patriarch
// smuggle something cPaynesGrey = wr1.cPaynes + cGrey; // PaynesGrey
// smuggle something cPeachCrayola = cPeach + wr1.cCrayola; // PeachCrayola
// smuggle something cPeachPuff = cPeach + wr1.cPuff; // PeachPuff
// smuggle something cPear = bas.cPe + bas.car; // Pear
// smuggle something cPearlyPurple = wr1.cPearly + cPurple; // PearlyPurple
// smuggle something cPeriwinkle = phn.cPer + bas.ciw + phn.cinkle; // Periwinkle
// smuggle something cPeriwinkleCrayola = phn.cPer + bas.ciw + phn.cinkle + wr1.cCrayola; // PeriwinkleCrayola
// smuggle something cPermanentGeraniumLake = wr1.cPermanent + wr1.cGeranium + wr1.cLake; // PermanentGeraniumLake
// smuggle something cPersianBlue = wr1.cPersian + cBlue; // PersianBlue
// smuggle something cPersianGreen = wr1.cPersian + cGreen; // PersianGreen
// smuggle something cPersianIndigo = wr1.cPersian + cIndigo; // PersianIndigo
// smuggle something cPersianOrange = wr1.cPersian + cOrange; // PersianOrange
// smuggle something cPersianPink = wr1.cPersian + cPink; // PersianPink
// smuggle something cPersianPlum = wr1.cPersian + cPlum; // PersianPlum
// smuggle something cPersianRed = wr1.cPersian + cRed; // PersianRed
// smuggle something cPersianRose = wr1.cPersian + cRose; // PersianRose
// smuggle something cPersimmon = phn.cPer + phn.csim + phn.cmon; // Persimmon
// smuggle something cPewterBlue = wr1.cPewter + cBlue; // PewterBlue
// smuggle something cPhlox = bas.cPh + bas.clo + bas.cx; // Phlox
// smuggle something cPhthaloBlue = wr1.cPhthalo + cBlue; // PhthaloBlue
// smuggle something cPhthaloGreen = wr1.cPhthalo + cGreen; // PhthaloGreen
// smuggle something cPicoteeBlue = wr1.cPicotee + cBlue; // PicoteeBlue
// smuggle something cPictorialCarmine = wr1.cPictorial + wr1.cCarmine; // PictorialCarmine
// smuggle something cPiggyPink = wr1.cPiggy + cPink; // PiggyPink
// smuggle something cPineGreen = wr1.cPine + cGreen; // PineGreen
// smuggle something cPineTree = wr1.cPine + wr1.cTree; // PineTree
// smuggle something cPinkPantone = cPink + wr1.cPantone; // PinkPantone
// smuggle something cPinkFlamingo = cPink + wr1.cFlamingo; // PinkFlamingo
// smuggle something cPinkLace = cPink + wr1.cLace; // PinkLace
// smuggle something cPinkLavender = cPink + cLavender; // PinkLavender
// smuggle something cPinkSherbet = cPink + wr1.cSherbet; // PinkSherbet
// smuggle something cPistachio = bas.cPi + bas.cst + phn.cach + bas.cio; // Pistachio
// smuggle something cPlumWeb = cPlum + wr1.cWeb; // PlumWeb
// smuggle something cPlumpPurple = wr1.cPlump + cPurple; // PlumpPurple
// smuggle something cPolishedPine = wr1.cPolished + wr1.cPine; // PolishedPine
// smuggle something cPompAndPower = wr1.cPomp + wr1.cAnd + wr1.cPower; // PompAndPower
// smuggle something cPopstar = wr1.cPop + phn.cstar; // Popstar
// smuggle something cPortlandOrange = wr1.cPortland + cOrange; // PortlandOrange
// smuggle something cPowderBlue = wr1.cPowder + cBlue; // PowderBlue
// smuggle something cPrincetonOrange = wr1.cPrinceton + cOrange; // PrincetonOrange
// smuggle something cPrune = bas.cPr + phn.cune; // Prune
// smuggle something cPrussianBlue = wr1.cPrussian + cBlue; // PrussianBlue
// smuggle something cPsychedelicPurple = wr1.cPsychedelic + cPurple; // PsychedelicPurple
// smuggle something cPuce = bas.cPu + bas.cce; // Puce
// smuggle something cPullmanBrown = wr1.cPullman + cBrown; // PullmanBrown
// smuggle something cPumpkin = bas.cPu + bas.cmp + phn.ckin; // Pumpkin
// smuggle something cPurpleWeb = cPurple + wr1.cWeb; // PurpleWeb
// smuggle something cPurpleMunsell = cPurple + wr1.cMunsell; // PurpleMunsell
// smuggle something cPurpleX11 = cPurple + bas.cX + num.c11; // PurpleX11
// smuggle something cPurpleMountainMajesty = cPurple + wr1.cMountain + wr1.cMajesty; // PurpleMountainMajesty
// smuggle something cPurpleNavy = cPurple + wr1.cNavy; // PurpleNavy
// smuggle something cPurplePizzazz = cPurple + wr1.cPizzazz; // PurplePizzazz
// smuggle something cPurplePlum = cPurple + cPlum; // PurplePlum
// smuggle something cPurpureus = bas.cPu + bas.crp + phn.cure + bas.cus; // Purpureus
// smuggle something cQueenBlue = wr1.cQueen + cBlue; // QueenBlue
// smuggle something cQueenPink = wr1.cQueen + cPink; // QueenPink
// smuggle something cQuickSilver = wr1.cQuick + cSilver; // QuickSilver
// smuggle something cQuinacridoneMagenta = wr1.cQuinacridone + cMagenta; // QuinacridoneMagenta
// smuggle something cRadicalRed = wr1.cRadical + cRed; // RadicalRed
// smuggle something cRaisinBlack = wr1.cRaisin + cBlack; // RaisinBlack
// smuggle something cRajah = bas.cRa + bas.cja + bas.ch; // Rajah
// smuggle something cRaspberry = bas.cRa + bas.csp + wr1.cberry; // Raspberry
// smuggle something cRaspberryGlace = bas.cRa + bas.csp + wr1.cberry + wr1.cGlace; // RaspberryGlace
// smuggle something cRaspberryRose = bas.cRa + bas.csp + wr1.cberry + cRose; // RaspberryRose
// smuggle something cRawSienna = wr1.cRaw + cSienna; // RawSienna
// smuggle something cRawUmber = wr1.cRaw + cUmber; // RawUmber
// smuggle something cRazzleDazzleRose = wr1.cRazzle + wr1.cDazzle + cRose; // RazzleDazzleRose
// smuggle something cRazzmatazz = bas.cRa + bas.czz + wr1.cmat + phn.cazz; // Razzmatazz
// smuggle something cRazzmicBerry = wr1.cRazzmic + wr1.cBerry; // RazzmicBerry
// smuggle something cRebeccaPurple = wr1.cRebecca + cPurple; // RebeccaPurple
// smuggle something cRedCrayola = cRed + wr1.cCrayola; // RedCrayola
// smuggle something cRedMunsell = cRed + wr1.cMunsell; // RedMunsell
// smuggle something cRedNCS = cRed + phn.cNCS; // RedNCS
// smuggle something cRedPantone = cRed + wr1.cPantone; // RedPantone
// smuggle something cRedPigment = cRed + wr1.cPigment; // RedPigment
// smuggle something cRedRYB = cRed + phn.cRYB; // RedRYB
// smuggle something cRedOrange = cRed + cOrange; // RedOrange
// smuggle something cRedOrangeCrayola = cRed + cOrange + wr1.cCrayola; // RedOrangeCrayola
// smuggle something cRedOrangeColorWheel = cRed + cOrange + wr1.cColor + wr1.cWheel; // RedOrangeColorWheel
// smuggle something cRedPurple = cRed + cPurple; // RedPurple
// smuggle something cRedSalsa = cRed + wr1.cSalsa; // RedSalsa
// smuggle something cRedViolet = cRed + cViolet; // RedViolet
// smuggle something cRedVioletCrayola = cRed + cViolet + wr1.cCrayola; // RedVioletCrayola
// smuggle something cRedVioletColorWheel = cRed + cViolet + wr1.cColor + wr1.cWheel; // RedVioletColorWheel
// smuggle something cRedwood = cRed + wr1.cwood; // Redwood
// smuggle something cResolutionBlue = wr1.cResolution + cBlue; // ResolutionBlue
// smuggle something cRhythm = bas.cRh + bas.cyt + bas.chm; // Rhythm
// smuggle something cRichBlack = wr1.cRich + cBlack; // RichBlack
// smuggle something cRichBlackFOGRA29 = wr1.cRich + cBlack + bas.cFO + bas.cGR + bas.cA + num.c29; // RichBlackFOGRA29
// smuggle something cRichBlackFOGRA39 = wr1.cRich + cBlack + bas.cFO + bas.cGR + bas.cA + num.c39; // RichBlackFOGRA39
// smuggle something cRifleGreen = wr1.cRifle + cGreen; // RifleGreen
// smuggle something cRobinEggBlue = wr1.cRobin + wr1.cEgg + cBlue; // RobinEggBlue
// smuggle something cRocketMetallic = wr1.cRocket + wr1.cMetallic; // RocketMetallic
// smuggle something cRomanSilver = wr1.cRoman + cSilver; // RomanSilver
// smuggle something cRoseBonbon = cRose + wr1.cBonbon; // RoseBonbon
// smuggle something cRoseDust = cRose + wr1.cDust; // RoseDust
// smuggle something cRoseEbony = cRose + wr1.cEbony; // RoseEbony
// smuggle something cRoseMadder = cRose + wr1.cMadder; // RoseMadder
// smuggle something cRosePink = cRose + cPink; // RosePink
// smuggle something cRoseQuartz = cRose + wr1.cQuartz; // RoseQuartz
// smuggle something cRoseRed = cRose + cRed; // RoseRed
// smuggle something cRoseTaupe = cRose + cTaupe; // RoseTaupe
// smuggle something cRoseVale = cRose + wr1.cVale; // RoseVale
// smuggle something cRosewood = cRose + wr1.cwood; // Rosewood
// smuggle something cRossoCorsa = wr1.cRosso + wr1.cCorsa; // RossoCorsa
// smuggle something cRosyBrown = wr1.cRosy + cBrown; // RosyBrown
// smuggle something cRoyalBlueDark = wr1.cRoyal + cBlue + wr1.cDark; // RoyalBlueDark
// smuggle something cRoyalBlueLight = wr1.cRoyal + cBlue + wr1.cLight; // RoyalBlueLight
// smuggle something cRoyalPurple = wr1.cRoyal + cPurple; // RoyalPurple
// smuggle something cRoyalYellow = wr1.cRoyal + cYellow; // RoyalYellow
// smuggle something cRuber = wr1.cRub + bas.cer; // Ruber
// smuggle something cRubineRed = wr1.cRubine + cRed; // RubineRed
// smuggle something cRubyRed = cRuby + cRed; // RubyRed
// smuggle something cRufous = bas.cRu + bas.cfo + bas.cus; // Rufous
// smuggle something cRusset = bas.cRu + bas.css + bas.cet; // Russet
// smuggle something cRussianGreen = lng.cRussian + cGreen; // RussianGreen
// smuggle something cRussianViolet = lng.cRussian + cViolet; // RussianViolet
// smuggle something cRust = bas.cRu + bas.cst; // Rust
// smuggle something cRustyRed = bas.cRu + phn.csty + cRed; // RustyRed
// smuggle something cSacramentoStateGreen = wr1.cSacramento + wr1.cState + cGreen; // SacramentoStateGreen
// smuggle something cSaddleBrown = wr1.cSaddle + cBrown; // SaddleBrown
// smuggle something cSafetyOrange = wr1.cSafety + cOrange; // SafetyOrange
// smuggle something cBlazeOrange = wr1.cBlaze + cOrange; // BlazeOrange
// smuggle something cSafetyYellow = wr1.cSafety + cYellow; // SafetyYellow
// smuggle something cSaffron = bas.cSa + phn.cffron; // Saffron
// smuggle something cSage = bas.cSa + bas.cge; // Sage
// smuggle something cStPatricksBlue = bas.cSt + wr1.cPatricks + cBlue; // StPatricksBlue
// smuggle something cSalmon = bas.cSa + phn.clmon; // Salmon
// smuggle something cSalmonPink = bas.cSa + phn.clmon + cPink; // SalmonPink
// smuggle something cSand = gen.cSan + bas.cd; // Sand
// smuggle something cSandDune = gen.cSan + bas.cdD + phn.cune; // SandDune
// smuggle something cSandyBrown = wr1.cSandy + cBrown; // SandyBrown
// smuggle something cSapGreen = wr1.cSap + cGreen; // SapGreen
// smuggle something cSapphireBlue = cSapphire + cBlue; // SapphireBlue
// smuggle something cSapphireCrayola = cSapphire + wr1.cCrayola; // SapphireCrayola
// smuggle something cSatinSheenGold = wr1.cSatin + wr1.cSheen + cGold; // SatinSheenGold
// smuggle something cSchaussPink = wr1.cSchauss + cPink; // SchaussPink
// smuggle something cSchoolBusYellow = wr1.cSchool + wr1.cBus + cYellow; // SchoolBusYellow
// smuggle something cScreaminGreen = wr1.cScreamin + cGreen; // ScreaminGreen
// smuggle something cSeaGreen = wr1.cSea + cGreen; // SeaGreen
// smuggle something cSeaGreenCrayola = wr1.cSea + cGreen + wr1.cCrayola; // SeaGreenCrayola
// smuggle something cSealBrown = wr1.cSeal + cBrown; // SealBrown
// smuggle something cSeashell = wr1.cSea + wr1.cshell; // Seashell
// smuggle something cSelectiveYellow = wr1.cSelective + cYellow; // SelectiveYellow
// smuggle something cSepia = bas.cSe + phn.cpia; // Sepia
// smuggle something cShadow = phn.cSha + phn.cdow; // Shadow
// smuggle something cShadowBlue = phn.cSha + phn.cdow + cBlue; // ShadowBlue
// smuggle something cShamrockGreen = wr1.cShamrock + cGreen; // ShamrockGreen
// smuggle something cSheenGreen = wr1.cSheen + cGreen; // SheenGreen
// smuggle something cShimmeringBlush = wr1.cShimmering + wr1.cBlush; // ShimmeringBlush
// smuggle something cShinyShamrock = wr1.cShiny + wr1.cShamrock; // ShinyShamrock
// smuggle something cShockingPink = wr1.cShocking + cPink; // ShockingPink
// smuggle something cShockingPinkCrayola = wr1.cShocking + cPink + wr1.cCrayola; // ShockingPinkCrayola
// smuggle something cSilverCrayola = cSilver + wr1.cCrayola; // SilverCrayola
// smuggle something cSilverMetallic = cSilver + wr1.cMetallic; // SilverMetallic
// smuggle something cSilverChalice = cSilver + wr1.cChalice; // SilverChalice
// smuggle something cSilverPink = cSilver + cPink; // SilverPink
// smuggle something cSilverSand = cSilver + gen.cSan + bas.cd; // SilverSand
// smuggle something cSinopia = bas.cSi + bas.cno + phn.cpia; // Sinopia
// smuggle something cSizzlingRed = wr1.cSizzling + cRed; // SizzlingRed
// smuggle something cSizzlingSunrise = wr1.cSizzling + wr1.cSunrise; // SizzlingSunrise
// smuggle something cSkobeloff = bas.cSk + phn.cobe + bas.clo + bas.cff; // Skobeloff
// smuggle something cSkyBlue = wr1.cSky + cBlue; // SkyBlue
// smuggle something cSkyBlueCrayola = wr1.cSky + cBlue + wr1.cCrayola; // SkyBlueCrayola
// smuggle something cSkyMagenta = wr1.cSky + cMagenta; // SkyMagenta
// smuggle something cSlateBlue = wr1.cSlate + cBlue; // SlateBlue
// smuggle something cSlateGray = wr1.cSlate + cGray; // SlateGray
// smuggle something cSlimyGreen = wr1.cSlimy + cGreen; // SlimyGreen
// smuggle something cSmitten = bas.cSm + bas.cit + num.cten; // Smitten
// smuggle something cSmokyBlack = wr1.cSmoky + cBlack; // SmokyBlack
// smuggle something cSnow = bas.cSn + bas.cow; // Snow
// smuggle something cSolidPink = wr1.cSolid + cPink; // SolidPink
// smuggle something cSonicSilver = wr1.cSonic + cSilver; // SonicSilver
// smuggle something cSpaceCadet = wr1.cSpace + wr1.cCadet; // SpaceCadet
// smuggle something cSpanishBistre = lng.cSpanish + wr1.cBistre; // SpanishBistre
// smuggle something cSpanishBlue = lng.cSpanish + cBlue; // SpanishBlue
// smuggle something cSpanishCarmine = lng.cSpanish + wr1.cCarmine; // SpanishCarmine
// smuggle something cSpanishGray = lng.cSpanish + cGray; // SpanishGray
// smuggle something cSpanishGreen = lng.cSpanish + cGreen; // SpanishGreen
// smuggle something cSpanishOrange = lng.cSpanish + cOrange; // SpanishOrange
// smuggle something cSpanishPink = lng.cSpanish + cPink; // SpanishPink
// smuggle something cSpanishRed = lng.cSpanish + cRed; // SpanishRed
// smuggle something cSpanishSkyBlue = lng.cSpanish + wr1.cSky + cBlue; // SpanishSkyBlue
// smuggle something cSpanishViolet = lng.cSpanish + cViolet; // SpanishViolet
// smuggle something cSpanishViridian = lng.cSpanish + cViridian; // SpanishViridian
// smuggle something cSpringBud = wr1.cSpring + wr1.cBud; // SpringBud
// smuggle something cSpringFrost = wr1.cSpring + wr1.cFrost; // SpringFrost
// smuggle something cSpringGreen = wr1.cSpring + cGreen; // SpringGreen
// smuggle something cSpringGreenCrayola = wr1.cSpring + cGreen + wr1.cCrayola; // SpringGreenCrayola
// smuggle something cStarCommandBlue = wr1.cStar + wr1.cCommand + cBlue; // StarCommandBlue
// smuggle something cSteelBlue = wr1.cSteel + cBlue; // SteelBlue
// smuggle something cSteelPink = wr1.cSteel + cPink; // SteelPink
// smuggle something cSteelTeal = wr1.cSteel + cTeal; // SteelTeal
// smuggle something cStilDeGrainYellow = wr1.cStil + bas.cDe + wr1.cGrain + cYellow; // StilDeGrainYellow
// smuggle something cStraw = bas.cSt + phn.craw; // Straw
// smuggle something cSugarPlum = wr1.cSugar + cPlum; // SugarPlum
// smuggle something cSunglow = wr1.cSun + wr1.cglow; // Sunglow
// smuggle something cSunray = wr1.cSun + phn.cray; // Sunray
// smuggle something cSunset = wr1.cSuns + bas.cet; // Sunset
// smuggle something cSuperPink = wr1.cSuper + cPink; // SuperPink
// smuggle something cSweetBrown = wr1.cSweet + cBrown; // SweetBrown
// smuggle something cTanCrayola = cTan + wr1.cCrayola; // TanCrayola
// smuggle something cTangoPink = gen.cTango + cPink; // TangoPink
// smuggle something cTartOrange = phn.cTart + cOrange; // TartOrange
// smuggle something cTaupeGray = cTaupe + cGray; // TaupeGray
// smuggle something cTeaGreen = wr1.cTea + cGreen; // TeaGreen
// smuggle something cTeaRose = wr1.cTea + cRose; // TeaRose
// smuggle something cTeaRoseWeb = wr1.cTea + cRose + wr1.cWeb; // TeaRoseWeb
// smuggle something cTealBlue = cTeal + cBlue; // TealBlue
// smuggle something cTelemagenta = bas.cTe + bas.cle + cmagenta; // Telemagenta
// smuggle something cTawny = bas.cTa + bas.cwn + bas.cy; // Tawny
// smuggle something cTerraCotta = wr1.cTerra + wr1.cCotta; // TerraCotta
// smuggle something cThistle = wr1.cThis + phn.ctle; // Thistle
// smuggle something cThulianPink = wr1.cThulian + cPink; // ThulianPink
// smuggle something cTickleMePink = wr1.cTickle + bas.cMe + cPink; // TickleMePink
// smuggle something cTiffanyBlue = wr1.cTiffany + cBlue; // TiffanyBlue
// smuggle something cTimberwolf = wr1.cTimber + wr1.cwolf; // Timberwolf
// smuggle something cTitaniumYellow = cTitanium + cYellow; // TitaniumYellow
// smuggle something cTomato = bas.cTo + wr1.cmat + bas.co; // Tomato
// smuggle something cTropicalRainforest = wr1.cTropical + wr1.cRain + phn.cfore + bas.cst; // TropicalRainforest
// smuggle something cTrueBlue = gen.cTrue + cBlue; // TrueBlue
// smuggle something cTrypanBlue = wr1.cTrypan + cBlue; // TrypanBlue
// smuggle something cTuftsBlue = wr1.cTufts + cBlue; // TuftsBlue
// smuggle something cTumbleweed = wr1.cTumble + wr1.cweed; // Tumbleweed
// smuggle something cTurquoiseBlue = cTurquoise + cBlue; // TurquoiseBlue
// smuggle something cTurquoiseGreen = cTurquoise + cGreen; // TurquoiseGreen
// smuggle something cTurtleGreen = bas.cTu + bas.crt + bas.cle + cGreen; // TurtleGreen
// smuggle something cTuscanBrown = cTuscan + cBrown; // TuscanBrown
// smuggle something cTuscanRed = cTuscan + cRed; // TuscanRed
// smuggle something cTuscanTan = cTuscan + cTan; // TuscanTan
// smuggle something cTuscany = cTuscan + bas.cy; // Tuscany
// smuggle something cTwilightLavender = wr1.cTwilight + cLavender; // TwilightLavender
// smuggle something cTyrianPurple = wr1.cTyrian + cPurple; // TyrianPurple
// smuggle something cUABlue = bas.cUA + cBlue; // UABlue
// smuggle something cUARed = bas.cUA + cRed; // UARed
// smuggle something cUltramarine = wr1.cUltra + phn.cmar + phn.cine; // Ultramarine
// smuggle something cUltramarineBlue = wr1.cUltra + phn.cmar + phn.cine + cBlue; // UltramarineBlue
// smuggle something cUltraPink = wr1.cUltra + cPink; // UltraPink
// smuggle something cUltraRed = wr1.cUltra + cRed; // UltraRed
// smuggle something cUnbleachedSilk = wr1.cUnbleached + wr1.cSilk; // UnbleachedSilk
// smuggle something cUnitedNationsBlue = wr1.cUnited + wr1.cNations + cBlue; // UnitedNationsBlue
// smuggle something cUnmellowYellow = bas.cUn + phn.cmel + wr1.clow + cYellow; // UnmellowYellow
// smuggle something cUPForestGreen = bas.cUP + wr1.cForest + cGreen; // UPForestGreen
// smuggle something cUPMaroon = bas.cUP + cMaroon; // UPMaroon
// smuggle something cUpsdellRed = wr1.cUpsdell + cRed; // UpsdellRed
// smuggle something cUranianBlue = wr1.cUranian + cBlue; // UranianBlue
// smuggle something cUSAFABlue = bas.cUS + bas.cAF + bas.cAB + phn.clue; // USAFABlue
// smuggle something cVanDykeBrown = wr1.cVan + wr1.cDyke + cBrown; // VanDykeBrown
// smuggle something cVanillaIce = cVanilla + wr1.cIce; // VanillaIce
// smuggle something cVegasGold = wr1.cVegas + cGold; // VegasGold
// smuggle something cVenetianRed = wr1.cVenetian + cRed; // VenetianRed
// smuggle something cVerdigris = phn.cVer + wr1.cdig + phn.cris; // Verdigris
// smuggle something cVermilionWeb = cVermilion + wr1.cWeb; // VermilionWeb
// smuggle something cVeronica = phn.cVer + bas.con + phn.cica; // Veronica
// smuggle something cVioletColorWheel = cViolet + wr1.cColor + wr1.cWheel; // VioletColorWheel
// smuggle something cVioletCrayola = cViolet + wr1.cCrayola; // VioletCrayola
// smuggle something cVioletRYB = cViolet + phn.cRYB; // VioletRYB
// smuggle something cVioletWeb = cViolet + wr1.cWeb; // VioletWeb
// smuggle something cVioletBlue = cViolet + cBlue; // VioletBlue
// smuggle something cVioletBlueCrayola = cViolet + cBlue + wr1.cCrayola; // VioletBlueCrayola
// smuggle something cVioletRed = cViolet + cRed; // VioletRed
// smuggle something cViridianGreen = cViridian + cGreen; // ViridianGreen
// smuggle something cVividBurgundy = wr1.cVivid + bas.cBu + phn.crgundy; // VividBurgundy
// smuggle something cVividSkyBlue = wr1.cVivid + wr1.cSky + cBlue; // VividSkyBlue
// smuggle something cVividTangerine = wr1.cVivid + cTangerine; // VividTangerine
// smuggle something cVividViolet = wr1.cVivid + cViolet; // VividViolet
// smuggle something cVolt = bas.cVo + bas.clt; // Volt
// smuggle something cWarmBlack = wr1.cWarm + cBlack; // WarmBlack
// smuggle something cWheat = bas.cWh + phn.ceat; // Wheat
// smuggle something cWildBlueYonder = wr1.cWild + cBlue + wr1.cYonder; // WildBlueYonder
// smuggle something cWildOrchid = wr1.cWild + bas.cOr + phn.cchid; // WildOrchid
// smuggle something cWildStrawberry = wr1.cWild + bas.cSt + phn.craw + wr1.cberry; // WildStrawberry
// smuggle something cWildWatermelon = wr1.cWild + bas.cWa + wr1.cterm + phn.celon; // WildWatermelon
// smuggle something cWindsorTan = wr1.cWindsor + cTan; // WindsorTan
// smuggle something cWine = bas.cWi + bas.cne; // Wine
// smuggle something cWineDregs = bas.cWi + bas.cne + wr1.cDregs; // WineDregs
// smuggle something cWinterSky = wr1.cWinter + wr1.cSky; // WinterSky
// smuggle something cWintergreenDream = wr1.cWinter + cgreen + wr1.cDream; // WintergreenDream
// smuggle something cWisteria = bas.cWi + phn.cster + bas.cia; // Wisteria
// smuggle something cWoodBrown = bas.cWo + bas.cod + cBrown; // WoodBrown
// smuggle something cXanthic = bas.cXa + wr1.cnth + bas.cic; // Xanthic
// smuggle something cXanadu = bas.cXa + bas.cna + bas.cdu; // Xanadu
// smuggle something cYaleBlue = wr1.cYale + cBlue; // YaleBlue
// smuggle something cYellowCrayola = cYellow + wr1.cCrayola; // YellowCrayola
// smuggle something cYellowMunsell = cYellow + wr1.cMunsell; // YellowMunsell
// smuggle something cYellowNCS = cYellow + phn.cNCS; // YellowNCS
// smuggle something cYellowPantone = cYellow + wr1.cPantone; // YellowPantone
// smuggle something cYellowProcess = cYellow + wr1.cProcess; // YellowProcess
// smuggle something cYellowRYB = cYellow + phn.cRYB; // YellowRYB
// smuggle something cYellowGreen = cYellow + cGreen; // YellowGreen
// smuggle something cYellowGreenCrayola = cYellow + cGreen + wr1.cCrayola; // YellowGreenCrayola
// smuggle something cYellowGreenColorWheel = cYellow + cGreen + wr1.cColor + wr1.cWheel; // YellowGreenColorWheel
// smuggle something cYellowOrange = cYellow + cOrange; // YellowOrange
// smuggle something cYellowOrangeColorWheel = cYellow + cOrange + wr1.cColor + wr1.cWheel; // YellowOrangeColorWheel
// smuggle something cYellowSunshine = cYellow + wr1.cSuns + phn.chine; // YellowSunshine
// smuggle something cYInMnBlue = bas.cY + bas.cIn + bas.cMn + cBlue; // YInMnBlue
// smuggle something cZaffre = bas.cZa + bas.cff + bas.cre; // Zaffre
// smuggle something cZomp = bas.cZo + bas.cmp; // Zomp

exports.cVermilion = cVermilion;