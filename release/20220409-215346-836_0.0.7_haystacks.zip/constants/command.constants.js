"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cworkflowHelp = exports.cvalidateConstants = exports.cvalidateCommandAliases = exports.csaveConfiguration = exports.cprintDataHiveAttributes = exports.cprintDataHive = exports.cechoCommand = exports.cconvertColors = exports.cconstantsPatternRecognizer = exports.cconstantsGeneratorList = exports.cconstantsGenerator = exports.ccommandSequencer = exports.ccommandMetrics = exports.ccommandGenerator = exports.ccommandAliasGenerator = exports.cclearScreen = exports.cclearDataStorage = exports.cbusinessRulesMetrics = exports.cbusinessRule = exports.cStartupWorkflow = exports.cFrameworkDetailsWorkflow = exports.cEchoCommand = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var biz = _interopRequireWildcard(require("./business.constants.js"));

var sys = _interopRequireWildcard(require("./system.constants.js"));

var wr1 = _interopRequireWildcard(require("./word1.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file command.constants.js
 * @module command.constants
 * @description Contains many re-usable command constants
 * @requires module:basic.constants
 * @requires module:business.constants
 * @requires module:system.constants
 * @requires module:word1.constants
 * @author Seth Hollingsead
 * @date 2022/02/04
 * @copyright Copyright © 2022-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// Generic Commands constants
// ***********************************************
// Nominal commands in order
// ***********************************************
var cechoCommand = biz.cecho + wr1.cCommand; // echoCommand

exports.cechoCommand = cechoCommand;
var cEchoCommand = biz.cEcho + wr1.cCommand; // EchoCommand

exports.cEchoCommand = cEchoCommand;
var cclearScreen = wr1.cclear + wr1.cScreen; // clearScreen

exports.cclearScreen = cclearScreen;
var cworkflowHelp = wr1.cworkflow + wr1.cHelp; // workflowHelp

exports.cworkflowHelp = cworkflowHelp;
var ccommandSequencer = wr1.ccommand + wr1.cSequencer; // commandSequencer

exports.ccommandSequencer = ccommandSequencer;
var cprintDataHive = wr1.cprint + wr1.cData + wr1.cHive; // printDataHive

exports.cprintDataHive = cprintDataHive;
var cprintDataHiveAttributes = cprintDataHive + wr1.cAttributes; // printDataHiveAttributes

exports.cprintDataHiveAttributes = cprintDataHiveAttributes;
var cclearDataStorage = wr1.cclear + wr1.cData + wr1.cStorage; // clearDataStorage

exports.cclearDataStorage = cclearDataStorage;
var cbusinessRule = wr1.cbusiness + wr1.cRule; // businessRule

exports.cbusinessRule = cbusinessRule;
var ccommandGenerator = wr1.ccommand + wr1.cGenerator; // commandGenerator

exports.ccommandGenerator = ccommandGenerator;
var ccommandAliasGenerator = wr1.ccommand + wr1.cAlias + wr1.cGenerator; // commandAliasGenerator

exports.ccommandAliasGenerator = ccommandAliasGenerator;
var cconstantsGenerator = wr1.cconstants + wr1.cGenerator; // constantsGenerator

exports.cconstantsGenerator = cconstantsGenerator;
var cconstantsGeneratorList = cconstantsGenerator + wr1.cList; // constantsGeneratorList

exports.cconstantsGeneratorList = cconstantsGeneratorList;
var cconstantsPatternRecognizer = wr1.cconstants + wr1.cPattern + wr1.cRecognizer; // constantsPatternRecognizer

exports.cconstantsPatternRecognizer = cconstantsPatternRecognizer;
var cbusinessRulesMetrics = wr1.cbusiness + wr1.cRules + wr1.cMetrics; // businessRulesMetrics

exports.cbusinessRulesMetrics = cbusinessRulesMetrics;
var ccommandMetrics = wr1.ccommand + wr1.cMetrics; // commandMetrics

exports.ccommandMetrics = ccommandMetrics;
var csaveConfiguration = wr1.csave + wr1.cConfiguration; // saveConfiguration

exports.csaveConfiguration = csaveConfiguration;
var cconvertColors = wr1.cconvert + wr1.cColors; // convertColors
// ***********************************************
// Integration Test commands in order
// ***********************************************

exports.cconvertColors = cconvertColors;
var cvalidateConstants = wr1.cvalidate + wr1.cConstants; // validateConstants

exports.cvalidateConstants = cvalidateConstants;
var cvalidateCommandAliases = wr1.cvalidate + wr1.cCommand + wr1.cAliases; // validateCommandAliases
// ********************************
// System defined workflows
// ********************************

exports.cvalidateCommandAliases = cvalidateCommandAliases;
var cStartupWorkflow = wr1.cWorkflow + bas.cSpace + wr1.cstartup; // Workflow startup

exports.cStartupWorkflow = cStartupWorkflow;
var cFrameworkDetailsWorkflow = wr1.cWorkflow + bas.cSpace + wr1.cframework + wr1.cDetails; // Workflow frameworkDetails

exports.cFrameworkDetailsWorkflow = cFrameworkDetailsWorkflow;