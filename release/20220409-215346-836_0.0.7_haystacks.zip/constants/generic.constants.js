"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cMike = exports.cMay = exports.cMax = exports.cMarch = exports.cLowerCaseEnglishAlphabet = exports.cLog = exports.cLima = exports.cLeft = exports.cLambda = exports.cLOG = exports.cKoppa = exports.cKilo = exports.cKappa = exports.cJune = exports.cJuly = exports.cJuliett = exports.cJson = exports.cJs = exports.cJanuary = exports.cJSON = exports.cJS = exports.cIota = exports.cInit = exports.cIndia = exports.cHotel = exports.cHex = exports.cHHmmss_SSS = exports.cHHmmss = exports.cGolf = exports.cGamma = exports.cFoxtrot = exports.cFebuary = exports.cFalse = exports.cFail = exports.cFALSE = exports.cExe = exports.cEta = exports.cEpsilon = exports.cEnv = exports.cEcho = exports.cEXE = exports.cENV = exports.cDown = exports.cDotzip = exports.cDotxml = exports.cDottxt = exports.cDotlog = exports.cDotjson = exports.cDotjs = exports.cDotexe = exports.cDotenv = exports.cDotcsv = exports.cDotZip = exports.cDotZIP = exports.cDotXml = exports.cDotXML = exports.cDotTxt = exports.cDotTXT = exports.cDotLog = exports.cDotLOG = exports.cDotJson = exports.cDotJs = exports.cDotJSON = exports.cDotJS = exports.cDotExe = exports.cDotEnv = exports.cDotEXE = exports.cDotENV = exports.cDotDotForwardSlash = exports.cDotDot = exports.cDotCsv = exports.cDotCom = exports.cDotCSV = exports.cDoc = exports.cDigamma = exports.cDelta = exports.cDecember = exports.cDOC = exports.cCsv = exports.cConst = exports.cCom = exports.cChi = exports.cCharlie = exports.cCSV = exports.cCOM = exports.cCMYK = exports.cBravo = exports.cBin = exports.cBeta = exports.cBIN = exports.cAugust = exports.cArgs = exports.cArg = exports.cApril = exports.cApp = exports.cAlpha = exports.cAllNumbers = exports.cAlfa = exports.cASAP = exports.cAPP = void 0;
exports.clng = exports.ckts = exports.cjson = exports.cjs = exports.ciso = exports.cinit = exports.chex = exports.cgen = exports.cfnc = exports.cfalse = exports.cexe = exports.ceta = exports.cenv = exports.celm = exports.cdoc = exports.cctr = exports.ccsv = exports.cconst = exports.ccon = exports.ccom = exports.ccmyk = exports.ccmd = exports.cclr = exports.ccfg = exports.cbiz = exports.cbin = exports.cbas = exports.cascii = exports.cargs = exports.carg = exports.capp = exports.capc = exports.cZulu = exports.cZip = exports.cZeta = exports.cZIP = exports.cYes = exports.cYankee = exports.cYYYY_MM_DD_HH_mm_ss_SSS = exports.cYYYYMMDD_HHmmss_SSS = exports.cYYYYMMDD_HHmmss = exports.cYYYYMMDD = exports.cYYYY = exports.cYES = exports.cXray = exports.cXml = exports.cXi = exports.cXML = exports.cWhiskey = exports.cWarning = exports.cVictor = exports.cUpsilon = exports.cUpperCaseEnglishAlphabet = exports.cUniform = exports.cUTF8 = exports.cTxt = exports.cTrue = exports.cTheta = exports.cTau = exports.cTango = exports.cTXT = exports.cTRUE = exports.cSigma = exports.cSierra = exports.cSeptember = exports.cSan = exports.cSSS = exports.cRomeo = exports.cRight = exports.cRho = exports.cRegExp = exports.cRegEx = exports.cRGB = exports.cQuebec = exports.cPsi = exports.cPi = exports.cPhi = exports.cPass = exports.cPapa = exports.cOscar = exports.cOmicron = exports.cOmega = exports.cOff = exports.cOctober = exports.cOFF = exports.cNu = exports.cNovember = exports.cNotok = exports.cNoteql = exports.cNotOk = exports.cNotOK = exports.cNotEql = exports.cNot = exports.cNOTok = exports.cNOTOk = exports.cNOTOK = exports.cNOT = exports.cMu = exports.cMostSpecialCharacters = exports.cMin = void 0;
exports.czip = exports.cyes = exports.cxml = exports.cwr1 = exports.cwin32 = exports.cunt = exports.ctxt = exports.ctrue = exports.csys = exports.cshp = exports.crgb = exports.cregExp = exports.cregEx = exports.cphn = exports.coff = exports.cnum = exports.cnotok = exports.cnoteql = exports.cnotOk = exports.cnotOK = exports.cnotEql = exports.cnot = exports.cmsg = exports.cmin = exports.cmax = exports.clog = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var num = _interopRequireWildcard(require("./numeric.constants.js"));

var phn = _interopRequireWildcard(require("./phonic.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file generic.constants.js
 * @module generic-constants
 * @description Contains many generic constants.
 * Also included are other generic constants like string numbers like "one", "two", "three".
 * Also included are spellings of Greek letters, military codes/standards, units of measurement, units of time, etc...
 * @requires module:basic.constants
 * @requires module:numeric.constants
 * @requires module:phonic.constants
 * @author Seth Hollingsead
 * @date 2020/06/04
 * @copyright Copyright © 2020-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
var cDotDot = bas.cDot + bas.cDot; // ..

exports.cDotDot = cDotDot;
var cDotDotForwardSlash = cDotDot + bas.cForwardSlash; // ../
// Boolean strings

exports.cDotDotForwardSlash = cDotDotForwardSlash;
var cTrue = bas.cT + phn.crue; // True

exports.cTrue = cTrue;
var cFalse = bas.cF + phn.calse; // False

exports.cFalse = cFalse;
var ctrue = bas.ct + phn.crue; // true

exports.ctrue = ctrue;
var cfalse = bas.cf + phn.calse; // false

exports.cfalse = cfalse;
var cTRUE = bas.cTR + bas.cUE; // TRUE

exports.cTRUE = cTRUE;
var cFALSE = bas.cFA + bas.cLS + bas.cE; // FALSE

exports.cFALSE = cFALSE;
var cOff = bas.cO + bas.cff; // Off

exports.cOff = cOff;
var coff = bas.co + bas.cff; // off

exports.coff = coff;
var cOFF = bas.cOF + bas.cF; // OFF

exports.cOFF = cOFF;
var cyes = bas.cy + bas.ces; // yes

exports.cyes = cyes;
var cnot = bas.cno + bas.ct; // not

exports.cnot = cnot;
var cYes = bas.cY + bas.ces; // Yes

exports.cYes = cYes;
var cNot = bas.cNo + bas.ct; // Not

exports.cNot = cNot;
var cYES = bas.cYE + bas.cS; // YES

exports.cYES = cYES;
var cNOT = 'NOT'; // bas.c_NO + bas.cT; // NOTE cNOT is some how a reserved word that is a variable.

exports.cNOT = cNOT;
var cnotok = cnot + bas.cok; // notok

exports.cnotok = cnotok;
var cnotOk = cnot + bas.cOk; // notOk

exports.cnotOk = cnotOk;
var cnotOK = cnot + bas.cOK; // notOK

exports.cnotOK = cnotOK;
var cNotok = cNot + bas.cok; // Notok

exports.cNotok = cNotok;
var cNotOk = cNot + bas.cOk; // NotOk

exports.cNotOk = cNotOk;
var cNotOK = cNot + bas.cOK; // NotOK

exports.cNotOK = cNotOK;
var cNOTok = 'NOTok'; // c_NOT = bas.cok;

exports.cNOTok = cNOTok;
var cNOTOk = 'NOTOk'; // c_NOT = bas.cOk;

exports.cNOTOk = cNOTOk;
var cNOTOK = 'NOTOK'; // c_NOT + bas.cOK;

exports.cNOTOK = cNOTOK;
var cnotEql = cnot + phn.cEql; // notEql

exports.cnotEql = cnotEql;
var cnoteql = cnot + phn.ceql; // noteql

exports.cnoteql = cnoteql;
var cNotEql = cNot + phn.cEql; // NotEql

exports.cNotEql = cNotEql;
var cNoteql = cNot + phn.ceql; // Noteql

exports.cNoteql = cNoteql;
var cmax = phn.cmax; // max

exports.cmax = cmax;
var cMax = phn.cMax; // Max

exports.cMax = cMax;
var cmin = phn.cmin; // min

exports.cmin = cmin;
var cMin = phn.cMin; // Min
// Test Status

exports.cMin = cMin;
var cPass = bas.cPa + bas.css; // Pass

exports.cPass = cPass;
var cWarning = bas.cWa + bas.crn + bas.cin + bas.cg; // Warning

exports.cWarning = cWarning;
var cFail = bas.cFa + bas.cil; // Fail
// Directions

exports.cFail = cFail;
var cDown = bas.cDo + bas.cwn; // Down

exports.cDown = cDown;
var cLeft = bas.cLe + bas.cft; // Left

exports.cLeft = cLeft;
var cRight = bas.cRi + bas.cgh + bas.ct; // Right
// Alphabets

exports.cRight = cRight;
var cLowerCaseEnglishAlphabet = bas.cab + bas.ccd + bas.cef + bas.cgh + bas.cij + bas.ckl + bas.cmn + bas.cop + bas.cqr + bas.cst + bas.cuv + bas.cwx + bas.cyz; // abcdefghijklmnopqrstuvwxyz

exports.cLowerCaseEnglishAlphabet = cLowerCaseEnglishAlphabet;
var cUpperCaseEnglishAlphabet = bas.cAB + bas.cCD + bas.cEF + bas.cGH + bas.cIJ + bas.cKL + bas.cMN + bas.cOP + bas.cQR + bas.cST + bas.cUV + bas.cWX + bas.cYZ; // ABCDEFGHIJKLMNOPQRSTUVWXYZ

exports.cUpperCaseEnglishAlphabet = cUpperCaseEnglishAlphabet;
var cAllNumbers = num.c0 + num.c1 + num.c2 + num.c3 + num.c4 + num.c5 + num.c6 + num.c7 + num.c8 + num.c9; // 0123456789

exports.cAllNumbers = cAllNumbers;
var cMostSpecialCharacters = bas.cExclamation + bas.cAt + bas.cHash + bas.cDollar + bas.cPercent + bas.cCarrot + bas.cAndPersand + bas.cStar + bas.cOpenParenthesis + bas.cCloseParenthesis + bas.cUnderscore + bas.cPlus + bas.cOpenCurlyBrace + bas.cCloseCurlyBrace + bas.cPipe + bas.cColon + bas.cDoubleQuote + bas.cLessThan + bas.cGreaterThan + bas.cQuestion + bas.cDot + bas.cComa + bas.cTilde; // !@#$%^&*()_+{}|:"<>?.,~
// File Extensions

exports.cMostSpecialCharacters = cMostSpecialCharacters;
var cexe = bas.cex + bas.ce; // exe

exports.cexe = cexe;
var cExe = bas.cEx + bas.ce; // Exe

exports.cExe = cExe;
var cEXE = bas.cEX + bas.cE; // EXE

exports.cEXE = cEXE;
var cdoc = bas.cdo + bas.cc; // doc

exports.cdoc = cdoc;
var cDoc = bas.cDo + bas.cc; // Doc

exports.cDoc = cDoc;
var cDOC = bas.cDO + bas.cC; // DOC

exports.cDOC = cDOC;
var ccom = bas.cco + bas.cm; // com

exports.ccom = ccom;
var cCom = bas.cCo + bas.cm; // Com

exports.cCom = cCom;
var cCOM = bas.cCO + bas.cM; // COM

exports.cCOM = cCOM;
var czip = bas.cz + bas.cip; // zip

exports.czip = czip;
var cZip = bas.cZ + bas.cip; // Zip

exports.cZip = cZip;
var cZIP = bas.cZ + bas.cIP; // ZIP

exports.cZIP = cZIP;
var ctxt = bas.ct + bas.cxt; // txt

exports.ctxt = ctxt;
var cTxt = bas.cT + bas.cxt; // Txt

exports.cTxt = cTxt;
var cTXT = bas.cT + bas.cXT; // TXT

exports.cTXT = cTXT;
var ccsv = bas.ccs + bas.cv; // csv

exports.ccsv = ccsv;
var cCsv = bas.cCs + bas.cv; // Csv

exports.cCsv = cCsv;
var cCSV = bas.cCS + bas.cV; // CSV

exports.cCSV = cCSV;
var cxml = bas.cxm + bas.cl; // xml

exports.cxml = cxml;
var cXml = bas.cXm + bas.cl; // Xml

exports.cXml = cXml;
var cXML = bas.cXM + bas.cL; // XML

exports.cXML = cXML;
var clog = bas.clo + bas.cg; // log

exports.clog = clog;
var cLog = bas.cLo + bas.cg; // Log

exports.cLog = cLog;
var cLOG = bas.cLO + bas.cG; // LOG

exports.cLOG = cLOG;
var cjs = bas.cjs; // js

exports.cjs = cjs;
var cJs = bas.cJs; // Js

exports.cJs = cJs;
var cJS = bas.cJS; // JS

exports.cJS = cJS;
var cjson = bas.cjs + bas.con; // json

exports.cjson = cjson;
var cJson = bas.cJs + bas.con; // Json

exports.cJson = cJson;
var cJSON = bas.cJS + bas.cON; // JSON

exports.cJSON = cJSON;
var cenv = bas.cen + bas.cv; // env

exports.cenv = cenv;
var cEnv = bas.cEn + bas.cv; // Env

exports.cEnv = cEnv;
var cENV = bas.cEN + bas.cV; // ENV

exports.cENV = cENV;
var cDotexe = bas.cDot + cexe; // .exe

exports.cDotexe = cDotexe;
var cDotExe = bas.cDot + cExe; // .Exe

exports.cDotExe = cDotExe;
var cDotEXE = bas.cDot + cEXE; // .EXE

exports.cDotEXE = cDotEXE;
var cDotcsv = bas.cDot + ccsv; // .csv

exports.cDotcsv = cDotcsv;
var cDotCsv = bas.cDot + cCsv; // .Csv

exports.cDotCsv = cDotCsv;
var cDotCSV = bas.cDot + cCSV; // .CSV

exports.cDotCSV = cDotCSV;
var cDotCom = bas.cDot + cCom; // .Com

exports.cDotCom = cDotCom;
var cDotzip = bas.cDot + czip; // .zip

exports.cDotzip = cDotzip;
var cDotZip = bas.cDot + cZip; // .Zip

exports.cDotZip = cDotZip;
var cDotZIP = bas.cDot + cZIP; // .ZIP

exports.cDotZIP = cDotZIP;
var cDottxt = bas.cDot + ctxt; // .txt

exports.cDottxt = cDottxt;
var cDotTxt = bas.cDot + cTxt; // .Txt

exports.cDotTxt = cDotTxt;
var cDotTXT = bas.cDot + cTXT; // .TXT

exports.cDotTXT = cDotTXT;
var cDotxml = bas.cDot + cxml; // .xml

exports.cDotxml = cDotxml;
var cDotXml = bas.cDot + cXml; // .Xml

exports.cDotXml = cDotXml;
var cDotXML = bas.cDot + cXML; // .XML

exports.cDotXML = cDotXML;
var cDotlog = bas.cDot + clog; // .log

exports.cDotlog = cDotlog;
var cDotLog = bas.cDot + cLog; // .Log

exports.cDotLog = cDotLog;
var cDotLOG = bas.cDot + cLOG; // .LOG

exports.cDotLOG = cDotLOG;
var cDotjs = bas.cDot + cjs; // .js

exports.cDotjs = cDotjs;
var cDotJs = bas.cDot + cJs; // .Js

exports.cDotJs = cDotJs;
var cDotJS = bas.cDot + cJS; // .JS

exports.cDotJS = cDotJS;
var cDotjson = bas.cDot + cjson; // .json

exports.cDotjson = cDotjson;
var cDotJson = bas.cDot + cJson; // .Json

exports.cDotJson = cDotJson;
var cDotJSON = bas.cDot + cJSON; // .JSON

exports.cDotJSON = cDotJSON;
var cDotenv = bas.cDot + cenv; // .env

exports.cDotenv = cDotenv;
var cDotEnv = bas.cDot + cEnv; // .Env

exports.cDotEnv = cDotEnv;
var cDotENV = bas.cDot + cENV; // .ENV

exports.cDotENV = cDotENV;
var cascii = bas.cas + bas.cci + bas.ci; // ascii
// Time Formatting

exports.cascii = cascii;
var cYYYY = bas.cYY + bas.cYY; // YYYY

exports.cYYYY = cYYYY;
var cSSS = bas.cSS + bas.cS; // SSS

exports.cSSS = cSSS;
var cYYYYMMDD = cYYYY + bas.cMM + bas.cDD; // YYYYMMDD

exports.cYYYYMMDD = cYYYYMMDD;
var cHHmmss = bas.cHH + bas.cmm + bas.css; // HHmmss

exports.cHHmmss = cHHmmss;
var cHHmmss_SSS = cHHmmss + bas.cDash + cSSS; // HHmmss-SSS

exports.cHHmmss_SSS = cHHmmss_SSS;
var cYYYYMMDD_HHmmss = cYYYYMMDD + bas.cDash + cHHmmss; // YYYYMMDD-HHmmss

exports.cYYYYMMDD_HHmmss = cYYYYMMDD_HHmmss;
var cYYYYMMDD_HHmmss_SSS = cYYYYMMDD_HHmmss + bas.cDash + cSSS; // YYYYMMDD-HHmmss-SSS

exports.cYYYYMMDD_HHmmss_SSS = cYYYYMMDD_HHmmss_SSS;
var cYYYY_MM_DD_HH_mm_ss_SSS = cYYYY + bas.cColon + bas.cMM + bas.cColon + bas.cDD + bas.cDash + bas.cHH + bas.cColon + bas.cmm + bas.cColon + bas.css + bas.cColon + cSSS; // YYYY:MM:DD-HH:mm:ss:SSS
// Operating Systems

exports.cYYYY_MM_DD_HH_mm_ss_SSS = cYYYY_MM_DD_HH_mm_ss_SSS;
var cwin32 = phn.cwin + num.c32; // Naval & Military Codes

exports.cwin32 = cwin32;
var cAlfa = bas.cAl + bas.cfa; //  Alfa

exports.cAlfa = cAlfa;
var cBravo = bas.cBr + bas.cav + bas.co; // Bravo

exports.cBravo = cBravo;
var cCharlie = bas.cCh + bas.car + bas.cli + bas.ce; // Charlie

exports.cCharlie = cCharlie;
var cDelta = bas.cDe + bas.clt + bas.ca; // Delta

exports.cDelta = cDelta;
var cEcho = bas.cEc + bas.cho; // Echo

exports.cEcho = cEcho;
var cFoxtrot = bas.cFo + bas.cxt + bas.cro + bas.ct; // Foxtrot

exports.cFoxtrot = cFoxtrot;
var cGolf = bas.cGo + bas.clf; // Golf

exports.cGolf = cGolf;
var cHotel = bas.cHo + bas.cte + bas.cl; // Hotel

exports.cHotel = cHotel;
var cIndia = bas.cIn + bas.cdi + bas.ca; // India

exports.cIndia = cIndia;
var cJuliett = bas.cJu + bas.cli + bas.cet + bas.ct; // Juliett

exports.cJuliett = cJuliett;
var cKilo = bas.cKi + bas.clo; // Kilo

exports.cKilo = cKilo;
var cLima = bas.cLi + bas.cma; // Lima

exports.cLima = cLima;
var cMike = bas.cMi + bas.cke; // Mike

exports.cMike = cMike;
var cNovember = bas.cNo + bas.cv + phn.cemb + bas.cer; // November

exports.cNovember = cNovember;
var cOscar = bas.cOs + bas.cca + bas.cr; // Oscar

exports.cOscar = cOscar;
var cPapa = bas.cPa + bas.cpa; // Papa

exports.cPapa = cPapa;
var cQuebec = bas.cQu + bas.ceb + bas.cec; // Quebec

exports.cQuebec = cQuebec;
var cRomeo = bas.cRo + bas.cme + bas.co; // Romeo

exports.cRomeo = cRomeo;
var cSierra = bas.cSi + bas.cer + bas.cra; // Sierra

exports.cSierra = cSierra;
var cTango = bas.cTa + bas.cng + bas.co; // Tango

exports.cTango = cTango;
var cUniform = bas.cUn + bas.cif + bas.cor + bas.cm; // Uniform

exports.cUniform = cUniform;
var cVictor = bas.cVi + phn.cctor; // Victor

exports.cVictor = cVictor;
var cWhiskey = bas.cWh + bas.cis + bas.cke + bas.cy; // Whiskey

exports.cWhiskey = cWhiskey;
var cXray = bas.cXr + bas.cay; // Xray

exports.cXray = cXray;
var cYankee = bas.cYa + bas.cnk + bas.cee; // Yankee

exports.cYankee = cYankee;
var cZulu = bas.cZu + bas.clu; // Zulu

exports.cZulu = cZulu;
var cAlpha = bas.cAl + bas.cph + bas.ca; // Alpha

exports.cAlpha = cAlpha;
var cBeta = bas.cBe + bas.cta; // Beta

exports.cBeta = cBeta;
var cGamma = bas.cGa + bas.cmm + bas.ca; // Gamma

exports.cGamma = cGamma;
var cEpsilon = bas.cEp + bas.csi + bas.clo + bas.cn; // Epsilon

exports.cEpsilon = cEpsilon;
var cDigamma = bas.cDi + bas.cga + bas.cmm + bas.ca; // Digamma

exports.cDigamma = cDigamma;
var cZeta = bas.cZe + bas.cta; // Zeta

exports.cZeta = cZeta;
var ceta = bas.cet + bas.ca; // eta

exports.ceta = ceta;
var cEta = bas.cEt + bas.ca; // Eta

exports.cEta = cEta;
var cTheta = bas.cTh + bas.cet + bas.ca; // Theta

exports.cTheta = cTheta;
var cIota = bas.cIo + bas.cta; // Iota

exports.cIota = cIota;
var cKappa = bas.cKa + bas.cpp + bas.ca; // Kappa

exports.cKappa = cKappa;
var cLambda = bas.cLa + bas.cmb + bas.cda; // Lambda

exports.cLambda = cLambda;
var cMu = bas.cMu; // Mu

exports.cMu = cMu;
var cNu = bas.cNu; // Nu

exports.cNu = cNu;
var cXi = bas.cXi; // Xi

exports.cXi = cXi;
var cOmicron = bas.cOm + bas.cic + bas.cro + bas.cn; // Omicron

exports.cOmicron = cOmicron;
var cPi = bas.cPi; // Pi

exports.cPi = cPi;
var cSan = bas.cSa + bas.cn; // San

exports.cSan = cSan;
var cKoppa = bas.cKo + bas.cpp + bas.ca; // Koppa

exports.cKoppa = cKoppa;
var cRho = bas.cRh + bas.co; // Rho

exports.cRho = cRho;
var cSigma = bas.cSi + bas.cgm + bas.ca; // Sigma

exports.cSigma = cSigma;
var cTau = bas.cTa + bas.cu; // Tau

exports.cTau = cTau;
var cUpsilon = bas.cUp + bas.csi + bas.clo + bas.cn; // Upsilon

exports.cUpsilon = cUpsilon;
var cPhi = bas.cPh + bas.ci; // Phi

exports.cPhi = cPhi;
var cChi = bas.cCh + bas.ci; // Chi

exports.cChi = cChi;
var cPsi = bas.cPs + bas.ci; // Psi

exports.cPsi = cPsi;
var cOmega = bas.cOm + bas.ceg + bas.ca; // Omega
// Months Of The Year

exports.cOmega = cOmega;
var cJanuary = bas.cJa + bas.cn + phn.cuary; // January

exports.cJanuary = cJanuary;
var cFebuary = bas.cFe + bas.cb + phn.cuary; // Febuary

exports.cFebuary = cFebuary;
var cMarch = bas.cMa + bas.crc + bas.ch; // March

exports.cMarch = cMarch;
var cApril = bas.cAp + bas.cri + bas.cl; // April

exports.cApril = cApril;
var cMay = bas.cMa + bas.cy; // May

exports.cMay = cMay;
var cJune = bas.cJu + bas.cne; // June

exports.cJune = cJune;
var cJuly = bas.cJu + bas.cly; // July

exports.cJuly = cJuly;
var cAugust = bas.cAu + bas.cgu + bas.cst; // August

exports.cAugust = cAugust;
var cSeptember = bas.cSe + bas.cpt + phn.cemb + bas.cer; // September

exports.cSeptember = cSeptember;
var cOctober = bas.cOc + bas.cto + bas.cb + bas.cer; // October
// cNovember = bas.cNo + bas.cv + bas.cemb + bas.cer; // November

exports.cOctober = cOctober;
var cDecember = bas.cDe + bas.cc + phn.cemb + bas.cer; // December
// Constants Abreviations

exports.cDecember = cDecember;
var cbas = bas.cba + bas.cs; // bas

exports.cbas = cbas;
var cbiz = bas.cbi + bas.cz; // biz

exports.cbiz = cbiz;
var cclr = phn.cclr; // clr

exports.cclr = cclr;
var ccmd = bas.ccm + bas.cd; // cmd

exports.ccmd = ccmd;
var ccfg = bas.ccf + bas.cg; // cfg

exports.ccfg = ccfg;
var ccon = bas.cco + bas.cn; // con

exports.ccon = ccon;
var cctr = phn.cctr; // ctr

exports.cctr = cctr;
var cfnc = bas.cfn + bas.cc; // fnc

exports.cfnc = cfnc;
var celm = bas.cel + bas.cm; // elm

exports.celm = celm;
var cgen = phn.cgen; // gen

exports.cgen = cgen;
var ciso = phn.ciso; // iso

exports.ciso = ciso;
var ckts = bas.ckt + bas.cs; // kts

exports.ckts = ckts;
var clng = bas.cln + bas.cg; // lng

exports.clng = clng;
var cmsg = bas.cms + bas.cg; // msg

exports.cmsg = cmsg;
var cnum = phn.cnum; // num

exports.cnum = cnum;
var cphn = bas.cph + bas.cn; // phn

exports.cphn = cphn;
var cshp = phn.cshp; // shp

exports.cshp = cshp;
var csys = bas.csy + bas.cs; // sys

exports.csys = csys;
var cunt = phn.cunt; // unt

exports.cunt = cunt;
var cwr1 = bas.cwr + num.c1; // wr1

exports.cwr1 = cwr1;
var capc = bas.cap + bas.cc; // apc
// Miscelanious

exports.capc = capc;
var cUTF8 = bas.cUT + bas.cF + num.c8; // UTF8

exports.cUTF8 = cUTF8;
var crgb = bas.crg + bas.cb; // rgb

exports.crgb = crgb;
var cRGB = bas.cRG + bas.cB; // RGB

exports.cRGB = cRGB;
var ccmyk = bas.ccm + bas.cyk; // cmyk

exports.ccmyk = ccmyk;
var cCMYK = bas.cCM + bas.cYK; // CMYK

exports.cCMYK = cCMYK;
var cconst = phn.ccon + bas.cst; // const

exports.cconst = cconst;
var cConst = phn.cCon + bas.cst; // Const

exports.cConst = cConst;
var cASAP = bas.cAS + bas.cAP; // ASAP

exports.cASAP = cASAP;
var capp = bas.cap + bas.cp; // app

exports.capp = capp;
var cApp = bas.cAp + bas.cp; // App

exports.cApp = cApp;
var cAPP = bas.cAP + bas.cP; // APP

exports.cAPP = cAPP;
var carg = bas.car + bas.cg; // arg

exports.carg = carg;
var cArg = bas.cAr + bas.cg; // Arg

exports.cArg = cArg;
var cargs = bas.ca + phn.crgs; // args

exports.cargs = cargs;
var cArgs = bas.cA + phn.crgs; // Args

exports.cArgs = cArgs;
var chex = bas.che + bas.cx; // hex

exports.chex = chex;
var cHex = bas.cHe + bas.cx; // Hex

exports.cHex = cHex;
var cregEx = phn.creg + bas.cEx; // regEx

exports.cregEx = cregEx;
var cRegEx = phn.cReg + bas.cEx; // RegEx

exports.cRegEx = cRegEx;
var cregExp = cregEx + bas.cp; // regExp

exports.cregExp = cregExp;
var cRegExp = cRegEx + bas.cp; // RegExp

exports.cRegExp = cRegExp;
var cbin = bas.cbi + bas.cn; // bin

exports.cbin = cbin;
var cBin = bas.cBi + bas.cn; // Bin

exports.cBin = cBin;
var cBIN = bas.cBI + bas.cN; // BIN

exports.cBIN = cBIN;
var cinit = phn.cini + bas.ct; // init

exports.cinit = cinit;
var cInit = phn.cIni + bas.ct; // Init

exports.cInit = cInit;