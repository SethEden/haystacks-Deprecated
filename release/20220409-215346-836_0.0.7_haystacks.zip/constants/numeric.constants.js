"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.c179 = exports.c178 = exports.c177 = exports.c176 = exports.c175 = exports.c174 = exports.c173 = exports.c172 = exports.c171 = exports.c170 = exports.c17 = exports.c169 = exports.c168 = exports.c167 = exports.c166 = exports.c165 = exports.c164 = exports.c163 = exports.c162 = exports.c161 = exports.c160 = exports.c16 = exports.c159 = exports.c158 = exports.c157 = exports.c156 = exports.c155 = exports.c154 = exports.c153 = exports.c152 = exports.c151 = exports.c150 = exports.c15 = exports.c149 = exports.c148 = exports.c147 = exports.c146 = exports.c145 = exports.c144 = exports.c143 = exports.c142 = exports.c141 = exports.c140 = exports.c14 = exports.c139 = exports.c138 = exports.c137 = exports.c136 = exports.c135 = exports.c134 = exports.c133 = exports.c132 = exports.c131 = exports.c130 = exports.c13 = exports.c129 = exports.c128 = exports.c127 = exports.c126 = exports.c125 = exports.c124 = exports.c123 = exports.c122 = exports.c121 = exports.c120 = exports.c12 = exports.c119 = exports.c118 = exports.c117 = exports.c116 = exports.c115 = exports.c114 = exports.c113 = exports.c112 = exports.c111 = exports.c110 = exports.c11 = exports.c109 = exports.c108 = exports.c107 = exports.c106 = exports.c105 = exports.c104 = exports.c103 = exports.c102 = exports.c101 = exports.c100 = exports.c10 = exports.c1 = exports.c09 = exports.c08 = exports.c07 = exports.c06 = exports.c05 = exports.c04 = exports.c03 = exports.c02 = exports.c01 = exports.c00 = exports.c0 = void 0;
exports.c269 = exports.c268 = exports.c267 = exports.c266 = exports.c265 = exports.c264 = exports.c263 = exports.c262 = exports.c261 = exports.c260 = exports.c26 = exports.c259 = exports.c258 = exports.c257 = exports.c256 = exports.c255 = exports.c254 = exports.c253 = exports.c252 = exports.c251 = exports.c250 = exports.c25 = exports.c249 = exports.c248 = exports.c247 = exports.c246 = exports.c245 = exports.c244 = exports.c243 = exports.c242 = exports.c241 = exports.c240 = exports.c24 = exports.c239 = exports.c238 = exports.c237 = exports.c236 = exports.c235 = exports.c234 = exports.c233 = exports.c232 = exports.c231 = exports.c230 = exports.c23 = exports.c229 = exports.c228 = exports.c227 = exports.c226 = exports.c225 = exports.c224 = exports.c223 = exports.c222 = exports.c221 = exports.c220 = exports.c22 = exports.c219 = exports.c218 = exports.c217 = exports.c216 = exports.c215 = exports.c214 = exports.c213 = exports.c212 = exports.c211 = exports.c210 = exports.c21 = exports.c209 = exports.c208 = exports.c207 = exports.c206 = exports.c205 = exports.c204 = exports.c203 = exports.c202 = exports.c201 = exports.c200 = exports.c20 = exports.c2 = exports.c199 = exports.c198 = exports.c197 = exports.c196 = exports.c195 = exports.c194 = exports.c193 = exports.c192 = exports.c191 = exports.c190 = exports.c19 = exports.c189 = exports.c188 = exports.c187 = exports.c186 = exports.c185 = exports.c184 = exports.c183 = exports.c182 = exports.c181 = exports.c180 = exports.c18 = void 0;
exports.c359 = exports.c358 = exports.c357 = exports.c356 = exports.c355 = exports.c354 = exports.c353 = exports.c352 = exports.c351 = exports.c350 = exports.c35 = exports.c349 = exports.c348 = exports.c347 = exports.c346 = exports.c345 = exports.c344 = exports.c343 = exports.c342 = exports.c341 = exports.c340 = exports.c34 = exports.c339 = exports.c338 = exports.c337 = exports.c336 = exports.c335 = exports.c334 = exports.c333 = exports.c332 = exports.c331 = exports.c330 = exports.c33 = exports.c329 = exports.c328 = exports.c327 = exports.c326 = exports.c325 = exports.c324 = exports.c323 = exports.c322 = exports.c321 = exports.c320 = exports.c32 = exports.c319 = exports.c318 = exports.c317 = exports.c316 = exports.c315 = exports.c314 = exports.c313 = exports.c312 = exports.c311 = exports.c310 = exports.c31 = exports.c309 = exports.c308 = exports.c307 = exports.c306 = exports.c305 = exports.c304 = exports.c303 = exports.c302 = exports.c301 = exports.c300 = exports.c30 = exports.c3 = exports.c299 = exports.c298 = exports.c297 = exports.c296 = exports.c295 = exports.c294 = exports.c293 = exports.c292 = exports.c291 = exports.c290 = exports.c29 = exports.c289 = exports.c288 = exports.c287 = exports.c286 = exports.c285 = exports.c284 = exports.c283 = exports.c282 = exports.c281 = exports.c280 = exports.c28 = exports.c279 = exports.c278 = exports.c277 = exports.c276 = exports.c275 = exports.c274 = exports.c273 = exports.c272 = exports.c271 = exports.c270 = exports.c27 = void 0;
exports.c449 = exports.c448 = exports.c447 = exports.c446 = exports.c445 = exports.c444 = exports.c443 = exports.c442 = exports.c441 = exports.c440 = exports.c44 = exports.c439 = exports.c438 = exports.c437 = exports.c436 = exports.c435 = exports.c434 = exports.c433 = exports.c432 = exports.c431 = exports.c430 = exports.c43 = exports.c429 = exports.c428 = exports.c427 = exports.c426 = exports.c425 = exports.c424 = exports.c423 = exports.c422 = exports.c421 = exports.c420 = exports.c42 = exports.c419 = exports.c418 = exports.c417 = exports.c416 = exports.c415 = exports.c414 = exports.c413 = exports.c412 = exports.c411 = exports.c410 = exports.c41 = exports.c409 = exports.c408 = exports.c407 = exports.c406 = exports.c405 = exports.c404 = exports.c403 = exports.c402 = exports.c401 = exports.c400 = exports.c40 = exports.c4 = exports.c399 = exports.c398 = exports.c397 = exports.c396 = exports.c395 = exports.c394 = exports.c393 = exports.c392 = exports.c391 = exports.c390 = exports.c39 = exports.c389 = exports.c388 = exports.c387 = exports.c386 = exports.c385 = exports.c384 = exports.c383 = exports.c382 = exports.c381 = exports.c380 = exports.c38 = exports.c379 = exports.c378 = exports.c377 = exports.c376 = exports.c375 = exports.c374 = exports.c373 = exports.c372 = exports.c371 = exports.c370 = exports.c37 = exports.c369 = exports.c368 = exports.c367 = exports.c366 = exports.c365 = exports.c364 = exports.c363 = exports.c362 = exports.c361 = exports.c360 = exports.c36 = void 0;
exports.c539 = exports.c538 = exports.c537 = exports.c536 = exports.c535 = exports.c534 = exports.c533 = exports.c532 = exports.c531 = exports.c530 = exports.c53 = exports.c529 = exports.c528 = exports.c527 = exports.c526 = exports.c525 = exports.c524 = exports.c523 = exports.c522 = exports.c521 = exports.c520 = exports.c52 = exports.c519 = exports.c518 = exports.c517 = exports.c516 = exports.c515 = exports.c514 = exports.c513 = exports.c512 = exports.c511 = exports.c510 = exports.c51 = exports.c509 = exports.c508 = exports.c507 = exports.c506 = exports.c505 = exports.c504 = exports.c503 = exports.c502 = exports.c501 = exports.c500 = exports.c50 = exports.c5 = exports.c499 = exports.c498 = exports.c497 = exports.c496 = exports.c495 = exports.c494 = exports.c493 = exports.c492 = exports.c491 = exports.c490 = exports.c49 = exports.c489 = exports.c488 = exports.c487 = exports.c486 = exports.c485 = exports.c484 = exports.c483 = exports.c482 = exports.c481 = exports.c480 = exports.c48 = exports.c479 = exports.c478 = exports.c477 = exports.c476 = exports.c475 = exports.c474 = exports.c473 = exports.c472 = exports.c471 = exports.c470 = exports.c47 = exports.c469 = exports.c468 = exports.c467 = exports.c466 = exports.c465 = exports.c464 = exports.c463 = exports.c462 = exports.c461 = exports.c460 = exports.c46 = exports.c459 = exports.c458 = exports.c457 = exports.c456 = exports.c455 = exports.c454 = exports.c453 = exports.c452 = exports.c451 = exports.c450 = exports.c45 = void 0;
exports.c629 = exports.c628 = exports.c627 = exports.c626 = exports.c625 = exports.c624 = exports.c623 = exports.c622 = exports.c621 = exports.c620 = exports.c62 = exports.c619 = exports.c618 = exports.c617 = exports.c616 = exports.c615 = exports.c614 = exports.c613 = exports.c612 = exports.c611 = exports.c610 = exports.c61 = exports.c609 = exports.c608 = exports.c607 = exports.c606 = exports.c605 = exports.c604 = exports.c603 = exports.c602 = exports.c601 = exports.c600 = exports.c60 = exports.c6 = exports.c599 = exports.c598 = exports.c597 = exports.c596 = exports.c595 = exports.c594 = exports.c593 = exports.c592 = exports.c591 = exports.c590 = exports.c59 = exports.c589 = exports.c588 = exports.c587 = exports.c586 = exports.c585 = exports.c584 = exports.c583 = exports.c582 = exports.c581 = exports.c580 = exports.c58 = exports.c579 = exports.c578 = exports.c577 = exports.c576 = exports.c575 = exports.c574 = exports.c573 = exports.c572 = exports.c571 = exports.c570 = exports.c57 = exports.c569 = exports.c568 = exports.c567 = exports.c566 = exports.c565 = exports.c564 = exports.c563 = exports.c562 = exports.c561 = exports.c560 = exports.c56 = exports.c559 = exports.c558 = exports.c557 = exports.c556 = exports.c555 = exports.c554 = exports.c553 = exports.c552 = exports.c551 = exports.c550 = exports.c55 = exports.c549 = exports.c548 = exports.c547 = exports.c546 = exports.c545 = exports.c544 = exports.c543 = exports.c542 = exports.c541 = exports.c540 = exports.c54 = void 0;
exports.c719 = exports.c718 = exports.c717 = exports.c716 = exports.c715 = exports.c714 = exports.c713 = exports.c712 = exports.c711 = exports.c710 = exports.c71 = exports.c709 = exports.c708 = exports.c707 = exports.c706 = exports.c705 = exports.c704 = exports.c703 = exports.c702 = exports.c701 = exports.c700 = exports.c70 = exports.c7 = exports.c699 = exports.c698 = exports.c697 = exports.c696 = exports.c695 = exports.c694 = exports.c693 = exports.c692 = exports.c691 = exports.c690 = exports.c69 = exports.c689 = exports.c688 = exports.c687 = exports.c686 = exports.c685 = exports.c684 = exports.c683 = exports.c682 = exports.c681 = exports.c680 = exports.c68 = exports.c679 = exports.c678 = exports.c677 = exports.c676 = exports.c675 = exports.c674 = exports.c673 = exports.c672 = exports.c671 = exports.c670 = exports.c67 = exports.c669 = exports.c668 = exports.c667 = exports.c666 = exports.c665 = exports.c664 = exports.c663 = exports.c662 = exports.c661 = exports.c660 = exports.c66 = exports.c659 = exports.c658 = exports.c657 = exports.c656 = exports.c655 = exports.c654 = exports.c653 = exports.c652 = exports.c651 = exports.c650 = exports.c65 = exports.c649 = exports.c648 = exports.c647 = exports.c646 = exports.c645 = exports.c644 = exports.c643 = exports.c642 = exports.c641 = exports.c640 = exports.c64 = exports.c639 = exports.c638 = exports.c637 = exports.c636 = exports.c635 = exports.c634 = exports.c633 = exports.c632 = exports.c631 = exports.c630 = exports.c63 = void 0;
exports.c809 = exports.c808 = exports.c807 = exports.c806 = exports.c805 = exports.c804 = exports.c803 = exports.c802 = exports.c801 = exports.c800 = exports.c80 = exports.c8 = exports.c799 = exports.c798 = exports.c797 = exports.c796 = exports.c795 = exports.c794 = exports.c793 = exports.c792 = exports.c791 = exports.c790 = exports.c79 = exports.c789 = exports.c788 = exports.c787 = exports.c786 = exports.c785 = exports.c784 = exports.c783 = exports.c782 = exports.c781 = exports.c780 = exports.c78 = exports.c779 = exports.c778 = exports.c777 = exports.c776 = exports.c775 = exports.c774 = exports.c773 = exports.c772 = exports.c771 = exports.c770 = exports.c77 = exports.c769 = exports.c768 = exports.c767 = exports.c766 = exports.c765 = exports.c764 = exports.c763 = exports.c762 = exports.c761 = exports.c760 = exports.c76 = exports.c759 = exports.c758 = exports.c757 = exports.c756 = exports.c755 = exports.c754 = exports.c753 = exports.c752 = exports.c751 = exports.c750 = exports.c75 = exports.c749 = exports.c748 = exports.c747 = exports.c746 = exports.c745 = exports.c744 = exports.c743 = exports.c742 = exports.c741 = exports.c740 = exports.c74 = exports.c739 = exports.c738 = exports.c737 = exports.c736 = exports.c735 = exports.c734 = exports.c733 = exports.c732 = exports.c731 = exports.c730 = exports.c73 = exports.c729 = exports.c728 = exports.c727 = exports.c726 = exports.c725 = exports.c724 = exports.c723 = exports.c722 = exports.c721 = exports.c720 = exports.c72 = void 0;
exports.c9 = exports.c899 = exports.c898 = exports.c897 = exports.c896 = exports.c895 = exports.c894 = exports.c893 = exports.c892 = exports.c891 = exports.c890 = exports.c89 = exports.c889 = exports.c888 = exports.c887 = exports.c886 = exports.c885 = exports.c884 = exports.c883 = exports.c882 = exports.c881 = exports.c880 = exports.c88 = exports.c879 = exports.c878 = exports.c877 = exports.c876 = exports.c875 = exports.c874 = exports.c873 = exports.c872 = exports.c871 = exports.c870 = exports.c87 = exports.c869 = exports.c868 = exports.c867 = exports.c866 = exports.c865 = exports.c864 = exports.c863 = exports.c862 = exports.c861 = exports.c860 = exports.c86 = exports.c859 = exports.c858 = exports.c857 = exports.c856 = exports.c855 = exports.c854 = exports.c853 = exports.c852 = exports.c851 = exports.c850 = exports.c85 = exports.c849 = exports.c848 = exports.c847 = exports.c846 = exports.c845 = exports.c844 = exports.c843 = exports.c842 = exports.c841 = exports.c840 = exports.c84 = exports.c839 = exports.c838 = exports.c837 = exports.c836 = exports.c835 = exports.c834 = exports.c833 = exports.c832 = exports.c831 = exports.c830 = exports.c83 = exports.c829 = exports.c828 = exports.c827 = exports.c826 = exports.c825 = exports.c824 = exports.c823 = exports.c822 = exports.c821 = exports.c820 = exports.c82 = exports.c819 = exports.c818 = exports.c817 = exports.c816 = exports.c815 = exports.c814 = exports.c813 = exports.c812 = exports.c811 = exports.c810 = exports.c81 = void 0;
exports.c99 = exports.c989 = exports.c988 = exports.c987 = exports.c986 = exports.c985 = exports.c984 = exports.c983 = exports.c982 = exports.c981 = exports.c980 = exports.c98 = exports.c979 = exports.c978 = exports.c977 = exports.c976 = exports.c975 = exports.c974 = exports.c973 = exports.c972 = exports.c971 = exports.c970 = exports.c97 = exports.c969 = exports.c968 = exports.c967 = exports.c966 = exports.c965 = exports.c964 = exports.c963 = exports.c962 = exports.c961 = exports.c960 = exports.c96 = exports.c959 = exports.c958 = exports.c957 = exports.c956 = exports.c955 = exports.c954 = exports.c953 = exports.c952 = exports.c951 = exports.c950 = exports.c95 = exports.c949 = exports.c948 = exports.c947 = exports.c946 = exports.c945 = exports.c944 = exports.c943 = exports.c942 = exports.c941 = exports.c940 = exports.c94 = exports.c939 = exports.c938 = exports.c937 = exports.c936 = exports.c935 = exports.c934 = exports.c933 = exports.c932 = exports.c931 = exports.c930 = exports.c93 = exports.c929 = exports.c928 = exports.c927 = exports.c926 = exports.c925 = exports.c924 = exports.c923 = exports.c922 = exports.c921 = exports.c920 = exports.c92 = exports.c919 = exports.c918 = exports.c917 = exports.c916 = exports.c915 = exports.c914 = exports.c913 = exports.c912 = exports.c911 = exports.c910 = exports.c91 = exports.c909 = exports.c908 = exports.c907 = exports.c906 = exports.c905 = exports.c904 = exports.c903 = exports.c902 = exports.c901 = exports.c900 = exports.c90 = void 0;
exports.cmillion = exports.chundredth = exports.chundred = exports.cfourty = exports.cfourtieth = exports.cfourth = exports.cfourteenth = exports.cfourteen = exports.cfour = exports.cfive = exports.cfirst = exports.cfifty = exports.cfiftieth = exports.cfifth = exports.cfifteenth = exports.cfifteen = exports.celeventh = exports.celeven = exports.ceighty = exports.ceightieth = exports.ceighth = exports.ceighteenth = exports.ceighteen = exports.ceight = exports.cbillionth = exports.cbillion = exports.cZero = exports.cTwo = exports.cTwenty = exports.cTwentieth = exports.cTwelveth = exports.cTwelve = exports.cTrillionth = exports.cTrillion = exports.cThree = exports.cThousandth = exports.cThousand = exports.cThirty = exports.cThirtieth = exports.cThirteenth = exports.cThirteen = exports.cThird = exports.cTenth = exports.cTen = exports.cSixty = exports.cSixtieth = exports.cSixth = exports.cSixteenth = exports.cSixteen = exports.cSix = exports.cSeventy = exports.cSeventieth = exports.cSeventh = exports.cSeventeenth = exports.cSeventeen = exports.cSeven = exports.cSecond = exports.cOne = exports.cNinety = exports.cNinetieth = exports.cNineteenth = exports.cNineteen = exports.cNine = exports.cMillionth = exports.cMillion = exports.cHundredth = exports.cHundred = exports.cFourty = exports.cFourtieth = exports.cFourth = exports.cFourteenth = exports.cFourteen = exports.cFour = exports.cFive = exports.cFirst = exports.cFifty = exports.cFiftieth = exports.cFifth = exports.cFifteenth = exports.cFifteen = exports.cEleventh = exports.cEleven = exports.cEighty = exports.cEightieth = exports.cEighth = exports.cEighteenth = exports.cEighteen = exports.cEight = exports.cBillionth = exports.cBillion = exports.c999 = exports.c998 = exports.c997 = exports.c996 = exports.c995 = exports.c994 = exports.c993 = exports.c992 = exports.c991 = exports.c990 = void 0;
exports.czero = exports.ctwo = exports.ctwenty = exports.ctwentieth = exports.ctwelveth = exports.ctwelve = exports.ctrillionth = exports.ctrillion = exports.cthree = exports.cthousandth = exports.cthousand = exports.cthirty = exports.cthirtieth = exports.cthirteenth = exports.cthirteen = exports.cthird = exports.ctenth = exports.cten = exports.csixty = exports.csixtieth = exports.csixth = exports.csixteenth = exports.csixteen = exports.csix = exports.cseventy = exports.cseventieth = exports.cseventh = exports.cseventeenth = exports.cseventeen = exports.cseven = exports.csecond = exports.cone = exports.cninety = exports.cninetieth = exports.cnineteenth = exports.cnineteen = exports.cnine = exports.cmillionth = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var phn = _interopRequireWildcard(require("./phonic.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file numeric.constants.js
 * @module numeric-constants
 * @description Contains numeric string values and numeric strings
 * @requires module:basic.constants
 * @requires module:phonic.constants
 * @author Seth Hollingsead
 * @date 2020/07/19
 * @copyright Copyright © 2020-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// Numbers
var c0 = '0'; // 0

exports.c0 = c0;
var c1 = '1'; // 1

exports.c1 = c1;
var c2 = '2'; // 2

exports.c2 = c2;
var c3 = '3'; // 3

exports.c3 = c3;
var c4 = '4'; // 4

exports.c4 = c4;
var c5 = '5'; // 5

exports.c5 = c5;
var c6 = '6'; // 6

exports.c6 = c6;
var c7 = '7'; // 7

exports.c7 = c7;
var c8 = '8'; // 8

exports.c8 = c8;
var c9 = '9'; // 9

exports.c9 = c9;
var c00 = c0 + c0; // 00

exports.c00 = c00;
var c01 = c0 + c1; // 01

exports.c01 = c01;
var c02 = c0 + c2; // 02

exports.c02 = c02;
var c03 = c0 + c3; // 03

exports.c03 = c03;
var c04 = c0 + c4; // 04

exports.c04 = c04;
var c05 = c0 + c5; // 05

exports.c05 = c05;
var c06 = c0 + c6; // 06

exports.c06 = c06;
var c07 = c0 + c7; // 07

exports.c07 = c07;
var c08 = c0 + c8; // 08

exports.c08 = c08;
var c09 = c0 + c9; // 09

exports.c09 = c09;
var c10 = c1 + c0; // 10

exports.c10 = c10;
var c11 = c1 + c1; // 11

exports.c11 = c11;
var c12 = c1 + c2; // 12

exports.c12 = c12;
var c13 = c1 + c3; // 13

exports.c13 = c13;
var c14 = c1 + c4; // 14

exports.c14 = c14;
var c15 = c1 + c5; // 15

exports.c15 = c15;
var c16 = c1 + c6; // 16

exports.c16 = c16;
var c17 = c1 + c7; // 17

exports.c17 = c17;
var c18 = c1 + c8; // 18

exports.c18 = c18;
var c19 = c1 + c9; // 19

exports.c19 = c19;
var c20 = c2 + c0; // 20

exports.c20 = c20;
var c21 = c2 + c1; // 21

exports.c21 = c21;
var c22 = c2 + c2; // 22

exports.c22 = c22;
var c23 = c2 + c3; // 23

exports.c23 = c23;
var c24 = c2 + c4; // 24

exports.c24 = c24;
var c25 = c2 + c5; // 25

exports.c25 = c25;
var c26 = c2 + c6; // 26

exports.c26 = c26;
var c27 = c2 + c7; // 27

exports.c27 = c27;
var c28 = c2 + c8; // 28

exports.c28 = c28;
var c29 = c2 + c9; // 29

exports.c29 = c29;
var c30 = c3 + c0; // 30

exports.c30 = c30;
var c31 = c3 + c1; // 31

exports.c31 = c31;
var c32 = c3 + c2; // 32

exports.c32 = c32;
var c33 = c3 + c3; // 33

exports.c33 = c33;
var c34 = c3 + c4; // 34

exports.c34 = c34;
var c35 = c3 + c5; // 35

exports.c35 = c35;
var c36 = c3 + c6; // 36

exports.c36 = c36;
var c37 = c3 + c7; // 37

exports.c37 = c37;
var c38 = c3 + c8; // 38

exports.c38 = c38;
var c39 = c3 + c9; // 39

exports.c39 = c39;
var c40 = c4 + c0; // 40

exports.c40 = c40;
var c41 = c4 + c1; // 41

exports.c41 = c41;
var c42 = c4 + c2; // 42

exports.c42 = c42;
var c43 = c4 + c3; // 43

exports.c43 = c43;
var c44 = c4 + c4; // 44

exports.c44 = c44;
var c45 = c4 + c5; // 45

exports.c45 = c45;
var c46 = c4 + c6; // 46

exports.c46 = c46;
var c47 = c4 + c7; // 47

exports.c47 = c47;
var c48 = c4 + c8; // 48

exports.c48 = c48;
var c49 = c4 + c9; // 49

exports.c49 = c49;
var c50 = c5 + c0; // 50

exports.c50 = c50;
var c51 = c5 + c1; // 51

exports.c51 = c51;
var c52 = c5 + c2; // 52

exports.c52 = c52;
var c53 = c5 + c3; // 53

exports.c53 = c53;
var c54 = c5 + c4; // 54

exports.c54 = c54;
var c55 = c5 + c5; // 55

exports.c55 = c55;
var c56 = c5 + c6; // 56

exports.c56 = c56;
var c57 = c5 + c7; // 57

exports.c57 = c57;
var c58 = c5 + c8; // 58

exports.c58 = c58;
var c59 = c5 + c9; // 59

exports.c59 = c59;
var c60 = c6 + c0; // 60

exports.c60 = c60;
var c61 = c6 + c1; // 61

exports.c61 = c61;
var c62 = c6 + c2; // 62

exports.c62 = c62;
var c63 = c6 + c3; // 63

exports.c63 = c63;
var c64 = c6 + c4; // 64

exports.c64 = c64;
var c65 = c6 + c5; // 65

exports.c65 = c65;
var c66 = c6 + c6; // 66

exports.c66 = c66;
var c67 = c6 + c7; // 67

exports.c67 = c67;
var c68 = c6 + c8; // 68

exports.c68 = c68;
var c69 = c6 + c9; // 69

exports.c69 = c69;
var c70 = c7 + c0; // 70

exports.c70 = c70;
var c71 = c7 + c1; // 71

exports.c71 = c71;
var c72 = c7 + c2; // 72

exports.c72 = c72;
var c73 = c7 + c3; // 73

exports.c73 = c73;
var c74 = c7 + c4; // 74

exports.c74 = c74;
var c75 = c7 + c5; // 75

exports.c75 = c75;
var c76 = c7 + c6; // 76

exports.c76 = c76;
var c77 = c7 + c7; // 77

exports.c77 = c77;
var c78 = c7 + c8; // 78

exports.c78 = c78;
var c79 = c7 + c9; // 79

exports.c79 = c79;
var c80 = c8 + c0; // 80

exports.c80 = c80;
var c81 = c8 + c1; // 81

exports.c81 = c81;
var c82 = c8 + c2; // 82

exports.c82 = c82;
var c83 = c8 + c3; // 83

exports.c83 = c83;
var c84 = c8 + c4; // 84

exports.c84 = c84;
var c85 = c8 + c5; // 85

exports.c85 = c85;
var c86 = c8 + c6; // 86

exports.c86 = c86;
var c87 = c8 + c7; // 87

exports.c87 = c87;
var c88 = c8 + c8; // 88

exports.c88 = c88;
var c89 = c8 + c9; // 89

exports.c89 = c89;
var c90 = c9 + c0; // 90

exports.c90 = c90;
var c91 = c9 + c1; // 91

exports.c91 = c91;
var c92 = c9 + c2; // 92

exports.c92 = c92;
var c93 = c9 + c3; // 93

exports.c93 = c93;
var c94 = c9 + c4; // 94

exports.c94 = c94;
var c95 = c9 + c5; // 95

exports.c95 = c95;
var c96 = c9 + c6; // 96

exports.c96 = c96;
var c97 = c9 + c7; // 97

exports.c97 = c97;
var c98 = c9 + c8; // 98

exports.c98 = c98;
var c99 = c9 + c9; // 99

exports.c99 = c99;
var c100 = c1 + c00; // 100

exports.c100 = c100;
var c101 = c1 + c01; // 101

exports.c101 = c101;
var c102 = c1 + c02; // 102

exports.c102 = c102;
var c103 = c1 + c03; // 103

exports.c103 = c103;
var c104 = c1 + c04; // 104

exports.c104 = c104;
var c105 = c1 + c05; // 105

exports.c105 = c105;
var c106 = c1 + c06; // 106

exports.c106 = c106;
var c107 = c1 + c07; // 107

exports.c107 = c107;
var c108 = c1 + c08; // 108

exports.c108 = c108;
var c109 = c1 + c09; // 109

exports.c109 = c109;
var c110 = c1 + c10; // 110

exports.c110 = c110;
var c111 = c1 + c11; // 111

exports.c111 = c111;
var c112 = c1 + c12; // 112

exports.c112 = c112;
var c113 = c1 + c13; // 113

exports.c113 = c113;
var c114 = c1 + c14; // 114

exports.c114 = c114;
var c115 = c1 + c15; // 115

exports.c115 = c115;
var c116 = c1 + c16; // 116

exports.c116 = c116;
var c117 = c1 + c17; // 117

exports.c117 = c117;
var c118 = c1 + c18; // 118

exports.c118 = c118;
var c119 = c1 + c19; // 119

exports.c119 = c119;
var c120 = c1 + c20; // 120

exports.c120 = c120;
var c121 = c1 + c21; // 121

exports.c121 = c121;
var c122 = c1 + c22; // 122

exports.c122 = c122;
var c123 = c1 + c23; // 123

exports.c123 = c123;
var c124 = c1 + c24; // 124

exports.c124 = c124;
var c125 = c1 + c25; // 125

exports.c125 = c125;
var c126 = c1 + c26; // 126

exports.c126 = c126;
var c127 = c1 + c27; // 127

exports.c127 = c127;
var c128 = c1 + c28; // 128

exports.c128 = c128;
var c129 = c1 + c29; // 129

exports.c129 = c129;
var c130 = c1 + c30; // 130

exports.c130 = c130;
var c131 = c1 + c31; // 131

exports.c131 = c131;
var c132 = c1 + c32; // 132

exports.c132 = c132;
var c133 = c1 + c33; // 133

exports.c133 = c133;
var c134 = c1 + c34; // 134

exports.c134 = c134;
var c135 = c1 + c35; // 135

exports.c135 = c135;
var c136 = c1 + c36; // 136

exports.c136 = c136;
var c137 = c1 + c37; // 137

exports.c137 = c137;
var c138 = c1 + c38; // 138

exports.c138 = c138;
var c139 = c1 + c39; // 139

exports.c139 = c139;
var c140 = c1 + c40; // 140

exports.c140 = c140;
var c141 = c1 + c41; // 141

exports.c141 = c141;
var c142 = c1 + c42; // 142

exports.c142 = c142;
var c143 = c1 + c43; // 143

exports.c143 = c143;
var c144 = c1 + c44; // 144

exports.c144 = c144;
var c145 = c1 + c45; // 145

exports.c145 = c145;
var c146 = c1 + c46; // 146

exports.c146 = c146;
var c147 = c1 + c47; // 147

exports.c147 = c147;
var c148 = c1 + c48; // 148

exports.c148 = c148;
var c149 = c1 + c49; // 149

exports.c149 = c149;
var c150 = c1 + c50; // 150

exports.c150 = c150;
var c151 = c1 + c51; // 151

exports.c151 = c151;
var c152 = c1 + c52; // 152

exports.c152 = c152;
var c153 = c1 + c53; // 153

exports.c153 = c153;
var c154 = c1 + c54; // 154

exports.c154 = c154;
var c155 = c1 + c55; // 155

exports.c155 = c155;
var c156 = c1 + c56; // 156

exports.c156 = c156;
var c157 = c1 + c57; // 157

exports.c157 = c157;
var c158 = c1 + c58; // 158

exports.c158 = c158;
var c159 = c1 + c59; // 159

exports.c159 = c159;
var c160 = c1 + c60; // 160

exports.c160 = c160;
var c161 = c1 + c61; // 161

exports.c161 = c161;
var c162 = c1 + c62; // 162

exports.c162 = c162;
var c163 = c1 + c63; // 163

exports.c163 = c163;
var c164 = c1 + c64; // 164

exports.c164 = c164;
var c165 = c1 + c65; // 165

exports.c165 = c165;
var c166 = c1 + c66; // 166

exports.c166 = c166;
var c167 = c1 + c67; // 167

exports.c167 = c167;
var c168 = c1 + c68; // 168

exports.c168 = c168;
var c169 = c1 + c69; // 169

exports.c169 = c169;
var c170 = c1 + c70; // 170

exports.c170 = c170;
var c171 = c1 + c71; // 171

exports.c171 = c171;
var c172 = c1 + c72; // 172

exports.c172 = c172;
var c173 = c1 + c73; // 173

exports.c173 = c173;
var c174 = c1 + c74; // 174

exports.c174 = c174;
var c175 = c1 + c75; // 175

exports.c175 = c175;
var c176 = c1 + c76; // 176

exports.c176 = c176;
var c177 = c1 + c77; // 177

exports.c177 = c177;
var c178 = c1 + c78; // 178

exports.c178 = c178;
var c179 = c1 + c79; // 179

exports.c179 = c179;
var c180 = c1 + c80; // 180

exports.c180 = c180;
var c181 = c1 + c81; // 181

exports.c181 = c181;
var c182 = c1 + c82; // 182

exports.c182 = c182;
var c183 = c1 + c83; // 183

exports.c183 = c183;
var c184 = c1 + c84; // 184

exports.c184 = c184;
var c185 = c1 + c85; // 185

exports.c185 = c185;
var c186 = c1 + c86; // 186

exports.c186 = c186;
var c187 = c1 + c87; // 187

exports.c187 = c187;
var c188 = c1 + c88; // 188

exports.c188 = c188;
var c189 = c1 + c89; // 189

exports.c189 = c189;
var c190 = c1 + c90; // 190

exports.c190 = c190;
var c191 = c1 + c91; // 191

exports.c191 = c191;
var c192 = c1 + c92; // 192

exports.c192 = c192;
var c193 = c1 + c93; // 193

exports.c193 = c193;
var c194 = c1 + c94; // 194

exports.c194 = c194;
var c195 = c1 + c95; // 195

exports.c195 = c195;
var c196 = c1 + c96; // 196

exports.c196 = c196;
var c197 = c1 + c97; // 197

exports.c197 = c197;
var c198 = c1 + c98; // 198

exports.c198 = c198;
var c199 = c1 + c99; // 199

exports.c199 = c199;
var c200 = c2 + c00; // 200

exports.c200 = c200;
var c201 = c2 + c01; // 201

exports.c201 = c201;
var c202 = c2 + c02; // 202

exports.c202 = c202;
var c203 = c2 + c03; // 203

exports.c203 = c203;
var c204 = c2 + c04; // 204

exports.c204 = c204;
var c205 = c2 + c05; // 205

exports.c205 = c205;
var c206 = c2 + c06; // 206

exports.c206 = c206;
var c207 = c2 + c07; // 207

exports.c207 = c207;
var c208 = c2 + c08; // 208

exports.c208 = c208;
var c209 = c2 + c09; // 209

exports.c209 = c209;
var c210 = c2 + c10; // 210

exports.c210 = c210;
var c211 = c2 + c11; // 211

exports.c211 = c211;
var c212 = c2 + c12; // 212

exports.c212 = c212;
var c213 = c2 + c13; // 213

exports.c213 = c213;
var c214 = c2 + c14; // 214

exports.c214 = c214;
var c215 = c2 + c15; // 215

exports.c215 = c215;
var c216 = c2 + c16; // 216

exports.c216 = c216;
var c217 = c2 + c17; // 217

exports.c217 = c217;
var c218 = c2 + c18; // 218

exports.c218 = c218;
var c219 = c2 + c19; // 219

exports.c219 = c219;
var c220 = c2 + c20; // 220

exports.c220 = c220;
var c221 = c2 + c21; // 221

exports.c221 = c221;
var c222 = c2 + c22; // 222

exports.c222 = c222;
var c223 = c2 + c23; // 223

exports.c223 = c223;
var c224 = c2 + c24; // 224

exports.c224 = c224;
var c225 = c2 + c25; // 225

exports.c225 = c225;
var c226 = c2 + c26; // 226

exports.c226 = c226;
var c227 = c2 + c27; // 227

exports.c227 = c227;
var c228 = c2 + c28; // 228

exports.c228 = c228;
var c229 = c2 + c29; // 229

exports.c229 = c229;
var c230 = c2 + c30; // 230

exports.c230 = c230;
var c231 = c2 + c31; // 231

exports.c231 = c231;
var c232 = c2 + c32; // 232

exports.c232 = c232;
var c233 = c2 + c33; // 233

exports.c233 = c233;
var c234 = c2 + c34; // 234

exports.c234 = c234;
var c235 = c2 + c35; // 235

exports.c235 = c235;
var c236 = c2 + c36; // 236

exports.c236 = c236;
var c237 = c2 + c37; // 237

exports.c237 = c237;
var c238 = c2 + c38; // 238

exports.c238 = c238;
var c239 = c2 + c39; // 239

exports.c239 = c239;
var c240 = c2 + c40; // 240

exports.c240 = c240;
var c241 = c2 + c41; // 241

exports.c241 = c241;
var c242 = c2 + c42; // 242

exports.c242 = c242;
var c243 = c2 + c43; // 243

exports.c243 = c243;
var c244 = c2 + c44; // 244

exports.c244 = c244;
var c245 = c2 + c45; // 245

exports.c245 = c245;
var c246 = c2 + c46; // 246

exports.c246 = c246;
var c247 = c2 + c47; // 247

exports.c247 = c247;
var c248 = c2 + c48; // 248

exports.c248 = c248;
var c249 = c2 + c49; // 249

exports.c249 = c249;
var c250 = c2 + c50; // 250

exports.c250 = c250;
var c251 = c2 + c51; // 251

exports.c251 = c251;
var c252 = c2 + c52; // 252

exports.c252 = c252;
var c253 = c2 + c53; // 253

exports.c253 = c253;
var c254 = c2 + c54; // 254

exports.c254 = c254;
var c255 = c2 + c55; // 255

exports.c255 = c255;
var c256 = c2 + c56; // 256

exports.c256 = c256;
var c257 = c2 + c57; // 257

exports.c257 = c257;
var c258 = c2 + c58; // 258

exports.c258 = c258;
var c259 = c2 + c59; // 259

exports.c259 = c259;
var c260 = c2 + c60; // 260

exports.c260 = c260;
var c261 = c2 + c61; // 261

exports.c261 = c261;
var c262 = c2 + c62; // 262

exports.c262 = c262;
var c263 = c2 + c63; // 263

exports.c263 = c263;
var c264 = c2 + c64; // 264

exports.c264 = c264;
var c265 = c2 + c65; // 265

exports.c265 = c265;
var c266 = c2 + c66; // 266

exports.c266 = c266;
var c267 = c2 + c67; // 267

exports.c267 = c267;
var c268 = c2 + c68; // 268

exports.c268 = c268;
var c269 = c2 + c69; // 269

exports.c269 = c269;
var c270 = c2 + c70; // 270

exports.c270 = c270;
var c271 = c2 + c71; // 271

exports.c271 = c271;
var c272 = c2 + c72; // 272

exports.c272 = c272;
var c273 = c2 + c73; // 273

exports.c273 = c273;
var c274 = c2 + c74; // 274

exports.c274 = c274;
var c275 = c2 + c75; // 275

exports.c275 = c275;
var c276 = c2 + c76; // 276

exports.c276 = c276;
var c277 = c2 + c77; // 277

exports.c277 = c277;
var c278 = c2 + c78; // 278

exports.c278 = c278;
var c279 = c2 + c79; // 279

exports.c279 = c279;
var c280 = c2 + c80; // 280

exports.c280 = c280;
var c281 = c2 + c81; // 281

exports.c281 = c281;
var c282 = c2 + c82; // 282

exports.c282 = c282;
var c283 = c2 + c83; // 283

exports.c283 = c283;
var c284 = c2 + c84; // 284

exports.c284 = c284;
var c285 = c2 + c85; // 285

exports.c285 = c285;
var c286 = c2 + c86; // 286

exports.c286 = c286;
var c287 = c2 + c87; // 287

exports.c287 = c287;
var c288 = c2 + c88; // 288

exports.c288 = c288;
var c289 = c2 + c89; // 289

exports.c289 = c289;
var c290 = c2 + c90; // 290

exports.c290 = c290;
var c291 = c2 + c91; // 291

exports.c291 = c291;
var c292 = c2 + c92; // 292

exports.c292 = c292;
var c293 = c2 + c93; // 293

exports.c293 = c293;
var c294 = c2 + c94; // 294

exports.c294 = c294;
var c295 = c2 + c95; // 295

exports.c295 = c295;
var c296 = c2 + c96; // 296

exports.c296 = c296;
var c297 = c2 + c97; // 297

exports.c297 = c297;
var c298 = c2 + c98; // 298

exports.c298 = c298;
var c299 = c2 + c99; // 299

exports.c299 = c299;
var c300 = c3 + c00; // 300

exports.c300 = c300;
var c301 = c3 + c01; // 301

exports.c301 = c301;
var c302 = c3 + c02; // 302

exports.c302 = c302;
var c303 = c3 + c03; // 303

exports.c303 = c303;
var c304 = c3 + c04; // 304

exports.c304 = c304;
var c305 = c3 + c05; // 305

exports.c305 = c305;
var c306 = c3 + c06; // 306

exports.c306 = c306;
var c307 = c3 + c07; // 307

exports.c307 = c307;
var c308 = c3 + c08; // 308

exports.c308 = c308;
var c309 = c3 + c09; // 309

exports.c309 = c309;
var c310 = c3 + c10; // 310

exports.c310 = c310;
var c311 = c3 + c11; // 311

exports.c311 = c311;
var c312 = c3 + c12; // 312

exports.c312 = c312;
var c313 = c3 + c13; // 313

exports.c313 = c313;
var c314 = c3 + c14; // 314

exports.c314 = c314;
var c315 = c3 + c15; // 315

exports.c315 = c315;
var c316 = c3 + c16; // 316

exports.c316 = c316;
var c317 = c3 + c17; // 317

exports.c317 = c317;
var c318 = c3 + c18; // 318

exports.c318 = c318;
var c319 = c3 + c19; // 319

exports.c319 = c319;
var c320 = c3 + c20; // 320

exports.c320 = c320;
var c321 = c3 + c21; // 321

exports.c321 = c321;
var c322 = c3 + c22; // 322

exports.c322 = c322;
var c323 = c3 + c23; // 323

exports.c323 = c323;
var c324 = c3 + c24; // 324

exports.c324 = c324;
var c325 = c3 + c25; // 325

exports.c325 = c325;
var c326 = c3 + c26; // 326

exports.c326 = c326;
var c327 = c3 + c27; // 327

exports.c327 = c327;
var c328 = c3 + c28; // 328

exports.c328 = c328;
var c329 = c3 + c29; // 329

exports.c329 = c329;
var c330 = c3 + c30; // 330

exports.c330 = c330;
var c331 = c3 + c31; // 331

exports.c331 = c331;
var c332 = c3 + c32; // 332

exports.c332 = c332;
var c333 = c3 + c33; // 333

exports.c333 = c333;
var c334 = c3 + c34; // 334

exports.c334 = c334;
var c335 = c3 + c35; // 335

exports.c335 = c335;
var c336 = c3 + c36; // 336

exports.c336 = c336;
var c337 = c3 + c37; // 337

exports.c337 = c337;
var c338 = c3 + c38; // 338

exports.c338 = c338;
var c339 = c3 + c39; // 339

exports.c339 = c339;
var c340 = c3 + c40; // 340

exports.c340 = c340;
var c341 = c3 + c41; // 341

exports.c341 = c341;
var c342 = c3 + c42; // 342

exports.c342 = c342;
var c343 = c3 + c43; // 343

exports.c343 = c343;
var c344 = c3 + c44; // 344

exports.c344 = c344;
var c345 = c3 + c45; // 345

exports.c345 = c345;
var c346 = c3 + c46; // 346

exports.c346 = c346;
var c347 = c3 + c47; // 347

exports.c347 = c347;
var c348 = c3 + c48; // 348

exports.c348 = c348;
var c349 = c3 + c49; // 349

exports.c349 = c349;
var c350 = c3 + c50; // 350

exports.c350 = c350;
var c351 = c3 + c51; // 351

exports.c351 = c351;
var c352 = c3 + c52; // 352

exports.c352 = c352;
var c353 = c3 + c53; // 353

exports.c353 = c353;
var c354 = c3 + c54; // 354

exports.c354 = c354;
var c355 = c3 + c55; // 355

exports.c355 = c355;
var c356 = c3 + c56; // 356

exports.c356 = c356;
var c357 = c3 + c57; // 357

exports.c357 = c357;
var c358 = c3 + c58; // 358

exports.c358 = c358;
var c359 = c3 + c59; // 359

exports.c359 = c359;
var c360 = c3 + c60; // 360

exports.c360 = c360;
var c361 = c3 + c61; // 361

exports.c361 = c361;
var c362 = c3 + c62; // 362

exports.c362 = c362;
var c363 = c3 + c63; // 363

exports.c363 = c363;
var c364 = c3 + c64; // 364

exports.c364 = c364;
var c365 = c3 + c65; // 365

exports.c365 = c365;
var c366 = c3 + c66; // 366

exports.c366 = c366;
var c367 = c3 + c67; // 367

exports.c367 = c367;
var c368 = c3 + c68; // 368

exports.c368 = c368;
var c369 = c3 + c69; // 369

exports.c369 = c369;
var c370 = c3 + c70; // 370

exports.c370 = c370;
var c371 = c3 + c71; // 371

exports.c371 = c371;
var c372 = c3 + c72; // 372

exports.c372 = c372;
var c373 = c3 + c73; // 373

exports.c373 = c373;
var c374 = c3 + c74; // 374

exports.c374 = c374;
var c375 = c3 + c75; // 375

exports.c375 = c375;
var c376 = c3 + c76; // 376

exports.c376 = c376;
var c377 = c3 + c77; // 377

exports.c377 = c377;
var c378 = c3 + c78; // 378

exports.c378 = c378;
var c379 = c3 + c79; // 379

exports.c379 = c379;
var c380 = c3 + c80; // 380

exports.c380 = c380;
var c381 = c3 + c81; // 381

exports.c381 = c381;
var c382 = c3 + c82; // 382

exports.c382 = c382;
var c383 = c3 + c83; // 383

exports.c383 = c383;
var c384 = c3 + c84; // 384

exports.c384 = c384;
var c385 = c3 + c85; // 385

exports.c385 = c385;
var c386 = c3 + c86; // 386

exports.c386 = c386;
var c387 = c3 + c87; // 387

exports.c387 = c387;
var c388 = c3 + c88; // 388

exports.c388 = c388;
var c389 = c3 + c89; // 389

exports.c389 = c389;
var c390 = c3 + c90; // 390

exports.c390 = c390;
var c391 = c3 + c91; // 391

exports.c391 = c391;
var c392 = c3 + c92; // 392

exports.c392 = c392;
var c393 = c3 + c93; // 393

exports.c393 = c393;
var c394 = c3 + c94; // 394

exports.c394 = c394;
var c395 = c3 + c95; // 395

exports.c395 = c395;
var c396 = c3 + c96; // 396

exports.c396 = c396;
var c397 = c3 + c97; // 397

exports.c397 = c397;
var c398 = c3 + c98; // 398

exports.c398 = c398;
var c399 = c3 + c99; // 399

exports.c399 = c399;
var c400 = c4 + c00; // 400

exports.c400 = c400;
var c401 = c4 + c01; // 401

exports.c401 = c401;
var c402 = c4 + c02; // 402

exports.c402 = c402;
var c403 = c4 + c03; // 403

exports.c403 = c403;
var c404 = c4 + c04; // 404

exports.c404 = c404;
var c405 = c4 + c05; // 405

exports.c405 = c405;
var c406 = c4 + c06; // 406

exports.c406 = c406;
var c407 = c4 + c07; // 407

exports.c407 = c407;
var c408 = c4 + c08; // 408

exports.c408 = c408;
var c409 = c4 + c09; // 409

exports.c409 = c409;
var c410 = c4 + c10; // 410

exports.c410 = c410;
var c411 = c4 + c11; // 411

exports.c411 = c411;
var c412 = c4 + c12; // 412

exports.c412 = c412;
var c413 = c4 + c13; // 413

exports.c413 = c413;
var c414 = c4 + c14; // 414

exports.c414 = c414;
var c415 = c4 + c15; // 415

exports.c415 = c415;
var c416 = c4 + c16; // 416

exports.c416 = c416;
var c417 = c4 + c17; // 417

exports.c417 = c417;
var c418 = c4 + c18; // 418

exports.c418 = c418;
var c419 = c4 + c19; // 419

exports.c419 = c419;
var c420 = c4 + c20; // 420

exports.c420 = c420;
var c421 = c4 + c21; // 421

exports.c421 = c421;
var c422 = c4 + c22; // 422

exports.c422 = c422;
var c423 = c4 + c23; // 423

exports.c423 = c423;
var c424 = c4 + c24; // 424

exports.c424 = c424;
var c425 = c4 + c25; // 425

exports.c425 = c425;
var c426 = c4 + c26; // 426

exports.c426 = c426;
var c427 = c4 + c27; // 427

exports.c427 = c427;
var c428 = c4 + c28; // 428

exports.c428 = c428;
var c429 = c4 + c29; // 429

exports.c429 = c429;
var c430 = c4 + c30; // 430

exports.c430 = c430;
var c431 = c4 + c31; // 431

exports.c431 = c431;
var c432 = c4 + c32; // 432

exports.c432 = c432;
var c433 = c4 + c33; // 433

exports.c433 = c433;
var c434 = c4 + c34; // 434

exports.c434 = c434;
var c435 = c4 + c35; // 435

exports.c435 = c435;
var c436 = c4 + c36; // 436

exports.c436 = c436;
var c437 = c4 + c37; // 437

exports.c437 = c437;
var c438 = c4 + c38; // 438

exports.c438 = c438;
var c439 = c4 + c39; // 439

exports.c439 = c439;
var c440 = c4 + c40; // 440

exports.c440 = c440;
var c441 = c4 + c41; // 441

exports.c441 = c441;
var c442 = c4 + c42; // 442

exports.c442 = c442;
var c443 = c4 + c43; // 443

exports.c443 = c443;
var c444 = c4 + c44; // 444

exports.c444 = c444;
var c445 = c4 + c45; // 445

exports.c445 = c445;
var c446 = c4 + c46; // 446

exports.c446 = c446;
var c447 = c4 + c47; // 447

exports.c447 = c447;
var c448 = c4 + c48; // 448

exports.c448 = c448;
var c449 = c4 + c49; // 449

exports.c449 = c449;
var c450 = c4 + c50; // 450

exports.c450 = c450;
var c451 = c4 + c51; // 451

exports.c451 = c451;
var c452 = c4 + c52; // 452

exports.c452 = c452;
var c453 = c4 + c53; // 453

exports.c453 = c453;
var c454 = c4 + c54; // 454

exports.c454 = c454;
var c455 = c4 + c55; // 455

exports.c455 = c455;
var c456 = c4 + c56; // 456

exports.c456 = c456;
var c457 = c4 + c57; // 457

exports.c457 = c457;
var c458 = c4 + c58; // 458

exports.c458 = c458;
var c459 = c4 + c59; // 459

exports.c459 = c459;
var c460 = c4 + c60; // 460

exports.c460 = c460;
var c461 = c4 + c61; // 461

exports.c461 = c461;
var c462 = c4 + c62; // 462

exports.c462 = c462;
var c463 = c4 + c63; // 463

exports.c463 = c463;
var c464 = c4 + c64; // 464

exports.c464 = c464;
var c465 = c4 + c65; // 465

exports.c465 = c465;
var c466 = c4 + c66; // 466

exports.c466 = c466;
var c467 = c4 + c67; // 467

exports.c467 = c467;
var c468 = c4 + c68; // 468

exports.c468 = c468;
var c469 = c4 + c69; // 469

exports.c469 = c469;
var c470 = c4 + c70; // 470

exports.c470 = c470;
var c471 = c4 + c71; // 471

exports.c471 = c471;
var c472 = c4 + c72; // 472

exports.c472 = c472;
var c473 = c4 + c73; // 473

exports.c473 = c473;
var c474 = c4 + c74; // 474

exports.c474 = c474;
var c475 = c4 + c75; // 475

exports.c475 = c475;
var c476 = c4 + c76; // 476

exports.c476 = c476;
var c477 = c4 + c77; // 477

exports.c477 = c477;
var c478 = c4 + c78; // 478

exports.c478 = c478;
var c479 = c4 + c79; // 479

exports.c479 = c479;
var c480 = c4 + c80; // 480

exports.c480 = c480;
var c481 = c4 + c81; // 481

exports.c481 = c481;
var c482 = c4 + c82; // 482

exports.c482 = c482;
var c483 = c4 + c83; // 483

exports.c483 = c483;
var c484 = c4 + c84; // 484

exports.c484 = c484;
var c485 = c4 + c85; // 485

exports.c485 = c485;
var c486 = c4 + c86; // 486

exports.c486 = c486;
var c487 = c4 + c87; // 487

exports.c487 = c487;
var c488 = c4 + c88; // 488

exports.c488 = c488;
var c489 = c4 + c89; // 489

exports.c489 = c489;
var c490 = c4 + c90; // 490

exports.c490 = c490;
var c491 = c4 + c91; // 491

exports.c491 = c491;
var c492 = c4 + c92; // 492

exports.c492 = c492;
var c493 = c4 + c93; // 493

exports.c493 = c493;
var c494 = c4 + c94; // 494

exports.c494 = c494;
var c495 = c4 + c95; // 495

exports.c495 = c495;
var c496 = c4 + c96; // 496

exports.c496 = c496;
var c497 = c4 + c97; // 497

exports.c497 = c497;
var c498 = c4 + c98; // 498

exports.c498 = c498;
var c499 = c4 + c99; // 499

exports.c499 = c499;
var c500 = c5 + c00; // 500

exports.c500 = c500;
var c501 = c5 + c01; // 501

exports.c501 = c501;
var c502 = c5 + c02; // 502

exports.c502 = c502;
var c503 = c5 + c03; // 503

exports.c503 = c503;
var c504 = c5 + c04; // 504

exports.c504 = c504;
var c505 = c5 + c05; // 505

exports.c505 = c505;
var c506 = c5 + c06; // 506

exports.c506 = c506;
var c507 = c5 + c07; // 507

exports.c507 = c507;
var c508 = c5 + c08; // 508

exports.c508 = c508;
var c509 = c5 + c09; // 509

exports.c509 = c509;
var c510 = c5 + c10; // 510

exports.c510 = c510;
var c511 = c5 + c11; // 511

exports.c511 = c511;
var c512 = c5 + c12; // 512

exports.c512 = c512;
var c513 = c5 + c13; // 513

exports.c513 = c513;
var c514 = c5 + c14; // 514

exports.c514 = c514;
var c515 = c5 + c15; // 515

exports.c515 = c515;
var c516 = c5 + c16; // 516

exports.c516 = c516;
var c517 = c5 + c17; // 517

exports.c517 = c517;
var c518 = c5 + c18; // 518

exports.c518 = c518;
var c519 = c5 + c19; // 519

exports.c519 = c519;
var c520 = c5 + c20; // 520

exports.c520 = c520;
var c521 = c5 + c21; // 521

exports.c521 = c521;
var c522 = c5 + c22; // 522

exports.c522 = c522;
var c523 = c5 + c23; // 523

exports.c523 = c523;
var c524 = c5 + c24; // 524

exports.c524 = c524;
var c525 = c5 + c25; // 525

exports.c525 = c525;
var c526 = c5 + c26; // 526

exports.c526 = c526;
var c527 = c5 + c27; // 527

exports.c527 = c527;
var c528 = c5 + c28; // 528

exports.c528 = c528;
var c529 = c5 + c29; // 529

exports.c529 = c529;
var c530 = c5 + c30; // 530

exports.c530 = c530;
var c531 = c5 + c31; // 531

exports.c531 = c531;
var c532 = c5 + c32; // 532

exports.c532 = c532;
var c533 = c5 + c33; // 533

exports.c533 = c533;
var c534 = c5 + c34; // 534

exports.c534 = c534;
var c535 = c5 + c35; // 535

exports.c535 = c535;
var c536 = c5 + c36; // 536

exports.c536 = c536;
var c537 = c5 + c37; // 537

exports.c537 = c537;
var c538 = c5 + c38; // 538

exports.c538 = c538;
var c539 = c5 + c39; // 539

exports.c539 = c539;
var c540 = c5 + c40; // 540

exports.c540 = c540;
var c541 = c5 + c41; // 541

exports.c541 = c541;
var c542 = c5 + c42; // 542

exports.c542 = c542;
var c543 = c5 + c43; // 543

exports.c543 = c543;
var c544 = c5 + c44; // 544

exports.c544 = c544;
var c545 = c5 + c45; // 545

exports.c545 = c545;
var c546 = c5 + c46; // 546

exports.c546 = c546;
var c547 = c5 + c47; // 547

exports.c547 = c547;
var c548 = c5 + c48; // 548

exports.c548 = c548;
var c549 = c5 + c49; // 549

exports.c549 = c549;
var c550 = c5 + c50; // 550

exports.c550 = c550;
var c551 = c5 + c51; // 551

exports.c551 = c551;
var c552 = c5 + c52; // 552

exports.c552 = c552;
var c553 = c5 + c53; // 553

exports.c553 = c553;
var c554 = c5 + c54; // 554

exports.c554 = c554;
var c555 = c5 + c55; // 555

exports.c555 = c555;
var c556 = c5 + c56; // 556

exports.c556 = c556;
var c557 = c5 + c57; // 557

exports.c557 = c557;
var c558 = c5 + c58; // 558

exports.c558 = c558;
var c559 = c5 + c59; // 559

exports.c559 = c559;
var c560 = c5 + c60; // 560

exports.c560 = c560;
var c561 = c5 + c61; // 561

exports.c561 = c561;
var c562 = c5 + c62; // 562

exports.c562 = c562;
var c563 = c5 + c63; // 563

exports.c563 = c563;
var c564 = c5 + c64; // 564

exports.c564 = c564;
var c565 = c5 + c65; // 565

exports.c565 = c565;
var c566 = c5 + c66; // 566

exports.c566 = c566;
var c567 = c5 + c67; // 567

exports.c567 = c567;
var c568 = c5 + c68; // 568

exports.c568 = c568;
var c569 = c5 + c69; // 569

exports.c569 = c569;
var c570 = c5 + c70; // 570

exports.c570 = c570;
var c571 = c5 + c71; // 571

exports.c571 = c571;
var c572 = c5 + c72; // 572

exports.c572 = c572;
var c573 = c5 + c73; // 573

exports.c573 = c573;
var c574 = c5 + c74; // 574

exports.c574 = c574;
var c575 = c5 + c75; // 575

exports.c575 = c575;
var c576 = c5 + c76; // 576

exports.c576 = c576;
var c577 = c5 + c77; // 577

exports.c577 = c577;
var c578 = c5 + c78; // 578

exports.c578 = c578;
var c579 = c5 + c79; // 579

exports.c579 = c579;
var c580 = c5 + c80; // 580

exports.c580 = c580;
var c581 = c5 + c81; // 581

exports.c581 = c581;
var c582 = c5 + c82; // 582

exports.c582 = c582;
var c583 = c5 + c83; // 583

exports.c583 = c583;
var c584 = c5 + c84; // 584

exports.c584 = c584;
var c585 = c5 + c85; // 585

exports.c585 = c585;
var c586 = c5 + c86; // 586

exports.c586 = c586;
var c587 = c5 + c87; // 587

exports.c587 = c587;
var c588 = c5 + c88; // 588

exports.c588 = c588;
var c589 = c5 + c89; // 589

exports.c589 = c589;
var c590 = c5 + c90; // 590

exports.c590 = c590;
var c591 = c5 + c91; // 591

exports.c591 = c591;
var c592 = c5 + c92; // 592

exports.c592 = c592;
var c593 = c5 + c93; // 593

exports.c593 = c593;
var c594 = c5 + c94; // 594

exports.c594 = c594;
var c595 = c5 + c95; // 595

exports.c595 = c595;
var c596 = c5 + c96; // 596

exports.c596 = c596;
var c597 = c5 + c97; // 597

exports.c597 = c597;
var c598 = c5 + c98; // 598

exports.c598 = c598;
var c599 = c5 + c99; // 599

exports.c599 = c599;
var c600 = c6 + c00; // 600

exports.c600 = c600;
var c601 = c6 + c01; // 601

exports.c601 = c601;
var c602 = c6 + c02; // 602

exports.c602 = c602;
var c603 = c6 + c03; // 603

exports.c603 = c603;
var c604 = c6 + c04; // 604

exports.c604 = c604;
var c605 = c6 + c05; // 605

exports.c605 = c605;
var c606 = c6 + c06; // 606

exports.c606 = c606;
var c607 = c6 + c07; // 607

exports.c607 = c607;
var c608 = c6 + c08; // 608

exports.c608 = c608;
var c609 = c6 + c09; // 609

exports.c609 = c609;
var c610 = c6 + c10; // 610

exports.c610 = c610;
var c611 = c6 + c11; // 611

exports.c611 = c611;
var c612 = c6 + c12; // 612

exports.c612 = c612;
var c613 = c6 + c13; // 613

exports.c613 = c613;
var c614 = c6 + c14; // 614

exports.c614 = c614;
var c615 = c6 + c15; // 615

exports.c615 = c615;
var c616 = c6 + c16; // 616

exports.c616 = c616;
var c617 = c6 + c17; // 617

exports.c617 = c617;
var c618 = c6 + c18; // 618

exports.c618 = c618;
var c619 = c6 + c19; // 619

exports.c619 = c619;
var c620 = c6 + c20; // 620

exports.c620 = c620;
var c621 = c6 + c21; // 621

exports.c621 = c621;
var c622 = c6 + c22; // 622

exports.c622 = c622;
var c623 = c6 + c23; // 623

exports.c623 = c623;
var c624 = c6 + c24; // 624

exports.c624 = c624;
var c625 = c6 + c25; // 625

exports.c625 = c625;
var c626 = c6 + c26; // 626

exports.c626 = c626;
var c627 = c6 + c27; // 627

exports.c627 = c627;
var c628 = c6 + c28; // 628

exports.c628 = c628;
var c629 = c6 + c29; // 629

exports.c629 = c629;
var c630 = c6 + c30; // 630

exports.c630 = c630;
var c631 = c6 + c31; // 631

exports.c631 = c631;
var c632 = c6 + c32; // 632

exports.c632 = c632;
var c633 = c6 + c33; // 633

exports.c633 = c633;
var c634 = c6 + c34; // 634

exports.c634 = c634;
var c635 = c6 + c35; // 635

exports.c635 = c635;
var c636 = c6 + c36; // 636

exports.c636 = c636;
var c637 = c6 + c37; // 637

exports.c637 = c637;
var c638 = c6 + c38; // 638

exports.c638 = c638;
var c639 = c6 + c39; // 639

exports.c639 = c639;
var c640 = c6 + c40; // 640

exports.c640 = c640;
var c641 = c6 + c41; // 641

exports.c641 = c641;
var c642 = c6 + c42; // 642

exports.c642 = c642;
var c643 = c6 + c43; // 643

exports.c643 = c643;
var c644 = c6 + c44; // 644

exports.c644 = c644;
var c645 = c6 + c45; // 645

exports.c645 = c645;
var c646 = c6 + c46; // 646

exports.c646 = c646;
var c647 = c6 + c47; // 647

exports.c647 = c647;
var c648 = c6 + c48; // 648

exports.c648 = c648;
var c649 = c6 + c49; // 649

exports.c649 = c649;
var c650 = c6 + c50; // 650

exports.c650 = c650;
var c651 = c6 + c51; // 651

exports.c651 = c651;
var c652 = c6 + c52; // 652

exports.c652 = c652;
var c653 = c6 + c53; // 653

exports.c653 = c653;
var c654 = c6 + c54; // 654

exports.c654 = c654;
var c655 = c6 + c55; // 655

exports.c655 = c655;
var c656 = c6 + c56; // 656

exports.c656 = c656;
var c657 = c6 + c57; // 657

exports.c657 = c657;
var c658 = c6 + c58; // 658

exports.c658 = c658;
var c659 = c6 + c59; // 659

exports.c659 = c659;
var c660 = c6 + c60; // 660

exports.c660 = c660;
var c661 = c6 + c61; // 661

exports.c661 = c661;
var c662 = c6 + c62; // 662

exports.c662 = c662;
var c663 = c6 + c63; // 663

exports.c663 = c663;
var c664 = c6 + c64; // 664

exports.c664 = c664;
var c665 = c6 + c65; // 665

exports.c665 = c665;
var c666 = c6 + c66; // 666

exports.c666 = c666;
var c667 = c6 + c67; // 667

exports.c667 = c667;
var c668 = c6 + c68; // 668

exports.c668 = c668;
var c669 = c6 + c69; // 669

exports.c669 = c669;
var c670 = c6 + c70; // 670

exports.c670 = c670;
var c671 = c6 + c71; // 671

exports.c671 = c671;
var c672 = c6 + c72; // 672

exports.c672 = c672;
var c673 = c6 + c73; // 673

exports.c673 = c673;
var c674 = c6 + c74; // 674

exports.c674 = c674;
var c675 = c6 + c75; // 675

exports.c675 = c675;
var c676 = c6 + c76; // 676

exports.c676 = c676;
var c677 = c6 + c77; // 677

exports.c677 = c677;
var c678 = c6 + c78; // 678

exports.c678 = c678;
var c679 = c6 + c79; // 679

exports.c679 = c679;
var c680 = c6 + c80; // 680

exports.c680 = c680;
var c681 = c6 + c81; // 681

exports.c681 = c681;
var c682 = c6 + c82; // 682

exports.c682 = c682;
var c683 = c6 + c83; // 683

exports.c683 = c683;
var c684 = c6 + c84; // 684

exports.c684 = c684;
var c685 = c6 + c85; // 685

exports.c685 = c685;
var c686 = c6 + c86; // 686

exports.c686 = c686;
var c687 = c6 + c87; // 687

exports.c687 = c687;
var c688 = c6 + c88; // 688

exports.c688 = c688;
var c689 = c6 + c89; // 689

exports.c689 = c689;
var c690 = c6 + c90; // 690

exports.c690 = c690;
var c691 = c6 + c91; // 691

exports.c691 = c691;
var c692 = c6 + c92; // 692

exports.c692 = c692;
var c693 = c6 + c93; // 693

exports.c693 = c693;
var c694 = c6 + c94; // 694

exports.c694 = c694;
var c695 = c6 + c95; // 695

exports.c695 = c695;
var c696 = c6 + c96; // 696

exports.c696 = c696;
var c697 = c6 + c97; // 697

exports.c697 = c697;
var c698 = c6 + c98; // 698

exports.c698 = c698;
var c699 = c6 + c99; // 699

exports.c699 = c699;
var c700 = c7 + c00; // 700

exports.c700 = c700;
var c701 = c7 + c01; // 701

exports.c701 = c701;
var c702 = c7 + c02; // 702

exports.c702 = c702;
var c703 = c7 + c03; // 703

exports.c703 = c703;
var c704 = c7 + c04; // 704

exports.c704 = c704;
var c705 = c7 + c05; // 705

exports.c705 = c705;
var c706 = c7 + c06; // 706

exports.c706 = c706;
var c707 = c7 + c07; // 707

exports.c707 = c707;
var c708 = c7 + c08; // 708

exports.c708 = c708;
var c709 = c7 + c09; // 709

exports.c709 = c709;
var c710 = c7 + c10; // 710

exports.c710 = c710;
var c711 = c7 + c11; // 711

exports.c711 = c711;
var c712 = c7 + c12; // 712

exports.c712 = c712;
var c713 = c7 + c13; // 713

exports.c713 = c713;
var c714 = c7 + c14; // 714

exports.c714 = c714;
var c715 = c7 + c15; // 715

exports.c715 = c715;
var c716 = c7 + c16; // 716

exports.c716 = c716;
var c717 = c7 + c17; // 717

exports.c717 = c717;
var c718 = c7 + c18; // 718

exports.c718 = c718;
var c719 = c7 + c19; // 719

exports.c719 = c719;
var c720 = c7 + c20; // 720

exports.c720 = c720;
var c721 = c7 + c21; // 721

exports.c721 = c721;
var c722 = c7 + c22; // 722

exports.c722 = c722;
var c723 = c7 + c23; // 723

exports.c723 = c723;
var c724 = c7 + c24; // 724

exports.c724 = c724;
var c725 = c7 + c25; // 725

exports.c725 = c725;
var c726 = c7 + c26; // 726

exports.c726 = c726;
var c727 = c7 + c27; // 727

exports.c727 = c727;
var c728 = c7 + c28; // 728

exports.c728 = c728;
var c729 = c7 + c29; // 729

exports.c729 = c729;
var c730 = c7 + c30; // 730

exports.c730 = c730;
var c731 = c7 + c31; // 731

exports.c731 = c731;
var c732 = c7 + c32; // 732

exports.c732 = c732;
var c733 = c7 + c33; // 733

exports.c733 = c733;
var c734 = c7 + c34; // 734

exports.c734 = c734;
var c735 = c7 + c35; // 735

exports.c735 = c735;
var c736 = c7 + c36; // 736

exports.c736 = c736;
var c737 = c7 + c37; // 737

exports.c737 = c737;
var c738 = c7 + c38; // 738

exports.c738 = c738;
var c739 = c7 + c39; // 739

exports.c739 = c739;
var c740 = c7 + c40; // 740

exports.c740 = c740;
var c741 = c7 + c41; // 741

exports.c741 = c741;
var c742 = c7 + c42; // 742

exports.c742 = c742;
var c743 = c7 + c43; // 743

exports.c743 = c743;
var c744 = c7 + c44; // 744

exports.c744 = c744;
var c745 = c7 + c45; // 745

exports.c745 = c745;
var c746 = c7 + c46; // 746

exports.c746 = c746;
var c747 = c7 + c47; // 747

exports.c747 = c747;
var c748 = c7 + c48; // 748

exports.c748 = c748;
var c749 = c7 + c49; // 749

exports.c749 = c749;
var c750 = c7 + c50; // 750

exports.c750 = c750;
var c751 = c7 + c51; // 751

exports.c751 = c751;
var c752 = c7 + c52; // 752

exports.c752 = c752;
var c753 = c7 + c53; // 753

exports.c753 = c753;
var c754 = c7 + c54; // 754

exports.c754 = c754;
var c755 = c7 + c55; // 755

exports.c755 = c755;
var c756 = c7 + c56; // 756

exports.c756 = c756;
var c757 = c7 + c57; // 757

exports.c757 = c757;
var c758 = c7 + c58; // 758

exports.c758 = c758;
var c759 = c7 + c59; // 759

exports.c759 = c759;
var c760 = c7 + c60; // 760

exports.c760 = c760;
var c761 = c7 + c61; // 761

exports.c761 = c761;
var c762 = c7 + c62; // 762

exports.c762 = c762;
var c763 = c7 + c63; // 763

exports.c763 = c763;
var c764 = c7 + c64; // 764

exports.c764 = c764;
var c765 = c7 + c65; // 765

exports.c765 = c765;
var c766 = c7 + c66; // 766

exports.c766 = c766;
var c767 = c7 + c67; // 767

exports.c767 = c767;
var c768 = c7 + c68; // 768

exports.c768 = c768;
var c769 = c7 + c69; // 769

exports.c769 = c769;
var c770 = c7 + c70; // 770

exports.c770 = c770;
var c771 = c7 + c71; // 771

exports.c771 = c771;
var c772 = c7 + c72; // 772

exports.c772 = c772;
var c773 = c7 + c73; // 773

exports.c773 = c773;
var c774 = c7 + c74; // 774

exports.c774 = c774;
var c775 = c7 + c75; // 775

exports.c775 = c775;
var c776 = c7 + c76; // 776

exports.c776 = c776;
var c777 = c7 + c77; // 777

exports.c777 = c777;
var c778 = c7 + c78; // 778

exports.c778 = c778;
var c779 = c7 + c79; // 779

exports.c779 = c779;
var c780 = c7 + c80; // 780

exports.c780 = c780;
var c781 = c7 + c81; // 781

exports.c781 = c781;
var c782 = c7 + c82; // 782

exports.c782 = c782;
var c783 = c7 + c83; // 783

exports.c783 = c783;
var c784 = c7 + c84; // 784

exports.c784 = c784;
var c785 = c7 + c85; // 785

exports.c785 = c785;
var c786 = c7 + c86; // 786

exports.c786 = c786;
var c787 = c7 + c87; // 787

exports.c787 = c787;
var c788 = c7 + c88; // 788

exports.c788 = c788;
var c789 = c7 + c89; // 789

exports.c789 = c789;
var c790 = c7 + c90; // 790

exports.c790 = c790;
var c791 = c7 + c91; // 791

exports.c791 = c791;
var c792 = c7 + c92; // 792

exports.c792 = c792;
var c793 = c7 + c93; // 793

exports.c793 = c793;
var c794 = c7 + c94; // 794

exports.c794 = c794;
var c795 = c7 + c95; // 795

exports.c795 = c795;
var c796 = c7 + c96; // 796

exports.c796 = c796;
var c797 = c7 + c97; // 797

exports.c797 = c797;
var c798 = c7 + c98; // 798

exports.c798 = c798;
var c799 = c7 + c99; // 799

exports.c799 = c799;
var c800 = c8 + c00; // 800

exports.c800 = c800;
var c801 = c8 + c01; // 801

exports.c801 = c801;
var c802 = c8 + c02; // 802

exports.c802 = c802;
var c803 = c8 + c03; // 803

exports.c803 = c803;
var c804 = c8 + c04; // 804

exports.c804 = c804;
var c805 = c8 + c05; // 805

exports.c805 = c805;
var c806 = c8 + c06; // 806

exports.c806 = c806;
var c807 = c8 + c07; // 807

exports.c807 = c807;
var c808 = c8 + c08; // 808

exports.c808 = c808;
var c809 = c8 + c09; // 809

exports.c809 = c809;
var c810 = c8 + c10; // 810

exports.c810 = c810;
var c811 = c8 + c11; // 811

exports.c811 = c811;
var c812 = c8 + c12; // 812

exports.c812 = c812;
var c813 = c8 + c13; // 813

exports.c813 = c813;
var c814 = c8 + c14; // 814

exports.c814 = c814;
var c815 = c8 + c15; // 815

exports.c815 = c815;
var c816 = c8 + c16; // 816

exports.c816 = c816;
var c817 = c8 + c17; // 817

exports.c817 = c817;
var c818 = c8 + c18; // 818

exports.c818 = c818;
var c819 = c8 + c19; // 819

exports.c819 = c819;
var c820 = c8 + c20; // 820

exports.c820 = c820;
var c821 = c8 + c21; // 821

exports.c821 = c821;
var c822 = c8 + c22; // 822

exports.c822 = c822;
var c823 = c8 + c23; // 823

exports.c823 = c823;
var c824 = c8 + c24; // 824

exports.c824 = c824;
var c825 = c8 + c25; // 825

exports.c825 = c825;
var c826 = c8 + c26; // 826

exports.c826 = c826;
var c827 = c8 + c27; // 827

exports.c827 = c827;
var c828 = c8 + c28; // 828

exports.c828 = c828;
var c829 = c8 + c29; // 829

exports.c829 = c829;
var c830 = c8 + c30; // 830

exports.c830 = c830;
var c831 = c8 + c31; // 831

exports.c831 = c831;
var c832 = c8 + c32; // 832

exports.c832 = c832;
var c833 = c8 + c33; // 833

exports.c833 = c833;
var c834 = c8 + c34; // 834

exports.c834 = c834;
var c835 = c8 + c35; // 835

exports.c835 = c835;
var c836 = c8 + c36; // 836

exports.c836 = c836;
var c837 = c8 + c37; // 837

exports.c837 = c837;
var c838 = c8 + c38; // 838

exports.c838 = c838;
var c839 = c8 + c39; // 839

exports.c839 = c839;
var c840 = c8 + c40; // 840

exports.c840 = c840;
var c841 = c8 + c41; // 841

exports.c841 = c841;
var c842 = c8 + c42; // 842

exports.c842 = c842;
var c843 = c8 + c43; // 843

exports.c843 = c843;
var c844 = c8 + c44; // 844

exports.c844 = c844;
var c845 = c8 + c45; // 845

exports.c845 = c845;
var c846 = c8 + c46; // 846

exports.c846 = c846;
var c847 = c8 + c47; // 847

exports.c847 = c847;
var c848 = c8 + c48; // 848

exports.c848 = c848;
var c849 = c8 + c49; // 849

exports.c849 = c849;
var c850 = c8 + c50; // 850

exports.c850 = c850;
var c851 = c8 + c51; // 851

exports.c851 = c851;
var c852 = c8 + c52; // 852

exports.c852 = c852;
var c853 = c8 + c53; // 853

exports.c853 = c853;
var c854 = c8 + c54; // 854

exports.c854 = c854;
var c855 = c8 + c55; // 855

exports.c855 = c855;
var c856 = c8 + c56; // 856

exports.c856 = c856;
var c857 = c8 + c57; // 857

exports.c857 = c857;
var c858 = c8 + c58; // 858

exports.c858 = c858;
var c859 = c8 + c59; // 859

exports.c859 = c859;
var c860 = c8 + c60; // 860

exports.c860 = c860;
var c861 = c8 + c61; // 861

exports.c861 = c861;
var c862 = c8 + c62; // 862

exports.c862 = c862;
var c863 = c8 + c63; // 863

exports.c863 = c863;
var c864 = c8 + c64; // 864

exports.c864 = c864;
var c865 = c8 + c65; // 865

exports.c865 = c865;
var c866 = c8 + c66; // 866

exports.c866 = c866;
var c867 = c8 + c67; // 867

exports.c867 = c867;
var c868 = c8 + c68; // 868

exports.c868 = c868;
var c869 = c8 + c69; // 869

exports.c869 = c869;
var c870 = c8 + c70; // 870

exports.c870 = c870;
var c871 = c8 + c71; // 871

exports.c871 = c871;
var c872 = c8 + c72; // 872

exports.c872 = c872;
var c873 = c8 + c73; // 873

exports.c873 = c873;
var c874 = c8 + c74; // 874

exports.c874 = c874;
var c875 = c8 + c75; // 875

exports.c875 = c875;
var c876 = c8 + c76; // 876

exports.c876 = c876;
var c877 = c8 + c77; // 877

exports.c877 = c877;
var c878 = c8 + c78; // 878

exports.c878 = c878;
var c879 = c8 + c79; // 879

exports.c879 = c879;
var c880 = c8 + c80; // 880

exports.c880 = c880;
var c881 = c8 + c81; // 881

exports.c881 = c881;
var c882 = c8 + c82; // 882

exports.c882 = c882;
var c883 = c8 + c83; // 883

exports.c883 = c883;
var c884 = c8 + c84; // 884

exports.c884 = c884;
var c885 = c8 + c85; // 885

exports.c885 = c885;
var c886 = c8 + c86; // 886

exports.c886 = c886;
var c887 = c8 + c87; // 887

exports.c887 = c887;
var c888 = c8 + c88; // 888

exports.c888 = c888;
var c889 = c8 + c89; // 889

exports.c889 = c889;
var c890 = c8 + c90; // 890

exports.c890 = c890;
var c891 = c8 + c91; // 891

exports.c891 = c891;
var c892 = c8 + c92; // 892

exports.c892 = c892;
var c893 = c8 + c93; // 893

exports.c893 = c893;
var c894 = c8 + c94; // 894

exports.c894 = c894;
var c895 = c8 + c95; // 895

exports.c895 = c895;
var c896 = c8 + c96; // 896

exports.c896 = c896;
var c897 = c8 + c97; // 897

exports.c897 = c897;
var c898 = c8 + c98; // 898

exports.c898 = c898;
var c899 = c8 + c99; // 899

exports.c899 = c899;
var c900 = c9 + c00; // 900

exports.c900 = c900;
var c901 = c9 + c01; // 901

exports.c901 = c901;
var c902 = c9 + c02; // 902

exports.c902 = c902;
var c903 = c9 + c03; // 903

exports.c903 = c903;
var c904 = c9 + c04; // 904

exports.c904 = c904;
var c905 = c9 + c05; // 905

exports.c905 = c905;
var c906 = c9 + c06; // 906

exports.c906 = c906;
var c907 = c9 + c07; // 907

exports.c907 = c907;
var c908 = c9 + c08; // 908

exports.c908 = c908;
var c909 = c9 + c09; // 909

exports.c909 = c909;
var c910 = c9 + c10; // 910

exports.c910 = c910;
var c911 = c9 + c11; // 911

exports.c911 = c911;
var c912 = c9 + c12; // 912

exports.c912 = c912;
var c913 = c9 + c13; // 913

exports.c913 = c913;
var c914 = c9 + c14; // 914

exports.c914 = c914;
var c915 = c9 + c15; // 915

exports.c915 = c915;
var c916 = c9 + c16; // 916

exports.c916 = c916;
var c917 = c9 + c17; // 917

exports.c917 = c917;
var c918 = c9 + c18; // 918

exports.c918 = c918;
var c919 = c9 + c19; // 919

exports.c919 = c919;
var c920 = c9 + c20; // 920

exports.c920 = c920;
var c921 = c9 + c21; // 921

exports.c921 = c921;
var c922 = c9 + c22; // 922

exports.c922 = c922;
var c923 = c9 + c23; // 923

exports.c923 = c923;
var c924 = c9 + c24; // 924

exports.c924 = c924;
var c925 = c9 + c25; // 925

exports.c925 = c925;
var c926 = c9 + c26; // 926

exports.c926 = c926;
var c927 = c9 + c27; // 927

exports.c927 = c927;
var c928 = c9 + c28; // 928

exports.c928 = c928;
var c929 = c9 + c29; // 929

exports.c929 = c929;
var c930 = c9 + c30; // 930

exports.c930 = c930;
var c931 = c9 + c31; // 931

exports.c931 = c931;
var c932 = c9 + c32; // 932

exports.c932 = c932;
var c933 = c9 + c33; // 933

exports.c933 = c933;
var c934 = c9 + c34; // 934

exports.c934 = c934;
var c935 = c9 + c35; // 935

exports.c935 = c935;
var c936 = c9 + c36; // 936

exports.c936 = c936;
var c937 = c9 + c37; // 937

exports.c937 = c937;
var c938 = c9 + c38; // 938

exports.c938 = c938;
var c939 = c9 + c39; // 939

exports.c939 = c939;
var c940 = c9 + c40; // 940

exports.c940 = c940;
var c941 = c9 + c41; // 941

exports.c941 = c941;
var c942 = c9 + c42; // 942

exports.c942 = c942;
var c943 = c9 + c43; // 943

exports.c943 = c943;
var c944 = c9 + c44; // 944

exports.c944 = c944;
var c945 = c9 + c45; // 945

exports.c945 = c945;
var c946 = c9 + c46; // 946

exports.c946 = c946;
var c947 = c9 + c47; // 947

exports.c947 = c947;
var c948 = c9 + c48; // 948

exports.c948 = c948;
var c949 = c9 + c49; // 949

exports.c949 = c949;
var c950 = c9 + c50; // 950

exports.c950 = c950;
var c951 = c9 + c51; // 951

exports.c951 = c951;
var c952 = c9 + c52; // 952

exports.c952 = c952;
var c953 = c9 + c53; // 953

exports.c953 = c953;
var c954 = c9 + c54; // 954

exports.c954 = c954;
var c955 = c9 + c55; // 955

exports.c955 = c955;
var c956 = c9 + c56; // 956

exports.c956 = c956;
var c957 = c9 + c57; // 957

exports.c957 = c957;
var c958 = c9 + c58; // 958

exports.c958 = c958;
var c959 = c9 + c59; // 959

exports.c959 = c959;
var c960 = c9 + c60; // 960

exports.c960 = c960;
var c961 = c9 + c61; // 961

exports.c961 = c961;
var c962 = c9 + c62; // 962

exports.c962 = c962;
var c963 = c9 + c63; // 963

exports.c963 = c963;
var c964 = c9 + c64; // 964

exports.c964 = c964;
var c965 = c9 + c65; // 965

exports.c965 = c965;
var c966 = c9 + c66; // 966

exports.c966 = c966;
var c967 = c9 + c67; // 967

exports.c967 = c967;
var c968 = c9 + c68; // 968

exports.c968 = c968;
var c969 = c9 + c69; // 969

exports.c969 = c969;
var c970 = c9 + c70; // 970

exports.c970 = c970;
var c971 = c9 + c71; // 971

exports.c971 = c971;
var c972 = c9 + c72; // 972

exports.c972 = c972;
var c973 = c9 + c73; // 973

exports.c973 = c973;
var c974 = c9 + c74; // 974

exports.c974 = c974;
var c975 = c9 + c75; // 975

exports.c975 = c975;
var c976 = c9 + c76; // 976

exports.c976 = c976;
var c977 = c9 + c77; // 977

exports.c977 = c977;
var c978 = c9 + c78; // 978

exports.c978 = c978;
var c979 = c9 + c79; // 979

exports.c979 = c979;
var c980 = c9 + c80; // 980

exports.c980 = c980;
var c981 = c9 + c81; // 981

exports.c981 = c981;
var c982 = c9 + c82; // 982

exports.c982 = c982;
var c983 = c9 + c83; // 983

exports.c983 = c983;
var c984 = c9 + c84; // 984

exports.c984 = c984;
var c985 = c9 + c85; // 985

exports.c985 = c985;
var c986 = c9 + c86; // 986

exports.c986 = c986;
var c987 = c9 + c87; // 987

exports.c987 = c987;
var c988 = c9 + c88; // 988

exports.c988 = c988;
var c989 = c9 + c89; // 989

exports.c989 = c989;
var c990 = c9 + c90; // 990

exports.c990 = c990;
var c991 = c9 + c91; // 991

exports.c991 = c991;
var c992 = c9 + c92; // 992

exports.c992 = c992;
var c993 = c9 + c93; // 993

exports.c993 = c993;
var c994 = c9 + c94; // 994

exports.c994 = c994;
var c995 = c9 + c95; // 995

exports.c995 = c995;
var c996 = c9 + c96; // 996

exports.c996 = c996;
var c997 = c9 + c97; // 997

exports.c997 = c997;
var c998 = c9 + c98; // 998

exports.c998 = c998;
var c999 = c9 + c99; // 999
// String Numbers

exports.c999 = c999;
var czero = bas.cze + bas.cro; // zero

exports.czero = czero;
var cZero = bas.cZe + bas.cro; // Zero

exports.cZero = cZero;
var cone = bas.co + bas.cne; // one

exports.cone = cone;
var ctwo = bas.ct + bas.cwo; // two

exports.ctwo = ctwo;
var cthree = bas.ct + phn.chree; // three

exports.cthree = cthree;
var cfour = bas.cf + phn.cour; // four

exports.cfour = cfour;
var cfive = bas.cf + phn.cive; // five

exports.cfive = cfive;
var csix = bas.cs + bas.cix; // six

exports.csix = csix;
var cseven = bas.cs + phn.ceven; // seven

exports.cseven = cseven;
var ceight = bas.ce + phn.cight; // eight

exports.ceight = ceight;
var cnine = bas.cn + phn.cine; // nine

exports.cnine = cnine;
var cten = bas.ct + bas.cen; // ten

exports.cten = cten;
var celeven = bas.ce + phn.cleven; // eleven

exports.celeven = celeven;
var ctwelve = bas.ct + phn.cwelve; // twelve

exports.ctwelve = ctwelve;
var cthirteen = bas.ct + phn.chir + phn.cteen; // thirteen

exports.cthirteen = cthirteen;
var cfourteen = cfour + phn.cteen; // fourteen

exports.cfourteen = cfourteen;
var cfifteen = bas.cf + bas.cif + phn.cteen; // fifteen

exports.cfifteen = cfifteen;
var csixteen = csix + phn.cteen; // sixteen

exports.csixteen = csixteen;
var cseventeen = cseven + phn.cteen; // seventeen

exports.cseventeen = cseventeen;
var ceighteen = bas.ce + phn.cigh + phn.cteen; // eighteen

exports.ceighteen = ceighteen;
var cnineteen = cnine + phn.cteen; // nineteen

exports.cnineteen = cnineteen;
var ctwenty = bas.ct + phn.cwenty; // twenty

exports.ctwenty = ctwenty;
var cthirty = bas.ct + phn.chirty; // thirty

exports.cthirty = cthirty;
var cfourty = cfour + bas.cty; // fourty

exports.cfourty = cfourty;
var cfifty = bas.cf + phn.cifty; // fifty

exports.cfifty = cfifty;
var csixty = csix + bas.cty; // sixty

exports.csixty = csixty;
var cseventy = cseven + bas.cty; // seventy

exports.cseventy = cseventy;
var ceighty = ceight + bas.cy; // eighty

exports.ceighty = ceighty;
var cninety = cnine + bas.cty; // ninety

exports.cninety = cninety;
var chundred = bas.ch + phn.cundred; // hundred

exports.chundred = chundred;
var cthousand = bas.ct + phn.chousand; // thousand

exports.cthousand = cthousand;
var cmillion = bas.cm + phn.cillion; // million

exports.cmillion = cmillion;
var cbillion = bas.cb + phn.cillion; // billion

exports.cbillion = cbillion;
var ctrillion = bas.ctr + phn.cillion; // trillion

exports.ctrillion = ctrillion;
var cOne = bas.cO + bas.cne; // One

exports.cOne = cOne;
var cTwo = bas.cT + bas.cwo; // Two

exports.cTwo = cTwo;
var cThree = bas.cT + phn.chree; // Three

exports.cThree = cThree;
var cFour = bas.cF + phn.cour; // Four

exports.cFour = cFour;
var cFive = bas.cF + phn.cive; // Five

exports.cFive = cFive;
var cSix = bas.cS + bas.cix; // Six

exports.cSix = cSix;
var cSeven = bas.cS + phn.ceven; // Seven

exports.cSeven = cSeven;
var cEight = bas.cE + phn.cight; // Eight

exports.cEight = cEight;
var cNine = bas.cN + phn.cine; // Nine

exports.cNine = cNine;
var cTen = bas.cT + bas.cen; // Ten

exports.cTen = cTen;
var cEleven = bas.cE + phn.cleven; // Eleven

exports.cEleven = cEleven;
var cTwelve = bas.cT + phn.cwelve; // Twelve

exports.cTwelve = cTwelve;
var cThirteen = bas.cT + phn.chir + phn.cteen; // Thirteen

exports.cThirteen = cThirteen;
var cFourteen = cFour + phn.cteen; // Fourteen

exports.cFourteen = cFourteen;
var cFifteen = bas.cF + bas.cif + phn.cteen; // Fifteen

exports.cFifteen = cFifteen;
var cSixteen = cSix + phn.cteen; // Sixteen

exports.cSixteen = cSixteen;
var cSeventeen = cSeven + phn.cteen; // Seventeen

exports.cSeventeen = cSeventeen;
var cEighteen = bas.cE + phn.cigh + phn.cteen; // Eighteen

exports.cEighteen = cEighteen;
var cNineteen = cNine + phn.cteen; // Nineteen

exports.cNineteen = cNineteen;
var cTwenty = bas.cT + phn.cwenty; // Twenty

exports.cTwenty = cTwenty;
var cThirty = bas.cT + phn.chirty; // Thirty

exports.cThirty = cThirty;
var cFourty = cFour + bas.cty; // Fourty

exports.cFourty = cFourty;
var cFifty = bas.cF + phn.cifty; // Fifty

exports.cFifty = cFifty;
var cSixty = cSix + bas.cty; // Sixty

exports.cSixty = cSixty;
var cSeventy = cSeven + bas.cty; // Seventy

exports.cSeventy = cSeventy;
var cEighty = cEight + bas.cy; // Eighty

exports.cEighty = cEighty;
var cNinety = cNine + bas.cty; // Ninety

exports.cNinety = cNinety;
var cHundred = bas.cH + phn.cundred; // Hundred

exports.cHundred = cHundred;
var cThousand = bas.cT + phn.chousand; // Thousand

exports.cThousand = cThousand;
var cMillion = bas.cM + phn.cillion; // Million

exports.cMillion = cMillion;
var cBillion = bas.cB + phn.cillion; // Billion

exports.cBillion = cBillion;
var cTrillion = bas.cTr + phn.cillion; // Trillion
// String Number Values

exports.cTrillion = cTrillion;
var cfirst = bas.cfi + bas.crs + bas.ct; // first

exports.cfirst = cfirst;
var cFirst = bas.cFi + bas.crs + bas.ct; // First

exports.cFirst = cFirst;
var csecond = bas.cse + phn.ccond; // second

exports.csecond = csecond;
var cSecond = bas.cSe + phn.ccond; // Second

exports.cSecond = cSecond;
var cthird = bas.cth + bas.cir + bas.cd; // third

exports.cthird = cthird;
var cThird = bas.cTh + bas.cir + bas.cd; // Third

exports.cThird = cThird;
var cfourth = cfour + bas.cth; // fourth

exports.cfourth = cfourth;
var cFourth = cFour + bas.cth; // Fourth

exports.cFourth = cFourth;
var cfifth = bas.cfi + bas.cft + bas.ch; // fifth

exports.cfifth = cfifth;
var cFifth = bas.cFi + bas.cft + bas.ch; // Fifth

exports.cFifth = cFifth;
var csixth = csix + bas.cth; // sixth

exports.csixth = csixth;
var cSixth = cSix + bas.cth; // Sixth

exports.cSixth = cSixth;
var cseventh = cseven + bas.cth; // seventh

exports.cseventh = cseventh;
var cSeventh = cSeven + bas.cth; // Seventh

exports.cSeventh = cSeventh;
var ceighth = ceight + bas.ch; // eighth

exports.ceighth = ceighth;
var cEighth = cEight + bas.ch; // Eighth

exports.cEighth = cEighth;
var ctenth = cten + bas.cth; // tenth

exports.ctenth = ctenth;
var cTenth = cTen + bas.cth; // Tenth

exports.cTenth = cTenth;
var celeventh = celeven + bas.cth; // eleventh

exports.celeventh = celeventh;
var cEleventh = cEleven + bas.cth; // Eleventh

exports.cEleventh = cEleventh;
var ctwelveth = ctwelve + bas.cth; // twelveth

exports.ctwelveth = ctwelveth;
var cTwelveth = cTwelve + bas.cth; // Twelveth

exports.cTwelveth = cTwelveth;
var cthirteenth = cthirteen + bas.cth; // thirteenth

exports.cthirteenth = cthirteenth;
var cThirteenth = cThirteen + bas.cth; // Thirteenth

exports.cThirteenth = cThirteenth;
var cfourteenth = cfourteen + bas.cth; // fourteenth

exports.cfourteenth = cfourteenth;
var cFourteenth = cFourteen + bas.cth; // Fourteenth

exports.cFourteenth = cFourteenth;
var cfifteenth = cfifteen + bas.cth; // fifteenth

exports.cfifteenth = cfifteenth;
var cFifteenth = cFifteen + bas.cth; // Fifteenth

exports.cFifteenth = cFifteenth;
var csixteenth = csixteen + bas.cth; // sixteenth

exports.csixteenth = csixteenth;
var cSixteenth = cSixteen + bas.cth; // Sixteenth

exports.cSixteenth = cSixteenth;
var cseventeenth = cseventeen + bas.cth; // seventeenth

exports.cseventeenth = cseventeenth;
var cSeventeenth = cSeventeen + bas.cth; // Seventeenth

exports.cSeventeenth = cSeventeenth;
var ceighteenth = ceighteen + bas.cth; // eighteenth

exports.ceighteenth = ceighteenth;
var cEighteenth = cEighteen + bas.cth; // Eighteenth

exports.cEighteenth = cEighteenth;
var cnineteenth = cnineteen + bas.cth; // nineteenth

exports.cnineteenth = cnineteenth;
var cNineteenth = cNineteen + bas.cth; // Nineteenth

exports.cNineteenth = cNineteenth;
var ctwentieth = bas.ctw + bas.cen + phn.ctieth; // twentieth

exports.ctwentieth = ctwentieth;
var cTwentieth = bas.cTw + bas.cen + phn.ctieth; // Twentieth

exports.cTwentieth = cTwentieth;
var cthirtieth = bas.cth + bas.cir + phn.ctieth; // thirtieth

exports.cthirtieth = cthirtieth;
var cThirtieth = bas.cTh + bas.cir + phn.ctieth; // Thirtieth

exports.cThirtieth = cThirtieth;
var cfourtieth = cfour + phn.ctieth; // fourtieth

exports.cfourtieth = cfourtieth;
var cFourtieth = cFour + phn.ctieth; // Fourtieth

exports.cFourtieth = cFourtieth;
var cfiftieth = bas.cfi + bas.cf + phn.ctieth; // fiftieth

exports.cfiftieth = cfiftieth;
var cFiftieth = bas.cFi + bas.cf + phn.ctieth; // Fiftieth

exports.cFiftieth = cFiftieth;
var csixtieth = csix + phn.ctieth; // sixtieth

exports.csixtieth = csixtieth;
var cSixtieth = cSix + phn.ctieth; // Sixtieth

exports.cSixtieth = cSixtieth;
var cseventieth = cseven + phn.ctieth; // seventieth

exports.cseventieth = cseventieth;
var cSeventieth = cSeven + phn.ctieth; // Seventieth

exports.cSeventieth = cSeventieth;
var ceightieth = ceight + phn.cieth; // eightieth

exports.ceightieth = ceightieth;
var cEightieth = cEight + phn.cieth; // Eightieth

exports.cEightieth = cEightieth;
var cninetieth = cnine + phn.ctieth; // ninetieth

exports.cninetieth = cninetieth;
var cNinetieth = cNine + phn.ctieth; // Ninetieth

exports.cNinetieth = cNinetieth;
var chundredth = chundred + bas.cth; // hundredth

exports.chundredth = chundredth;
var cHundredth = cHundred + bas.cth; // Hundredth

exports.cHundredth = cHundredth;
var cthousandth = cthousand + bas.cth; // thousandth

exports.cthousandth = cthousandth;
var cThousandth = cThousand + bas.cth; // Thousandth

exports.cThousandth = cThousandth;
var cmillionth = cmillion + bas.cth; // millionth

exports.cmillionth = cmillionth;
var cMillionth = cMillion + bas.cth; // Millionth

exports.cMillionth = cMillionth;
var cbillionth = cbillion + bas.cth; // billionth

exports.cbillionth = cbillionth;
var cBillionth = cBillion + bas.cth; // Billionth

exports.cBillionth = cBillionth;
var ctrillionth = ctrillion + bas.cth; // trillionth

exports.ctrillionth = ctrillionth;
var cTrillionth = cTrillion + bas.cth; // Trillionth

exports.cTrillionth = cTrillionth;