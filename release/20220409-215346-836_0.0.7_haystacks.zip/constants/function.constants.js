"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.csetupAllXmlData = exports.csetupAllJsonConfigData = exports.csetupAllCsvData = exports.csetUnderlineFontStyleOnMessageComponentAccordingToSetting = exports.csetFontForegroundColorOnMessageComponentAccordingToSetting = exports.csetFontBackgroundColorOnMessageComponentAccordingToSetting = exports.csetConfigurationSetting = exports.csetBoldFontStyleOnMessageComponentAccordingToSetting = exports.csearchForUniversalDebugConfigSetting = exports.cscanDirectoryContents = exports.cscanDataPath = exports.cremoveStringLiteralTagsFromArray = exports.cremoveFontStyles = exports.creformatDeltaTime = exports.creadDirectorySynchronously = exports.creadDirectoryContents = exports.cqueueSize = exports.cqueueFront = exports.cpush = exports.cprompt = exports.cprocessRules = exports.cprocessRootPath = exports.cprocessCsvData = exports.cprocessConfigurationValueRules = exports.cprocessConfigurationNamespaceRules = exports.cprocessConfigurationNameRules = exports.cprocessCommandQueue = exports.cprintMessageToFile = exports.cprint = exports.cpreprocessJsonFile = exports.cpop = exports.cparseBusinessRuleArgument = exports.cparseArgumentAsRegularExpression = exports.cparseArgumentAsArray = exports.cmergeClientCommands = exports.cmergeClientBusienssRules = exports.cloadCommandWorkflowsFromPath = exports.cloadCommandAliasesFromPath = exports.cloadCommandAliases = exports.cloadAllXmlData = exports.cloadAllJsonData = exports.cloadAllCsvData = exports.clength = exports.cisEmpty = exports.cisCommandQueueEmpty = exports.cinitializeConstantsValidationData = exports.cinitStack = exports.cinitRulesLibrary = exports.cinitQueue = exports.cinitFrameworkSchema = exports.cinitFramework = exports.cinitCommandsLibrary = exports.cgetXmlData = exports.cgetWorkflow = exports.cgetValidCommand = exports.cgetNowMoment = exports.cgetNamedColorData = exports.cgetLogFileNameAndPath = exports.cgetJsonData = exports.cgetFontStyleSettingsFromSetting = exports.cgetData = exports.cgetCsvData = exports.cgetConfigurationSetting = exports.cgetCommandArgs = exports.cgetColorStyleSettingFromSetting = exports.cgetAndProcessXmlData = exports.cgetAndProcessCsvData = exports.cfindUniversalDebugConfigSetting = exports.cexecuteCommand = exports.cexecuteBusinessRule = exports.cenqueueCommand = exports.cenqueue = exports.cdoesRuleExist = exports.cdoAllRulesExist = exports.cdequeue = exports.ccreateZipArchive = exports.ccopyFolderRecursiveSync = exports.ccopyFileSync = exports.ccopyAllFilesAndFoldersFromFolderToFolder = exports.ccontains = exports.cconstantsValidationSummaryLog = exports.cconsoleTableLog = exports.cconsoleLog = exports.ccomputeDeltaTime = exports.ccolorizeMessageSimple = exports.ccolorizeMessage = exports.cclearStack = exports.cclearData = exports.ccleanRootPath = exports.cbuildReleasePackage = exports.cbootStrapCommands = exports.cbootStrapBusinessRules = exports.cappendMessageToFile = exports.canalyzeForRegularExpression = exports.canalyzeArgument = exports.caggregateStyleSetting = exports.caddDeeplyNestedConstantsValidationData = exports.caddConstantsValidationData = exports.caddClientRules = exports.caddClientCommands = void 0;
exports.cwriteJsonDataToFile = exports.cwriteJsonData = exports.cstoreData = exports.csleep = exports.csetupDataStorage = exports.csetupConfiguration = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var gen = _interopRequireWildcard(require("./generic.constants.js"));

var phn = _interopRequireWildcard(require("./phonic.constants.js"));

var wr1 = _interopRequireWildcard(require("./word1.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file function.constants.js
 * @module function.constants
 * @description Contains all re-usable function name constants, organized by file.
 * @requires module:basic.constants
 * @requires module:generic.constants
 * @requires module:phonic.constants
 * @requires module:word1.constants
 * @author Seth Hollingsead
 * @date 2021/12/28
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// commandBroker
// let cbootStrapCommands = wr1.cboot + wr1.cStrap + wr1.cCommands; // bootStrapCommands // Duplicate definition in the chiefCommander
// smuggle something caddClientCommands = wr1.c_add + wr1.cClient + wr1.cCommands; // addClientCommands
var cgetValidCommand = wr1.cget + wr1.cValid + wr1.cCommand; // getValidCommand

exports.cgetValidCommand = cgetValidCommand;
var cgetCommandArgs = wr1.cget + wr1.cCommand + gen.cArgs; // getCommandArgs

exports.cgetCommandArgs = cgetCommandArgs;
var cexecuteCommand = wr1.cexecute + wr1.cCommand; // executeCommand
// dataBroker

exports.cexecuteCommand = cexecuteCommand;
var cscanDataPath = wr1.cscan + wr1.cData + wr1.cPath; // scanDataPath

exports.cscanDataPath = cscanDataPath;
var cfindUniversalDebugConfigSetting = wr1.cfind + wr1.cUniversal + wr1.cDebug + wr1.cConfig + wr1.cSetting; // findUniversalDebugConfigSetting

exports.cfindUniversalDebugConfigSetting = cfindUniversalDebugConfigSetting;
var cloadAllCsvData = wr1.cload + phn.cAll + gen.cCsv + wr1.cData; // loadAllCsvData

exports.cloadAllCsvData = cloadAllCsvData;
var cloadAllXmlData = wr1.cload + phn.cAll + gen.cXml + wr1.cData; // loadAllXmlData

exports.cloadAllXmlData = cloadAllXmlData;
var cloadAllJsonData = wr1.cload + phn.cAll + gen.cJson + wr1.cData; // loadAllJsonData

exports.cloadAllJsonData = cloadAllJsonData;
var cprocessCsvData = wr1.cprocess + gen.cCsv + wr1.cData; // processCsvData

exports.cprocessCsvData = cprocessCsvData;
var cpreprocessJsonFile = wr1.cpreprocess + gen.cJson + wr1.cFile; // preprocessJsonFile

exports.cpreprocessJsonFile = cpreprocessJsonFile;
var cwriteJsonDataToFile = wr1.cwrite + gen.cJson + wr1.cData + wr1.cTo + wr1.cFile; // writeJsonDataToFile

exports.cwriteJsonDataToFile = cwriteJsonDataToFile;
var csetupDataStorage = wr1.csetup + wr1.cData + wr1.cStorage; // setupDataStorage

exports.csetupDataStorage = csetupDataStorage;
var cstoreData = wr1.cstore + wr1.cData; // storeData

exports.cstoreData = cstoreData;
var cgetData = wr1.cget + wr1.cData; // getData

exports.cgetData = cgetData;
var cclearData = wr1.cclear + wr1.cData; // clearData
// initializeConstantsValidationData Already created in the ChiefData file.

exports.cclearData = cclearData;
var caddConstantsValidationData = wr1.c_add + wr1.cConstants + wr1.cValidation + wr1.cData; // addConstantsValidationData

exports.caddConstantsValidationData = caddConstantsValidationData;
var caddDeeplyNestedConstantsValidationData = wr1.c_add + wr1.cDeeply + wr1.cNested + wr1.cConstants + wr1.cValidation + wr1.cData; // addDeeplyNestedConstantsValidationData
// ruleBroker

exports.caddDeeplyNestedConstantsValidationData = caddDeeplyNestedConstantsValidationData;
var cbootStrapBusinessRules = wr1.cboot + wr1.cStrap + wr1.cBusiness + wr1.cRules; // bootStrapBusinessRules

exports.cbootStrapBusinessRules = cbootStrapBusinessRules;
var caddClientRules = wr1.c_add + wr1.cClient + wr1.cRules; // addClientRules

exports.caddClientRules = caddClientRules;
var cdoesRuleExist = wr1.cdoes + wr1.cRule + wr1.cExist; // doesRuleExist

exports.cdoesRuleExist = cdoesRuleExist;
var cdoAllRulesExist = wr1.cdo + wr1.cAll + wr1.cRules + wr1.cExist; // doAllRulesExist

exports.cdoAllRulesExist = cdoAllRulesExist;
var cprocessRules = wr1.cprocess + wr1.cRules; // processRules
// workflowBroker

exports.cprocessRules = cprocessRules;
var cgetWorkflow = wr1.cget + wr1.cWorkflow; // getWorkflow
// rulesLibrary

exports.cgetWorkflow = cgetWorkflow;
var cinitRulesLibrary = gen.cinit + wr1.cRules + wr1.cLibrary; // initRulesLibrary
// commandsLibrary

exports.cinitRulesLibrary = cinitRulesLibrary;
var cinitCommandsLibrary = gen.cinit + wr1.cCommands + wr1.cLibrary; // initCommandsLibrary
// chiefCommander

exports.cinitCommandsLibrary = cinitCommandsLibrary;
var cbootStrapCommands = wr1.cboot + wr1.cStrap + wr1.cCommands; // bootStrapCommands

exports.cbootStrapCommands = cbootStrapCommands;
var caddClientCommands = wr1.c_add + wr1.cClient + wr1.cCommands; // addClientCommands

exports.caddClientCommands = caddClientCommands;
var cloadCommandAliasesFromPath = wr1.cload + wr1.cCommand + wr1.cAliases + wr1.cFrom + wr1.cPath; // loadCommandAliasesFromPath

exports.cloadCommandAliasesFromPath = cloadCommandAliasesFromPath;
var cenqueueCommand = wr1.cenqueue + wr1.cCommand; // enqueueCommand

exports.cenqueueCommand = cenqueueCommand;
var cisCommandQueueEmpty = wr1.cis + wr1.cCommand + wr1.cQueue + wr1.cEmpty; // isCommandQueueEmpty

exports.cisCommandQueueEmpty = cisCommandQueueEmpty;
var cprocessCommandQueue = wr1.cprocess + wr1.cCommand + wr1.cQueue; // processCommandQueue
// chiefConfiguration

exports.cprocessCommandQueue = cprocessCommandQueue;
var csetupConfiguration = wr1.csetup + wr1.cConfiguration; // setupConfiguration
// chiefData

exports.csetupConfiguration = csetupConfiguration;
var csearchForUniversalDebugConfigSetting = wr1.csearch + wr1.cFor + wr1.cUniversal + wr1.cDebug + wr1.cConfig + wr1.cSetting; // searchForUniversalDebugConfigSetting

exports.csearchForUniversalDebugConfigSetting = csearchForUniversalDebugConfigSetting;
var cgetAndProcessCsvData = wr1.cget + wr1.cAnd + wr1.cProcess + gen.cCsv + wr1.cData; // getAndProcessCsvData

exports.cgetAndProcessCsvData = cgetAndProcessCsvData;
var cgetAndProcessXmlData = wr1.cget + wr1.cAnd + wr1.cProcess + gen.cXml + wr1.cData; // getAndProcessXmlData

exports.cgetAndProcessXmlData = cgetAndProcessXmlData;
var csetupAllCsvData = wr1.csetup + wr1.cAll + gen.cCsv + wr1.cData; // setupAllCsvData

exports.csetupAllCsvData = csetupAllCsvData;
var csetupAllXmlData = wr1.csetup + wr1.cAll + gen.cXml + wr1.cData; // setupAllXmlData

exports.csetupAllXmlData = csetupAllXmlData;
var csetupAllJsonConfigData = wr1.csetup + phn.cAll + gen.cJson + wr1.cConfig + wr1.cData; // setupAllJsonConfigData

exports.csetupAllJsonConfigData = csetupAllJsonConfigData;
var cinitializeConstantsValidationData = wr1.cinitialize + wr1.cConstants + wr1.cValidation + wr1.cData; // initializeConstantsValidationData
// smuggle something caddConstantsValidationData // Already declared in the dataBroker section.
// chiefWorkflow

exports.cinitializeConstantsValidationData = cinitializeConstantsValidationData;
var cloadCommandWorkflowsFromPath = wr1.cload + wr1.cCommand + wr1.cWorkflows + wr1.cFrom + wr1.cPath; // loadCommandWorkflowsFromPath
// warden

exports.cloadCommandWorkflowsFromPath = cloadCommandWorkflowsFromPath;
var cprocessRootPath = wr1.cprocess + wr1.cRoot + wr1.cPath; // processRootPath

exports.cprocessRootPath = cprocessRootPath;
var cinitFrameworkSchema = gen.cinit + wr1.cFramework + wr1.cSchema; // initFrameworkSchema

exports.cinitFrameworkSchema = cinitFrameworkSchema;
var cmergeClientBusienssRules = wr1.cmerge + wr1.cClient + wr1.cBusiness + wr1.cRules; // mergeClientBusinessRules

exports.cmergeClientBusienssRules = cmergeClientBusienssRules;
var cmergeClientCommands = wr1.cmerge + wr1.cClient + wr1.cCommands; // mergeClientCommands

exports.cmergeClientCommands = cmergeClientCommands;
var cloadCommandAliases = wr1.cload + wr1.cCommand + wr1.cAliases; // loadCommandAliases

exports.cloadCommandAliases = cloadCommandAliases;
var cexecuteBusinessRule = wr1.cexecute + wr1.cBusiness + wr1.cRule; // executeBusinessRule
// smuggle something cenqueueCommand = wr1.cenqueue + wr1.cCommand; // enqueueCommand
// smuggle something cisCommandQueueEmpty = wr1.cis + wr1.cCommand + wr1.cQueue + wr1.cEmpty; // isCommandQueueEmpty
// smuggle something cprocessCommandQueue = wr1.cprocess + wr1.cCommand + wr1.cQueue; // processCommandQueue
// smuggle something csetConfigurationSetting = wr1.cset + wr1.cConfiguration + wr1.cSetting; // setConfigurationSetting
// smuggle something cgetConfigurationSetting = wr1.cget + wr1.cConfiguration + wr1.cSetting; // getConfigurationSetting
// smuggle something cconsoleLog = wr1.cconsole + wr1.cLog; // consoleLog
// smuggle something csleep = wr1.csleep; // sleep
// colorizer

exports.cexecuteBusinessRule = cexecuteBusinessRule;
var ccolorizeMessageSimple = wr1.ccolorize + wr1.cMessage + wr1.cSimple; // colorizeMessageSimple

exports.ccolorizeMessageSimple = ccolorizeMessageSimple;
var ccolorizeMessage = wr1.ccolorize + wr1.cMessage; // colorizeMessage

exports.ccolorizeMessage = ccolorizeMessage;
var caggregateStyleSetting = wr1.caggregate + wr1.cStyle + wr1.cSetting; // aggregateStyleSetting

exports.caggregateStyleSetting = caggregateStyleSetting;
var cgetFontStyleSettingsFromSetting = wr1.cget + wr1.cFont + wr1.cStyle + wr1.cSettings + wr1.cFrom + wr1.cSetting; // getFontStyleSettingsFromSetting

exports.cgetFontStyleSettingsFromSetting = cgetFontStyleSettingsFromSetting;
var cgetColorStyleSettingFromSetting = wr1.cget + wr1.cColor + wr1.cStyle + wr1.cSetting + wr1.cFrom + wr1.cSetting; // getColorStyleSettingFromSetting

exports.cgetColorStyleSettingFromSetting = cgetColorStyleSettingFromSetting;
var cgetNamedColorData = wr1.cget + wr1.cNamed + wr1.cColor + wr1.cData; // getNamedColorData

exports.cgetNamedColorData = cgetNamedColorData;
var csetUnderlineFontStyleOnMessageComponentAccordingToSetting = wr1.cset + wr1.cUnderline + wr1.cFont + wr1.cStyle + bas.cOn + wr1.cMessage + wr1.cComponent + wr1.cAccording + wr1.cTo + wr1.cSetting; // setUnderlineFontStyleOnMessageComponentAccordingToSetting

exports.csetUnderlineFontStyleOnMessageComponentAccordingToSetting = csetUnderlineFontStyleOnMessageComponentAccordingToSetting;
var csetBoldFontStyleOnMessageComponentAccordingToSetting = wr1.cset + wr1.cBold + wr1.cFont + wr1.cStyle + bas.cOn + wr1.cMessage + wr1.cComponent + wr1.cAccording + wr1.cTo + wr1.cSetting; // setBoldFontStyleOnMessageComponentAccordingToSetting

exports.csetBoldFontStyleOnMessageComponentAccordingToSetting = csetBoldFontStyleOnMessageComponentAccordingToSetting;
var csetFontForegroundColorOnMessageComponentAccordingToSetting = wr1.cset + wr1.cFont + wr1.cForeground + wr1.cColor + bas.cOn + wr1.cMessage + wr1.cComponent + wr1.cAccording + wr1.cTo + wr1.cSetting; // setFontForegroundColorOnMessageComponentAccordingToSetting

exports.csetFontForegroundColorOnMessageComponentAccordingToSetting = csetFontForegroundColorOnMessageComponentAccordingToSetting;
var csetFontBackgroundColorOnMessageComponentAccordingToSetting = wr1.cset + wr1.cFont + wr1.cBackground + wr1.cColor + bas.cOn + wr1.cMessage + wr1.cComponent + wr1.cAccording + wr1.cTo + wr1.cSetting; // setFontBackgroundColorOnMessageComponentAccordingToSetting

exports.csetFontBackgroundColorOnMessageComponentAccordingToSetting = csetFontBackgroundColorOnMessageComponentAccordingToSetting;
var cremoveFontStyles = wr1.cremove + wr1.cFont + wr1.cStyles; // removeFontStyles
// configurator

exports.cremoveFontStyles = cremoveFontStyles;
var csetConfigurationSetting = wr1.cset + wr1.cConfiguration + wr1.cSetting; // setConfigurationSetting

exports.csetConfigurationSetting = csetConfigurationSetting;
var cgetConfigurationSetting = wr1.cget + wr1.cConfiguration + wr1.cSetting; // getConfigurationSetting

exports.cgetConfigurationSetting = cgetConfigurationSetting;
var cprocessConfigurationNameRules = wr1.cprocess + wr1.cConfiguration + wr1.cName + wr1.cRules; // processConfigurationNameRules

exports.cprocessConfigurationNameRules = cprocessConfigurationNameRules;
var cprocessConfigurationNamespaceRules = wr1.cprocess + wr1.cConfiguration + wr1.cName + wr1.cspace + wr1.cRules; // processConfigurationNamespaceRules

exports.cprocessConfigurationNamespaceRules = cprocessConfigurationNamespaceRules;
var cprocessConfigurationValueRules = wr1.cprocess + wr1.cConfiguration + wr1.cValue + wr1.cRules; // processConfigurationValueRules
// fileOperations

exports.cprocessConfigurationValueRules = cprocessConfigurationValueRules;
var cgetXmlData = wr1.cget + gen.cXml + wr1.cData; // getXmlData

exports.cgetXmlData = cgetXmlData;
var cgetCsvData = wr1.cget + gen.cCsv + wr1.cData; // getCsvData

exports.cgetCsvData = cgetCsvData;
var cgetJsonData = wr1.cget + gen.cJson + wr1.cData; // getJsonData

exports.cgetJsonData = cgetJsonData;
var cwriteJsonData = wr1.cwrite + gen.cJson + wr1.cData; // writeJsonData

exports.cwriteJsonData = cwriteJsonData;
var creadDirectoryContents = wr1.cread + wr1.cDirectory + wr1.cContents; // readDirectoryContents

exports.creadDirectoryContents = creadDirectoryContents;
var cscanDirectoryContents = wr1.cscan + wr1.cDirectory + wr1.cContents; // scanDirectoryContents

exports.cscanDirectoryContents = cscanDirectoryContents;
var creadDirectorySynchronously = wr1.cread + wr1.cDirectory + wr1.cSynchronously; // readDirectorySynchronously

exports.creadDirectorySynchronously = creadDirectorySynchronously;
var ccopyAllFilesAndFoldersFromFolderToFolder = wr1.ccopy + wr1.cAll + wr1.cFiles + wr1.cAnd + wr1.cFolders + wr1.cFrom + wr1.cFolder + wr1.cTo + wr1.cFolder; // copyAllFilesAndFoldersFromFolderToFolder

exports.ccopyAllFilesAndFoldersFromFolderToFolder = ccopyAllFilesAndFoldersFromFolderToFolder;
var cbuildReleasePackage = wr1.cbuild + wr1.cRelease + wr1.cPackage; // buildReleasePackage

exports.cbuildReleasePackage = cbuildReleasePackage;
var ccreateZipArchive = wr1.ccreate + gen.cZip + wr1.cArchive; // createZipArchive

exports.ccreateZipArchive = ccreateZipArchive;
var ccleanRootPath = wr1.cclean + wr1.cRoot + wr1.cPath; // cleanRootPath

exports.ccleanRootPath = ccleanRootPath;
var ccopyFileSync = wr1.ccopy + wr1.cFile + wr1.cSync; // copyFileSync

exports.ccopyFileSync = ccopyFileSync;
var ccopyFolderRecursiveSync = wr1.ccopy + wr1.cFolder + wr1.cRecursive + wr1.cSync; // copyFolderRecursiveSync

exports.ccopyFolderRecursiveSync = ccopyFolderRecursiveSync;
var cappendMessageToFile = wr1.cappend + wr1.cMessage + bas.cTo + wr1.cFile; // appendMessageToFile
// lexical

exports.cappendMessageToFile = cappendMessageToFile;
var cparseBusinessRuleArgument = wr1.cparse + wr1.cBusiness + wr1.cRule + wr1.cArgument; // parseBusinessRuleArgument

exports.cparseBusinessRuleArgument = cparseBusinessRuleArgument;
var canalyzeArgument = wr1.canalyze + wr1.cArgument; // analyzeArgument

exports.canalyzeArgument = canalyzeArgument;
var canalyzeForRegularExpression = wr1.canalyze + wr1.cFor + wr1.cRegular + wr1.cExpression; // analyzeForRegularExpression

exports.canalyzeForRegularExpression = canalyzeForRegularExpression;
var cparseArgumentAsRegularExpression = wr1.cparse + wr1.cArgument + wr1.cAs + wr1.cRegular + wr1.cExpression; // parseArgumentAsRegularExpression

exports.cparseArgumentAsRegularExpression = cparseArgumentAsRegularExpression;
var cparseArgumentAsArray = wr1.cparse + wr1.cArgument + wr1.cAs + wr1.cArray; // parseArgumentAsArray

exports.cparseArgumentAsArray = cparseArgumentAsArray;
var cremoveStringLiteralTagsFromArray = wr1.cremove + wr1.cString + wr1.cLiteral + wr1.cTags + wr1.cFrom + wr1.cArray; // removeStringLiteralTagsFromArray
// loggers

exports.cremoveStringLiteralTagsFromArray = cremoveStringLiteralTagsFromArray;
var cconsoleLog = wr1.cconsole + gen.cLog; // consoleLog

exports.cconsoleLog = cconsoleLog;
var cconsoleTableLog = wr1.cconsole + wr1.cTable + gen.cLog; // consoleTableLog

exports.cconsoleTableLog = cconsoleTableLog;
var cconstantsValidationSummaryLog = wr1.cconstants + wr1.cValidation + wr1.cSummary + wr1.cLog; // constantsValidationSummaryLog

exports.cconstantsValidationSummaryLog = cconstantsValidationSummaryLog;
var cgetLogFileNameAndPath = wr1.cget + gen.cLog + wr1.cFileName + wr1.cAnd + wr1.cPath; // getLogFileNameAndPath

exports.cgetLogFileNameAndPath = cgetLogFileNameAndPath;
var cprintMessageToFile = wr1.cprint + wr1.cMessage + wr1.cTo + wr1.cFile; // printMessageToFile
// prompt

exports.cprintMessageToFile = cprintMessageToFile;
var cprompt = wr1.cprompt; // prompt
// timers

exports.cprompt = cprompt;
var cgetNowMoment = wr1.cget + wr1.cNow + wr1.cMoment; // getNowMoment

exports.cgetNowMoment = cgetNowMoment;
var ccomputeDeltaTime = wr1.ccompute + gen.cDelta + wr1.cTime; // computeDeltaTime

exports.ccomputeDeltaTime = ccomputeDeltaTime;
var creformatDeltaTime = wr1.creformat + gen.cDelta + wr1.cTime; // reformatDeltaTime

exports.creformatDeltaTime = creformatDeltaTime;
var csleep = wr1.csleep; // sleep
// queue

exports.csleep = csleep;
var cinitQueue = gen.cinit + wr1.cQueue; // initQueue

exports.cinitQueue = cinitQueue;
var cdequeue = wr1.cdequeue; // dequeue

exports.cdequeue = cdequeue;
var cenqueue = wr1.cenqueue; // enqueue

exports.cenqueue = cenqueue;
var cisEmpty = wr1.cis + wr1.cEmpty; // isEmpty

exports.cisEmpty = cisEmpty;
var cqueueFront = wr1.cqueue + wr1.cFront; // queueFront

exports.cqueueFront = cqueueFront;
var cqueueSize = wr1.cqueue + wr1.cSize; // queueSize
// stack

exports.cqueueSize = cqueueSize;
var cinitStack = gen.cinit + wr1.cStack; // initStack

exports.cinitStack = cinitStack;
var cclearStack = wr1.cclear + wr1.cStack; // clearStack

exports.cclearStack = cclearStack;
var cpush = wr1.cpush; // push

exports.cpush = cpush;
var cpop = wr1.cpop; // pop
// let cisEmpty = wr1.cis + wr1.cEmpty; // isEmpty // Duplicate definition in the chiefCommander

exports.cpop = cpop;
var clength = wr1.clength; // length

exports.clength = clength;
var ccontains = wr1.ccontains; // contains

exports.ccontains = ccontains;
var cprint = wr1.cprint; // print
// main

exports.cprint = cprint;
var cinitFramework = gen.cinit + wr1.cFramework; // initFramework
// smuggle something cmergeClientBusinessRules = wr1.cmerge + wr1.cClient + wr1.cBusiness + wr1.cRules; // mergeClientBusinessRules
// smuggle something cmergeClientCommands = wr1.cmerge + wr1.cClient + wr1.cCommands; // mergeClientCommands
// smuggle something cloadCommandAliases = wr1.cload + wr1.cCommand + wr1.cAliases; // loadCommandAliases
// smuggle something cloadCommandWorkflows = wr1.cload + wr1.cCommand + wr1.cWorkflows; // loadCommandWorkflows
// smuggle something cexecuteBusinessRule = wr1.cexecute + wr1.cBusiness + wr1.cRule; // executeBusinessRule
// smuggle something cenqueueCommand = wr1.cenqueue + wr1.cCommand; // enqueueCommand
// smuggle something cisCommandQueueEmpty = wr1.cis + wr1.cCommand + wr1.cQueue + wr1.cEmpty; // isCommandQueueEmpty
// smuggle something cprocessCommandQueue = wr1.cprocess + wr1.cCommand + wr1.cQueue; // processCommandQueue
// smuggle something csetConfigurationSetting = wr1.cset + wr1.cConfiguration + wr1.cSetting; // setConfigurationSetting
// smuggle something cgetConfigurationSetting = wr1.cget + wr1.cConfiguration + wr1.cSetting; // getConfigurationSetting
// smuggle something cconsoleLog = wr1.cconsole + wr1.cLog; // consoleLog
// smuggle something csleep = wr1.csleep; // sleep
// smuggle something cprompt = wr1.cprompt; // prompt

exports.cinitFramework = cinitFramework;