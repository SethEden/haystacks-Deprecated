"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cisStringCamelCase = exports.cisString = exports.cisOdd = exports.cisObjectEmpty = exports.cisObject = exports.cisNonZeroLengthArray = exports.cisInteger = exports.cisFloat = exports.cisFirstCharacterUpperCase = exports.cisFirstCharacterLowerCase = exports.cisEven = exports.cisConstantValid = exports.cisConstantTypeValid = exports.cisBoolean = exports.cisArrayOrObject = exports.cisArrayEmpty = exports.cisArray = exports.chex2rgbConversion = exports.cgetWordsArrayFromString = exports.cgetWordCountInString = exports.cgetValueFromAssignmentOperationString = exports.cgetUserNameFromEmail = exports.cgetStoredData = exports.cgetNowMoment = exports.cgetLengthOfLongestStringInArray = exports.cgetLehmerCodeValue = exports.cgetKeywordNameFromDataContextName = exports.cgetFirstTopLevelFolderFromPath = exports.cgetFileNameFromPath = exports.cgetFileExtension = exports.cgetFileAndPathListForPath = exports.cgetDataCatagoryFromDataContextName = exports.cgetDataCatagoryDetailNameFromDataContextName = exports.cgetConstantType = exports.cgetConstantName = exports.cgetConstantActualValue = exports.cgetAttributeValue = exports.cgetAttributeName = exports.cgenerateValidEmailWithSpecificSuffixAndDomainName = exports.cgenerateValidEmail = exports.cgenerateRandomValidEmail = exports.cgenerateRandomUpperCaseTextWithSpecialCharactersByLength = exports.cgenerateRandomUpperCaseTextByLength = exports.cgenerateRandomUpperCaseAlphaNumericCodeWithSpecialCharactersByLength = exports.cgenerateRandomUpperCaseAlphaNumericCodeByLength = exports.cgenerateRandomSpecialCharacterCodeByLength = exports.cgenerateRandomNumericCodeByLength = exports.cgenerateRandomMixedCaseTextWithSpecialCharactersByLength = exports.cgenerateRandomMixedCaseTextByLength = exports.cgenerateRandomMixedCaseAlphaNumericCodeWithSpecialCharactersByLength = exports.cgenerateRandomMixedCaseAlphaNumericCodeByLength = exports.cgenerateRandomLowerCaseTextWithSpecialCharactersByLength = exports.cgenerateRandomLowerCaseTextByLength = exports.cgenerateRandomLowerCaseAlphaNumericCodeWithSpecialCharactersByLength = exports.cgenerateRandomLowerCaseAlphaNumericCodeByLength = exports.cgenerateRandomInvalidEmail = exports.cgenerateRandomDarkColor = exports.cgenerateRandomColor = exports.cgenerateRandomBrightColor = exports.cgenerateInvalidEmailWithSpecificSuffixAndDomainName = exports.cgenerateInvalidEmail = exports.cgenerateCommandAliases = exports.cfindConstantName = exports.cecho = exports.cdoesStringContainUpperCaseCharacter = exports.cdoesStringContainLowerCaseCharacter = exports.cdoesStringContainAcronym = exports.cdoesConstantExist = exports.cdoesArrayContainValue = exports.cdoesArrayContainLowerCaseConsolidatedString = exports.cdoesArrayContainFilename = exports.cdoesArrayContainCharacter = exports.cdetermineWordDelimiter = exports.cdetermineSuggestedConstantsValidationLineOfCode = exports.cdetermineObjectDataType = exports.cdetermineConstantsContextQualifiedPrefix = exports.ccreateZipArchive = exports.ccountDuplicateCommandAliases = exports.ccountDelimiterInString = exports.ccountCamelCaseWords = exports.ccopyAllFilesAndFoldersFromFolderToFolder = exports.cconvertStringToUpperCase = exports.cconvertStringToLowerCase = exports.cconvertNumberToUpperCaseLetter = exports.cconvertNumberToLowerCaseLetter = exports.cconvertConstantTypeToConstantPrefix = exports.cconvertCamelCaseStringToArray = exports.cconvertArrayToCamelCaseString = exports.cconstantsOptimizedFulfillmentSystem = exports.cconstantsFulfillmentSystem = exports.ccompareSimplifiedAndConsolidatedStrings = exports.ccleanCommandInput = exports.ccleanCarriageReturnFromString = exports.cascertainMatchingFilenames = exports.cascertainMatchingElements = exports.carraysAreEqual = exports.carrayDeepClone = exports.caggregateNumericalDifferenceBetweenTwoStrings = exports.caggregateCommandArguments = exports.cEcho = void 0;
exports.cvalidatePatternsThatNeedImplementation = exports.cvalidateConstantsDataValues = exports.cvalidateConstantsDataValidationLineItemName = exports.cvalidateConstantsDataValidation = exports.cutilitiesReplaceCharacterWithCharacter = exports.cswapForwardSlashToBackSlash = exports.cswapDoubleForwardSlashToSingleForwardSlash = exports.cswapDoubleBackSlashToSingleBackSlash = exports.cswapBackSlashToForwardSlash = exports.csupportedFileFormatsAre = exports.cstringToDataType = exports.cstringToBoolean = exports.cstoreData = exports.csolveLehmerCode = exports.csingleQuoteSwapAfterEquals = exports.csimplifyAndConsolidateString = exports.csearchForPatternsInStringArray = exports.csaveDataFile = exports.creplaceSpacesWithPlus = exports.creplaceDoublePercentWithMessage = exports.creplaceColonWithUnderscore = exports.creplaceCharacterWithCharacter = exports.creplaceCharacterAtIndex = exports.cremoveXnumberOfFoldersFromEndOfPath = exports.cremoveFileExtensionFromFileName = exports.cremoveDotFromFileExtension = exports.cremoveCharacterFromArray = exports.crecursiveArrayExpansion = exports.crecombineStringArrayWithSpaces = exports.creadDirectoryContents = exports.crandomlyGenerateUpperCaseLetterOrSpecialCharacter = exports.crandomlyGenerateUpperCaseLetter = exports.crandomlyGenerateUpperCaseAlphaNumericCharacter = exports.crandomlyGenerateSpecialCharacter = exports.crandomlyGenerateNumericCharacter = exports.crandomlyGenerateNumberInRange = exports.crandomlyGenerateMixedCaseLetterOrSpecialCharacter = exports.crandomlyGenerateMixedCaseAlphabeticCharacter = exports.crandomlyGenerateMixedCaseAlphaNumericCharacter = exports.crandomlyGenerateLowerCaseLetterOrSpecialCharacter = exports.crandomlyGenerateLowerCaseLetter = exports.crandomlyGenerateLowerCaseAlphaNumericCharacter = exports.crandomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter = exports.crandomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter = exports.crandomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter = exports.crandomlyGenerateBooleanValue = exports.cparseSystemRootPath = exports.cparseColorRangeInputs = exports.cmapWordToCamelCaseWord = exports.cloadDataFile = exports.cisValidCommandNameString = exports.cisStringList = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var gen = _interopRequireWildcard(require("./generic.constants.js"));

var num = _interopRequireWildcard(require("./numeric.constants.js"));

var phn = _interopRequireWildcard(require("./phonic.constants.js"));

var sys = _interopRequireWildcard(require("./system.constants.js"));

var wr1 = _interopRequireWildcard(require("./word1.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file business.constants.js
 * @module business.constants
 * @description Contains many re-usable business rules constants.
 * @requires module:basic.constants
 * @requires module:generic.constants
 * @requires module:numeric.constants
 * @requires module:phonic.constants
 * @requires module:system.constants
 * @requires module:word1.constants
 * @author Seth Hollingsead
 * @date 2021/10/29
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// Business Rules
var cecho = wr1.cecho; // echo

exports.cecho = cecho;
var cEcho = wr1.cEcho; // Echo
// ***********************************************
// ArrayParsing rules in order
// ***********************************************

exports.cEcho = cEcho;
var creplaceCharacterWithCharacter = wr1.creplace + wr1.cCharacter + wr1.cWith + wr1.cCharacter; // replaceCharacterWithCharacter

exports.creplaceCharacterWithCharacter = creplaceCharacterWithCharacter;
var cconvertCamelCaseStringToArray = wr1.cconvert + wr1.cCamel + wr1.cCase + wr1.cString + wr1.cTo + wr1.cArray; // convertCamelCaseStringToArray

exports.cconvertCamelCaseStringToArray = cconvertCamelCaseStringToArray;
var cgetWordsArrayFromString = wr1.cget + wr1.cWords + wr1.cArray + wr1.cFrom + wr1.cString; // getWordsArrayFromString

exports.cgetWordsArrayFromString = cgetWordsArrayFromString;
var crecombineStringArrayWithSpaces = wr1.crecombine + wr1.cString + wr1.cArray + wr1.cWith + wr1.cSpaces; // recombineStringArrayWithSpaces

exports.crecombineStringArrayWithSpaces = crecombineStringArrayWithSpaces;
var cconvertArrayToCamelCaseString = wr1.cconvert + wr1.cArray + wr1.cTo + wr1.cCamel + wr1.cCase + wr1.cString; // convertArrayToCamelCaseString

exports.cconvertArrayToCamelCaseString = cconvertArrayToCamelCaseString;
var cdoesArrayContainLowerCaseConsolidatedString = wr1.cdoes + wr1.cArray + wr1.cContain + wr1.cLower + wr1.cCase + wr1.cConsolidated + wr1.cString; // doesArrayContainLowerCaseConsolidatedString

exports.cdoesArrayContainLowerCaseConsolidatedString = cdoesArrayContainLowerCaseConsolidatedString;
var cdoesArrayContainCharacter = wr1.cdoes + wr1.cArray + wr1.cContain + wr1.cCharacter; // doesArrayContainCharacter

exports.cdoesArrayContainCharacter = cdoesArrayContainCharacter;
var cremoveCharacterFromArray = wr1.cremove + wr1.cCharacter + wr1.cFrom + wr1.cArray; // removeCharacterFromArray

exports.cremoveCharacterFromArray = cremoveCharacterFromArray;
var cascertainMatchingElements = wr1.cascertain + wr1.cMatching + wr1.cElements; // ascertainMatchingElements

exports.cascertainMatchingElements = cascertainMatchingElements;
var cdoesArrayContainFilename = wr1.cdoes + wr1.cArray + wr1.cContain + wr1.cFilename; // doesArrayContainFilename

exports.cdoesArrayContainFilename = cdoesArrayContainFilename;
var creadDirectoryContents = wr1.cread + wr1.cDirectory + wr1.cContents; // readDirectoryContents

exports.creadDirectoryContents = creadDirectoryContents;
var cgetLengthOfLongestStringInArray = wr1.cget + wr1.cLength + wr1.cOf + wr1.cLongest + wr1.cString + bas.cIn + wr1.cArray; // getLengthOfLongestStringInArray

exports.cgetLengthOfLongestStringInArray = cgetLengthOfLongestStringInArray;
var csearchForPatternsInStringArray = wr1.csearch + wr1.cFor + wr1.cPatterns + bas.cIn + wr1.cString + wr1.cArray; // searchForPatternsInStringArray

exports.csearchForPatternsInStringArray = csearchForPatternsInStringArray;
var cvalidatePatternsThatNeedImplementation = wr1.cvalidate + wr1.cPatterns + wr1.cThat + wr1.cNeed + wr1.cImplementation; // validatePatternsThatNeedImplementation

exports.cvalidatePatternsThatNeedImplementation = cvalidatePatternsThatNeedImplementation;
var csolveLehmerCode = wr1.csolve + wr1.cLehmer + wr1.cCode; // solveLehmerCode

exports.csolveLehmerCode = csolveLehmerCode;
var crecursiveArrayExpansion = wr1.crecursive + wr1.cArray + wr1.cExpansion; // recursiveArrayExpansion

exports.crecursiveArrayExpansion = crecursiveArrayExpansion;
var cgetLehmerCodeValue = wr1.cget + wr1.cLehmer + wr1.cCode + wr1.cValue; // getLehmerCodeValue

exports.cgetLehmerCodeValue = cgetLehmerCodeValue;
var carraysAreEqual = wr1.carrays + wr1.cAre + wr1.cEqual; // arraysAreEqual

exports.carraysAreEqual = carraysAreEqual;
var cstoreData = wr1.cstore + wr1.cData; // storeData

exports.cstoreData = cstoreData;
var cgetStoredData = wr1.cget + wr1.cStored + wr1.cData; // getStoredData

exports.cgetStoredData = cgetStoredData;
var cisObjectEmpty = wr1.cis + wr1.cObject + wr1.cEmpty; // isObjectEmpty

exports.cisObjectEmpty = cisObjectEmpty;
var cisArrayEmpty = wr1.cis + wr1.cArray + wr1.cEmpty; // isArrayEmpty

exports.cisArrayEmpty = cisArrayEmpty;
var cisObject = wr1.cis + wr1.cObject; // isObject

exports.cisObject = cisObject;
var cisArray = wr1.cis + wr1.cArray; // isArray

exports.cisArray = cisArray;
var cisArrayOrObject = wr1.cis + wr1.cArray + wr1.cOr + wr1.cObject; // isArrayOrObject

exports.cisArrayOrObject = cisArrayOrObject;
var cisNonZeroLengthArray = wr1.cis + phn.cNon + num.cZero + wr1.cLength + wr1.cArray; // isNonZeroLengthArray

exports.cisNonZeroLengthArray = cisNonZeroLengthArray;
var carrayDeepClone = wr1.carray + wr1.cDeep + wr1.cClone; // arrayDeepClone

exports.carrayDeepClone = carrayDeepClone;
var creplaceCharacterAtIndex = wr1.creplace + wr1.cCharacter + wr1.cAt + wr1.cIndex; // replaceCharacterAtIndex

exports.creplaceCharacterAtIndex = creplaceCharacterAtIndex;
var cgenerateCommandAliases = wr1.cgenerate + wr1.cCommand + wr1.cAliases; // generateCommandAliases

exports.cgenerateCommandAliases = cgenerateCommandAliases;
var caggregateCommandArguments = wr1.caggregate + wr1.cCommand + wr1.cArguments; // aggregateCommandArguments

exports.caggregateCommandArguments = caggregateCommandArguments;
var cgetFileAndPathListForPath = wr1.cget + wr1.cFile + wr1.cAnd + wr1.cPath + wr1.cList + wr1.cFor + wr1.cPath; // getFileAndPathListForPath

exports.cgetFileAndPathListForPath = cgetFileAndPathListForPath;
var cparseColorRangeInputs = wr1.cparse + wr1.cColor + wr1.cRange + wr1.cInputs; // parseColorRangeInputs

exports.cparseColorRangeInputs = cparseColorRangeInputs;
var cdoesArrayContainValue = wr1.cdoes + wr1.cArray + wr1.cContain + wr1.cValue; // doesArrayContainValue
// ***********************************************
// characterGeneration rules in order
// ***********************************************

exports.cdoesArrayContainValue = cdoesArrayContainValue;
var crandomlyGenerateMixedCaseLetterOrSpecialCharacter = wr1.crandomly + wr1.cGenerate + wr1.cMixed + wr1.cCase + wr1.cLetter + wr1.cOr + wr1.cSpecial + wr1.cCharacter; // randomlyGenerateMixedCaseLetterOrSpecialCharacter

exports.crandomlyGenerateMixedCaseLetterOrSpecialCharacter = crandomlyGenerateMixedCaseLetterOrSpecialCharacter;
var crandomlyGenerateUpperCaseLetterOrSpecialCharacter = wr1.crandomly + wr1.cGenerate + wr1.cUpper + wr1.cCase + wr1.cLetter + wr1.cOr + wr1.cSpecial + wr1.cCharacter; // randomlyGenerateUpperCaseLetterOrSpecialCharacter

exports.crandomlyGenerateUpperCaseLetterOrSpecialCharacter = crandomlyGenerateUpperCaseLetterOrSpecialCharacter;
var crandomlyGenerateLowerCaseLetterOrSpecialCharacter = wr1.crandomly + wr1.cGenerate + wr1.cLower + wr1.cCase + wr1.cLetter + wr1.cOr + wr1.cSpecial + wr1.cCharacter; // randomlyGenerateLowerCaseLetterOrSpecialCharacter

exports.crandomlyGenerateLowerCaseLetterOrSpecialCharacter = crandomlyGenerateLowerCaseLetterOrSpecialCharacter;
var crandomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter = wr1.crandomly + wr1.cGenerate + wr1.cEither + wr1.cMixed + wr1.cCase + wr1.cLetter + wr1.cOr + wr1.cNumber + wr1.cOr + wr1.cSpecial + wr1.cCharacter; // randomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter

exports.crandomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter = crandomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter;
var crandomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter = wr1.crandomly + wr1.cGenerate + wr1.cEither + wr1.cUpper + wr1.cCase + wr1.cLetter + wr1.cOr + wr1.cNumber + wr1.cOr + wr1.cSpecial + wr1.cCharacter; // randomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter

exports.crandomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter = crandomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter;
var crandomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter = wr1.crandomly + wr1.cGenerate + wr1.cEither + wr1.cLower + wr1.cCase + wr1.cLetter + wr1.cOr + wr1.cNumber + wr1.cOr + wr1.cSpecial + wr1.cCharacter; // randomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter

exports.crandomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter = crandomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter;
var crandomlyGenerateMixedCaseAlphaNumericCharacter = wr1.crandomly + wr1.cGenerate + wr1.cMixed + wr1.cCase + wr1.cAlpha + wr1.cNumeric + wr1.cCharacter; // randomlyGenerateMixedCaseAlphaNumericCharacter

exports.crandomlyGenerateMixedCaseAlphaNumericCharacter = crandomlyGenerateMixedCaseAlphaNumericCharacter;
var crandomlyGenerateUpperCaseAlphaNumericCharacter = wr1.crandomly + wr1.cGenerate + wr1.cUpper + wr1.cCase + wr1.cAlpha + wr1.cNumeric + wr1.cCharacter; // randomlyGenerateUpperCaseAlphaNumericCharacter

exports.crandomlyGenerateUpperCaseAlphaNumericCharacter = crandomlyGenerateUpperCaseAlphaNumericCharacter;
var crandomlyGenerateLowerCaseAlphaNumericCharacter = wr1.crandomly + wr1.cGenerate + wr1.cLower + wr1.cCase + wr1.cAlpha + wr1.cNumeric + wr1.cCharacter; // randomlyGenerateLowerCaseAlphaNumericCharacter

exports.crandomlyGenerateLowerCaseAlphaNumericCharacter = crandomlyGenerateLowerCaseAlphaNumericCharacter;
var crandomlyGenerateNumericCharacter = wr1.crandomly + wr1.cGenerate + wr1.cNumeric + wr1.cCharacter; // randomlyGenerateNumericCharacter

exports.crandomlyGenerateNumericCharacter = crandomlyGenerateNumericCharacter;
var crandomlyGenerateSpecialCharacter = wr1.crandomly + wr1.cGenerate + wr1.cSpecial + wr1.cCharacter; // randomlyGenerateSpecialCharacter

exports.crandomlyGenerateSpecialCharacter = crandomlyGenerateSpecialCharacter;
var crandomlyGenerateNumberInRange = wr1.crandomly + wr1.cGenerate + wr1.cNumber + wr1.cIn + wr1.cRange; // randomlyGenerateNumberInRange

exports.crandomlyGenerateNumberInRange = crandomlyGenerateNumberInRange;
var crandomlyGenerateBooleanValue = wr1.crandomly + wr1.cGenerate + wr1.cBoolean + wr1.cValue; // randomlyGenerateBooleanValue

exports.crandomlyGenerateBooleanValue = crandomlyGenerateBooleanValue;
var crandomlyGenerateMixedCaseAlphabeticCharacter = wr1.crandomly + wr1.cGenerate + wr1.cMixed + wr1.cCase + wr1.cAlphabetic + wr1.cCharacter; // randomlyGenerateMixedCaseAlphabeticCharacter

exports.crandomlyGenerateMixedCaseAlphabeticCharacter = crandomlyGenerateMixedCaseAlphabeticCharacter;
var crandomlyGenerateLowerCaseLetter = wr1.crandomly + wr1.cGenerate + wr1.cLower + wr1.cCase + wr1.cLetter; // randomlyGenerateLowerCaseLetter

exports.crandomlyGenerateLowerCaseLetter = crandomlyGenerateLowerCaseLetter;
var crandomlyGenerateUpperCaseLetter = wr1.crandomly + wr1.cGenerate + wr1.cUpper + wr1.cCase + wr1.cLetter; // randomlyGenerateUpperCaseLetter

exports.crandomlyGenerateUpperCaseLetter = crandomlyGenerateUpperCaseLetter;
var cconvertNumberToUpperCaseLetter = wr1.cconvert + wr1.cNumber + wr1.cTo + wr1.cUpper + wr1.cCase + wr1.cLetter; // convertNumberToUpperCaseLetter

exports.cconvertNumberToUpperCaseLetter = cconvertNumberToUpperCaseLetter;
var cconvertNumberToLowerCaseLetter = wr1.cconvert + wr1.cNumber + wr1.cTo + wr1.cLower + wr1.cCase + wr1.cLetter; // convertNumberToLowerCaseLetter
// ***********************************************
// mathOperations rules in order
// ***********************************************

exports.cconvertNumberToLowerCaseLetter = cconvertNumberToLowerCaseLetter;
var chex2rgbConversion = gen.chex + num.c2 + gen.crgb + wr1.cConversion; // hex2rgbConversion

exports.chex2rgbConversion = chex2rgbConversion;
var cisOdd = wr1.cis + wr1.cOdd; // isOdd

exports.cisOdd = cisOdd;
var cisEven = wr1.cis + wr1.cEven; // isEven
// ***********************************************
// stringGeneration rules in order
// ***********************************************

exports.cisEven = cisEven;
var cgenerateRandomMixedCaseTextByLength = wr1.cgenerate + wr1.cRandom + wr1.cMixed + wr1.cCase + wr1.cText + wr1.cBy + wr1.cLength; // generateRandomMixedCaseTextByLength

exports.cgenerateRandomMixedCaseTextByLength = cgenerateRandomMixedCaseTextByLength;
var cgenerateRandomUpperCaseTextByLength = wr1.cgenerate + wr1.cRandom + wr1.cUpper + wr1.cCase + wr1.cText + wr1.cBy + wr1.cLength; // generateRandomUpperCaseTextByLength

exports.cgenerateRandomUpperCaseTextByLength = cgenerateRandomUpperCaseTextByLength;
var cgenerateRandomLowerCaseTextByLength = wr1.cgenerate + wr1.cRandom + wr1.cLower + wr1.cCase + wr1.cText + wr1.cBy + wr1.cLength; // generateRandomLowerCaseTextByLength

exports.cgenerateRandomLowerCaseTextByLength = cgenerateRandomLowerCaseTextByLength;
var cgenerateRandomMixedCaseTextWithSpecialCharactersByLength = wr1.cgenerate + wr1.cRandom + wr1.cMixed + wr1.cCase + wr1.cText + wr1.cWith + wr1.cSpecial + wr1.cCharacters + wr1.cBy + wr1.cLength; // generateRandomMixedCaseTextWithSpecialCharactersByLength

exports.cgenerateRandomMixedCaseTextWithSpecialCharactersByLength = cgenerateRandomMixedCaseTextWithSpecialCharactersByLength;
var cgenerateRandomUpperCaseTextWithSpecialCharactersByLength = wr1.cgenerate + wr1.cRandom + wr1.cUpper + wr1.cCase + wr1.cText + wr1.cWith + wr1.cSpecial + wr1.cCharacters + wr1.cBy + wr1.cLength; // generateRandomUpperCaseTextWithSpecialCharactersByLength

exports.cgenerateRandomUpperCaseTextWithSpecialCharactersByLength = cgenerateRandomUpperCaseTextWithSpecialCharactersByLength;
var cgenerateRandomLowerCaseTextWithSpecialCharactersByLength = wr1.cgenerate + wr1.cRandom + wr1.cLower + wr1.cCase + wr1.cText + wr1.cWith + wr1.cSpecial + wr1.cCharacters + wr1.cBy + wr1.cLength; // generateRandomLowerCaseTextWithSpecialCharactersByLength

exports.cgenerateRandomLowerCaseTextWithSpecialCharactersByLength = cgenerateRandomLowerCaseTextWithSpecialCharactersByLength;
var cgenerateRandomMixedCaseAlphaNumericCodeByLength = wr1.cgenerate + wr1.cRandom + wr1.cMixed + wr1.cCase + wr1.cAlpha + wr1.cNumeric + wr1.cCode + wr1.cBy + wr1.cLength; // generateRandomMixedCaseAlphaNumericCodeByLength

exports.cgenerateRandomMixedCaseAlphaNumericCodeByLength = cgenerateRandomMixedCaseAlphaNumericCodeByLength;
var cgenerateRandomUpperCaseAlphaNumericCodeByLength = wr1.cgenerate + wr1.cRandom + wr1.cUpper + wr1.cCase + wr1.cAlpha + wr1.cNumeric + wr1.cCode + wr1.cBy + wr1.cLength; // generateRandomUpperCaseAlphaNumericCodeByLength

exports.cgenerateRandomUpperCaseAlphaNumericCodeByLength = cgenerateRandomUpperCaseAlphaNumericCodeByLength;
var cgenerateRandomLowerCaseAlphaNumericCodeByLength = wr1.cgenerate + wr1.cRandom + wr1.cLower + wr1.cCase + wr1.cAlpha + wr1.cNumeric + wr1.cCode + wr1.cBy + wr1.cLength; // generateRandomLowerCaseAlphaNumericCodeByLength

exports.cgenerateRandomLowerCaseAlphaNumericCodeByLength = cgenerateRandomLowerCaseAlphaNumericCodeByLength;
var cgenerateRandomNumericCodeByLength = wr1.cgenerate + wr1.cRandom + wr1.cNumeric + wr1.cCode + wr1.cBy + wr1.cLength; // generateRandomNumericCodeByLength

exports.cgenerateRandomNumericCodeByLength = cgenerateRandomNumericCodeByLength;
var cgenerateRandomMixedCaseAlphaNumericCodeWithSpecialCharactersByLength = wr1.cgenerate + wr1.cRandom + wr1.cMixed + wr1.cCase + wr1.cAlpha + wr1.cNumeric + wr1.cCode + wr1.cWith + wr1.cSpecial + wr1.cCharacters + wr1.cBy + wr1.cLength; // generateRandomMixedCaseAlphaNumericCodeWithSpecialCharactersByLength

exports.cgenerateRandomMixedCaseAlphaNumericCodeWithSpecialCharactersByLength = cgenerateRandomMixedCaseAlphaNumericCodeWithSpecialCharactersByLength;
var cgenerateRandomUpperCaseAlphaNumericCodeWithSpecialCharactersByLength = wr1.cgenerate + wr1.cRandom + wr1.cUpper + wr1.cCase + wr1.cAlpha + wr1.cNumeric + wr1.cCode + wr1.cWith + wr1.cSpecial + wr1.cCharacters + wr1.cBy + wr1.cLength; // generateRandomUpperCaseAlphaNumericCodeWithSpecialCharactersByLength

exports.cgenerateRandomUpperCaseAlphaNumericCodeWithSpecialCharactersByLength = cgenerateRandomUpperCaseAlphaNumericCodeWithSpecialCharactersByLength;
var cgenerateRandomLowerCaseAlphaNumericCodeWithSpecialCharactersByLength = wr1.cgenerate + wr1.cRandom + wr1.cLower + wr1.cCase + wr1.cAlpha + wr1.cNumeric + wr1.cCode + wr1.cWith + wr1.cSpecial + wr1.cCharacters + wr1.cBy + wr1.cLength; // generateRandomLowerCaseAlphaNumericCodeWithSpecialCharactersByLength

exports.cgenerateRandomLowerCaseAlphaNumericCodeWithSpecialCharactersByLength = cgenerateRandomLowerCaseAlphaNumericCodeWithSpecialCharactersByLength;
var cgenerateRandomSpecialCharacterCodeByLength = wr1.cgenerate + wr1.cRandom + wr1.cSpecial + wr1.cCharacter + wr1.cCode + wr1.cBy + wr1.cLength; // generateRandomSpecialCharacterCodeByLength

exports.cgenerateRandomSpecialCharacterCodeByLength = cgenerateRandomSpecialCharacterCodeByLength;
var cgenerateValidEmail = wr1.cgenerate + wr1.cValid + wr1.cEmail; // generateValidEmail

exports.cgenerateValidEmail = cgenerateValidEmail;
var cgenerateInvalidEmail = wr1.cgenerate + wr1.cInvalid + wr1.cEmail; // generateInvalidEmail

exports.cgenerateInvalidEmail = cgenerateInvalidEmail;
var cgenerateValidEmailWithSpecificSuffixAndDomainName = wr1.cgenerate + wr1.cValid + wr1.cEmail + wr1.cWith + wr1.cSpecific + wr1.cSuffix + wr1.cAnd + wr1.cDomain + wr1.cName; // generateValidEmailWithSpecificSuffixAndDomainName

exports.cgenerateValidEmailWithSpecificSuffixAndDomainName = cgenerateValidEmailWithSpecificSuffixAndDomainName;
var cgenerateRandomValidEmail = wr1.cgenerate + wr1.cRandom + wr1.cValid + wr1.cEmail; // generateRandomValidEmail

exports.cgenerateRandomValidEmail = cgenerateRandomValidEmail;
var cgenerateInvalidEmailWithSpecificSuffixAndDomainName = wr1.cgenerate + wr1.cInvalid + wr1.cEmail + wr1.cWith + wr1.cSpecific + wr1.cSuffix + wr1.cAnd + wr1.cDomain + wr1.cName; // generateInvalidEmailWithSpecificSuffixAndDomainName

exports.cgenerateInvalidEmailWithSpecificSuffixAndDomainName = cgenerateInvalidEmailWithSpecificSuffixAndDomainName;
var cgenerateRandomInvalidEmail = wr1.cgenerate + wr1.cRandom + wr1.cInvalid + wr1.cEmail; // generateRandomInvalidEmail

exports.cgenerateRandomInvalidEmail = cgenerateRandomInvalidEmail;
var cgenerateRandomBrightColor = wr1.cgenerate + wr1.cRandom + wr1.cBright + wr1.cColor; // generateRandomBrightColor

exports.cgenerateRandomBrightColor = cgenerateRandomBrightColor;
var cgenerateRandomDarkColor = wr1.cgenerate + wr1.cRandom + wr1.cDark + wr1.cColor; // generateRandomDarkColor

exports.cgenerateRandomDarkColor = cgenerateRandomDarkColor;
var cgenerateRandomColor = wr1.cgenerate + wr1.cRandom + wr1.cColor; // generateRandomColor
// ***********************************************
// StringParsing rules in order
// ***********************************************

exports.cgenerateRandomColor = cgenerateRandomColor;
var csingleQuoteSwapAfterEquals = wr1.csingle + wr1.cQuote + wr1.cSwap + wr1.cAfter + wr1.cEquals; // singleQuoteSwapAfterEquals

exports.csingleQuoteSwapAfterEquals = csingleQuoteSwapAfterEquals;
var cswapForwardSlashToBackSlash = wr1.cswap + sys.cForwardSlash + bas.cTo + sys.cBackSlash; // swapForwardSlashToBackSlash

exports.cswapForwardSlashToBackSlash = cswapForwardSlashToBackSlash;
var cswapBackSlashToForwardSlash = wr1.cswap + sys.cBackSlash + bas.cTo + sys.cForwardSlash; // swapBackSlashToForwardSlash

exports.cswapBackSlashToForwardSlash = cswapBackSlashToForwardSlash;
var cswapDoubleForwardSlashToSingleForwardSlash = wr1.cswap + wr1.cDouble + sys.cForwardSlash + bas.cTo + wr1.cSingle + sys.cForwardSlash; // swapDoubleForwardSlashToSingleForwardSlash

exports.cswapDoubleForwardSlashToSingleForwardSlash = cswapDoubleForwardSlashToSingleForwardSlash;
var cswapDoubleBackSlashToSingleBackSlash = wr1.cswap + wr1.cDouble + sys.cBackSlash + bas.cTo + wr1.cSingle + sys.cBackSlash; // swapDoubleBackSlashToSingleBackSlash

exports.cswapDoubleBackSlashToSingleBackSlash = cswapDoubleBackSlashToSingleBackSlash;
var cgetUserNameFromEmail = wr1.cget + wr1.cUser + wr1.cName + wr1.cFrom + wr1.cEmail; // getUserNameFromEmail

exports.cgetUserNameFromEmail = cgetUserNameFromEmail;
var creplaceSpacesWithPlus = wr1.creplace + wr1.cSpaces + wr1.cWith + wr1.cPlus; // replaceSpacesWithPlus

exports.creplaceSpacesWithPlus = creplaceSpacesWithPlus;
var creplaceColonWithUnderscore = wr1.creplace + wr1.cColon + wr1.cWith + wr1.cUnderscore; // replaceColonWithUnderscore

exports.creplaceColonWithUnderscore = creplaceColonWithUnderscore;
var ccleanCarriageReturnFromString = wr1.cclean + wr1.cCarriage + wr1.cReturn + wr1.cFrom + wr1.cString; // cleanCarriageReturnFromString

exports.ccleanCarriageReturnFromString = ccleanCarriageReturnFromString;
var cconvertStringToLowerCase = wr1.cconvert + wr1.cString + wr1.cTo + wr1.cLower + wr1.cCase; // convertStringToLowerCase

exports.cconvertStringToLowerCase = cconvertStringToLowerCase;
var cconvertStringToUpperCase = wr1.cconvert + wr1.cString + wr1.cTo + wr1.cUpper + wr1.cCase; // convertStringToUpperCase

exports.cconvertStringToUpperCase = cconvertStringToUpperCase;
var cgetFileNameFromPath = wr1.cget + wr1.cFile + wr1.cName + wr1.cFrom + wr1.cPath; // getFileNameFromPath

exports.cgetFileNameFromPath = cgetFileNameFromPath;
var cgetFileExtension = wr1.cget + wr1.cFile + wr1.cExtension; // getFileExtension

exports.cgetFileExtension = cgetFileExtension;
var cremoveDotFromFileExtension = wr1.cremove + wr1.cDot + wr1.cFrom + wr1.cFile + wr1.cExtension; // removeDotFromFileExtension

exports.cremoveDotFromFileExtension = cremoveDotFromFileExtension;
var cremoveFileExtensionFromFileName = wr1.cremove + wr1.cFile + wr1.cExtension + wr1.cFrom + wr1.cFileName; // removeFileExtensionFromFileName

exports.cremoveFileExtensionFromFileName = cremoveFileExtensionFromFileName;
var cgetValueFromAssignmentOperationString = wr1.cget + wr1.cValue + wr1.cFrom + wr1.cAssignment + wr1.cOperation + wr1.cString; // getValueFromAssignmentOperationString

exports.cgetValueFromAssignmentOperationString = cgetValueFromAssignmentOperationString;
var caggregateNumericalDifferenceBetweenTwoStrings = wr1.caggregate + wr1.cNumerical + wr1.cDifference + wr1.cBetween + num.cTwo + wr1.cStrings; // aggregateNumericalDifferenceBetweenTwoStrings

exports.caggregateNumericalDifferenceBetweenTwoStrings = caggregateNumericalDifferenceBetweenTwoStrings;
var ccountCamelCaseWords = wr1.ccount + wr1.cCamel + wr1.cCase + wr1.cWords; // countCamelCaseWords

exports.ccountCamelCaseWords = ccountCamelCaseWords;
var cdoesStringContainAcronym = wr1.cdoes + wr1.cString + wr1.cContain + wr1.cAcronym; // doesStringContainAcronym

exports.cdoesStringContainAcronym = cdoesStringContainAcronym;
var ccountDelimiterInString = wr1.ccount + wr1.cDelimiter + wr1.cIn + wr1.cString; // countDelimiterInString

exports.ccountDelimiterInString = ccountDelimiterInString;
var cdetermineWordDelimiter = wr1.cdetermine + wr1.cWord + wr1.cDelimiter; // determineWordDelimiter

exports.cdetermineWordDelimiter = cdetermineWordDelimiter;
var cgetWordCountInString = wr1.cget + wr1.cWord + wr1.cCount + wr1.cIn + wr1.cString; // getWordCountInString

exports.cgetWordCountInString = cgetWordCountInString;
var cdoesStringContainUpperCaseCharacter = wr1.cdoes + wr1.cString + wr1.cContain + wr1.cUpper + wr1.cCase + wr1.cCharacter; // doesStringContainUpperCaseCharacter

exports.cdoesStringContainUpperCaseCharacter = cdoesStringContainUpperCaseCharacter;
var cdoesStringContainLowerCaseCharacter = wr1.cdoes + wr1.cString + wr1.cContain + wr1.cLower + wr1.cCase + wr1.cCharacter; // doesStringContainLowerCaseCharacter

exports.cdoesStringContainLowerCaseCharacter = cdoesStringContainLowerCaseCharacter;
var cisFirstCharacterLowerCase = wr1.cis + num.cFirst + wr1.cCharacter + wr1.cLower + wr1.cCase; // isFirstCharacterLowerCase

exports.cisFirstCharacterLowerCase = cisFirstCharacterLowerCase;
var cisFirstCharacterUpperCase = wr1.cis + num.cFirst + wr1.cCharacter + wr1.cUpper + wr1.cCase; // isFirstCharacterUpperCase

exports.cisFirstCharacterUpperCase = cisFirstCharacterUpperCase;
var cisStringList = wr1.cis + wr1.cString + wr1.cList; // isStringList

exports.cisStringList = cisStringList;
var cisStringCamelCase = wr1.cis + wr1.cString + wr1.cCamel + wr1.cCase; // isStringCamelCase

exports.cisStringCamelCase = cisStringCamelCase;
var cmapWordToCamelCaseWord = wr1.cmap + wr1.cWord + wr1.cTo + wr1.cCamel + wr1.cCase + wr1.cWord; // mapWordToCamelCaseWord

exports.cmapWordToCamelCaseWord = cmapWordToCamelCaseWord;
var csimplifyAndConsolidateString = wr1.csimplify + wr1.cAnd + wr1.cConsolidate + wr1.cString; // simplifyAndConsolidateString

exports.csimplifyAndConsolidateString = csimplifyAndConsolidateString;
var ccompareSimplifiedAndConsolidatedStrings = wr1.ccompare + wr1.cSimplified + wr1.cAnd + wr1.cConsolidated + wr1.cStrings; // compareSimplifiedAndConsolidatedStrings

exports.ccompareSimplifiedAndConsolidatedStrings = ccompareSimplifiedAndConsolidatedStrings;
var cascertainMatchingFilenames = wr1.cascertain + wr1.cMatching + wr1.cFilenames; // ascertainMatchingFilenames

exports.cascertainMatchingFilenames = cascertainMatchingFilenames;
var cvalidateConstantsDataValidation = wr1.cvalidate + wr1.cConstants + wr1.cData + wr1.cValidation; // validateConstantsDataValidation

exports.cvalidateConstantsDataValidation = cvalidateConstantsDataValidation;
var cdetermineConstantsContextQualifiedPrefix = wr1.cdetermine + wr1.cConstants + wr1.cContext + wr1.cQualified + wr1.cPrefix; // determineConstantsContextQualifiedPrefix

exports.cdetermineConstantsContextQualifiedPrefix = cdetermineConstantsContextQualifiedPrefix;
var cdetermineSuggestedConstantsValidationLineOfCode = wr1.cdetermine + wr1.cSuggested + wr1.cConstants + wr1.cValidation + wr1.cLine + wr1.cOf + wr1.cCode; // determineSuggestedConstantsValidationLineOfCode

exports.cdetermineSuggestedConstantsValidationLineOfCode = cdetermineSuggestedConstantsValidationLineOfCode;
var cvalidateConstantsDataValidationLineItemName = wr1.cvalidate + wr1.cConstants + wr1.cData + wr1.cValidation + wr1.cLine + wr1.cItem + wr1.cName; // validateConstantsDataValidationLineItemName

exports.cvalidateConstantsDataValidationLineItemName = cvalidateConstantsDataValidationLineItemName;
var cdoesConstantExist = wr1.cdoes + wr1.cConstant + wr1.cExist; // doesConstantExist

exports.cdoesConstantExist = cdoesConstantExist;
var cgetConstantType = wr1.cget + wr1.cConstant + wr1.cType; // getConstantType

exports.cgetConstantType = cgetConstantType;
var cgetConstantActualValue = wr1.cget + wr1.cConstant + wr1.cActual + wr1.cValue; // getConstantActualValue

exports.cgetConstantActualValue = cgetConstantActualValue;
var cgetConstantName = wr1.cget + wr1.cConstant + wr1.cName; // getConstantName

exports.cgetConstantName = cgetConstantName;
var cfindConstantName = wr1.cfind + wr1.cConstant + wr1.cName; // findConstantName

exports.cfindConstantName = cfindConstantName;
var cisConstantTypeValid = wr1.cis + wr1.cConstant + wr1.cType + wr1.cValid; // isConstantTypeValid

exports.cisConstantTypeValid = cisConstantTypeValid;
var cconvertConstantTypeToConstantPrefix = wr1.cconvert + wr1.cConstant + wr1.cType + wr1.cTo + wr1.cConstant + wr1.cPrefix; // convertConstantTypeToConstantPrefix

exports.cconvertConstantTypeToConstantPrefix = cconvertConstantTypeToConstantPrefix;
var cconstantsOptimizedFulfillmentSystem = wr1.cconstants + wr1.cOptimized + wr1.cFulfillment + wr1.cSystem; // constantsOptimizedFulfillmentSystem

exports.cconstantsOptimizedFulfillmentSystem = cconstantsOptimizedFulfillmentSystem;
var cconstantsFulfillmentSystem = wr1.cconstants + wr1.cFulfillment + wr1.cSystem; // constantsFulfillmentSystem

exports.cconstantsFulfillmentSystem = cconstantsFulfillmentSystem;
var cvalidateConstantsDataValues = wr1.cvalidate + wr1.cConstants + wr1.cData + wr1.cValues; // validateConstantsDataValues

exports.cvalidateConstantsDataValues = cvalidateConstantsDataValues;
var cisValidCommandNameString = wr1.cis + wr1.cValid + wr1.cCommand + wr1.cName + wr1.cString; // isValidCommandNameString

exports.cisValidCommandNameString = cisValidCommandNameString;
var cisConstantValid = wr1.cis + wr1.cConstant + wr1.cValid; // isConstantValid

exports.cisConstantValid = cisConstantValid;
var ccountDuplicateCommandAliases = wr1.ccount + wr1.cDuplicate + wr1.cCommand + wr1.cAliases; // countDuplicateCommandAliases

exports.ccountDuplicateCommandAliases = ccountDuplicateCommandAliases;
var cgetDataCatagoryFromDataContextName = wr1.cget + wr1.cData + wr1.cCatagory + wr1.cFrom + wr1.cData + wr1.cContext + wr1.cName; // getDataCatagoryFromDataContextName

exports.cgetDataCatagoryFromDataContextName = cgetDataCatagoryFromDataContextName;
var cgetDataCatagoryDetailNameFromDataContextName = wr1.cget + wr1.cData + wr1.cCatagory + wr1.cDetail + wr1.cName + wr1.cFrom + wr1.cData + wr1.cContext + wr1.cName; // getDataCatagoryDetailNameFromDataContextName

exports.cgetDataCatagoryDetailNameFromDataContextName = cgetDataCatagoryDetailNameFromDataContextName;
var cgetKeywordNameFromDataContextName = wr1.cget + wr1.cKeyword + wr1.cName + wr1.cFrom + wr1.cData + wr1.cContext + wr1.cName; // getKeywordNameFromDataContextName

exports.cgetKeywordNameFromDataContextName = cgetKeywordNameFromDataContextName;
var cremoveXnumberOfFoldersFromEndOfPath = wr1.cremove + bas.cX + wr1.cnumber + wr1.cOf + wr1.cFolders + wr1.cFrom + wr1.cEnd + wr1.cOf + wr1.cPath; // removeXnumberOfFoldersFromEndOfPath

exports.cremoveXnumberOfFoldersFromEndOfPath = cremoveXnumberOfFoldersFromEndOfPath;
var cgetFirstTopLevelFolderFromPath = wr1.cget + num.cFirst + wr1.cTop + wr1.cLevel + wr1.cFolder + wr1.cFrom + wr1.cPath; // getFirstTopLevelFolderFromPath

exports.cgetFirstTopLevelFolderFromPath = cgetFirstTopLevelFolderFromPath;
var cloadDataFile = wr1.cload + wr1.cData + wr1.cFile; // loadDataFile

exports.cloadDataFile = cloadDataFile;
var csaveDataFile = wr1.csave + wr1.cData + wr1.cFile; // saveDataFile

exports.csaveDataFile = csaveDataFile;
var csupportedFileFormatsAre = wr1.csupported + wr1.cFile + wr1.cFormats + wr1.cAre; // supportedFileFormatsAre

exports.csupportedFileFormatsAre = csupportedFileFormatsAre;
var ccopyAllFilesAndFoldersFromFolderToFolder = wr1.ccopy + wr1.cAll + wr1.cFiles + wr1.cAnd + wr1.cFolders + wr1.cFrom + wr1.cFolder + wr1.cTo + wr1.cFolder; // copyAllFilesAndFoldersFromFolderToFolder

exports.ccopyAllFilesAndFoldersFromFolderToFolder = ccopyAllFilesAndFoldersFromFolderToFolder;
var cgetAttributeName = wr1.cget + wr1.cAttribute + wr1.cName; // getAttributeName

exports.cgetAttributeName = cgetAttributeName;
var cgetAttributeValue = wr1.cget + wr1.cAttribute + wr1.cValue; // getAttributeValue

exports.cgetAttributeValue = cgetAttributeValue;
var ccleanCommandInput = wr1.cclean + wr1.cCommand + wr1.cInput; // cleanCommandInput

exports.ccleanCommandInput = ccleanCommandInput;
var cgetNowMoment = wr1.cget + wr1.cNow + wr1.cMoment; // getNowMoment

exports.cgetNowMoment = cgetNowMoment;
var ccreateZipArchive = wr1.ccreate + gen.cZip + wr1.cArchive; // createZipArchive
// ***********************************************
// StringParsingUtiities rules in order
// ***********************************************

exports.ccreateZipArchive = ccreateZipArchive;
var cparseSystemRootPath = wr1.cparse + wr1.cSystem + wr1.cRoot + wr1.cPath; // parseSystemRootPath

exports.cparseSystemRootPath = cparseSystemRootPath;
var cstringToDataType = wr1.cstring + wr1.cTo + wr1.cData + wr1.cType; // stringToDataType

exports.cstringToDataType = cstringToDataType;
var cstringToBoolean = wr1.cstring + wr1.cTo + wr1.cBoolean; // stringToBoolean

exports.cstringToBoolean = cstringToBoolean;
var cdetermineObjectDataType = wr1.cdetermine + wr1.cObject + wr1.cData + wr1.cType; // determineObjectDataType

exports.cdetermineObjectDataType = cdetermineObjectDataType;
var cisBoolean = wr1.cis + wr1.cBoolean; // isBoolean

exports.cisBoolean = cisBoolean;
var cisInteger = wr1.cis + wr1.cInteger; // isInteger

exports.cisInteger = cisInteger;
var cisFloat = wr1.cis + wr1.cFloat; // isFloat

exports.cisFloat = cisFloat;
var cisString = wr1.cis + wr1.cString; // isString

exports.cisString = cisString;
var creplaceDoublePercentWithMessage = wr1.creplace + wr1.cDouble + wr1.cPercent + wr1.cWith + wr1.cMessage; // replaceDoublePercentWithMessage

exports.creplaceDoublePercentWithMessage = creplaceDoublePercentWithMessage;
var cutilitiesReplaceCharacterWithCharacter = wr1.cutilities + wr1.cReplace + wr1.cCharacter + wr1.cWith + wr1.cCharacter; // utilitiesReplaceCharacterWithCharacter

exports.cutilitiesReplaceCharacterWithCharacter = cutilitiesReplaceCharacterWithCharacter;