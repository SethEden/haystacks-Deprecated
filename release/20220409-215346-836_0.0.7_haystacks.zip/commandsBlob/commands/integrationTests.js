"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _ruleBroker = _interopRequireDefault(require("../../brokers/ruleBroker.js"));

var bas = _interopRequireWildcard(require("../../constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("../../constants/business.constants.js"));

var cfg = _interopRequireWildcard(require("../../constants/configuration.constants.js"));

var msg = _interopRequireWildcard(require("../../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../../constants/word1.constants.js"));

var _configurator = _interopRequireDefault(require("../../executrix/configurator.js"));

var _loggers = _interopRequireDefault(require("../../executrix/loggers.js"));

var _data = _interopRequireDefault(require("../../structures/data.js"));

var _path2 = _interopRequireDefault(require("path"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

/**
 * @file integrationTests.js
 * @module integrationTests
 * @description Contains all of the commands to test various components of the system.
 * @requires module:ruleBroker
 * @requires module:basic.constants
 * @requires module:business.constants
 * @requires module:configuration.constants
 * @requires module:message.constants
 * @requires module:system.constants
 * @requires module:word1.constants
 * @requires module:configurator
 * @requires module:loggers
 * @requires module:data
 * @requires {@link https://www.npmjs.com/package/path|path}
 * @author Seth Hollingsead
 * @date 2022/03/25
 * @copyright Copyright © 2022-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// External imports
var baseFileName = _path2["default"].basename(import.meta.url, _path2["default"].extname(import.meta.url)); // commandsBlob.commands.integrationTests.


var namespacePrefix = sys.ccommandsBlob + bas.cDot + wr1.ccommands + bas.cDot + baseFileName + bas.cDot;
/**
 * @function validateConstants
 * @description Validates all constants with a 2-phase verification process.
 * @param {string} inputData Not used for this command.
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/03/25
 */

var validateConstants = function validateConstants(inputData, inputMetaData) {
  var functionName = validateConstants.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableConstantsValidation) === true) {
    // Get the array of keys and values for all the constants that need to be validated.
    var validationArray = _data["default"][sys.cConstantsValidationData][sys.cConstantsFilePaths]; // This will return an object with all of the key-value pair attributes we need.

    var phase1FinalResult = true;
    var phase2FinalResult = true;
    var phase1Results = {};
    var phase2Results = {};
    var phase1ResultsKeysArray = [];
    var phase2ResultsKeysArray = [];
    var rulesPhase1 = [];
    var rulesPhase2 = [];
    rulesPhase1[0] = biz.cvalidateConstantsDataValidation;
    rulesPhase2[0] = biz.cvalidateConstantsDataValues; // Phase1 Constants Validation
    // BEGIN Phase 1 Constants Validation

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBeginPhase1ConstantsValidation); // First scan through each file and vaidate that the constants defined in the constants code file are also contained in the validation file.


    for (var key1 in validationArray) {
      var _path = validationArray[key1];
      phase1Results[key1] = _ruleBroker["default"].processRules(_path, key1, rulesPhase1);
    }

    phase1ResultsKeysArray = phase1Results.keys; // END Phase 1 Constants Validation

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEndPhase1ConstantsValidation); // Phase 2 Constants Validation
    // BEGIN Phase 2 Constants Validation


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBeginPhase2ConstantsValidation); // Now verify that the values of the constants are what they are expected to be by using the constants validation data to validate.


    for (var key2 in validationArray) {
      phase2Results[key2] = _ruleBroker["default"].processRules(key2, '', rulesPhase2);
    }

    phase2ResultsKeysArray = phase2Results.keys; // END Phase 2 Constants Vaidation

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEndPhase2ConstantsValidation);

    for (var key3 in phase1Results) {
      _loggers["default"].constantsValidationSummaryLog(_data["default"][sys.cConstantsValidationData][sys.cConstantsPhase1ValidationMessages][key3], phase1Results[key3]);

      if (phase1Results[key3] === false) {
        phase1FinalResult = false;
      }
    } // End-for (let key3 in phase1ResultsArray)


    for (var key4 in phase2Results) {
      _loggers["default"].constantsValidationSummaryLog(_data["default"][sys.cConstantsValidationData][sys.cConstantsPhase2ValidationMessages][key4], phase2Results[key4]);

      if (phase2Results[key4] === false) {
        phase2FinalResult = false;
      }
    }

    if (phase1FinalResult === true && phase2FinalResult === true) {
      _configurator["default"].setConfigurationSetting(wr1.csystem, cfg.cpassAllConstantsValidation, true);
    } else {
      _configurator["default"].setConfigurationSetting(wr1.csystem, cfg.cpassAllConstantsValidation, false);
    }
  } else {
    // The enableConstantsValidation flag is disabled. Enable this flag in the configuration settings to activate this command.
    console.log(msg.ccconstantsGeneratorMessage3 + msg.cconstantsGeneratorMessage4);

    _configurator["default"].setConfigurationSetting(wr1.csystem, cfg.cpassAllConstantsValidation, false);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function validateCommandAliases
 * @description Validates all command aliases have no duplicates within a command, but also between commands.
 * @param {string} inputData Not used for this command.
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/03/30
 */


var validateCommandAliases = function validateCommandAliases(inputData, inputMetaData) {
  var functionName = validateCommandAliases.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;
  var allCommandAliases = _data["default"][sys.cCommandsAliases][wr1.cCommands];
  var passedAllCommandAliasesDuplicateCheck = true;
  var rules = [];
  rules[0] = biz.ccountDuplicateCommandAliases;

  loop1: for (var key1 in allCommandAliases) {
    // key1 is:
    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ckey1Is + key1);

    var currentCommand = allCommandAliases[key1]; // currentCommand is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccurrentCommandIs + JSON.stringify(currentCommand));

    var aliasList = currentCommand[wr1.cAliases]; // aliasList is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.caliasListIs + aliasList);

    var arrayOfAliases = aliasList.split(bas.cComa);

    loop2: for (var j = 0; j < arrayOfAliases.length; j++) {
      // BEGIN j-th loop:
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_jthLoop + j);

      var currentAlias = arrayOfAliases[j]; // currentAlias is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccurrentAliasIs + currentAlias);

      var duplicateAliasCount = _ruleBroker["default"].processRules(currentAlias, allCommandAliases, rules);

      if (duplicateAliasCount > 1) {
        passedAllCommandAliasesDuplicateCheck = false;
      } // END j-th loop:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_jthLoop + j);
    } // End-for (let j = 0; j < arrayOfAliases.length; j++)

  } // End-for (let i = 0; i < allCommandAliases.length; i++)


  if (passedAllCommandAliasesDuplicateCheck === true) {
    // PASSED: All duplicate command aliases validation tests!
    console.log(msg.cvalidateCommandAliasesMessage1);
  }

  _configurator["default"].setConfigurationSetting(wr1.csystem, cfg.cpassedAllCommandAliasesDuplicateChecks, passedAllCommandAliasesDuplicateCheck);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};

var _default = {
  validateConstants: validateConstants,
  validateCommandAliases: validateCommandAliases
};
exports["default"] = _default;