"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _stringParsingUtilities = _interopRequireDefault(require("./stringParsingUtilities.js"));

var bas = _interopRequireWildcard(require("../../constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("../../constants/business.constants.js"));

var gen = _interopRequireWildcard(require("../../constants/generic.constants.js"));

var msg = _interopRequireWildcard(require("../../constants/message.constants.js"));

var num = _interopRequireWildcard(require("../../constants/numeric.constants.js"));

var sys = _interopRequireWildcard(require("../../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../../constants/word1.constants.js"));

var _loggers = _interopRequireDefault(require("../../executrix/loggers.js"));

var _path = _interopRequireDefault(require("path"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

/**
 * @file characterGeneration.js
 * @module characterGeneration
 * @description Contains all business rules for randomly generating characters of all kinds.
 * @requires module:stringParsingUtilities
 * @requires module:basic.constants
 * @requires module:business.constants
 * @requires module:generic.constants
 * @requires module:message.constants
 * @requires module:numeric.constants
 * @requires module:system.constants
 * @requires module:word1.constants
 * @requires module:loggers
 * @requires {@link https://www.npmjs.com/package/path|path}
 * @author Seth Hollingsead
 * @date 2022/01/25
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// External imports
var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // businessRules.rules.characterGeneration.


var namespacePrefix = sys.cbusinessRules + bas.cDot + wr1.crules + bas.cDot + baseFileName + bas.cDot;
/**
 * @function randomlyGenerateMixedCaseLetterOrSpecialCharacter
 * @description Randomly geenrates an english alphabetic letter from A-Z, a-z or
 * a random special character from the input list of special characters.
 * @param {string} inputData the list of allowable special characters that should be used to randomly select from.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} Randomly returns a random mixed case letter of the english alphabet,
 * or a random special character from the list of alowable special characters.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */

var randomlyGenerateMixedCaseLetterOrSpecialCharacter = function randomlyGenerateMixedCaseLetterOrSpecialCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateMixedCaseLetterOrSpecialCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + JSON.stringify(inputMetaData));

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(inputData + gen.cUpperCaseEnglishAlphabet + gen.cLowerCaseEnglishAlphabet);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + JSON.stringify(returnData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateUpperCaseLetterOrSpecialCharacter
 * @description Randomly generates an english alphabetic letter from A-Z or
 * a random special character from the input list of special characters.
 * @param {string} inputData The list of allowable special characters that should be used to randomly select from.
 * @param {string} inputMetaData Not used for this busienss rule.
 * @return {string} Randomly returns a random upper case letter of the english alphabet,
 * or a random special character from the ist of allowable special characters.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateUpperCaseLetterOrSpecialCharacter = function randomlyGenerateUpperCaseLetterOrSpecialCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateUpperCaseLetterOrSpecialCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(inputData + gen.cUpperCaseEnglishAlphabet);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateLowerCaseLetterOrSpecialCharacter
 * @descriptiong Randomly generates an english alphabetic letter from a-z or
 * a random special character from the intpu list of special characters.
 * @param {string} inputData The list of allowable special characters that should be used  to ranomly select from.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} Randomly returns a random lower case letter of the english alphabet,
 * or a random special character from the list of allowable special characters.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateLowerCaseLetterOrSpecialCharacter = function randomlyGenerateLowerCaseLetterOrSpecialCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateLowerCaseLetterOrSpecialCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(inputData + gen.cLowerCaseEnglishAlphabet);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter
 * @description Randomly generates an alphabetic letter from A-Z, a-z or a number 0-9 or
 * a random special character from the iput ist of special characters.
 * @param {string} inputData The list of allowable special characters that should be used to randomly select from.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} Randomly returns a random number, a random mixed case letter of the english alphabet,
 * or a random special character from the ist of allowable special characters.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter = function randomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(inputData + gen.cUpperCaseEnglishAlphabet + gen.cLowerCaseEnglishAlphabet + gen.cAllNumbers);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter
 * @description Randomly generates an english alphabetic letter from A-Z or a number 0-9 or
 * a random special character from the input ist of special characters.
 * @param {string} inputData The list orf allowable special characters that should be used to randomly select from.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} Randomly returns a random number, a random upper case letter of the engish alphabet,
 * or a random special character from the list of allowable special characters.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter = function randomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(inputData + gen.cUpperCaseEnglishAlphabet + gen.cAllNumbers);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter
 * @description Randomly generates an english alphabetic letter from a-z or a number 0-9 or
 * a random special character from the input list of special characters.
 * @param {string} inputData The list of allowable special characters that should be used to randomly select from.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string}Randomly returns a random number, a random lower case letter of the english alphabet,
 * or a random special character from the list of allowable special characters.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter = function randomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(inputData + gen.cLowerCaseEnglishAlphabet + gen.cAllNumbers);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateMixedCaseAlphaNumericCharacter
 * @description Randomly generates an alpha-numeric code from a-z or A-Z or 0-9.
 * @param {string} inputData Not used for this business rule.
 * @param  {string} inputMetaData Not used for this business rule.
 * @return {string} Either a random letter (could be upper case or lower case, which is also random) or a random number.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateMixedCaseAlphaNumericCharacter = function randomlyGenerateMixedCaseAlphaNumericCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateMixedCaseAlphaNumericCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(gen.cUpperCaseEnglishAlphabet + gen.cLowerCaseEnglishAlphabet + gen.cAllNumbers);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateUpperCaseAlphaNumericCharacter
 * @description Randomly generates an alpha-numeric code from A-Z or 0-9.
 * @param {string} inputData Not used for this business rule.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} Either a random upper case letter or a random number.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateUpperCaseAlphaNumericCharacter = function randomlyGenerateUpperCaseAlphaNumericCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateUpperCaseAlphaNumericCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(gen.cUpperCaseEnglishAlphabet + gen.cAllNumbers);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateLowerCaseAlphaNumericCharacter
 * @description Randomly generates an alpha-numeric code from a-z or 0-9.
 * @param {string} inputData Not used for this business rule.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} Either a random lower case letter or a random number.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateLowerCaseAlphaNumericCharacter = function randomlyGenerateLowerCaseAlphaNumericCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateLowerCaseAlphaNumericCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(gen.cLowerCaseEnglishAlphabet + gen.cAllNumbers);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateNumericCharacter
 * @description Randomly generates a string character in the range of 0-9.
 * @param {string} inputData Not used for this business rule.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} A single randomly generated string character in the range of 0-9.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateNumericCharacter = function randomlyGenerateNumericCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateNumericCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(gen.cAllNumbers);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateSpecialCharacter
 * @description Randomly select a special character from a list of allowable special characters.
 * @param {string} inputData The list of allowable special characters that should be used to randomly select from.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} A character randomly selected from the input list of allowable characters.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateSpecialCharacter = function randomlyGenerateSpecialCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateSpecialCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = ''; // NOTE Canot have a "." as part of a variable name in a {set}

  var cTrue = gen.cTrue;

  if (inputData) {
    var inputDataLength = inputData.length.toString();
    var number = randomlyGenerateNumberInRange(num.c1, [inputDataLength, gen.cTrue, gen.cTrue]); // NOTE: The String.length() above is a 1-base count, the String.substring is zero-based.

    returnData = inputData.substring(number - 1, number);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateNumberInRange
 * @description Randomly generates a number between the start-range and end-range.
 * @param {string} inputData A string that contains the number with the minimum value.
 * @param {array<string|integer,boolean,boolean>} inputMetaData An array with multiple input parameters:
 * inputMetaData[0] = maximumValue - A string or integer that contains the number with the maximum value.
 * inputMetaData[1] = includeMaximum - A True or False value that indicates if the maximum should be included or
 * excluded from the range of allowable range of values to return from.
 * inputMetaData[2] = addMinimum - A True or False value that indicates if the minimum should be added to the value or not.
 * @return {string} The new random number that was generated according to the input parameters.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateNumberInRange = function randomlyGenerateNumberInRange(inputData, inputMetaData) {
  var functionName = randomlyGenerateNumberInRange.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';

  if (inputData && inputMetaData) {
    var minimum = parseInt(inputData);
    var maximum = parseInt(inputMetaData[0]);

    var addOne = _stringParsingUtilities["default"].stringToBoolean(inputMetaData[1]);

    var addMinimum = _stringParsingUtilities["default"].stringToBoolean(inputMetaData[2]);

    if (addOne === true) {
      if (addMinimum === true) {
        returnData = Math.floor(Math.random() * (maximum - minimum + 1)) + minimum;
      } else {
        returnData = Math.floor(Math.random() * (maximum - minimum + 1));
      }
    } else {
      if (addMinimum === true) {
        returnData = Math.floor(Math.random() * (maximum - minimum)) + minimum;
      } else {
        returnData = Math.floor(Math.random() * (maximum - minimum));
      }
    }
  } // End-if (inputData && inputMetaData)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData.toString();
};
/**
 * @function randomlyGenerateBooleanValue
 * @description Randomly generates a boolean value {@code TRUE} or {@code FALSE}.
 * @param {string} inputData Not used for this business rule.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {boolean} A boolean value that is
 * either {@code TRUE} or {@code FALSE} as a random 50-50 chance of one or the other.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateBooleanValue = function randomlyGenerateBooleanValue(inputData, inputMetaData) {
  var functionName = randomlyGenerateBooleanValue.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = Math.random() >= 0.5;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateMixedCaseAlphabeticCharacter
 * @description Randomly generates either an upper case or
 * lower case random english alphabetic letter from a-z or A-Z.
 * @param {string} inputData Not used for this business rule.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} A randomly generated english alphabetic letter from a-z or A-Z.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateMixedCaseAlphabeticCharacter = function randomlyGenerateMixedCaseAlphabeticCharacter(inputData, inputMetaData) {
  var functionName = randomlyGenerateMixedCaseAlphabeticCharacter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(gen.cUpperCaseEnglishAlphabet + gen.cLowerCaseEnglishAlphabet);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateLowerCaseLetter
 * @description Randomly generates a lower case english alphabetic letter from a-z.
 * @param {string} inputData Not used for this business rule.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} A ranomly generated english alphabetic letter from a-z.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateLowerCaseLetter = function randomlyGenerateLowerCaseLetter(inputData, inputMetaData) {
  var functionName = randomlyGenerateLowerCaseLetter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(gen.cLowerCaseEnglishAlphabet);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function randomlyGenerateUpperCaseLetter
 * @description Randomly generates an upper case alphabetic letter from A-Z.
 * @param {string} inputData Not used for this business rule.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} A randomly generated alphabetic letter from A-Z.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var randomlyGenerateUpperCaseLetter = function randomlyGenerateUpperCaseLetter(inputData, inputMetaData) {
  var functionName = randomlyGenerateUpperCaseLetter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';
  returnData = randomlyGenerateSpecialCharacter(gen.cUpperCaseEnglishAlphabet);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function convertNumberToUpperCaseLetter
 * @description Converts a number from 1-26 into an upper case letter of the english alphabet A-Z.
 * @param {sring} inputData A string that contaisn a number in the range of 1-26 that
 * should be converted to an upper case letter of the english alphabet.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} A letter of the alphabet where 1-26 is converted in a letter A-Z.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var convertNumberToUpperCaseLetter = function convertNumberToUpperCaseLetter(inputData, inputMetaData) {
  var functionName = convertNumberToUpperCaseLetter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';

  if (inputData) {
    var number = parseInt(inputData);
    number--; // number is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cnumberIs + number);

    if (number > 25 || number < 0) {
      returnData = ''; // Shouldn't actually ened to do this, but it's a good place holder.
    } else {
      returnData = gen.cUpperCaseEnglishAlphabet.substring(number, number + 1).toUpperCase();
    }
  } // End-if (inputData)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function convertNumberToLowerCaseLetter
 * @description Converts a number from 1-26 into a lower case letter of the english alphabet a-z.
 * @param {string} inputData A string that contains a number in the range of 1-26 that
 * should be converted in a ower case letter of the english alphabet.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {string} A letter of the alphabet where 1-26 is converted to a letter a-z.
 * @author Seth Hollingsead
 * @date 2022/01/25
 */


var convertNumberToLowerCaseLetter = function convertNumberToLowerCaseLetter(inputData, inputMetaData) {
  var functionName = convertNumberToLowerCaseLetter.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + inputData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = '';

  if (inputData) {
    var number = parseInt(inputData);
    number--; // number is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cnumberIs + number);

    if (number > 25 || number < 0) {
      returnData = ''; // Shouldn't actually ened to do this, but it's a good place holder.
    } else {
      returnData = gen.cUpperCaseEnglishAlphabet.substring(number, number + 1).toLowerCase();
    }
  } // End-if (inputData)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};

var _default = {
  randomlyGenerateMixedCaseLetterOrSpecialCharacter: randomlyGenerateMixedCaseLetterOrSpecialCharacter,
  randomlyGenerateUpperCaseLetterOrSpecialCharacter: randomlyGenerateUpperCaseLetterOrSpecialCharacter,
  randomlyGenerateLowerCaseLetterOrSpecialCharacter: randomlyGenerateLowerCaseLetterOrSpecialCharacter,
  randomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter: randomlyGenerateEitherMixedCaseLetterOrNumberOrSpecialCharacter,
  randomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter: randomlyGenerateEitherUpperCaseLetterOrNumberOrSpecialCharacter,
  randomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter: randomlyGenerateEitherLowerCaseLetterOrNumberOrSpecialCharacter,
  randomlyGenerateMixedCaseAlphaNumericCharacter: randomlyGenerateMixedCaseAlphaNumericCharacter,
  randomlyGenerateUpperCaseAlphaNumericCharacter: randomlyGenerateUpperCaseAlphaNumericCharacter,
  randomlyGenerateLowerCaseAlphaNumericCharacter: randomlyGenerateLowerCaseAlphaNumericCharacter,
  randomlyGenerateNumericCharacter: randomlyGenerateNumericCharacter,
  randomlyGenerateSpecialCharacter: randomlyGenerateSpecialCharacter,
  randomlyGenerateNumberInRange: randomlyGenerateNumberInRange,
  randomlyGenerateBooleanValue: randomlyGenerateBooleanValue,
  randomlyGenerateMixedCaseAlphabeticCharacter: randomlyGenerateMixedCaseAlphabeticCharacter,
  randomlyGenerateLowerCaseLetter: randomlyGenerateLowerCaseLetter,
  randomlyGenerateUpperCaseLetter: randomlyGenerateUpperCaseLetter,
  convertNumberToUpperCaseLetter: convertNumberToUpperCaseLetter,
  convertNumberToLowerCaseLetter: convertNumberToLowerCaseLetter
};
exports["default"] = _default;