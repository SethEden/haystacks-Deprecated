#!/usr/bin/env node

/**
 * @file main.js
 * @module main
 * @description Contains all customer facing functions to are used to interface with the rest of the application framework.
 * @requires module:basic.constants
 * @requires module:business.constants
 * @requires module:configuration.constants
 * @requires module:country.constants
 * @requires module:function.constants
 * @requires module:generic.constants
 * @requires module:language.constants
 * @requires module:message.constants
 * @requires module:numeric.constants
 * @requires module:phonic.constants
 * @requires module:system.constants
 * @requires module:unit.constants
 * @requires module:word1.constants
 * @requires module:word2.constants
 * @requires module:warden
 * @requires module:loggers
 * @requires module:prompt
 * @requires module:timers
 * @requires module:allConstantsValidationMetadata
 * @requires module:data
 * @requires {@link https://www.npmjs.com/package/url|url}
 * @requires {@link https://www.npmjs.com/package/dotenv|dotenv}
 * @requires {@link https://www.npmjs.com/package/path|path}
 * @author Seth Hollingsead
 * @date 2021/10/14
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var bas = _interopRequireWildcard(require("./constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("./constants/business.constants.js"));

var cmd = _interopRequireWildcard(require("./constants/command.constants.js"));

var cfg = _interopRequireWildcard(require("./constants/configuration.constants.js"));

var ctr = _interopRequireWildcard(require("./constants/country.constants.js"));

var fnc = _interopRequireWildcard(require("./constants/function.constants.js"));

var gen = _interopRequireWildcard(require("./constants/generic.constants.js"));

var lng = _interopRequireWildcard(require("./constants/language.constants.js"));

var msg = _interopRequireWildcard(require("./constants/message.constants.js"));

var num = _interopRequireWildcard(require("./constants/numeric.constants.js"));

var phn = _interopRequireWildcard(require("./constants/phonic.constants.js"));

var sys = _interopRequireWildcard(require("./constants/system.constants.js"));

var unt = _interopRequireWildcard(require("./constants/unit.constants.js"));

var wr1 = _interopRequireWildcard(require("./constants/word1.constants.js"));

var _warden = _interopRequireDefault(require("./controllers/warden.js"));

var _loggers = _interopRequireDefault(require("./executrix/loggers.js"));

var _prompt = _interopRequireDefault(require("./executrix/prompt.js"));

var _timers = _interopRequireDefault(require("./executrix/timers.js"));

var _allConstantsValidationMetadata = _interopRequireDefault(require("./resources/constantsValidation/allConstantsValidationMetadata.js"));

var _data = _interopRequireDefault(require("./structures/data.js"));

var _url = _interopRequireDefault(require("url"));

var _dotenv = _interopRequireDefault(require("dotenv"));

var _path = _interopRequireDefault(require("path"));

var _fnc$cinitFramework$f;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // main.


var namespacePrefix = baseFileName + bas.cDot;

_dotenv["default"].config();

var NODE_ENV = process.env.NODE_ENV;
/**
* @function initFramework
* @description Initializes the framework systems.
* @param {object} clientConfiguration A configuration data object that contains
* all the data needed to bootstrap the framework for a client application.
* @return {void}
* @author Seth Hollingsead
* @date 2021/10/07
*/

function initFramework(clientConfiguration) {
  var functionName = initFramework.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`clientConfiguration is: ${JSON.stringify(clientConfiguration)}`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cclientConfigurationIs + clientConfiguration); // let frameworkRootPath = path.resolve(process.cwd());
  // let frameworkRootPath = path.resolve(path.dirname(import.meta.url));


  var frameworkCodeRootPath = _url["default"].fileURLToPath(_path["default"].dirname(import.meta.url));

  var frameworkCommandAliasesPath = '';
  var frameworkWorkflowsPath = '';
  frameworkCodeRootPath = _warden["default"].processRootPath(frameworkCodeRootPath) + bas.cDoubleForwardSlash;
  var frameworkRootPath = frameworkCodeRootPath;

  if (NODE_ENV === wr1.cdevelopment) {
    frameworkCodeRootPath = frameworkCodeRootPath + sys.cFrameworkDevelopRootPath;
  } else if (NODE_ENV === wr1.cproduction) {
    frameworkCodeRootPath = frameworkCodeRootPath + sys.cFrameworkProductionRootPath;
  } else {
    // WARNING: No .env file found! Going to default to the DEVELOPMENT ENVIRONMENT!
    console.log(msg.cApplicationWarningMessage1a + msg.cApplicationWarningMessage1b);
    frameworkCodeRootPath = frameworkCodeRootPath + sys.cFrameworkDevelopRootPath;
  }

  frameworkCommandAliasesPath = frameworkCodeRootPath + sys.cframeworkResourcesCommandAliasesPath;
  frameworkWorkflowsPath = frameworkCodeRootPath + sys.cframeworkResourcesWorkflowsPath;
  clientConfiguration[cfg.cframeworkRootPath] = _path["default"].resolve(frameworkRootPath);
  clientConfiguration[cfg.cframeworkConstantsPath] = frameworkCodeRootPath + sys.cframeworkConstantsPath;
  clientConfiguration[cfg.cappConfigPath] = clientConfiguration[cfg.cappConfigReferencePath];
  clientConfiguration[cfg.cframeworkResourcesPath] = frameworkCodeRootPath + sys.cframeworkResourcesPath;
  clientConfiguration[cfg.cclientMetaDataPath] = _path["default"].resolve(clientConfiguration[cfg.cclientRootPath] + clientConfiguration[cfg.cclientMetaDataPath]);
  clientConfiguration[cfg.cframeworkFullMetaDataPath] = _path["default"].resolve(clientConfiguration[cfg.cframeworkResourcesPath] + sys.cmetaDatadotJson);
  clientConfiguration[cfg.cframeworkConfigPath] = frameworkCodeRootPath + sys.cframeworkResourcesConfigurationPath;
  clientConfiguration[cfg.cframeworkCommandAliasesPath] = frameworkCommandAliasesPath;
  clientConfiguration[cfg.cframeworkWorkflowsPath] = frameworkWorkflowsPath;
  clientConfiguration[cfg.cframeworkConstantsValidationData] = _allConstantsValidationMetadata["default"].initiaizeAllSystemConstantsValidationData;

  _warden["default"].initFrameworkSchema(clientConfiguration);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cAllLoadedDataIs + JSON.stringify(_data["default"]));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function); // console.log('All loaded data is: ' + JSON.stringify(D));
  // console.log(`END ${namespacePrefix}${functionName} function`);

}

;
/**
 * @function mergeClientBusinessRules
 * @description A wrapper function to expose the warden.mergeClientBusienssRules functionality.
 * @param {object} clientBusinessRules A map of client defined business rule names and client defined business rule function calls.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function mergeClientBusinessRules(clientBusinessRules) {
  var functionName = mergeClientBusinessRules.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _warden["default"].mergeClientBusinessRules(clientBusinessRules);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function mergeClientCommands
 * @description A wrapper function to expose the warden.mergeClientCommands functionality.
 * @param {object} clientCommands A map of client defined command names and client defined command function calls.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function mergeClientCommands(clientCommands) {
  var functionName = mergeClientCommands.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _warden["default"].mergeClientCommands(clientCommands);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function loadCommandAliases
 * @description Loads and merges a set of client command aliases with the framework command aliases.
 * This function acts as a wrapper for calling the warden.loadCommandAliases function.
 * @param {string} commandAliasesPath The path to where the commands aliases XML file is stored, that should be loaded.
 * @param {string} contextName A name for the set of command aliases that should be
 * used to store the path in the configuration system so it can be loaded by the framework.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function loadCommandAliases(commandAliasesPath, contextName) {
  var functionName = loadCommandAliases.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // commandAliasesPath is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandAliasesPathIs + commandAliasesPath); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  _warden["default"].setConfigurationSetting(wr1.csystem, contextName, commandAliasesPath);

  _warden["default"].loadCommandAliases(contextName);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function loadCommandWorkflows
 * @description Loads and merges a set of client workflows with the framework workflows.
 * This function acts as a wrapper for calling the warden.loadCommandWorkflows function.
 * @param {string} workflowPath The path to where the workflows file is stored, that should be loaded.
 * @param {string} contextName A name for the workflows that should be used
 * to store the path in the configuration system so it can be loaded by the framework.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function loadCommandWorkflows(workflowPath, contextName) {
  var functionName = loadCommandWorkflows.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // workflowPath is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cworkflowPathIs + workflowPath); // contextName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontextNameIs + contextName);

  _warden["default"].setConfigurationSetting(wr1.csystem, contextName, workflowPath);

  _warden["default"].loadCommandWorkflows(contextName);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function executeBusinessRule
 * @description A wrapper call to a business rule from the warden.executeBusinessRule.
 * @NOTE It would be good to implement another function like this: executeBusinessRules,
 * since the ruleBroker supports executing multiple sequential business rules.
 * It would be good to pass that feature along to the customer, if/when there is ever a business need.
 * @param {string} businessRule The name of the business rule that should execute.
 * @param {string} ruleInput The input to the rule that is being called.
 * @param {string} ruleMetaData Additional data to input to the rule.
 * @return {string} The value that is returned from the rule is also returned.
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function executeBusinessRule(businessRule, ruleInput, ruleMetaData) {
  var functionName = executeBusinessRule.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // businessRule is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cbusinessRuleIs + JSON.stringify(businessRule)); // ruleInput is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cruleInputIs + JSON.stringify(ruleInput)); // ruleMetaData is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cruleMetaDataIs + JSON.stringify(ruleMetaData));

  var returnData = _warden["default"].executeBusinessRule(businessRule, ruleInput, ruleMetaData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function enqueueCommand
 * @description Adds a command to the command queue.
 * It is worth noting that a command could actually load a whole workflow of commands.
 * So one command can spawn into many commands that cause
 * the command queue to be very full with a very complicated workflow.
 * This also acts as a wrapper for the warden.enqueueCommand function.
 * @param {string} command The command to add to the command queue for executing.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function enqueueCommand(command) {
  var functionName = enqueueCommand.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // command is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandIs + command);

  _warden["default"].enqueueCommand(command);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function isCommandQueueEmpty
 * @description Determines if the command queue is empty or not empty.
 * This is a wrapper function for the warden.isCommandQueueEmpty function.
 * @return {boolean} True or False to indicate if the command execution queue is empty or not.
 * Useful to determine if the command queue should continue executing or not.
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function isCommandQueueEmpty() {
  var functionName = isCommandQueueEmpty.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  var returnData = false;
  returnData = _warden["default"].isCommandQueueEmpty();

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function processCommandQueue
 * @description This is a wrapper function for the warden.processCommandQueue.
 * This leads to a call to the chiefCommander.processCommand to process an individual command.
 * This is because a command could actually invoke a command workflow that might enqueue a bunch of commands
 * to the command queue. All of them must be executed in sequence as part of the main appication loop.
 * @return {boolean} A True or False value to indicate if the command loop should termiante when it's done.
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function processCommandQueue() {
  var functionName = processCommandQueue.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  var returnData = false;
  returnData = _warden["default"].processCommandQueue();

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function setConfigurationSetting
 * @description This is just a wrapper for the warden.setConfigurationSetting function.
 * @param {string} configurationNamespace The path in the configuration JSON object
 * where the configuration setting should be set.
 * Ex: businessRules.rules.stringParsing.countCamelCaseWords
 * @param {string} configurationName The key of the configuration setting.
 * @param {string|integer|boolean|double|object} configurationValue The value of the configuration setting.
 * @return {void}
 * @author Seth Hollingsead
 * @date 222/02/18
 */

function setConfigurationSetting(configurationNamespace, configurationName, configurationValue) {
  var functionName = setConfigurationSetting.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // configurationNamespace is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cconfigurationNamespaceIs + configurationNamespace); // configurationName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cconfigurationNameIs + configurationName); // configurationValue is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cconfigurationValueIs + configurationValue); // D[sys.cConfiguration][configurationName] = configurationValue;


  _warden["default"].setConfigurationSetting(configurationNamespace, configurationName, configurationValue);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function getConfigurationSetting
 * @description This is just a wrapper for the warden.getConfigurationSetting function.
 * @param {string} configurationNamespace The path in the configuration JSON object
 * where the configuration setting should be found.
 * @param {string} configurationName The key of the configuration setting.
 * @return {string|integer|boolean|double|object} The value of whatever was stored in the D[configuration][configurationName].
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function getConfigurationSetting(configurationNamespace, configurationName) {
  var functionName = getConfigurationSetting.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // configurationNamespace is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cconfigurationNamespaceIs + configurationNamespace); // configurationName is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cconfigurationNameIs + configurationName); // let returnConfigurationValue = D[sys.cConfiguration][configurationName];


  var returnConfigurationValue = _warden["default"].getConfigurationSetting(configurationNamespace, configurationName); // returnConfigurationValue is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnConfiguraitonValueIs + returnConfigurationValue);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnConfigurationValue;
}

;
/**
 * @function consoleLog
 * @description A wrapper function to expose the loggers.consoleLog function to the client application.
 * @param {string} theNamespacePrefix The namespace of the log that is being sent. Ex: folder.filename
 * @param {string} theFunctionName The name of the function that log is being called from.
 * @param {string|object} message The message that should be logged.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/12/30
 */

function consoleLog(theNamespacePrefix, theFunctionName, message) {
  var functionName = consoleLog.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`theNamespacePrefix is: ${theNamespacePrefix}`);
  // console.log(`theFunctionName is: ${theFunctionName}`);
  // console.log(`message is: ${JSON.stringify(message)}`);

  _loggers["default"].consoleLog(theNamespacePrefix + theFunctionName, message); // console.log(`END ${namespacePrefix}${functionName} function`);

}

;
/**
 * @function sleep
 * @description Causes the entire application to sleep for a set time.
 * This is a wrapper for the warden.sleep function.
 * @param {integer} sleepTime The time that the application should sleep in milliseconds.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/18
 */

function sleep(sleepTime) {
  var functionName = sleep.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // sleepTime is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.csleepTimeIs + sleepTime);

  _timers["default"].sleep(sleepTime);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;

var _default = (_fnc$cinitFramework$f = {}, _defineProperty(_fnc$cinitFramework$f, fnc.cinitFramework, function (clientConfiguration) {
  return initFramework(clientConfiguration);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cmergeClientBusinessRules, function (clientBusinessRules) {
  return mergeClientBusinessRules(clientBusinessRules);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cmergeClientCommands, function (clientCommands) {
  return mergeClientCommands(clientCommands);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cloadCommandAliases, function (commandAliasesPath, contextName) {
  return loadCommandAliases(commandAliasesPath, contextName);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cloadCommandWorkflows, function (workflowPath, contextName) {
  return loadCommandWorkflows(workflowPath, contextName);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cexecuteBusinessRule, function (businessRule, ruleInput, ruleMetaData) {
  return executeBusinessRule(businessRule, ruleInput, ruleMetaData);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cenqueueCommand, function (command) {
  return enqueueCommand(command);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cisCommandQueueEmpty, function () {
  return isCommandQueueEmpty();
}), _defineProperty(_fnc$cinitFramework$f, fnc.cprocessCommandQueue, function () {
  return processCommandQueue();
}), _defineProperty(_fnc$cinitFramework$f, fnc.csetConfigurationSetting, function (configurationNamespace, configurationName, configurationValue) {
  return setConfigurationSetting(configurationNamespace, configurationName, configurationValue);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cgetConfigurationSetting, function (configurationNamespace, configurationName) {
  return getConfigurationSetting(configurationNamespace, configurationName);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cconsoleLog, function (theNamespacePrefix, theFunctionName, message) {
  return consoleLog(theNamespacePrefix, theFunctionName, message);
}), _defineProperty(_fnc$cinitFramework$f, fnc.csleep, function (sleepTime) {
  return sleep(sleepTime);
}), _defineProperty(_fnc$cinitFramework$f, fnc.cprompt, function (ask) {
  return _prompt["default"].prompt(ask);
}), _defineProperty(_fnc$cinitFramework$f, gen.cbas, bas), _defineProperty(_fnc$cinitFramework$f, gen.cbiz, biz), _defineProperty(_fnc$cinitFramework$f, gen.ccmd, cmd), _defineProperty(_fnc$cinitFramework$f, gen.ccfg, cfg), _defineProperty(_fnc$cinitFramework$f, gen.cctr, ctr), _defineProperty(_fnc$cinitFramework$f, gen.cfnc, fnc), _defineProperty(_fnc$cinitFramework$f, gen.cgen, gen), _defineProperty(_fnc$cinitFramework$f, gen.clng, lng), _defineProperty(_fnc$cinitFramework$f, gen.cmsg, msg), _defineProperty(_fnc$cinitFramework$f, gen.cnum, num), _defineProperty(_fnc$cinitFramework$f, gen.cphn, phn), _defineProperty(_fnc$cinitFramework$f, gen.csys, sys), _defineProperty(_fnc$cinitFramework$f, gen.cunt, unt), _defineProperty(_fnc$cinitFramework$f, gen.cwr1, wr1), _fnc$cinitFramework$f);

exports["default"] = _default;