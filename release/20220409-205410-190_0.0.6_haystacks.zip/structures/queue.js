"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _data = _interopRequireDefault(require("./data.js"));

var _path = _interopRequireDefault(require("path"));

var _fnc$cinitQueue$fnc$c;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // structures.queue.


var namespacePrefix = wr1.cstructures + bas.cDot + baseFileName + bas.cDot;
/**
 * @function initQueue
 * @description Initializes the queue with the provided namespace.
 * @param {string} queueNameSpace The namespace the queue array should be created under.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/01
 * @reference {@link https://www.youtube.com/watch?v=bK7I79hcm08}
 */

function initQueue(queueNameSpace) {
  var functionName = initQueue.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cqueueNameSpaceIs + queueNameSpace);

  _data["default"][queueNameSpace] = [];

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function dequeue
 * @description Gets the entity at the front of the queue, removes it from the queue and returns that entity.
 * @param {string} queueNameSpace The namespace the queue array should be dequeued from.
 * @return {string} The item at the front of the queue and removes it from the queue.
 * @author Seth Hollingsead
 * @date 2022/02/01
 * @reference {@link https://www.youtube.com/watch?v=bK7I79hcm08}
 */

function dequeue(queueNameSpace) {
  var functionName = dequeue.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cqueueNameSpaceIs + queueNameSpace);

  var returnData;
  returnData = _data["default"][queueNameSpace].shift();

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function enqueue
 * @description Adds the value to the specified namespace queue.
 * @param {string} queueNameSpace The namespace the queue array should have a value added to.
 * @param {string} value The value that should be added to the specified queue array.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/01
 * @reference {@link https://www.youtube.com/watch?v=bK7I79hcm08}
 */

function enqueue(queueNameSpace, value) {
  var functionName = enqueue.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cqueueNameSpaceIs + queueNameSpace);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cvalueIs + value);

  _data["default"][queueNameSpace].push(value);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function isEmpty
 * @description Determines if the queue is empty or not empty.
 * @param {string} queueNameSpace The namespace the queue array should have a value added to.
 * @return {boolean} True or False to indicate if the queue is empty or not empty.
 * @author Seth Hollingsead
 * @date 2022/02/01
 * @reference {@link https://www.youtube.com/watch?v=bK7I79hcm08}
 */

function isEmpty(queueNameSpace) {
  var functionName = isEmpty.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cqueueNameSpaceIs + queueNameSpace);

  var returnData;

  if (_data["default"][queueNameSpace] === undefined) {
    returnData = true;
  } else {
    returnData = _data["default"][queueNameSpace].length === 0;
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function queueFront
 * @description Gets the entity at the front of the queue.
 * @param {string} queueNameSpace The namespace the queue array from which the front of the queue should be found.
 * @return {string} The entity at the front of the queue.
 * @author Seth Hollingsead
 * @date 2022/02/01
 * @reference {@link https://www.youtube.com/watch?v=bK7I79hcm08}
 */

function queueFront(queueNameSpace) {
  var functionName = queueFront.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cqueueNameSpaceIs + queueNameSpace);

  var returnData;
  returnData = _data["default"][queueNameSpace][0];

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;
/**
 * @function queueSize
 * @description Gets the current size of the queue.
 * @param {string} queueNameSpace The namespace of the queue array from which we should get the current queue size.
 * @return {integer} A count for the number of entities in the specified queue.
 * @author Seth Hollingsead
 * @date 2022/02/01
 * @reference {@link https://www.youtube.com/watch?v=bK7I79hcm08}
 */

function queueSize(queueNameSpace) {
  var functionName = queueFront.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cqueueNameSpaceIs + queueNameSpace);

  var returnData;
  returnData = _data["default"][queueNameSpace].length;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
}

;

var _default = (_fnc$cinitQueue$fnc$c = {}, _defineProperty(_fnc$cinitQueue$fnc$c, fnc.cinitQueue, function (queueNameSpace) {
  return initQueue(queueNameSpace);
}), _defineProperty(_fnc$cinitQueue$fnc$c, fnc.cdequeue, function (queueNameSpace) {
  return dequeue(queueNameSpace);
}), _defineProperty(_fnc$cinitQueue$fnc$c, fnc.cenqueue, function (queueNameSpace, value) {
  return enqueue(queueNameSpace, value);
}), _defineProperty(_fnc$cinitQueue$fnc$c, fnc.cisEmpty, function (queueNameSpace) {
  return isEmpty(queueNameSpace);
}), _defineProperty(_fnc$cinitQueue$fnc$c, fnc.cqueueFront, function (queueNameSpace) {
  return queueFront(queueNameSpace);
}), _defineProperty(_fnc$cinitQueue$fnc$c, fnc.cqueueSize, function (queueNameSpace) {
  return queueSize(queueNameSpace);
}), _fnc$cinitQueue$fnc$c);

exports["default"] = _default;