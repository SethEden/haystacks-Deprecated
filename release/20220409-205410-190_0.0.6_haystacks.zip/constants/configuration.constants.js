"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ctimeStamp = exports.ctertiaryCommandDelimiter = exports.csecondaryCommandDelimiter = exports.crootPath = exports.creleaseCompleted = exports.cprintDataHiveToLogFile = exports.cprimaryCommandDelimiter = exports.cpassedAllCommandAliasesDuplicateChecks = exports.cpassAllConstantsValidation = exports.clogFileName = exports.clogFileEnabled = exports.cincludeDateTimeStampInLogFiles = exports.cframeworkWorkflowsPath = exports.cframeworkRootPath = exports.cframeworkResourcesPath = exports.cframeworkFullMetaDataPath = exports.cframeworkConstantsValidationData = exports.cframeworkConstantsPath = exports.cframeworkConfigPath = exports.cframeworkConfigFiles = exports.cframeworkCommandAliasesPath = exports.cfigletFont = exports.cenableConstantsValidation = exports.cenableCommandPerformanceMetrics = exports.cenableColorizedConsoleLogs = exports.cenableBusinessRulePerformanceMetrics = exports.cenableBusinessRuleOutput = exports.cdisplaySummaryConstantsValidationPassMessages = exports.cdisplaySummaryConstantsValidationFailMessages = exports.cdisplayIndividualCosntantsValidationFailMessages = exports.cdisplayIndividualConstantsValidationPassMessages = exports.cdebugSettings = exports.cdebugSetting = exports.cdebugFunctions = exports.cdebugFiles = exports.cdateTimeStamp = exports.cdateStamp = exports.cconsoleLogEnabled = exports.ccommandsPerformanceTrackingStack = exports.ccommandsPerformanceAnalysisStack = exports.ccommandNamesPerformanceTrackingStack = exports.cclientWorkflowsPath = exports.cclientRootPath = exports.cclientMetaDataPath = exports.cclientConstantsPath = exports.cclientCommandAliasesPath = exports.cclearCommandPerformanceDataAfterAnalysis = exports.cclearBusinessRulesPerformanceDataAfterAnalysis = exports.cbusinessRulesPerformanceTrackingStack = exports.cbusinessRulesPerformanceAnalysisStack = exports.cbusinessRulesNamesPerformanceTrackingStack = exports.capplicationConstantsValidationData = exports.capplicationConstantsPath = exports.cappRootPath = exports.cappConfigResourcesPath = exports.cappConfigReferencePath = exports.cappConfigPath = exports.cappConfigFiles = exports.cTestDataPath = exports.cRootPath = exports.cResultsLogFilePathAndName = exports.cLogFilePathAndName = exports.cIncludeDateTimeStampInLogFiles = exports.cExecutionJournalFilePathAndName = exports.cEndDateTimeStamp = exports.cDataLogFilePathAndName = exports.cBusinessRulePerformanceTrackingStack = exports.cBusinessRuleNamesPerformanceTrackingStack = exports.cBeginDateTimeStamp = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var gen = _interopRequireWildcard(require("./generic.constants.js"));

var sys = _interopRequireWildcard(require("./system.constants.js"));

var wr1 = _interopRequireWildcard(require("./word1.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file configuration.constants.js
 * @module configuration.constants
 * @description Contains all re-usable configuration constants.
 * @requires module:basic.constants
 * @requires module:generic.constants
 * @requires module:system.constants
 * @requires module:word1.constants
 * @author Seth Hollingsead
 * @date 2021/11/09
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// Configuration Settings
var crootPath = wr1.croot + wr1.cPath; // rootPath

exports.crootPath = crootPath;
var cRootPath = wr1.cRoot + wr1.cPath; // RootPath

exports.cRootPath = cRootPath;
var cappRootPath = gen.capp + wr1.cRoot + wr1.cPath; // appRootPath

exports.cappRootPath = cappRootPath;
var cclientRootPath = wr1.cclient + wr1.cRoot + wr1.cPath; // clientRootPath

exports.cclientRootPath = cclientRootPath;
var cframeworkRootPath = wr1.cframework + wr1.cRoot + wr1.cPath; // frameworkRootPath

exports.cframeworkRootPath = cframeworkRootPath;
var cappConfigResourcesPath = gen.capp + wr1.cConfig + wr1.cResources + wr1.cPath; // appConfigResourcesPath

exports.cappConfigResourcesPath = cappConfigResourcesPath;
var cframeworkResourcesPath = wr1.cframework + wr1.cResources + wr1.cPath; // frameworkResourcesPath

exports.cframeworkResourcesPath = cframeworkResourcesPath;
var cframeworkConstantsPath = wr1.cframework + wr1.cConstants + wr1.cPath; // frameworkConstantsPath

exports.cframeworkConstantsPath = cframeworkConstantsPath;
var cclientConstantsPath = wr1.cclient + wr1.cConstants + wr1.cPath; // clientConstantsPath

exports.cclientConstantsPath = cclientConstantsPath;
var capplicationConstantsPath = wr1.capplication + wr1.cConstants + wr1.cPath; // applicationConstantsPath

exports.capplicationConstantsPath = capplicationConstantsPath;
var cclientMetaDataPath = wr1.cclient + wr1.cMetaData + wr1.cPath; // clientMetaDataPath

exports.cclientMetaDataPath = cclientMetaDataPath;
var cclientCommandAliasesPath = wr1.cclient + wr1.cCommand + wr1.cAliases + wr1.cPath; // clientCommandAliasesPath

exports.cclientCommandAliasesPath = cclientCommandAliasesPath;
var cclientWorkflowsPath = wr1.cclient + wr1.cWorkflows + wr1.cPath; // clientWorkflowsPath

exports.cclientWorkflowsPath = cclientWorkflowsPath;
var cframeworkFullMetaDataPath = wr1.cframework + wr1.cFull + wr1.cMetaData + wr1.cPath; // frameworkFullMetaDataPath

exports.cframeworkFullMetaDataPath = cframeworkFullMetaDataPath;
var cappConfigPath = gen.capp + wr1.cConfig + wr1.cPath; // appConfigPath

exports.cappConfigPath = cappConfigPath;
var cframeworkConfigPath = wr1.cframework + wr1.cConfig + wr1.cPath; // frameworkConfigPath

exports.cframeworkConfigPath = cframeworkConfigPath;
var cappConfigFiles = gen.capp + wr1.cConfig + wr1.cFiles; // appConfigFiles

exports.cappConfigFiles = cappConfigFiles;
var cframeworkConfigFiles = wr1.cframework + wr1.cConfig + wr1.cFiles; // frameworkConfigFiles

exports.cframeworkConfigFiles = cframeworkConfigFiles;
var cappConfigReferencePath = gen.capp + wr1.cConfig + wr1.cReference + wr1.cPath; // appConfigReferencePath

exports.cappConfigReferencePath = cappConfigReferencePath;
var cframeworkCommandAliasesPath = wr1.cframework + wr1.cCommand + wr1.cAliases + wr1.cPath; // frameworkCommandAliasesPath

exports.cframeworkCommandAliasesPath = cframeworkCommandAliasesPath;
var cframeworkWorkflowsPath = wr1.cframework + wr1.cWorkflows + wr1.cPath; // frameworkWorkflowsPath

exports.cframeworkWorkflowsPath = cframeworkWorkflowsPath;
var cdebugSetting = wr1.cdebug + wr1.cSetting; // debugSetting

exports.cdebugSetting = cdebugSetting;
var cdebugSettings = wr1.cdebug + wr1.cSettings; // debugSettings

exports.cdebugSettings = cdebugSettings;
var cdebugFiles = wr1.cdebug + wr1.cFiles; // debugFiles

exports.cdebugFiles = cdebugFiles;
var cdebugFunctions = wr1.cdebug + wr1.cFunctions; // debugFunctions

exports.cdebugFunctions = cdebugFunctions;
var cfigletFont = wr1.cfiglet + wr1.cFont; // figletFont

exports.cfigletFont = cfigletFont;
var cincludeDateTimeStampInLogFiles = wr1.cinclude + wr1.cDate + wr1.cTime + wr1.cStamp + bas.cIn + gen.cLog + wr1.cFiles; // includeDateTimeStampInLogFiles

exports.cincludeDateTimeStampInLogFiles = cincludeDateTimeStampInLogFiles;
var cLogFilePathAndName = wr1.cLog + wr1.cFile + wr1.cPath + wr1.cAnd + wr1.cName; // LogFilePathAndName

exports.cLogFilePathAndName = cLogFilePathAndName;
var cDataLogFilePathAndName = wr1.cData + wr1.cLog + wr1.cFile + wr1.cPath + wr1.cAnd + wr1.cName; // DataLogFilePathAndName

exports.cDataLogFilePathAndName = cDataLogFilePathAndName;
var cExecutionJournalFilePathAndName = wr1.cExecution + wr1.cJournal + wr1.cFile + wr1.cPath + wr1.cAnd + wr1.cName; // ExecutionJournalFilePathAndName

exports.cExecutionJournalFilePathAndName = cExecutionJournalFilePathAndName;
var cResultsLogFilePathAndName = wr1.cResults + wr1.cLog + wr1.cFile + wr1.cPath + wr1.cAnd + wr1.cName; // ResultsLogFilePathAndName

exports.cResultsLogFilePathAndName = cResultsLogFilePathAndName;
var cTestDataPath = wr1.cTest + wr1.cData + wr1.cPath; // TestDataPath

exports.cTestDataPath = cTestDataPath;
var cconsoleLogEnabled = wr1.cconsole + wr1.cLog + wr1.cEnabled; // consoleLogEnabled

exports.cconsoleLogEnabled = cconsoleLogEnabled;
var clogFileEnabled = wr1.clog + wr1.cFile + wr1.cEnabled; // logFileEnabled

exports.clogFileEnabled = clogFileEnabled;
var cdateTimeStamp = wr1.cdate + wr1.cTime + wr1.cStamp; // dateTimeStamp

exports.cdateTimeStamp = cdateTimeStamp;
var cdateStamp = wr1.cdate + wr1.cStamp; // dateStamp

exports.cdateStamp = cdateStamp;
var ctimeStamp = wr1.ctime + wr1.cStamp; // timeStamp

exports.ctimeStamp = ctimeStamp;
var clogFileName = gen.clog + wr1.cFileName; // logFileName

exports.clogFileName = clogFileName;
var cIncludeDateTimeStampInLogFiles = wr1.cInclude + wr1.cDate + wr1.cTime + wr1.cStamp + bas.cIn + gen.cLog + wr1.cFiles; // IncludeDateTimeStampInLogFiles

exports.cIncludeDateTimeStampInLogFiles = cIncludeDateTimeStampInLogFiles;
var cenableColorizedConsoleLogs = wr1.cenable + wr1.cColorized + wr1.cConsole + wr1.cLogs; // enableColorizedConsoleLogs

exports.cenableColorizedConsoleLogs = cenableColorizedConsoleLogs;
var cprimaryCommandDelimiter = wr1.cprimary + wr1.cCommand + wr1.cDelimiter; // primaryCommandDelimiter

exports.cprimaryCommandDelimiter = cprimaryCommandDelimiter;
var csecondaryCommandDelimiter = wr1.csecondary + wr1.cCommand + wr1.cDelimiter; // secondaryCommandDelimiter

exports.csecondaryCommandDelimiter = csecondaryCommandDelimiter;
var ctertiaryCommandDelimiter = wr1.ctertiary + wr1.cCommand + wr1.cDelimiter; // tertiaryCommandDelimiter

exports.ctertiaryCommandDelimiter = ctertiaryCommandDelimiter;
var cenableBusinessRuleOutput = wr1.cenable + wr1.cBusiness + wr1.cRule + wr1.cOutput; // enableBusinessRuleOutput

exports.cenableBusinessRuleOutput = cenableBusinessRuleOutput;
var cenableBusinessRulePerformanceMetrics = wr1.cenable + wr1.cBusiness + wr1.cRule + wr1.cPerformance + wr1.cMetrics; // enableBusinessRulePerformanceMetrics

exports.cenableBusinessRulePerformanceMetrics = cenableBusinessRulePerformanceMetrics;
var cbusinessRulesNamesPerformanceTrackingStack = wr1.cbusiness + wr1.cRules + wr1.cNames + wr1.cPerformance + wr1.cTracking + wr1.cStack; // businessRulesNamesPerformanceTrackingStack

exports.cbusinessRulesNamesPerformanceTrackingStack = cbusinessRulesNamesPerformanceTrackingStack;
var cbusinessRulesPerformanceTrackingStack = wr1.cbusiness + wr1.cRules + wr1.cPerformance + wr1.cTracking + wr1.cStack; // businessRulesPerformanceTrackingStack

exports.cbusinessRulesPerformanceTrackingStack = cbusinessRulesPerformanceTrackingStack;
var cbusinessRulesPerformanceAnalysisStack = wr1.cbusiness + wr1.cRules + wr1.cPerformance + wr1.cAnalysis + wr1.cStack; // businessRulesPerformanceAnalysisStack

exports.cbusinessRulesPerformanceAnalysisStack = cbusinessRulesPerformanceAnalysisStack;
var cenableCommandPerformanceMetrics = wr1.cenable + wr1.cCommand + wr1.cPerformance + wr1.cMetrics; // enableCommandPerformanceMetrics

exports.cenableCommandPerformanceMetrics = cenableCommandPerformanceMetrics;
var ccommandNamesPerformanceTrackingStack = wr1.ccommand + wr1.cNames + wr1.cPerformance + wr1.cTracking + wr1.cStack; // commandNamesPerformanceTrackingStack

exports.ccommandNamesPerformanceTrackingStack = ccommandNamesPerformanceTrackingStack;
var ccommandsPerformanceTrackingStack = wr1.ccommands + wr1.cPerformance + wr1.cTracking + wr1.cStack; // commandsPerformanceTrackingStack

exports.ccommandsPerformanceTrackingStack = ccommandsPerformanceTrackingStack;
var ccommandsPerformanceAnalysisStack = wr1.ccommands + wr1.cPerformance + wr1.cAnalysis + wr1.cStack; // commandsPerformanceAnalysisStack

exports.ccommandsPerformanceAnalysisStack = ccommandsPerformanceAnalysisStack;
var cclearBusinessRulesPerformanceDataAfterAnalysis = wr1.cclear + wr1.cBusiness + wr1.cRules + wr1.cPerformance + wr1.cData + wr1.cAfter + wr1.cAnalysis; // clearBusinessRulesPerformanceDataAfterAnalysis

exports.cclearBusinessRulesPerformanceDataAfterAnalysis = cclearBusinessRulesPerformanceDataAfterAnalysis;
var cclearCommandPerformanceDataAfterAnalysis = wr1.cclear + wr1.cCommand + wr1.cPerformance + wr1.cData + wr1.cAfter + wr1.cAnalysis; // clearCommandPerformanceDataAfterAnalysis

exports.cclearCommandPerformanceDataAfterAnalysis = cclearCommandPerformanceDataAfterAnalysis;
var cprintDataHiveToLogFile = wr1.cprint + wr1.cData + wr1.cHive + wr1.cTo + gen.cLog + wr1.cFile; // printDataHiveToLogFile

exports.cprintDataHiveToLogFile = cprintDataHiveToLogFile;
var cenableConstantsValidation = wr1.cenable + wr1.cConstants + wr1.cValidation; // enableConstantsValidation

exports.cenableConstantsValidation = cenableConstantsValidation;
var cframeworkConstantsValidationData = wr1.cframework + wr1.cConstants + wr1.cValidation + wr1.cData; // frameworkConstantsValidationData

exports.cframeworkConstantsValidationData = cframeworkConstantsValidationData;
var capplicationConstantsValidationData = wr1.capplication + wr1.cConstants + wr1.cValidation + wr1.cData; // applicationConstantsValidationData

exports.capplicationConstantsValidationData = capplicationConstantsValidationData;
var cdisplayIndividualConstantsValidationPassMessages = wr1.cdisplay + wr1.cIndividual + wr1.cConstants + wr1.cValidation + wr1.cPass + wr1.cMessages; // displayIndividualConstantsValidationPassMessages

exports.cdisplayIndividualConstantsValidationPassMessages = cdisplayIndividualConstantsValidationPassMessages;
var cdisplayIndividualCosntantsValidationFailMessages = wr1.cdisplay + wr1.cIndividual + wr1.cConstants + wr1.cValidation + wr1.cFail + wr1.cMessages; // displayIndividualConstantsValidationFailMessages

exports.cdisplayIndividualCosntantsValidationFailMessages = cdisplayIndividualCosntantsValidationFailMessages;
var cdisplaySummaryConstantsValidationPassMessages = wr1.cdisplay + wr1.cSummary + wr1.cConstants + wr1.cValidation + wr1.cPass + wr1.cMessages; // displaySummaryConstantsValidationPassMessages

exports.cdisplaySummaryConstantsValidationPassMessages = cdisplaySummaryConstantsValidationPassMessages;
var cdisplaySummaryConstantsValidationFailMessages = wr1.cdisplay + wr1.cSummary + wr1.cConstants + wr1.cValidation + wr1.cFail + wr1.cMessages; // displaySummaryConstantsValidationFailMessages

exports.cdisplaySummaryConstantsValidationFailMessages = cdisplaySummaryConstantsValidationFailMessages;
var cpassAllConstantsValidation = wr1.cpass + wr1.cAll + wr1.cConstants + wr1.cValidation; // passAllConstantsValidation

exports.cpassAllConstantsValidation = cpassAllConstantsValidation;
var cpassedAllCommandAliasesDuplicateChecks = wr1.cpassed + wr1.cAll + wr1.cCommand + wr1.cAliases + wr1.cDuplicate + wr1.cChecks; // passedAllCommandAliasesDuplicateChecks

exports.cpassedAllCommandAliasesDuplicateChecks = cpassedAllCommandAliasesDuplicateChecks;
var creleaseCompleted = wr1.crelease + wr1.cCompleted; // releaseCompleted
// Test Time Tracking

exports.creleaseCompleted = creleaseCompleted;
var cBeginDateTimeStamp = wr1.cBegin + sys.cDateTimeStamp; // BeginDateTimeStamp

exports.cBeginDateTimeStamp = cBeginDateTimeStamp;
var cEndDateTimeStamp = wr1.cEnd + sys.cDateTimeStamp; // EndDateTimeStamp

exports.cEndDateTimeStamp = cEndDateTimeStamp;
var cBusinessRulePerformanceTrackingStack = wr1.cBusiness + wr1.cRule + wr1.cPerformance + wr1.cTracking + wr1.cStack; // BusinessRulePerformanceTrackingStack

exports.cBusinessRulePerformanceTrackingStack = cBusinessRulePerformanceTrackingStack;
var cBusinessRuleNamesPerformanceTrackingStack = wr1.cBusiness + wr1.cRule + wr1.cNames + wr1.cPerformance + wr1.cTracking + wr1.cStack; // BusinessRuleNamesPerformanceTrackingStack

exports.cBusinessRuleNamesPerformanceTrackingStack = cBusinessRuleNamesPerformanceTrackingStack;