"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cFileNumber = exports.cFileNames = exports.cFileName = exports.cFileCounter = exports.cEnvironmentRowNumber = exports.cEnvironmentRow = exports.cEndTestTimeStamp = exports.cEndScriptTimeStamp = exports.cEndPageScriptTimeStamp = exports.cEndKeywordTimeStamp = exports.cElementConstantsValidation = exports.cENVIRONMENT = exports.cENV = exports.cDwellTime = exports.cDraft = exports.cDoubleDotForwardSlash = exports.cDocuments = exports.cDocument = exports.cDeltaT = exports.cDebugTestExhaustive = exports.cDebugTestData = exports.cDebugTest = exports.cDebugSelectors = exports.cDebugPageScripts = exports.cDebugPageData = exports.cDebugPage = exports.cDebugKeywords = exports.cDebugForceMessageToLogFile = exports.cDebugBrowserActions = exports.cDateTimeStamp = exports.cDataStorage = exports.cDataPath = exports.cDataFontStyle = exports.cDataFontColor = exports.cDataFontBackgroundColor = exports.cDashboardLogs = exports.cDWG = exports.cDEV = exports.cCtempPath = exports.cCountryConstantsValidation = exports.cConstantsValidationData = exports.cConstantsShortNames = exports.cConstantsPrefix = exports.cConstantsPhase2ValidationMessages = exports.cConstantsPhase1ValidationMessages = exports.cConstantsFilePaths = exports.cConstantsFileNames = exports.cConfiguration_Colors = exports.cConfigurationPath = exports.cConfigurationName = exports.cConfigurationElements = exports.cConfigurationElement = exports.cConfigurationConstantsValidation = exports.cCommandsBlob = exports.cCommandsAliases = exports.cCommandWorkflows = exports.cCommandQueue = exports.cCommandConstantsValidation = exports.cColorName = exports.cColorData = exports.cColorConstantsValidation = exports.cClientConstantsPath = exports.cCatia = exports.cCarriageReturn = exports.cCamelCase = exports.cByLength = exports.cButton = exports.cBusinessRules = exports.cBusinessRule = exports.cBusinessConstantsValidation = exports.cBrowserRefresh = exports.cBrowserName = exports.cBooleanValue = exports.cBinaryRootPath = exports.cBinaryReleasePath = exports.cBeginTestTimeStamp = exports.cBeginScriptTimeStamp = exports.cBeginPageScriptTimeStamp = exports.cBeginKeywordTimeStamp = exports.cBasicConstantsValidation = exports.cBackground = exports.cBackSlash = exports.cAsyncSingular = exports.cApplicationVersionNumber = exports.cApplicationRootPath = exports.cApplicationName = exports.cApplicationDescription = exports.cApplicationCleanedRootPath = exports.cAlphabeticCharacter = exports.cAlphaNumericCodeWithSpecialCharactersByLength = exports.cAlphaNumericCodeWithSpecialCharacters = exports.cAlphaNumericCodeByLength = exports.cAlphaNumericCode = exports.cAlphaNumericCharacter = exports.cAlphaNumeric = exports.cAllowableCharacters = exports.cActualFrameworkName = exports.cAccessLevel = exports.cAbreviatedSelectorsInLogs = exports.cAbreviatedSelectors = void 0;
exports.cSpaceIsColonSpace = exports.cSource2 = exports.cSource1 = exports.cSolidWorks = exports.cSolidEdge = exports.cShareEmail = exports.cShapeConstantsValidation = exports.cScriptTimeStamp = exports.cScriptRunTime = exports.cScriptDateTimeStamp = exports.cScriptDateStamp = exports.cSTYLE = exports.cRuntime = exports.cRunTime = exports.cRowNumber = exports.cRhino = exports.cRandomValidEmail = exports.cRandomInvalidEmail = exports.cQA = exports.cProjectName = exports.cProjectDescription = exports.cProd = exports.cProcessingTimeout = exports.cProE = exports.cPreValidateFileName = exports.cPreProd = exports.cPre = exports.cPhonicConstantsValidation = exports.cPassword = exports.cParasolid = exports.cParallelMultiUnified = exports.cPage_Keywords = exports.cPageScriptTimeStamp = exports.cPageScript = exports.cPageDataPath = exports.cPROD = exports.cPREPROD = exports.cPRE = exports.cOperatingSystem = exports.cNumericConstantsValidation = exports.cNumericCodeByLength = exports.cNumericCode = exports.cNumericCharacter = exports.cNumberOfRows = exports.cNumberInRange = exports.cNeutral = exports.cNavigateTo = exports.cNX = exports.cModuleFontStyle = exports.cModuleFontColor = exports.cModuleFontBackgroundColor = exports.cMixedCase = exports.cMessageFontStyle = exports.cMessageFontColor = exports.cMessageFontBackgroundColor = exports.cMessageConstantsValidation = exports.cMasterRowNumber = exports.cLowerCase = exports.cLogBrowserActions = exports.cLocatorsDataPath = exports.cLetterOrSpecialCharacter = exports.cLetterOrNumberOrSpecialCharacter = exports.cLetterOr = exports.cLehmerCodeArray = exports.cLanguageConstantsValidation = exports.cLOG = exports.cKnotConstantsValidation = exports.cKeywordsDataPath = exports.cKeywordTimeStamp = exports.cJournalBrowserActions = exports.cIsotopeConstantsValidation = exports.cInventor = exports.cInvalidEmail = exports.cIntermediatePath = exports.cInnerText = exports.cInnerHTML = exports.cIngestionCompleteDwellTime = exports.cImages = exports.cImage = exports.cITERATION = exports.cHostName = exports.cHoops = exports.cHexValue = exports.cHOOPS = exports.cGenericConstantsValidation = exports.cGenerateA = exports.cFunctionFontStyle = exports.cFunctionFontColor = exports.cFunctionFontBackgroundColor = exports.cFunctionConstantsValidation = exports.cFrameworkVersionNumber = exports.cFrameworkProductionRootPath = exports.cFrameworkName = exports.cFrameworkDevelopRootPath = exports.cFrameworkDescription = exports.cFramework = exports.cForwardSlash = exports.cFilenames = exports.cFilename = exports.cFileTypes = void 0;
exports.cdevtty = exports.cdev = exports.cdeployMetaData = exports.cdeployApplication = exports.ccurrentMasterStringArrayElement = exports.cctrl_z = exports.cctrl_y = exports.cctrl_x = exports.cctrl_w = exports.cctrl_v = exports.cctrl_u = exports.cctrl_t = exports.cctrl_s = exports.cctrl_r = exports.cctrl_q = exports.cctrl_p = exports.cctrl_o = exports.cctrl_n = exports.cctrl_m = exports.cctrl_l = exports.cctrl_k = exports.cctrl_j = exports.cctrl_i = exports.cctrl_h = exports.cctrl_g = exports.cctrl_f = exports.cctrl_e = exports.cctrl_d = exports.cctrl_c = exports.cctrl_b = exports.cctrl_a = exports.ccountry_constants_js = exports.cconstant_constants_js = exports.cconfiguration_constants_js = exports.ccommandsBlob = exports.ccommand_constants_js = exports.ccolor_constants_js = exports.cclientRulesLibrary = exports.cclientCommands = exports.cclientBusinessRules = exports.cchildElementCount = exports.cbusiness_constants_js = exports.cbusinessRules = exports.cbusinessRule = exports.cbigInteger = exports.cbasic_constants_js = exports.cbackground = exports.capplicationConfigFileName = exports.cappConfigPath = exports.candSuffix = exports.candSpaceDomainSpaceName = exports.candPrefix = exports.callowableSpecialCharacters = exports.caddWithText = exports.caddTimeout = exports.caddSibling = exports.caddParent = exports.caddNth = exports.caddFindValue = exports.caddFilter = exports.cWorkflowDataPath = exports.cWord2ConstantsValidation = exports.cWord1ConstantsValidation = exports.cWithoutThe = exports.cWithText = exports.cWithSpecificSuffixAndDomainName = exports.cWithSpecialCharacters = exports.cVrml = exports.cVisibilityCheck = exports.cVideoLogs = exports.cVersionControl = exports.cValidEmail = exports.cVRML = exports.cUsername = exports.cUpperCase = exports.cUnitConstantsValidation = exports.cUnderscore = exports.cUnderline = exports.cTypeText = exports.cTimeoutOverride = exports.cTimeStamp = exports.cTextWithSpecialCharactersByLength = exports.cTextWithSpecialCharacters = exports.cTextByLength = exports.cTestTimeStamp = exports.cTestRunTime = exports.cTestRunID = exports.cTestDataFileName = exports.cTestData = exports.cTestBureau = exports.cTestAutomation = exports.cSystemConstantsValidation = exports.cSystemConstantsPathActual = exports.cSystemConstantsPath = exports.cSyncSingular = exports.cSuffixAndDomain = exports.cStandardDeviation = exports.cSpecialCharacters = exports.cSpecialCharacterCodeByLength = exports.cSpecialCharacter = void 0;
exports.cword1_constants_js = exports.cwithText = exports.cwasCompleted = exports.cvrml = exports.cvisibilityCheck = exports.cvalidEmail = exports.cunit_constants_js = exports.cunderline = exports.ctypeText = exports.csystem_constants_js = exports.csystemConfigFileName = exports.cspecifiedSuffixAndDomain = exports.csmuggleSomething = exports.cshape_constants_js = exports.cselectorTimeout = exports.crulesLibrary = exports.creturnData = exports.creleaseApplication = exports.crandomlyGenerate = exports.cprogramLoop = exports.cphonic_constants_js = exports.cpackageDotJson = exports.cnumeric_constants_js = exports.cnumberOfCharactersToGenerate = exports.cnavigateTo = exports.cmetaDatadotJson = exports.cmessage_constants_js = exports.clanguage_constants_js = exports.cknot_constants_js = exports.cisotope_constants_js = exports.cinnerText = exports.cinnerHTML = exports.cgeneric_constants_js = exports.cgenerateValidEmail = exports.cgenerateSpecialCharacters = exports.cgenerateRandom = exports.cgenerateInvalidEmail = exports.cfunction_constants_js = exports.cframeworkResourcesWorkflowsPath = exports.cframeworkResourcesPath = exports.cframeworkResourcesConfigurationPath = exports.cframeworkResourcesCommandAliasesPath = exports.cframeworkConstantsPath = exports.cframeworkConfigPath = exports.cframework = exports.cfilesLists = exports.cfilenames = exports.cfilename = exports.cfailureMode = exports.cexportconst = exports.celement_constants_js = exports.cdomainSpaceName = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var gen = _interopRequireWildcard(require("./generic.constants.js"));

var num = _interopRequireWildcard(require("./numeric.constants.js"));

var phn = _interopRequireWildcard(require("./phonic.constants.js"));

var wr1 = _interopRequireWildcard(require("./word1.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file system.constants.js
 * @module system.constants
 * @description Contains system defined acronyms, many of them derived from the basic.constants.
 * The constants contained in this file are system words, phrases, codes and paths.
 * @requires module:basic.constants
 * @requires module:generic.constants
 * @requires module:numeric.constants
 * @requires module:phonic.constants
 * @requires module:word1.constants
 * @author Seth Hollingsead
 * @date 2021/11/09
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// Miscelaneious
var cENV = bas.cEN + bas.cV; // ENV

exports.cENV = cENV;
var cLOG = bas.cLO + bas.cG; // LOG

exports.cLOG = cLOG;
var cENVIRONMENT = phn.cENV + bas.cIR + bas.cON + phn.cMENT; // ENVIRONMENT

exports.cENVIRONMENT = cENVIRONMENT;
var cITERATION = bas.cIT + bas.cER + bas.cAT + bas.cIO + bas.cN; // ITERATION

exports.cITERATION = cITERATION;
var cSTYLE = bas.cST + bas.cYL + bas.cE; // STYLE
// Compound System Words

exports.cSTYLE = cSTYLE;
var cunderline = wr1.cunder + wr1.cline; // underline

exports.cunderline = cunderline;
var cUnderline = wr1.cUnder + wr1.cline; // Underline

exports.cUnderline = cUnderline;
var cwithText = wr1.cwith + wr1.cText; // withText

exports.cwithText = cwithText;
var cWithText = wr1.cWith + wr1.cText; // WithText

exports.cWithText = cWithText;
var cDebugTest = wr1.cDebug + wr1.cTest; // DebugTest

exports.cDebugTest = cDebugTest;
var cDebugPage = wr1.cDebug + wr1.cPage; // DebugPage

exports.cDebugPage = cDebugPage;
var cDebugTestExhaustive = cDebugTest + wr1.cExhaustive; // DebugTestExhaustive

exports.cDebugTestExhaustive = cDebugTestExhaustive;
var cDebugForceMessageToLogFile = wr1.cDebug + wr1.cForce + wr1.cMessage + bas.cTo + wr1.cLog + wr1.cFile; // DebugForceMessageToLogFile

exports.cDebugForceMessageToLogFile = cDebugForceMessageToLogFile;
var cDebugTestData = cDebugTest + wr1.cData; // DebugTestData

exports.cDebugTestData = cDebugTestData;
var cDebugPageScripts = cDebugPage + wr1.cScripts; // DebugPageScripts

exports.cDebugPageScripts = cDebugPageScripts;
var cDebugPageData = cDebugPage + wr1.cData; // DebugPageData

exports.cDebugPageData = cDebugPageData;
var cDebugKeywords = wr1.cDebug + wr1.cKeywords; // DebugKeywords

exports.cDebugKeywords = cDebugKeywords;
var cLogBrowserActions = wr1.cLog + wr1.cBrowser + wr1.cActions; // LogBrowserActions

exports.cLogBrowserActions = cLogBrowserActions;
var cJournalBrowserActions = wr1.cJournal + wr1.cBrowser + wr1.cActions; // JournalBrowserActions

exports.cJournalBrowserActions = cJournalBrowserActions;
var cDebugBrowserActions = wr1.cDebug + wr1.cBrowser + wr1.cActions; // DebugBrowserActions

exports.cDebugBrowserActions = cDebugBrowserActions;
var cDebugSelectors = wr1.cDebug + wr1.cSelectors; // DebugSelectors

exports.cDebugSelectors = cDebugSelectors;
var cTestAutomation = wr1.cTest + wr1.cAutomation; // TestAutomation

exports.cTestAutomation = cTestAutomation;
var cNumberOfRows = wr1.cNumber + wr1.cOf + wr1.cRows; // NumberOfRows

exports.cNumberOfRows = cNumberOfRows;
var cMasterRowNumber = wr1.cMaster + wr1.cRow + wr1.cNumber; // MasterRowNumber

exports.cMasterRowNumber = cMasterRowNumber;
var cEnvironmentRow = wr1.cEnvironment + wr1.cRow; // EnvironmentRow

exports.cEnvironmentRow = cEnvironmentRow;
var cEnvironmentRowNumber = cEnvironmentRow + wr1.cNumber; // EnvironmentRowNumber

exports.cEnvironmentRowNumber = cEnvironmentRowNumber;
var cPageScript = wr1.cPage + wr1.cScript; // PageScript

exports.cPageScript = cPageScript;
var cIntermediatePath = wr1.cIntermediate + wr1.cPath; // IntermediatePath

exports.cIntermediatePath = cIntermediatePath;
var cTimeStamp = wr1.cTime + wr1.cStamp; // TimeStamp

exports.cTimeStamp = cTimeStamp;
var cPageScriptTimeStamp = cPageScript + cTimeStamp; // PageScriptTimeStamp

exports.cPageScriptTimeStamp = cPageScriptTimeStamp;
var cDateTimeStamp = wr1.cDate + cTimeStamp; // DateTimeStamp

exports.cDateTimeStamp = cDateTimeStamp;
var cScriptDateStamp = wr1.cScript + wr1.cDate + wr1.cStamp; // ScriptDateStamp

exports.cScriptDateStamp = cScriptDateStamp;
var cScriptTimeStamp = wr1.cScript + cTimeStamp; // ScriptTimeStamp

exports.cScriptTimeStamp = cScriptTimeStamp;
var cKeywordTimeStamp = wr1.cKeyword + cTimeStamp; // KeywordTimeStamp

exports.cKeywordTimeStamp = cKeywordTimeStamp;
var cTestTimeStamp = wr1.cTest + cTimeStamp; // TestTimeStamp

exports.cTestTimeStamp = cTestTimeStamp;
var cScriptDateTimeStamp = wr1.cScript + cDateTimeStamp; // ScriptDateTimeStamp

exports.cScriptDateTimeStamp = cScriptDateTimeStamp;
var cBeginScriptTimeStamp = wr1.cBegin + cScriptTimeStamp; // BeginScriptTimeStamp

exports.cBeginScriptTimeStamp = cBeginScriptTimeStamp;
var cEndScriptTimeStamp = wr1.cEnd + cScriptTimeStamp; // EndScriptTimeStamp

exports.cEndScriptTimeStamp = cEndScriptTimeStamp;
var cBeginTestTimeStamp = wr1.cBegin + cTestTimeStamp; // BeginTestTimeStamp

exports.cBeginTestTimeStamp = cBeginTestTimeStamp;
var cEndTestTimeStamp = wr1.cEnd + cTestTimeStamp; // EndTestTimeStamp

exports.cEndTestTimeStamp = cEndTestTimeStamp;
var cBeginPageScriptTimeStamp = wr1.cBegin + cPageScriptTimeStamp; // BeginPageScriptTimeStamp

exports.cBeginPageScriptTimeStamp = cBeginPageScriptTimeStamp;
var cEndPageScriptTimeStamp = wr1.cEnd + cPageScriptTimeStamp; // EndPageScriptTimeStamp

exports.cEndPageScriptTimeStamp = cEndPageScriptTimeStamp;
var cBeginKeywordTimeStamp = wr1.cBegin + cKeywordTimeStamp; // BeginKeywordTimeStamp

exports.cBeginKeywordTimeStamp = cBeginKeywordTimeStamp;
var cEndKeywordTimeStamp = wr1.cEnd + cKeywordTimeStamp; // EndKeywordTimeStamp

exports.cEndKeywordTimeStamp = cEndKeywordTimeStamp;
var cRuntime = wr1.cRun + wr1.ctime; // Runtime

exports.cRuntime = cRuntime;
var cRunTime = wr1.cRun + wr1.cTime; // RunTime

exports.cRunTime = cRunTime;
var cBrowserName = wr1.cBrowser + wr1.cName; // BrowserName

exports.cBrowserName = cBrowserName;
var cHostName = wr1.cHost + wr1.cName; // HostName

exports.cHostName = cHostName;
var cTestRunID = wr1.cTest + wr1.cRun + wr1.cID; // TestRunID

exports.cTestRunID = cTestRunID;
var cfilesLists = wr1.cfiles + wr1.cLists; // filesLists

exports.cfilesLists = cfilesLists;
var cFileTypes = wr1.cFile + wr1.cTypes; // FileTypes

exports.cFileTypes = cFileTypes;
var cfilename = wr1.cfile + wr1.cname; // filename

exports.cfilename = cfilename;
var cFilename = wr1.cFile + wr1.cname; // Filename

exports.cFilename = cFilename;
var cFileName = wr1.cFile + wr1.cName; // FileName

exports.cFileName = cFileName;
var cfilenames = cfilename + bas.cs; // filenames

exports.cfilenames = cfilenames;
var cFilenames = cFilename + bas.cs; // Filenames

exports.cFilenames = cFilenames;
var cFileNames = cFileName + bas.cs; // FileNames

exports.cFileNames = cFileNames;
var cPreValidateFileName = phn.cPre + wr1.cValidate + cFileName; // PreValidateFileName

exports.cPreValidateFileName = cPreValidateFileName;
var cAsyncSingular = wr1.cAsync + wr1.cSingular; // AsyncSingular

exports.cAsyncSingular = cAsyncSingular;
var cSyncSingular = wr1.cSync + wr1.cSingular; // SyncSingular

exports.cSyncSingular = cSyncSingular;
var cParallelMultiUnified = wr1.cParallel + wr1.cMulti + wr1.cUnified; // ParallelMultiUnified

exports.cParallelMultiUnified = cParallelMultiUnified;
var cAllowableCharacters = wr1.cAllowable + wr1.cCharacters; // AllowableCharacters

exports.cAllowableCharacters = cAllowableCharacters;
var cSpecialCharacters = wr1.cSpecial + wr1.cCharacters; // SpecialCharacters

exports.cSpecialCharacters = cSpecialCharacters;
var cTimeoutOverride = wr1.cTimeout + wr1.cOverride; // TimeoutOverride

exports.cTimeoutOverride = cTimeoutOverride;
var cDwellTime = wr1.cDwell + wr1.cTime; // DwellTime

exports.cDwellTime = cDwellTime;
var cFileCounter = wr1.cFile + wr1.cCounter; // FileCounter

exports.cFileCounter = cFileCounter;
var cDeltaT = gen.cDelta + bas.cT; // DeltaT

exports.cDeltaT = cDeltaT;
var cvisibilityCheck = wr1.cvisibility + wr1.cCheck; // visibilityCheck

exports.cvisibilityCheck = cvisibilityCheck;
var cVisibilityCheck = wr1.cVisibility + wr1.cCheck; // VisibilityCheck

exports.cVisibilityCheck = cVisibilityCheck;
var cOperatingSystem = wr1.cOperating + wr1.cSystem; // OperatingSystem

exports.cOperatingSystem = cOperatingSystem;
var cinnerText = wr1.cinner + wr1.cText; // innerText

exports.cinnerText = cinnerText;
var cInnerText = wr1.cInner + wr1.cText; // InnerText

exports.cInnerText = cInnerText;
var cinnerHTML = wr1.cinner + wr1.cHTML; // innerHTML

exports.cinnerHTML = cinnerHTML;
var cInnerHTML = wr1.cInner + wr1.cHTML; // InnerHTML

exports.cInnerHTML = cInnerHTML;
var cTestData = wr1.cTest + wr1.cData; // TestData

exports.cTestData = cTestData;
var cProcessingTimeout = wr1.cProcessing + wr1.cTimeout; // ProcessingTimeout

exports.cProcessingTimeout = cProcessingTimeout;
var cIngestionCompleteDwellTime = wr1.cIngestion + wr1.cComplete + cDwellTime; // IngestionCompleteDwellTime

exports.cIngestionCompleteDwellTime = cIngestionCompleteDwellTime;
var cRowNumber = wr1.cRow + wr1.cNumber; // RowNumber

exports.cRowNumber = cRowNumber;
var cUsername = wr1.cUser + wr1.cname; // Username

exports.cUsername = cUsername;
var cPassword = wr1.cPass + wr1.cword; // Password

exports.cPassword = cPassword;
var cProjectName = wr1.cProject + wr1.cName; // ProjectName

exports.cProjectName = cProjectName;
var cProjectDescription = wr1.cProject + wr1.cDescription; // ProjectDescription

exports.cProjectDescription = cProjectDescription;
var cTestDataFileName = wr1.cTest + wr1.cData + cFileName; // TestDataFileName

exports.cTestDataFileName = cTestDataFileName;
var cShareEmail = wr1.cShare + wr1.cEmail; // ShareEmail

exports.cShareEmail = cShareEmail;
var cAccessLevel = wr1.cAccess + wr1.cLevel; // AccessLevel

exports.cAccessLevel = cAccessLevel;
var cFileNumber = wr1.cFile + wr1.cNumber; // FileNumber

exports.cFileNumber = cFileNumber;
var cConfigurationName = wr1.cConfiguration + wr1.cName; // ConfigurationName

exports.cConfigurationName = cConfigurationName;
var cConfigurationElement = wr1.cConfiguration + wr1.cElement; // ConfigurationElement

exports.cConfigurationElement = cConfigurationElement;
var cConfigurationElements = cConfigurationElement + bas.cs; // ConfigurationElements

exports.cConfigurationElements = cConfigurationElements;
var cVersionControl = wr1.cVersion + wr1.cControl; // VersionControl

exports.cVersionControl = cVersionControl;
var cScriptRunTime = wr1.cScript + cRunTime; // ScriptRunTime

exports.cScriptRunTime = cScriptRunTime;
var cTestRunTime = wr1.cTest + cRunTime; // TestRunTime

exports.cTestRunTime = cTestRunTime;
var ctypeText = wr1.ctype + wr1.cText; // typeText

exports.ctypeText = ctypeText;
var cTypeText = wr1.cType + wr1.cText; // TypeText

exports.cTypeText = cTypeText;
var cAbreviatedSelectors = wr1.cAbreviated + wr1.cSelectors; // AbreviatedSelectors

exports.cAbreviatedSelectors = cAbreviatedSelectors;
var cAbreviatedSelectorsInLogs = cAbreviatedSelectors + bas.cIn + wr1.cLogs; // AbreviatedSelectorsInLogs

exports.cAbreviatedSelectorsInLogs = cAbreviatedSelectorsInLogs;
var cselectorTimeout = wr1.cselector + wr1.cTimeout; // selectorTimeout

exports.cselectorTimeout = cselectorTimeout;
var cchildElementCount = wr1.cchild + wr1.cElement + wr1.cCount; // childElementCount

exports.cchildElementCount = cchildElementCount;
var cUnderscore = wr1.cUnder + wr1.cscore; // Underscore

exports.cUnderscore = cUnderscore;
var cTestBureau = wr1.cTest + wr1.cBureau; // TestBureau

exports.cTestBureau = cTestBureau;
var caddWithText = wr1.c_add + wr1.cWith + wr1.cText; // addWithText

exports.caddWithText = caddWithText;
var caddTimeout = wr1.c_add + wr1.cTimeout; // addTimeout

exports.caddTimeout = caddTimeout;
var caddParent = wr1.c_add + wr1.cParent; // addParent

exports.caddParent = caddParent;
var caddFindValue = wr1.c_add + wr1.cFind + wr1.cValue; // addFindValue

exports.caddFindValue = caddFindValue;
var caddNth = wr1.c_add + wr1.cNth; // addNth

exports.caddNth = caddNth;
var caddSibling = wr1.c_add + wr1.cSibling; // addSibling

exports.caddSibling = caddSibling;
var caddFilter = wr1.c_add + wr1.cFilter; // addFilter

exports.caddFilter = caddFilter;
var cgenerateRandom = wr1.cgenerate + wr1.cRandom; // generateRandom

exports.cgenerateRandom = cgenerateRandom;
var crandomlyGenerate = wr1.crandomly + wr1.cGenerate; // randomlyGenerate

exports.crandomlyGenerate = crandomlyGenerate;
var cMixedCase = wr1.cMixed + wr1.cCase; // MixedCase

exports.cMixedCase = cMixedCase;
var cUpperCase = wr1.cUpper + wr1.cCase; // UpperCase

exports.cUpperCase = cUpperCase;
var cLowerCase = wr1.cLower + wr1.cCase; // LowerCase

exports.cLowerCase = cLowerCase;
var cByLength = wr1.cBy + wr1.cLength; // ByLength

exports.cByLength = cByLength;
var cSpecialCharacter = wr1.cSpecial + wr1.cCharacter; // SpecialCharacter

exports.cSpecialCharacter = cSpecialCharacter;
var cWithSpecialCharacters = wr1.cWith + cSpecialCharacters; // WithSpecialCharacters

exports.cWithSpecialCharacters = cWithSpecialCharacters;
var cTextByLength = wr1.cText + cByLength; // TextByLength

exports.cTextByLength = cTextByLength;
var cTextWithSpecialCharacters = wr1.cText + cWithSpecialCharacters; // TextWithSpecialCharacters

exports.cTextWithSpecialCharacters = cTextWithSpecialCharacters;
var cTextWithSpecialCharactersByLength = cTextWithSpecialCharacters + cByLength; // TextWithSpecialCharactersByLength

exports.cTextWithSpecialCharactersByLength = cTextWithSpecialCharactersByLength;
var cAlphaNumeric = wr1.cAlpha + wr1.cNumeric; // AlphaNumeric

exports.cAlphaNumeric = cAlphaNumeric;
var cAlphaNumericCode = cAlphaNumeric + wr1.cCode; // AlphaNumericCode

exports.cAlphaNumericCode = cAlphaNumericCode;
var cAlphaNumericCodeByLength = cAlphaNumericCode + cByLength; // AlphaNumericCodeByLength

exports.cAlphaNumericCodeByLength = cAlphaNumericCodeByLength;
var cNumericCode = wr1.cNumeric + wr1.cCode; // NumericCode

exports.cNumericCode = cNumericCode;
var cNumericCodeByLength = cNumericCode + cByLength; // NumericCodeByLength

exports.cNumericCodeByLength = cNumericCodeByLength;
var cAlphaNumericCodeWithSpecialCharacters = cAlphaNumericCode + cWithSpecialCharacters; // AlphaNumericCodeWithSpecialCharacters

exports.cAlphaNumericCodeWithSpecialCharacters = cAlphaNumericCodeWithSpecialCharacters;
var cAlphaNumericCodeWithSpecialCharactersByLength = cAlphaNumericCodeWithSpecialCharacters + cByLength; // AlphaNumericCodeWithSpecialCharactersByLength

exports.cAlphaNumericCodeWithSpecialCharactersByLength = cAlphaNumericCodeWithSpecialCharactersByLength;
var cSpecialCharacterCodeByLength = cSpecialCharacter + wr1.cCode + cByLength; // SpecialCharacterCodeByLength

exports.cSpecialCharacterCodeByLength = cSpecialCharacterCodeByLength;
var cvalidEmail = wr1.cvalid + wr1.cEmail; // validEmail

exports.cvalidEmail = cvalidEmail;
var cValidEmail = wr1.cValid + wr1.cEmail; // ValidEmail

exports.cValidEmail = cValidEmail;
var cInvalidEmail = bas.cIn + cvalidEmail; // InvalidEmail

exports.cInvalidEmail = cInvalidEmail;
var cgenerateValidEmail = wr1.cgenerate + cValidEmail; // generateValidEmail

exports.cgenerateValidEmail = cgenerateValidEmail;
var cgenerateInvalidEmail = wr1.cgenerate + cInvalidEmail; // generateInvalidEmail

exports.cgenerateInvalidEmail = cgenerateInvalidEmail;
var cRandomValidEmail = wr1.cRandom + cValidEmail; // RandomValidEmail

exports.cRandomValidEmail = cRandomValidEmail;
var cRandomInvalidEmail = wr1.cRandom + cInvalidEmail; // RandomInvalidEmail

exports.cRandomInvalidEmail = cRandomInvalidEmail;
var cLetterOr = wr1.cLetter + bas.cOr; // LetterOr

exports.cLetterOr = cLetterOr;
var cLetterOrSpecialCharacter = cLetterOr + cSpecialCharacter; // LetterOrSpecialCharacter

exports.cLetterOrSpecialCharacter = cLetterOrSpecialCharacter;
var cLetterOrNumberOrSpecialCharacter = cLetterOr + wr1.cNumber + wr1.cOr + cSpecialCharacter; // LetterOrNumberOrSpecialCharacter

exports.cLetterOrNumberOrSpecialCharacter = cLetterOrNumberOrSpecialCharacter;
var cAlphaNumericCharacter = cAlphaNumeric + wr1.cCharacter; // AlphaNumericCharacter

exports.cAlphaNumericCharacter = cAlphaNumericCharacter;
var cSuffixAndDomain = wr1.cSuffix + wr1.cAnd + wr1.cDomain; // SuffixAndDomain

exports.cSuffixAndDomain = cSuffixAndDomain;
var cWithSpecificSuffixAndDomainName = wr1.cWith + wr1.cSpecific + wr1.cSuffix + wr1.cAnd + wr1.cDomain + wr1.cName; // WithSpecificSuffixAndDomainName

exports.cWithSpecificSuffixAndDomainName = cWithSpecificSuffixAndDomainName;
var cNumericCharacter = wr1.cNumeric + wr1.cCharacter; // NumericCharacter

exports.cNumericCharacter = cNumericCharacter;
var cNumberInRange = wr1.cNumber + bas.cIn + wr1.cRange; // NumberInRange

exports.cNumberInRange = cNumberInRange;
var cBooleanValue = wr1.cBoolean + wr1.cValue; // BooleanValue

exports.cBooleanValue = cBooleanValue;
var cAlphabeticCharacter = wr1.cAlphabetic + wr1.cCharacter; // AlphabeticCharacter

exports.cAlphabeticCharacter = cAlphabeticCharacter;
var cCarriageReturn = wr1.cCarriage + wr1.cReturn; // CarriageReturn

exports.cCarriageReturn = cCarriageReturn;
var cDashboardLogs = wr1.cDashboard + wr1.cLogs; // DashboardLogs

exports.cDashboardLogs = cDashboardLogs;
var cVideoLogs = wr1.cVideo + wr1.cLogs; // VideoLogs

exports.cVideoLogs = cVideoLogs;
var cForwardSlash = wr1.cForward + wr1.cSlash; // ForwardSlash

exports.cForwardSlash = cForwardSlash;
var cBackSlash = wr1.cBack + wr1.cSlash; // BackSlash

exports.cBackSlash = cBackSlash;
var cPage_Keywords = wr1.cPage + bas.cUnderscore + wr1.cKeywords; // Page_Keywords

exports.cPage_Keywords = cPage_Keywords;
var cnavigateTo = wr1.cnavigate + bas.cTo; // navigateTo

exports.cnavigateTo = cnavigateTo;
var cNavigateTo = wr1.cNavigate + bas.cTo; // NavigateTo

exports.cNavigateTo = cNavigateTo;
var cBrowserRefresh = wr1.cBrowser + wr1.cRefresh; // BrowserRefresh

exports.cBrowserRefresh = cBrowserRefresh;
var cSpaceIsColonSpace = bas.cSpace + bas.cis + bas.cColon + bas.cSpace; // is:

exports.cSpaceIsColonSpace = cSpaceIsColonSpace;
var cdeployApplication = wr1.cdeploy + wr1.cApplication; // deployApplication

exports.cdeployApplication = cdeployApplication;
var cdeployMetaData = wr1.cdeploy + wr1.cMetaData; // deployMetaData

exports.cdeployMetaData = cdeployMetaData;
var creleaseApplication = wr1.crelease + wr1.cApplication; // releaseApplication

exports.creleaseApplication = creleaseApplication;
var cbackground = wr1.cback + wr1.cground; // background

exports.cbackground = cbackground;
var cBackground = wr1.cBack + wr1.cground; // Background

exports.cBackground = cBackground;
var cConfiguration_Colors = wr1.cConfiguration + bas.cUnderscore + wr1.cColors; // Configuration_Colors

exports.cConfiguration_Colors = cConfiguration_Colors;
var cColorData = wr1.cColor + wr1.cData; // ColorData

exports.cColorData = cColorData;
var cColorName = wr1.cColor + wr1.cName; // ColorName

exports.cColorName = cColorName;
var cbusinessRule = wr1.cbusiness + wr1.cRule; // businessRule

exports.cbusinessRule = cbusinessRule;
var cBusinessRule = wr1.cBusiness + wr1.cRule; // BusinessRule

exports.cBusinessRule = cBusinessRule;
var cbusinessRules = wr1.cbusiness + wr1.cRules; // businessRules

exports.cbusinessRules = cbusinessRules;
var cBusinessRules = wr1.cBusiness + wr1.cRules; // BusinessRules

exports.cBusinessRules = cBusinessRules;
var ccommandsBlob = wr1.ccommands + wr1.cBlob; // commandsBlob

exports.ccommandsBlob = ccommandsBlob;
var cCommandsBlob = wr1.cCommands + wr1.cBlob; // CommandsBlob

exports.cCommandsBlob = cCommandsBlob;
var crulesLibrary = wr1.crules + wr1.cLibrary; // rulesLibrary

exports.crulesLibrary = crulesLibrary;
var cframework = wr1.cframe + wr1.cwork; // framework

exports.cframework = cframework;
var cFramework = wr1.cFrame + wr1.cwork; // Framework

exports.cFramework = cFramework;
var cCommandsAliases = wr1.cCommands + wr1.cAliases; // CommandsAliases

exports.cCommandsAliases = cCommandsAliases;
var cCommandWorkflows = wr1.cCommand + wr1.cWorkflows; // CommandWorkflows

exports.cCommandWorkflows = cCommandWorkflows;
var cStandardDeviation = wr1.cStandard + wr1.cDeviation; // StandardDeviation

exports.cStandardDeviation = cStandardDeviation;
var cHexValue = phn.cHex + wr1.cValue; // HexValue

exports.cHexValue = cHexValue;
var cexportconst = wr1.cexport + bas.cSpace + gen.cconst; // export-const // With a space not a dash, but the validation code is looking for that exact string.

exports.cexportconst = cexportconst;
var csmuggleSomething = wr1.csmuggle + bas.cSpace + wr1.csomething; // smuggle something

exports.csmuggleSomething = csmuggleSomething;
var cDataStorage = wr1.cData + wr1.cStorage; // DataStorage

exports.cDataStorage = cDataStorage;
var cSource1 = wr1.cSource + num.c1; // Source1

exports.cSource1 = cSource1;
var cSource2 = wr1.cSource + num.c2; // Source2

exports.cSource2 = cSource2;
var cbigInteger = wr1.cbig + wr1.cInteger; // bigInteger

exports.cbigInteger = cbigInteger;
var cnumberOfCharactersToGenerate = wr1.cnumber + bas.cOf + wr1.cCharacters + bas.cTo + wr1.cGenerate; // numberOfCharactersToGenerate

exports.cnumberOfCharactersToGenerate = cnumberOfCharactersToGenerate;
var cgenerateSpecialCharacters = wr1.cgenerate + cSpecialCharacters; // generateSpecialCharacters

exports.cgenerateSpecialCharacters = cgenerateSpecialCharacters;
var callowableSpecialCharacters = wr1.callowable + cSpecialCharacters; // allowableSpecialCharacters

exports.callowableSpecialCharacters = callowableSpecialCharacters;
var cspecifiedSuffixAndDomain = wr1.cspecified + cSuffixAndDomain; // specifiedSuffixAndDomain

exports.cspecifiedSuffixAndDomain = cspecifiedSuffixAndDomain;
var cfailureMode = wr1.cfailure + wr1.cMode; // failureMode

exports.cfailureMode = cfailureMode;
var cWithoutThe = wr1.cWithout + bas.cSpace + wr1.cthe; // Without the

exports.cWithoutThe = cWithoutThe;
var cwasCompleted = wr1.cwas + bas.cSpace + wr1.ccompleted; // was completed

exports.cwasCompleted = cwasCompleted;
var cGenerateA = wr1.cGenerate + bas.cSpace + bas.ca; // Generate a

exports.cGenerateA = cGenerateA;
var cprogramLoop = wr1.cprogram + bas.cSpace + wr1.cloop; // program loop

exports.cprogramLoop = cprogramLoop;
var candPrefix = wr1.cand + bas.cSpace + wr1.cprefix; // and prefix

exports.candPrefix = candPrefix;
var candSuffix = wr1.cand + bas.cSpace + wr1.csuffix; // and suffix

exports.candSuffix = candSuffix;
var cdomainSpaceName = wr1.cdomain + bas.cSpace + wr1.cname; // domain name

exports.cdomainSpaceName = cdomainSpaceName;
var candSpaceDomainSpaceName = wr1.cand + bas.cSpace + cdomainSpaceName; // and domain name

exports.candSpaceDomainSpaceName = candSpaceDomainSpaceName;
var ccurrentMasterStringArrayElement = wr1.ccurrent + wr1.cMaster + wr1.cString + wr1.cArray + wr1.cElement; // currentMasterStringArrayElement

exports.ccurrentMasterStringArrayElement = ccurrentMasterStringArrayElement;
var cLehmerCodeArray = wr1.cLehmer + wr1.cCode + wr1.cArray; // LehmerCodeArray

exports.cLehmerCodeArray = cLehmerCodeArray;
var creturnData = wr1.creturn + wr1.cData; // returnData

exports.creturnData = creturnData;
var cCamelCase = wr1.cCamel + wr1.cCase; // CamelCase
// Logging Styles Constants

exports.cCamelCase = cCamelCase;
var cModuleFontStyle = wr1.cModule + wr1.cFont + wr1.cStyle; // ModuleFontStyle

exports.cModuleFontStyle = cModuleFontStyle;
var cFunctionFontStyle = wr1.cFunction + wr1.cFont + wr1.cStyle; // FunctionFontStyle

exports.cFunctionFontStyle = cFunctionFontStyle;
var cMessageFontStyle = wr1.cMessage + wr1.cFont + wr1.cStyle; // MessageFontStyle

exports.cMessageFontStyle = cMessageFontStyle;
var cDataFontStyle = wr1.cData + wr1.cFont + wr1.cStyle; // DataFontStyle

exports.cDataFontStyle = cDataFontStyle;
var cModuleFontColor = wr1.cModule + wr1.cFont + wr1.cColor; // ModuleFontColor

exports.cModuleFontColor = cModuleFontColor;
var cFunctionFontColor = wr1.cFunction + wr1.cFont + wr1.cColor; // FunctionFontColor

exports.cFunctionFontColor = cFunctionFontColor;
var cMessageFontColor = wr1.cMessage + wr1.cFont + wr1.cColor; // MessageFontColor

exports.cMessageFontColor = cMessageFontColor;
var cDataFontColor = wr1.cData + wr1.cFont + wr1.cColor; // DataFontColor

exports.cDataFontColor = cDataFontColor;
var cModuleFontBackgroundColor = wr1.cModule + wr1.cFont + cBackground + wr1.cColor; // ModuleFontBackgroundColor

exports.cModuleFontBackgroundColor = cModuleFontBackgroundColor;
var cFunctionFontBackgroundColor = wr1.cFunction + wr1.cFont + cBackground + wr1.cColor; // FunctionFontBackgroundColor

exports.cFunctionFontBackgroundColor = cFunctionFontBackgroundColor;
var cMessageFontBackgroundColor = wr1.cMessage + wr1.cFont + cBackground + wr1.cColor; // MessageFontBackgroundColor

exports.cMessageFontBackgroundColor = cMessageFontBackgroundColor;
var cDataFontBackgroundColor = wr1.cData + wr1.cFont + cBackground + wr1.cColor; // DataFontBackgroundColor
// File Types

exports.cDataFontBackgroundColor = cDataFontBackgroundColor;
var cCatia = bas.cCa + bas.cti + bas.ca; // Catia

exports.cCatia = cCatia;
var cDocument = wr1.cDocument; // Document

exports.cDocument = cDocument;
var cDocuments = cDocument + bas.cs; // Documents

exports.cDocuments = cDocuments;
var cDraft = bas.cDr + phn.caft; // Draft

exports.cDraft = cDraft;
var cDWG = bas.cDW + bas.cG; // DWG

exports.cDWG = cDWG;
var cHoops = bas.cH + wr1.coops; // Hoops

exports.cHoops = cHoops;
var cHOOPS = bas.cH + wr1.cOOPS; // HOOPS

exports.cHOOPS = cHOOPS;
var cImage = bas.cIm + phn.cage; // Image

exports.cImage = cImage;
var cImages = cImage + bas.cs; // Images

exports.cImages = cImages;
var cInventor = phn.cInv + bas.cen + phn.ctor; // Inventor

exports.cInventor = cInventor;
var cNeutral = bas.cNe + bas.cut + phn.cral; // Neutral

exports.cNeutral = cNeutral;
var cNX = bas.cNX; // NX

exports.cNX = cNX;
var cParasolid = bas.cP + phn.cara + wr1.csolid; // Parasolid

exports.cParasolid = cParasolid;
var cProE = phn.cPro + bas.cE; // ProE

exports.cProE = cProE;
var cRhino = bas.cRh + phn.cino; // Rhino

exports.cRhino = cRhino;
var cSolidEdge = wr1.cSolid + wr1.cEdge; // SolidEdge

exports.cSolidEdge = cSolidEdge;
var cSolidWorks = wr1.cSolid + wr1.cWorks; // SolidWorks

exports.cSolidWorks = cSolidWorks;
var cvrml = bas.cvr + bas.cml; // vrml

exports.cvrml = cvrml;
var cVrml = bas.cVr + bas.cml; // Vrml

exports.cVrml = cVrml;
var cVRML = bas.cVR + bas.cML; // VRML
// UI Element Types

exports.cVRML = cVRML;
var cButton = bas.cBu + bas.ctt + bas.con; // Button
// Environment Variables

exports.cButton = cButton;
var cQA = bas.cQA; // QA

exports.cQA = cQA;
var cdev = bas.cde + bas.cv; // dev

exports.cdev = cdev;
var cDEV = bas.cDE + bas.cV; // DEV

exports.cDEV = cDEV;
var cProd = phn.cPro + bas.cd; // Prod

exports.cProd = cProd;
var cPROD = phn.cPRO + bas.cD; // PROD

exports.cPROD = cPROD;
var cPre = phn.cPre; // Pre

exports.cPre = cPre;
var cPRE = phn.cPRE; // PRE

exports.cPRE = cPRE;
var cPreProd = phn.cPre + cProd; // PreProd

exports.cPreProd = cPreProd;
var cPREPROD = phn.cPRE + cPROD; // PREPROD
// Key Combinations

exports.cPREPROD = cPREPROD;
var cctrl_a = phn.cctrl + bas.cPlus + bas.ca; // ctrl+a

exports.cctrl_a = cctrl_a;
var cctrl_b = phn.cctrl + bas.cPlus + bas.cb; // ctrl+b

exports.cctrl_b = cctrl_b;
var cctrl_c = phn.cctrl + bas.cPlus + bas.cc; // ctrl+c

exports.cctrl_c = cctrl_c;
var cctrl_d = phn.cctrl + bas.cPlus + bas.cd; // ctrl+d

exports.cctrl_d = cctrl_d;
var cctrl_e = phn.cctrl + bas.cPlus + bas.ce; // ctrl+e

exports.cctrl_e = cctrl_e;
var cctrl_f = phn.cctrl + bas.cPlus + bas.cf; // ctrl+f

exports.cctrl_f = cctrl_f;
var cctrl_g = phn.cctrl + bas.cPlus + bas.cg; // ctrl+g

exports.cctrl_g = cctrl_g;
var cctrl_h = phn.cctrl + bas.cPlus + bas.ch; // ctrl+h

exports.cctrl_h = cctrl_h;
var cctrl_i = phn.cctrl + bas.cPlus + bas.ci; // ctrl+i

exports.cctrl_i = cctrl_i;
var cctrl_j = phn.cctrl + bas.cPlus + bas.cj; // ctrl+j

exports.cctrl_j = cctrl_j;
var cctrl_k = phn.cctrl + bas.cPlus + bas.ck; // ctrl+k

exports.cctrl_k = cctrl_k;
var cctrl_l = phn.cctrl + bas.cPlus + bas.cl; // ctrl+l

exports.cctrl_l = cctrl_l;
var cctrl_m = phn.cctrl + bas.cPlus + bas.cm; // ctrl+m

exports.cctrl_m = cctrl_m;
var cctrl_n = phn.cctrl + bas.cPlus + bas.cn; // ctrl+n

exports.cctrl_n = cctrl_n;
var cctrl_o = phn.cctrl + bas.cPlus + bas.co; // ctrl+o

exports.cctrl_o = cctrl_o;
var cctrl_p = phn.cctrl + bas.cPlus + bas.cp; // ctrl+p

exports.cctrl_p = cctrl_p;
var cctrl_q = phn.cctrl + bas.cPlus + bas.cq; // ctrl+q

exports.cctrl_q = cctrl_q;
var cctrl_r = phn.cctrl + bas.cPlus + bas.cr; // ctrl+r

exports.cctrl_r = cctrl_r;
var cctrl_s = phn.cctrl + bas.cPlus + bas.cs; // ctrl+s

exports.cctrl_s = cctrl_s;
var cctrl_t = phn.cctrl + bas.cPlus + bas.ct; // ctrl+t

exports.cctrl_t = cctrl_t;
var cctrl_u = phn.cctrl + bas.cPlus + bas.cu; // ctrl+u

exports.cctrl_u = cctrl_u;
var cctrl_v = phn.cctrl + bas.cPlus + bas.cv; // ctrl+v

exports.cctrl_v = cctrl_v;
var cctrl_w = phn.cctrl + bas.cPlus + bas.cw; // ctrl+w

exports.cctrl_w = cctrl_w;
var cctrl_x = phn.cctrl + bas.cPlus + bas.cx; // ctrl+x

exports.cctrl_x = cctrl_x;
var cctrl_y = phn.cctrl + bas.cPlus + bas.cy; // ctrl+y

exports.cctrl_y = cctrl_y;
var cctrl_z = phn.cctrl + bas.cPlus + bas.cz; // ctrl+z
// System Terms

exports.cctrl_z = cctrl_z;
var csystemConfigFileName = wr1.cframework + bas.cDot + wr1.csystem + gen.cDotjson; // framework.system.json

exports.csystemConfigFileName = csystemConfigFileName;
var capplicationConfigFileName = wr1.capplication + bas.cDot + wr1.csystem + gen.cDotjson; // application.system.json

exports.capplicationConfigFileName = capplicationConfigFileName;
var cappConfigPath = gen.capp + wr1.cConfig + wr1.cPath; // appConfigPath

exports.cappConfigPath = cappConfigPath;
var cframeworkConfigPath = wr1.cframework + wr1.cConfig + wr1.cPath; // frameworkConfigPath

exports.cframeworkConfigPath = cframeworkConfigPath;
var cApplicationName = wr1.cApplication + wr1.cName; // ApplicationName

exports.cApplicationName = cApplicationName;
var cApplicationRootPath = wr1.cApplication + wr1.cRoot + wr1.cPath; // ApplicationRootPath

exports.cApplicationRootPath = cApplicationRootPath;
var cApplicationCleanedRootPath = wr1.cApplication + wr1.cCleaned + wr1.cRoot + wr1.cPath; // ApplicationCleanedRootPath

exports.cApplicationCleanedRootPath = cApplicationCleanedRootPath;
var cConfigurationPath = wr1.cConfiguration + wr1.cPath; // ConfigurationPath

exports.cConfigurationPath = cConfigurationPath;
var cApplicationVersionNumber = wr1.cApplication + wr1.cVersion + wr1.cNumber; // ApplicationVersionNumber

exports.cApplicationVersionNumber = cApplicationVersionNumber;
var cApplicationDescription = wr1.cApplication + wr1.cDescription; // ApplicationDescription

exports.cApplicationDescription = cApplicationDescription;
var cDataPath = wr1.cData + wr1.cPath; // DataPath

exports.cDataPath = cDataPath;
var cCtempPath = bas.cc + bas.cColon + bas.cForwardSlash + phn.ctemp + bas.cForwardSlash; // CtempPath

exports.cCtempPath = cCtempPath;
var cPageDataPath = wr1.cPage + cDataPath; // PageDataPath

exports.cPageDataPath = cPageDataPath;
var cWorkflowDataPath = wr1.cWorkflow + cDataPath; // WorkflowDataPath

exports.cWorkflowDataPath = cWorkflowDataPath;
var cKeywordsDataPath = wr1.cKeywords + cDataPath; // KeywordsDataPath

exports.cKeywordsDataPath = cKeywordsDataPath;
var cLocatorsDataPath = wr1.cLocators + cDataPath; // LocatorsDataPath

exports.cLocatorsDataPath = cLocatorsDataPath;
var cClientConstantsPath = wr1.cClient + wr1.cConstants + wr1.cPath; // ClientConstantsPath

exports.cClientConstantsPath = cClientConstantsPath;
var cSystemConstantsPath = wr1.cSystem + wr1.cConstants + wr1.cPath; // SystemConstantsPath

exports.cSystemConstantsPath = cSystemConstantsPath;
var cSystemConstantsPathActual = wr1.csrc + bas.cForwardSlash + wr1.cconstants + bas.cForwardSlash; // src/constants/

exports.cSystemConstantsPathActual = cSystemConstantsPathActual;
var cclientBusinessRules = wr1.cclient + wr1.cBusiness + wr1.cRules; // clientBusinessRules

exports.cclientBusinessRules = cclientBusinessRules;
var cclientCommands = wr1.cclient + wr1.cCommands; // clientCommands

exports.cclientCommands = cclientCommands;
var cclientRulesLibrary = wr1.cclient + wr1.cRules + wr1.cLibrary; // clientRulesLibrary

exports.cclientRulesLibrary = cclientRulesLibrary;
var cCommandQueue = wr1.cCommand + wr1.cQueue; // CommandQueue

exports.cCommandQueue = cCommandQueue;
var cConstantsValidationData = wr1.cConstants + wr1.cValidation + wr1.cData; // ConstantsValidationData

exports.cConstantsValidationData = cConstantsValidationData;
var cConstantsShortNames = wr1.cConstants + wr1.cShort + wr1.cNames; // ConstantsShortNames

exports.cConstantsShortNames = cConstantsShortNames;
var cConstantsFileNames = wr1.cConstants + wr1.cFile + wr1.cNames; // ConstantsFileNames

exports.cConstantsFileNames = cConstantsFileNames;
var cConstantsPrefix = wr1.cConstants + wr1.cPrefix; // ConstantsPrefix

exports.cConstantsPrefix = cConstantsPrefix;
var cConstantsFilePaths = wr1.cConstants + wr1.cFile + wr1.cPaths; // ConstantsFilePaths

exports.cConstantsFilePaths = cConstantsFilePaths;
var cConstantsPhase1ValidationMessages = wr1.cConstants + wr1.cPhase + num.c1 + wr1.cValidation + wr1.cMessages; // ConstantsPhase1ValidationMessages

exports.cConstantsPhase1ValidationMessages = cConstantsPhase1ValidationMessages;
var cConstantsPhase2ValidationMessages = wr1.cConstants + wr1.cPhase + num.c2 + wr1.cValidation + wr1.cMessages; // ConstantsPhase2ValidationMessages

exports.cConstantsPhase2ValidationMessages = cConstantsPhase2ValidationMessages;
var cBasicConstantsValidation = wr1.cBasic + wr1.cConstants + wr1.cValidation; // BasicConstantsValidation

exports.cBasicConstantsValidation = cBasicConstantsValidation;
var cBusinessConstantsValidation = wr1.cBusiness + wr1.cConstants + wr1.cValidation; // BusinessConstantsValidation

exports.cBusinessConstantsValidation = cBusinessConstantsValidation;
var cColorConstantsValidation = wr1.cColor + wr1.cConstants + wr1.cValidation; // ColorConstantsValidation

exports.cColorConstantsValidation = cColorConstantsValidation;
var cCommandConstantsValidation = wr1.cCommand + wr1.cConstants + wr1.cValidation; // CommandConstantsValidation

exports.cCommandConstantsValidation = cCommandConstantsValidation;
var cConfigurationConstantsValidation = wr1.cConfiguration + wr1.cConstants + wr1.cValidation; // ConfigurationConstantsValidation

exports.cConfigurationConstantsValidation = cConfigurationConstantsValidation;
var cCountryConstantsValidation = wr1.cCountry + wr1.cConstants + wr1.cValidation; // CountryConstantsValidation

exports.cCountryConstantsValidation = cCountryConstantsValidation;
var cElementConstantsValidation = wr1.cElement + wr1.cConstants + wr1.cValidation; // ElementConstantsValidation

exports.cElementConstantsValidation = cElementConstantsValidation;
var cFunctionConstantsValidation = wr1.cFunction + wr1.cConstants + wr1.cValidation; // FunctionConstantsValidation

exports.cFunctionConstantsValidation = cFunctionConstantsValidation;
var cGenericConstantsValidation = wr1.cGeneric + wr1.cConstants + wr1.cValidation; // GenericConstantsValidation

exports.cGenericConstantsValidation = cGenericConstantsValidation;
var cIsotopeConstantsValidation = wr1.cIsotope + wr1.cConstants + wr1.cValidation; // IsotopeConstantsValidation

exports.cIsotopeConstantsValidation = cIsotopeConstantsValidation;
var cKnotConstantsValidation = wr1.cKnot + wr1.cConstants + wr1.cValidation; // KnotConstantsValidation

exports.cKnotConstantsValidation = cKnotConstantsValidation;
var cLanguageConstantsValidation = wr1.cLanguage + wr1.cConstants + wr1.cValidation; // LanguageConstantsValidation

exports.cLanguageConstantsValidation = cLanguageConstantsValidation;
var cMessageConstantsValidation = wr1.cMessage + wr1.cConstants + wr1.cValidation; // MessageConstantsValidation

exports.cMessageConstantsValidation = cMessageConstantsValidation;
var cNumericConstantsValidation = wr1.cNumeric + wr1.cConstants + wr1.cValidation; // NumericConstantsValidation

exports.cNumericConstantsValidation = cNumericConstantsValidation;
var cPhonicConstantsValidation = wr1.cPhonic + wr1.cConstants + wr1.cValidation; // PhonicConstantsValidation

exports.cPhonicConstantsValidation = cPhonicConstantsValidation;
var cShapeConstantsValidation = wr1.cShape + wr1.cConstants + wr1.cValidation; // ShapeConstantsValidation

exports.cShapeConstantsValidation = cShapeConstantsValidation;
var cSystemConstantsValidation = wr1.cSystem + wr1.cConstants + wr1.cValidation; // SystemConstantsValidation

exports.cSystemConstantsValidation = cSystemConstantsValidation;
var cUnitConstantsValidation = wr1.cUnit + wr1.cConstants + wr1.cValidation; // UnitConstantsValidation

exports.cUnitConstantsValidation = cUnitConstantsValidation;
var cWord1ConstantsValidation = wr1.cWord + num.c1 + wr1.cConstants + wr1.cValidation; // Word1ConstantsValidation

exports.cWord1ConstantsValidation = cWord1ConstantsValidation;
var cWord2ConstantsValidation = wr1.cWord + num.c2 + wr1.cConstants + wr1.cValidation; // Word2ConstantsValidation

exports.cWord2ConstantsValidation = cWord2ConstantsValidation;
var cBinaryRootPath = wr1.cBinary + wr1.cRoot + wr1.cPath; // BinaryRootPath

exports.cBinaryRootPath = cBinaryRootPath;
var cBinaryReleasePath = wr1.cBinary + wr1.cRelease + wr1.cPath; // BinaryReleasePath

exports.cBinaryReleasePath = cBinaryReleasePath;
var cdevtty = bas.cForwardSlash + cdev + bas.cForwardSlash + phn.ctty; // /dev/tty

exports.cdevtty = cdevtty;
var cpackageDotJson = wr1.cpackage + bas.cDot + gen.cjson; // package.json

exports.cpackageDotJson = cpackageDotJson;
var cDoubleDotForwardSlash = bas.cDoubleDot + bas.cForwardSlash; // ../
// Constants Filenames

exports.cDoubleDotForwardSlash = cDoubleDotForwardSlash;
var cbasic_constants_js = wr1.cbasic + bas.cDot + wr1.cconstants + gen.cDotjs; // basic.constants.js

exports.cbasic_constants_js = cbasic_constants_js;
var cbusiness_constants_js = wr1.cbusiness + bas.cDot + wr1.cconstants + gen.cDotjs; // business.constants.js

exports.cbusiness_constants_js = cbusiness_constants_js;
var ccolor_constants_js = wr1.ccolor + bas.cDot + wr1.cconstants + gen.cDotjs; // color.constants.js

exports.ccolor_constants_js = ccolor_constants_js;
var ccommand_constants_js = wr1.ccommand + bas.cDot + wr1.cconstants + gen.cDotjs; // command.constants.js

exports.ccommand_constants_js = ccommand_constants_js;
var cconfiguration_constants_js = wr1.cconfiguration + bas.cDot + wr1.cconstants + gen.cDotjs; // configuration.constants.js

exports.cconfiguration_constants_js = cconfiguration_constants_js;
var cconstant_constants_js = wr1.cconstant + bas.cDot + wr1.cconstants + gen.cDotjs; // constant.constants.js

exports.cconstant_constants_js = cconstant_constants_js;
var ccountry_constants_js = wr1.ccountry + bas.cDot + wr1.cconstants + gen.cDotjs; // country.constants.js

exports.ccountry_constants_js = ccountry_constants_js;
var cfunction_constants_js = wr1.cfunction + bas.cDot + wr1.cconstants + gen.cDotjs; // function.constants.js

exports.cfunction_constants_js = cfunction_constants_js;
var celement_constants_js = wr1.celement + bas.cDot + wr1.cconstants + gen.cDotjs; // element.constants.js

exports.celement_constants_js = celement_constants_js;
var cgeneric_constants_js = wr1.cgeneric + bas.cDot + wr1.cconstants + gen.cDotjs; // generic.constants.js

exports.cgeneric_constants_js = cgeneric_constants_js;
var cisotope_constants_js = wr1.cisotope + bas.cDot + wr1.cconstants + gen.cDotjs; // isotope.constants.js

exports.cisotope_constants_js = cisotope_constants_js;
var cknot_constants_js = wr1.cknot + bas.cDot + wr1.cconstants + gen.cDotjs; // knot.constants.js

exports.cknot_constants_js = cknot_constants_js;
var clanguage_constants_js = wr1.clanguage + bas.cDot + wr1.cconstants + gen.cDotjs; // language.constants.js

exports.clanguage_constants_js = clanguage_constants_js;
var cmessage_constants_js = wr1.cmessage + bas.cDot + wr1.cconstants + gen.cDotjs; // message.constants.js

exports.cmessage_constants_js = cmessage_constants_js;
var cnumeric_constants_js = wr1.cnumeric + bas.cDot + wr1.cconstants + gen.cDotjs; // numeric.constants.js

exports.cnumeric_constants_js = cnumeric_constants_js;
var cphonic_constants_js = wr1.cphonic + bas.cDot + wr1.cconstants + gen.cDotjs; // phonic.constants.js

exports.cphonic_constants_js = cphonic_constants_js;
var cshape_constants_js = wr1.cshape + bas.cDot + wr1.cconstants + gen.cDotjs; // shape.constants.js

exports.cshape_constants_js = cshape_constants_js;
var csystem_constants_js = wr1.csystem + bas.cDot + wr1.cconstants + gen.cDotjs; // system.constants.js

exports.csystem_constants_js = csystem_constants_js;
var cunit_constants_js = wr1.cunit + bas.cDot + wr1.cconstants + gen.cDotjs; // unit.constants.js

exports.cunit_constants_js = cunit_constants_js;
var cword1_constants_js = wr1.cword + num.c1 + bas.cDot + wr1.cconstants + gen.cDotjs; // word1.constants.js
// System Paths

exports.cword1_constants_js = cword1_constants_js;
var cActualFrameworkName = wr1.chay + wr1.cstacks; // haystacks

exports.cActualFrameworkName = cActualFrameworkName;
var cFrameworkName = wr1.cFramework + wr1.cName; // FrameworkName

exports.cFrameworkName = cFrameworkName;
var cFrameworkVersionNumber = wr1.cFramework + wr1.cVersion + wr1.cNumber; // FrameworkVersionNumber

exports.cFrameworkVersionNumber = cFrameworkVersionNumber;
var cFrameworkDescription = wr1.cFramework + wr1.cDescription; // FrameworkDescription

exports.cFrameworkDescription = cFrameworkDescription;
var cmetaDatadotJson = wr1.cmeta + wr1.cData + bas.cDot + gen.cjson; // metaData.json

exports.cmetaDatadotJson = cmetaDatadotJson;
var cFrameworkDevelopRootPath = wr1.csrc + bas.cDoubleForwardSlash; // src//

exports.cFrameworkDevelopRootPath = cFrameworkDevelopRootPath;
var cFrameworkProductionRootPath = wr1.cbin + bas.cDoubleForwardSlash; // bin//

exports.cFrameworkProductionRootPath = cFrameworkProductionRootPath;
var cframeworkConstantsPath = wr1.cconstants + bas.cDoubleForwardSlash; // constants//

exports.cframeworkConstantsPath = cframeworkConstantsPath;
var cframeworkResourcesPath = wr1.cresources + bas.cDoubleForwardSlash; // resources//

exports.cframeworkResourcesPath = cframeworkResourcesPath;
var cframeworkResourcesConfigurationPath = cframeworkResourcesPath + wr1.cconfiguration + bas.cDoubleForwardSlash; // resources//configuration//

exports.cframeworkResourcesConfigurationPath = cframeworkResourcesConfigurationPath;
var cframeworkResourcesCommandAliasesPath = cframeworkResourcesPath + wr1.ccommands + bas.cDoubleForwardSlash; // resources//commands//

exports.cframeworkResourcesCommandAliasesPath = cframeworkResourcesCommandAliasesPath;
var cframeworkResourcesWorkflowsPath = cframeworkResourcesPath + wr1.cworkflows + bas.cDoubleForwardSlash; // resources//workflows//

exports.cframeworkResourcesWorkflowsPath = cframeworkResourcesWorkflowsPath;