"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cDoneWritingTheZipFile = exports.cDoneLoadingDataFrom = exports.cDoneCommandPerformanceSumIs = exports.cDoneCommandPerformanceStdSumIs = exports.cDoneBusinessRulePerformanceSumIs = exports.cDoneBusinessRulePerformanceStdSumIs = exports.cDoingStraightSplitCommandString = exports.cDetermineWordDelimiterMessage4 = exports.cDetermineWordDelimiterMessage3 = exports.cDetermineWordDelimiterMessage2 = exports.cDetermineWordDelimiterMessage1 = exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage6 = exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage5 = exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage4 = exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage3 = exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage2 = exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage1 = exports.cDataWasWrittenToTheFile = exports.cDataCatagoryShouldBe = exports.cDataCatagoryDetailNameShouldBe = exports.cD_finalMergeIs = exports.cDONE_PROCESSING_ADDITIONAL_DATA = exports.cDEPLOY_APPLICATION = exports.cDEFAULTWithoutTheAtSymbolAndPrefix = exports.cCountryConstantsPhase2Validation = exports.cCountryConstantsPhase1Validation = exports.cContentsOfTheStackNamespace = exports.cConstantsListPrompt3 = exports.cConstantsListPrompt2 = exports.cConstantsListPrompt1 = exports.cConstantsListPatternSearchPrompt3 = exports.cConstantsListPatternSearchPrompt2 = exports.cConstantsListPatternSearchPrompt1 = exports.cConstantPrompt3 = exports.cConstantPrompt2 = exports.cConstantPrompt1 = exports.cConstantDoesNotExist = exports.cConstantDoesExist = exports.cConfigurationConstantsPhase2Validation = exports.cConfigurationConstantsPhase1Validation = exports.cCommandWordAliasPrompt3 = exports.cCommandWordAliasPrompt2 = exports.cCommandWordAliasPrompt1 = exports.cCommandStartTimeIs = exports.cCommandRunTimeIs = exports.cCommandNamePrompt5 = exports.cCommandNamePrompt4 = exports.cCommandNamePrompt3 = exports.cCommandNamePrompt2 = exports.cCommandNamePrompt1 = exports.cCommandEndTimeIs = exports.cCommandConstantsPhase2Validation = exports.cCommandConstantsPhase1Validation = exports.cCommandAliasesAre = exports.cColorConstantsPhase2Validation = exports.cColorConstantsPhase1Validation = exports.cCheckIfThereIsRegularExpressionOrNot = exports.cCheckIfThereAreBracketsOrNoBrackets = exports.cCheckIfTheDataCatagoryIsAnEmptyStringOrNot = exports.cCharacterGenerationMessage5 = exports.cCharacterGenerationMessage4 = exports.cCharacterGenerationMessage3 = exports.cCharacterGenerationMessage2 = exports.cCharacterGenerationMessage1 = exports.cCaughtTheSpecialCaseThatWeAreMergingFlatList = exports.cCaptureSessionDateTimeStampLogFileName = exports.cCallingAnalyzeArgumentIndexIs = exports.cBusinessRuleStartTimeIs = exports.cBusinessRuleRunTimeIs = exports.cBusinessRuleEndTimeIs = exports.cBusinessConstantsPhase2Validation = exports.cBusinessConstantsPhase1Validation = exports.cBracketsWereFound = exports.cBracketsAreFound = exports.cBeginPhase2ConstantsValidation = exports.cBeginPhase1ConstantsValidation = exports.cBasicConstantsPhase2Validation = exports.cBasicConstantsPhase1Validation = exports.cBEGIN_theIthIterationOfInputDataArray = exports.cBEGIN_kthIteration = exports.cBEGIN_jthLoop = exports.cBEGIN_ithLoop = exports.cBEGIN_ithIteration = exports.cBEGIN_PROCESSING_ADDITIONAL_DATA = exports.cBEGIN_Function = exports.cAttemptingToLoadXmlData = exports.cAttemptingToLoadJsonData = exports.cAttemptingToLoadCsvData = exports.cArrayElementsMatch = exports.cArrayElementsDoNotMatch = exports.cApplicationWarningMessage1b = exports.cApplicationWarningMessage1a = exports.cApplicationVersionNumberIs = exports.cApplicationNameIs = exports.cApplicationDescriptionIs = exports.cAlreadyExists = exports.cAllLoadedDataIs = exports.cAdditionalIndexIs = exports.cActualColonDoublePercent = exports.cALL_DATA_IS = void 0;
exports.cWithoutTheAtSymbolPrefixSuffixAndDomainName = exports.cWithoutTheAtSymbolPrefixAndDomainName = exports.cWithoutTheAtSymbolDotPrefixAndSuffix = exports.cWithoutTheAtSymbolDotAndSuffix = exports.cWithoutTheAtSymbolDotAndPrefix = exports.cWithoutTheAtSymbolDotAndDomainName = exports.cWithoutTheAtSymbolAndSuffix = exports.cWithoutTheAtSymbolAndPrefix = exports.cWithoutTheAtSymbolAndDomainName = exports.cWithoutTheAtSymbol = exports.cWithoutTheAtAndDotSymbols = exports.cWarningTheSpecifiedCommand = exports.cWarningStackColon = exports.cWarningMessageIsUndefined = exports.cUnitConstantsPhase2Validation = exports.cUnitConstantsPhase1Validation = exports.cTheValueWasNotFoundInTheArray = exports.cTheValueWasFoundInTheArray = exports.cSystemConstantsPhase2Validation = exports.cSystemConstantsPhase1Validation = exports.cSuggestedLineOfCodeIs = exports.cSourceIs = exports.cShapeConstantsPhase2Validation = exports.cShapeConstantsPhase1Validation = exports.cSetTheReturnPackageSuccessFlagToTrue = exports.cSearchForPatternsInStringArrayMessage4 = exports.cSearchForPatternsInStringArrayMessage3 = exports.cSearchForPatternsInStringArrayMessage2 = exports.cSearchForPatternsInStringArrayMessage1 = exports.cRuleOutputIs = exports.cRootPathBeforeProcessingIs = exports.cRootPathAfterProcessingIs = exports.cReturnArgumentValueSameAsItWasPassedIn = exports.cReleaseFailed = exports.cRegularExpressionWasFound = exports.cRELEASE_APPLICATION = exports.cPushingArgumentValueToReturnDataAsArrayElement = exports.cProcessRulesWarningSomeRulesDoNotExist = exports.cPhonicConstantsPhase2Validation = exports.cPhonicConstantsPhase1Validation = exports.cPathThatShouldBeScannedIs = exports.cPARSER_ERROR = exports.cOptimizedConstantDefinitionForWord = exports.cNumericConstantsPhase2Validation = exports.cNumericConstantsPhase1Validation = exports.cNothingToEcho = exports.cNoSecondaryCommandArgumentDelimiters = exports.cNoRegExpFound = exports.cMessageConstantsPhase2Validation = exports.cMessageConstantsPhase1Validation = exports.cMergedDataIs = exports.cMathOperationsMessage1 = exports.cMERGED_dataIs = exports.cLoadedDataIs = exports.cLoadDataFileMessage1 = exports.cLanguageConstantsPhase2Validation = exports.cLanguageConstantsPhase1Validation = exports.cKnotConstantsPhase2Validation = exports.cKnotConstantsPhase1Validation = exports.cKeywordNameShouldBe = exports.cIsotopeConstantsPhase2Validation = exports.cIsotopeConstantsPhase1Validation = exports.cInputMetaData = exports.cInputData = exports.cIndexOfTheSpace = exports.cINPUT = exports.cGetWordsArrayFromStringMessage3 = exports.cGetWordsArrayFromStringMessage2 = exports.cGetWordsArrayFromStringMessage1 = exports.cGetWordCountInStringMessage3 = exports.cGetWordCountInStringMessage2 = exports.cGetWordCountInStringMessage1 = exports.cGenericConstantsPhase2Validation = exports.cGenericConstantsPhase1Validation = exports.cFunctionConstantsPhase2Validation = exports.cFunctionConstantsPhase1Validation = exports.cFrameworkVersionNumberIs = exports.cFrameworkNameIs = exports.cFrameworkDescriptionIs = exports.cFirstIndexIs = exports.cFilenamesMatch = exports.cFilenamesDoNotMatch = exports.cFileToLoadIs = exports.cErrorZipPackageReleaseFailed = exports.cErrorUnknownConstantFile = exports.cErrorInvalidAccessTo = exports.cErrorCouldNotCreateFolder = exports.cErrorCouldNotCopyFolderContents = exports.cErrorCouldNotCopyFile = exports.cEndPhase2ConstantsValidation = exports.cEndPhase1ConstantsValidation = exports.cElementConstantsPhase2Validation = exports.cElementConstantsPhase1Validation = exports.cERROR_Colon = exports.cERROR = exports.cEND_kthIteration = exports.cEND_jthLoop = exports.cEND_ithLoop = exports.cEND_ithIteration = exports.cEND_Function = void 0;
exports.ccommandSequencerCommandToEnqueueIs = exports.ccommandPerformanceSumIs = exports.ccommandPerformanceStdSumIs = exports.ccommandIs = exports.ccommandGeneratorMessage6 = exports.ccommandGeneratorMessage5 = exports.ccommandGeneratorMessage4 = exports.ccommandGeneratorMessage3 = exports.ccommandGeneratorMessage2 = exports.ccommandGeneratorMessage1 = exports.ccommandDelimiterIs = exports.ccommandCounterIs = exports.ccommandArgsIs = exports.ccommandAliasesPathIs = exports.ccommandAliasesPathConfigNameIs = exports.ccommandAliasesFilePathConfigurationNameIs = exports.ccommandAliasGeneratorMessage5 = exports.ccommandAliasGeneratorMessage4 = exports.ccommandAliasGeneratorMessage3 = exports.ccommandAliasGeneratorMessage2 = exports.ccommandAliasGeneratorMessage1 = exports.ccommandAliasDataStructureIs = exports.ccolorKeysIs = exports.cclientWorkflowsPathIs = exports.cclientValidationDataIs = exports.cclientRootPathIs = exports.cclientMetaDataPathIs = exports.cclientConfigurationIs = exports.cclientCommandsAre = exports.cclientCommandAliasesPathIs = exports.cclientBusinessRulesAre = exports.cclassPathIs = exports.ccheckIfThePageNameIsNotAnEmptyString = exports.ccasePathElementEqual = exports.ccaseIEqual0 = exports.ccaseElse = exports.ccamelCaseWordCountIs = exports.ccamelCaseCommandNameArrayIs = exports.cbusinessRulePerformanceSumIs = exports.cbusinessRulePerformanceStdSumIs = exports.cbusinessRuleIs = exports.cbusinessRuleCounterIs = exports.caverageIs = exports.cattributeValueIs = exports.cattributeJsonStringIs = exports.cattributeArrayIs = exports.cattributeArray1Is = exports.cattributeArray0Is = exports.caskIs = exports.carrayValidationDataIs = exports.carrayToBeExpandedIs = exports.carrayToBeExpandedDotLengthIs = exports.carrayIs = exports.carrayInputObjectIsNotAnArray = exports.cargumentValueLengthGreaterThanZero = exports.cargumentValueIs = exports.cargumentValueContainsTheDelimiterLetsSplitIt = exports.cargumentValueAfterAttemptingToRemoveOpenBracketFromAllArrayElementsIs = exports.cargumentValueAfterAttemptingToRemoveCloseBracketFromAllArrayElementsIs = exports.cargumentArrayIs = exports.cargsArrayContainsRegEx2Is = exports.cargsArrayContainsRegEx1Is = exports.cargsArrayContainsColonIs = exports.capplicationMetaDataPathAndFilenameIs = exports.capplicationMetaDataIs = exports.capplicationConstantsValidationDataIs = exports.cappConfigResourcesPathIs = exports.cappConfigReferencePathIs = exports.cappConfigPathIs = exports.cappAttributeValueIs = exports.cappAttributeNameIs = exports.callowableSpecialCharactersIs = exports.callXmlDataIs = exports.callSystemConstantsValidationDataIs = exports.callCommandWorkflowsDataIs = exports.callCommandAliasesIs = exports.callCommandAliasesDataIs = exports.callClientConstantsValidationDataIs = exports.caliasListIs = exports.caggregateCommandStringIs = exports.cafterAttemptToMergeResultsAre = exports.cWord1ConstantsPhase2Validation = exports.cWord1ConstantsPhase1Validation = exports.cWithoutTheSuffixAndDomainName = exports.cWithoutTheSuffix = exports.cWithoutThePrefixSuffixAndDot = exports.cWithoutThePrefixSuffixAndDomainName = exports.cWithoutThePrefixSuffixAndAtSymbol = exports.cWithoutThePrefixAndSuffix = exports.cWithoutThePrefixAndDomainName = exports.cWithoutThePrefix = exports.cWithoutTheDotSymbol = exports.cWithoutTheDotSuffixAndDomainName = exports.cWithoutTheDotPrefixSuffixAndDomainName = exports.cWithoutTheDotPrefixAndDomainName = exports.cWithoutTheDotAndSuffix = exports.cWithoutTheDotAndPrefix = exports.cWithoutTheDotAndDomainName = exports.cWithoutTheDomainName = exports.cWithoutTheAtSymbolSuffixAndDomainName = void 0;
exports.cexecuteBusinessRules = exports.cexecuteBusienssRulesColon = exports.cevenIndex = exports.centryIs = exports.centityIs = exports.cendTimeIs = exports.cenableLimitIs = exports.celseClauseLookingForCommandAliases = exports.celementNamePatternIs = exports.celementNameIs = exports.celementCountIs = exports.cduplicateCommandAliasIs = exports.cduplicateAliasCountIs = exports.cdomainNameIs = exports.cdoesNotExistPleaseTryAgain = exports.cdoesNotExist = exports.cdirectoryPathIs = exports.cdirectorIs = exports.cdestinationFolderIs = exports.cdeltaTimeResultIs = exports.cdeltaTimeIs = exports.cdeltaLengthIs = exports.cdeletionCostIs = exports.cdebugConfigurationSettingValueIs = exports.cdataToWriteOutIs = exports.cdataToWriteIs = exports.cdataToStoreIs = exports.cdataToMergeIs = exports.cdataToMergeElementCountIs1 = exports.cdataToMergeElementCountIs = exports.cdataStorageContextNameIs = exports.cdataPathIs = exports.cdataPathConfigurationNameIs = exports.cdataPathAfterBusinessRulesProcessingIs = exports.cdataObjectValueIs = exports.cdataObjectIs = exports.cdataHivePathArrayIs = exports.cdataFileToMergeIs = exports.cdataFileIs = exports.cdataCatagoryIsNotAnEmptyString = exports.cdataCatagoryIsAnEmptyString = exports.cdataCatagoryIs = exports.cdataCatagoryDetailsNameIs = exports.cdashCountIs = exports.ccurrentWorkflowIs = exports.ccurrentVersionIs = exports.ccurrentVersionAlreadyReleased = exports.ccurrentRuleIs = exports.ccurrentPathElementIs = exports.ccurrentMasterStringArrayElementIs = exports.ccurrentCommandWordIs = exports.ccurrentCommandIs = exports.ccurrentColorObjectIs = exports.ccurrentColorNameIs = exports.ccurrentColorHexValueIs = exports.ccurrentAliasIs = exports.ccopySuccessIs = exports.ccontextNameIs = exports.ccontentsOfLeafDataHiveElementIs = exports.ccontentsOfDataStructreIs = exports.ccontentsOfDare = exports.ccontentsAre = exports.ccontainsAcronymIs = exports.cconstantsTypesKeysIs = exports.cconstantsPathIs = exports.cconstantsLineIs = exports.cconstantsKeysIs = exports.cconstantsGeneratorMessage4 = exports.cconstantsGeneratorMessage3 = exports.cconstantsGeneratorMessage2 = exports.cconstantsGeneratorMessage1 = exports.cconstantsGeneratorListMessage1 = exports.cconstantValueIs = exports.cconstantTypeValuesIs = exports.cconstantTypeKeyIs = exports.cconstantNameIs = exports.cconstantLibraryDataIs = exports.cconstantKeyIs = exports.cconstantActualValueIs = exports.cconsolidatedArgumentModeIs = exports.cconfigurationValueIs = exports.cconfigurationNamespaceIs = exports.cconfigurationNameIs = exports.cconfigDataIs = exports.ccommonPatternsArrayIs = exports.ccommandWorkflowFilePathConfigurationNameIs = exports.ccommandWordAliasesBeforeChangeIs = exports.ccommandWordAliasesAfterChangeIs = exports.ccommandToExecuteIs = exports.ccommandToExecuteBeforeTheAliasIs = exports.ccommandToExecuteAfterTheAliasIs = exports.ccommandStringIs = exports.ccommandStringContainsSingleQuote = exports.ccommandStringContainsEitherSingleQuoteOrBackTickQuote = exports.ccommandStringBeforeAttemptedDelimiterSwapIs = exports.ccommandStringAfterTaggingTheFirstStringDelimiter = exports.ccommandStringAfterTaggingAnOddStringDelimiter = exports.ccommandStringAfterTaggingAnEvenStringDelimiter = exports.ccommandSequencerMessage2 = exports.ccommandSequencerMessage1 = void 0;
exports.cprefixIs = exports.cpreSplitCommandStringIs = exports.cpreSplitCommandStringElementIs = exports.cpostSplitCommandStringIs = exports.cplusCountIs = exports.cperiodCountIs = exports.cpercentCountIs = exports.cpathElementIs = exports.cpathArrayIs = exports.cpathAndFilenameIs = exports.cparsedStringSpaceTerm = exports.cparsedDataFileIs = exports.cparsedDataFileContentsAre = exports.cparseBusinessRuleArgumentMessage2 = exports.cparseBusinessRuleArgumentMessage1 = exports.cpageNameIsNotAnEmptyString = exports.cpageNameIsAnEmptyString = exports.cpageNameIs = exports.cpackageSuccessIs = exports.coriginalStringIs = exports.coddIndex = exports.cnumberOfSuffixCharactersIs = exports.cnumberOfSingleQuotesIsEven = exports.cnumberOfPrefixCharactersIs = exports.cnumberOfCharactersToGenerateIs = exports.cnumberIs = exports.cmyFunctionIs = exports.cminimumColorRangeIs = exports.cminStringLengthIs = exports.cmetaDataPathAndFilenameIs = exports.cmetaDataParametersLengthIs = exports.cmetaDataParametersIs = exports.cmetaDataOutputIs = exports.cmergedDataIs = exports.cmaximumColorRangeIs = exports.cmaxStringLengthIs = exports.cmasterTempReturnDataBeforeRecursiveCallIs = exports.cmasterTempReturnDataAfterRecursiveCallIs = exports.cmasterCommandWordAlisesArrayIs = exports.cmasterArrayIndexIs = exports.clookupValueIs = exports.clookupIndexIs = exports.clogFilePathAndNameIs = exports.clogFileNameIs = exports.cloadedFileDataIs = exports.cloadedAndMergedDataAllFilesIs = exports.cloadedAndMergedDataAllFilesContentsAre = exports.cloadDataFileMessage3 = exports.cloadDataFileMessage2 = exports.clineArray2Is = exports.climitOfExpansionIs = exports.ckeyIs = exports.ckey2Is = exports.ckey1Is = exports.cjValueIs = exports.cisResolvingAs = exports.cisEmpty = exports.cinsideTheForLoop = exports.cinsertionCostIs = exports.cinputMetaDataIs = exports.cinputMetaData = exports.cinputIs = exports.cinputDataRightBeforeProcessingIs = exports.cinputDataIs = exports.cinputData = exports.cindexOfExpansionIs = exports.cindexIs = exports.ciValueIs = exports.cgetCommandArgsMessage2 = exports.cgetCommandArgsMessage1 = exports.cgenerateSpecialCharactersIs = exports.cfullyParsedDataIs = exports.cframeworkWorkflowsPathIs = exports.cframeworkRootPathIs = exports.cframeworkResourcesPathIs = exports.cframeworkMetaDataPathAndFilenameIs = exports.cframeworkMetaDataIs = exports.cframeworkFullMetaDataPathIs = exports.cframeworkConstantsValidationDataIs = exports.cframeworkConfigPathIs = exports.cframeworkCommandAliasesPathIs = exports.cformattingIs = exports.cformatIs = exports.cfilterArrayIs = exports.cfilesToLoadIs = exports.cfilesListLimitIs = exports.cfilesLimitIs = exports.cfilesFoundIs = exports.cfilesFoundAre = exports.cfileToSaveToIs = exports.cfileToLoadIs = exports.cfileNameIs = exports.cfileIs = exports.cfileExtensionIs = exports.cfileAndPathToWriteDataToIs = exports.cfileAndPathToLoadFromIs = exports.cfailureModeIs = exports.cexpandedLehmerCodeArrayIs = exports.cexecuteCommandMessage1 = exports.cexecuteBusinessRulesColon = void 0;
exports.cuserDefinedConstantsListDoesNotContainComas = exports.cuserDefinedConstantsListArrayIs = exports.cuserDefinedConstantListIs = exports.cuserDefinedConstantListContainsComas = exports.cuserDefinedConstantIs = exports.cunderscoreCountIs = exports.ctertiaryCommandDelimiterIs = exports.ctempReturnData1Is = exports.ctempReturnData1DotLengthIs = exports.ctempDataIs = exports.ctargetIs = exports.ctargetDataIsModifiedInTheInputPassByReferenceVariableContentIs = exports.ctargetDataIs = exports.ctargetDataContentIs = exports.csuffixIs = exports.csuccessfulCopyIs = exports.csubstitutionCostIs = exports.cstringDeltaValueIs = exports.cstringContainsAcronymIs = exports.cstring2Is = exports.cstring1Is = exports.cstartTimeIs = exports.cstandardDevIs = exports.cstackNameSpaceIs = exports.cspecifiedSuffixAndDomainIs = exports.cspacesCountIs = exports.csourceFolderIs = exports.csourceDestinationArrayIs = exports.csleepTimeIs = exports.csessionDateTimeStampIs = exports.csecondaryCommandDelimiterIs = exports.csecondaryCommandArgsDelimiterIs = exports.csaveDataFileMessage1 = exports.crulesIs = exports.cruleOutputIs = exports.cruleMetaDataIs = exports.cruleInputMetaData = exports.cruleInputIs = exports.cruleInputDataIs = exports.crootPathIs = exports.creturnDeltaTimeIs = exports.creturnDataSoFarIs = exports.creturnDataIs = exports.creturnDataDotLengthIs = exports.creturnDataBeforePopIs = exports.creturnDataAfterPushIs = exports.creturnDataAfterPopIs = exports.creturnDataAfterLevel1Is = exports.creturnConfiguraitonValueIs = exports.cresolvedSystemWorkflowsPathIs = exports.cresolvedSystemCommandsAliasesPathIs = exports.cresolvedFrameworkConstantsPathActualIs = exports.cresolvedCustomWorkflowsPathIs = exports.cresolvedCustomCommandsAliasesPathIs = exports.cresolvedConstantsPath_Word1Is = exports.cresolvedConstantsPath_UnitIs = exports.cresolvedConstantsPath_SystemIs = exports.cresolvedConstantsPath_ShapeIs = exports.cresolvedConstantsPath_PhonicIs = exports.cresolvedConstantsPath_NumericIs = exports.cresolvedConstantsPath_MessageIs = exports.cresolvedConstantsPath_LanguageIs = exports.cresolvedConstantsPath_KnotIs = exports.cresolvedConstantsPath_IsotopeIs = exports.cresolvedConstantsPath_GenericIs = exports.cresolvedConstantsPath_FunctionIs = exports.cresolvedConstantsPath_ElementIs = exports.cresolvedConstantsPath_CountryIs = exports.cresolvedConstantsPath_ConfigurationIs = exports.cresolvedConstantsPath_CommandIs = exports.cresolvedConstantsPath_ColorIs = exports.cresolvedConstantsPath_BusinessIs = exports.cresolvedConstantsPath_BasicIs = exports.cresolvedClientWorkflowsPathIs = exports.cresolvedClientConstantsPathActualIs = exports.cresolvedClientCommandsAliasesPathIs = exports.creplacementIs = exports.creplaceCharacterWithCharacterRuleIs = exports.creleasedArchiveFilesListIs = exports.creleaseFilesListIs = exports.creleaseFileNameIs = exports.creleaseDateTimeStampIs = exports.cregularExpressionIs = exports.cregularExpressionFlagsAre = exports.cregExValueIs = exports.cregExFlagsIs = exports.crecursiveSubStringIs = exports.cqueueNameSpaceIs = exports.cpushingTempReturnData1Kvalue = exports.cpushingLehmerCodeArray1ToReturnDataValue = exports.cprompt03 = exports.cprompt02 = exports.cprompt01 = exports.cprintMessageToFile03 = exports.cprintMessageToFile02 = exports.cprintMessageToFile01 = exports.cprintDataHiveAttributesMessage3 = exports.cprintDataHiveAttributesMessage2 = exports.cprintDataHiveAttributesMessage1 = exports.cprimaryCommandDelimiterIs = void 0;
exports.cworkflowValueIs = exports.cworkflowPathIs = exports.cworkflowPathConfigurationNameIs = exports.cworkflowNameIs = exports.cworkflowMessage3 = exports.cworkflowMessage2 = exports.cworkflowMessage1 = exports.cwordsArrayIs = exports.cwordDelimiterIs = exports.cwordCountIs = exports.cvariation1ValueIs = exports.cvariation0ValueIs = exports.cvalueIs = exports.cvalidateCommandAliasesMessage1 = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var gen = _interopRequireWildcard(require("./generic.constants.js"));

var num = _interopRequireWildcard(require("./numeric.constants.js"));

var phn = _interopRequireWildcard(require("./phonic.constants.js"));

var sys = _interopRequireWildcard(require("./system.constants.js"));

var wr1 = _interopRequireWildcard(require("./word1.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file message.constants.js
 * @module message-constants
 * @description Contains many re-usable message constants.
 * @requires module:basic.constants
 * @requires module:generic.constants
 * @requires module:numeric.constants
 * @requires module:phonic.constants
 * @requires module:system.constants
 * @requires module:word1.constants
 * @author Seth Hollingsead
 * @date 2021/12/27
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// Logging Constants
var cBEGIN_Function = wr1.cBEGIN + bas.cSpace + bas.cDoublePercent + bas.cSpace + wr1.cFunction; // BEGIN %% Function

exports.cBEGIN_Function = cBEGIN_Function;
var cEND_Function = wr1.cEND + bas.cSpace + bas.cDoublePercent + bas.cSpace + wr1.cFunction; // END %% Function

exports.cEND_Function = cEND_Function;
var cinputData = wr1.cinput + wr1.cData; // inputData

exports.cinputData = cinputData;
var cInputData = wr1.cInput + wr1.cData; // InputData

exports.cInputData = cInputData;
var cinputMetaData = wr1.cinput + wr1.cMetaData; // inputMetaData

exports.cinputMetaData = cinputMetaData;
var cInputMetaData = wr1.cInput + wr1.cMetaData; // InputMetaData

exports.cInputMetaData = cInputMetaData;
var cinputDataIs = cinputData + sys.cSpaceIsColonSpace; // inputData is:

exports.cinputDataIs = cinputDataIs;
var cinputMetaDataIs = wr1.cinput + wr1.cMetaData + sys.cSpaceIsColonSpace; // inputMetaData is:

exports.cinputMetaDataIs = cinputMetaDataIs;
var creturnDataIs = wr1.creturn + wr1.cData + sys.cSpaceIsColonSpace; // returnData is:
// System Messages
// WARNING: No .env file found! Going to default to the DEVELOPMENT ENVIRONMENT!

exports.creturnDataIs = creturnDataIs;
var cApplicationWarningMessage1a = wr1.cWARNING + bas.cColon + bas.cSpace + bas.cNo + bas.cSpace + gen.cDotEnv + bas.cSpace + wr1.cFile + bas.cSpace + wr1.cfound + bas.cExclamation + bas.cSpace; // WARNING: No .Env File found!

exports.cApplicationWarningMessage1a = cApplicationWarningMessage1a;
var cApplicationWarningMessage1b = wr1.cGoing + bas.cSpace + bas.cto + bas.cSpace + wr1.cdefault + bas.cSpace + bas.cto + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cDEVELOPMENT + bas.cSpace + wr1.cENVIRONMENT + bas.cExclamation; // Going to default to the DEVELOPMENT ENVIRONMENT!

exports.cApplicationWarningMessage1b = cApplicationWarningMessage1b;
var cCharacterGenerationMessage1 = wr1.ctype + bas.cTo + wr1.cGenerate + sys.cSpaceIsColonSpace; // typeToGenerate is:

exports.cCharacterGenerationMessage1 = cCharacterGenerationMessage1;
var cCharacterGenerationMessage2 = sys.cGenerateA + bas.cSpace + wr1.cnumber + bas.cDot; // Generate a number.

exports.cCharacterGenerationMessage2 = cCharacterGenerationMessage2;
var cCharacterGenerationMessage3 = sys.cGenerateA + bas.cSpace + wr1.crandom + bas.cSpace + wr1.cupper + bas.cSpace + wr1.ccase + bas.cSpace + bas.cor + bas.cSpace + wr1.clower + bas.cSpace + wr1.ccase + bas.cSpace + wr1.cletter + bas.cDot; // Generate a random upper case or lower case letter.

exports.cCharacterGenerationMessage3 = cCharacterGenerationMessage3;
var cCharacterGenerationMessage4 = sys.cGenerateA + bas.cSpace + wr1.cspecial + bas.cSpace + wr1.ccharacter + bas.cDot; // Generate a special character.

exports.cCharacterGenerationMessage4 = cCharacterGenerationMessage4;
var cCharacterGenerationMessage5 = wr1.cDEFAULT + bas.cColon + bas.cSpace + sys.cGenerateA + bas.cSpace + wr1.crandom + bas.cSpace + wr1.cupper + bas.cSpace + wr1.ccase + bas.cSpace + bas.cor + bas.cSpace + wr1.clower + bas.cSpace + wr1.ccase + bas.cSpace + wr1.cletter + bas.cDot; // DEFAULT: Generate a random upper case or lower case letter.

exports.cCharacterGenerationMessage5 = cCharacterGenerationMessage5;
var cMathOperationsMessage1 = sys.cbigInteger + sys.cSpaceIsColonSpace; // bigInteger is:

exports.cMathOperationsMessage1 = cMathOperationsMessage1;
var cnumberOfCharactersToGenerateIs = sys.cnumberOfCharactersToGenerate + sys.cSpaceIsColonSpace; // numberOfCharactersToGenerate is:

exports.cnumberOfCharactersToGenerateIs = cnumberOfCharactersToGenerateIs;
var cgenerateSpecialCharactersIs = sys.cgenerateSpecialCharacters + sys.cSpaceIsColonSpace; // generateSpecialCharacters is:

exports.cgenerateSpecialCharactersIs = cgenerateSpecialCharactersIs;
var callowableSpecialCharactersIs = sys.callowableSpecialCharacters + sys.cSpaceIsColonSpace; // allowableSpecialCharacters is:

exports.callowableSpecialCharactersIs = callowableSpecialCharactersIs;
var cspecifiedSuffixAndDomainIs = sys.cspecifiedSuffixAndDomain + sys.cSpaceIsColonSpace; // specifiedSuffixAndDomain is:

exports.cspecifiedSuffixAndDomainIs = cspecifiedSuffixAndDomainIs;
var cfailureModeIs = sys.cfailureMode + sys.cSpaceIsColonSpace; // failureMode is:

exports.cfailureModeIs = cfailureModeIs;
var cprefixIs = wr1.cprefix + sys.cSpaceIsColonSpace; // prefix is:

exports.cprefixIs = cprefixIs;
var csuffixIs = wr1.csuffix + sys.cSpaceIsColonSpace; // suffix is:

exports.csuffixIs = csuffixIs;
var cWithoutTheAtSymbol = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cSpace + wr1.csymbol + bas.cDot; // Without the @ symbol.

exports.cWithoutTheAtSymbol = cWithoutTheAtSymbol;
var cWithoutThePrefix = sys.cWithoutThe + bas.cSpace + wr1.cprefix + bas.cDot; // Without the prefix.

exports.cWithoutThePrefix = cWithoutThePrefix;
var cWithoutTheSuffix = sys.cWithoutThe + bas.cSpace + wr1.csuffix + bas.cDot; // Without the suffix.

exports.cWithoutTheSuffix = cWithoutTheSuffix;
var cWithoutTheAtSymbolAndPrefix = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cSpace + sys.candPrefix + bas.cDot; // Without the @ and prefix.

exports.cWithoutTheAtSymbolAndPrefix = cWithoutTheAtSymbolAndPrefix;
var cDEFAULTWithoutTheAtSymbolAndPrefix = wr1.cDEFAULT + bas.cColon + bas.cSpace + cWithoutTheAtSymbolAndPrefix; // DEFAULT: Without the @ and prefix.

exports.cDEFAULTWithoutTheAtSymbolAndPrefix = cDEFAULTWithoutTheAtSymbolAndPrefix;
var cdomainNameIs = wr1.cdomain + wr1.cName + sys.cSpaceIsColonSpace; // domainName is:

exports.cdomainNameIs = cdomainNameIs;
var cnumberOfPrefixCharactersIs = wr1.cnumber + bas.cOf + wr1.cPrefix + wr1.cCharacters + sys.cSpaceIsColonSpace; // numberOfPrefixCharacters is:

exports.cnumberOfPrefixCharactersIs = cnumberOfPrefixCharactersIs;
var cnumberOfSuffixCharactersIs = wr1.cnumber + bas.cOf + wr1.cSuffix + wr1.cCharacters + sys.cSpaceIsColonSpace; // numberOfSuffixCharacters is:

exports.cnumberOfSuffixCharactersIs = cnumberOfSuffixCharactersIs;
var cWithoutTheDotSymbol = sys.cWithoutThe + bas.cSpace + bas.cDot + bas.cSpace + wr1.csymbol + bas.cDot; // Without the . symbol.

exports.cWithoutTheDotSymbol = cWithoutTheDotSymbol;
var cWithoutTheAtAndDotSymbols = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cSpace + wr1.cand + bas.cSpace + bas.cDot + bas.cSpace + wr1.csymbols + bas.cDot; // Without the @ and . symbols.

exports.cWithoutTheAtAndDotSymbols = cWithoutTheAtAndDotSymbols;
var cWithoutTheDomainName = sys.cWithoutThe + bas.cSpace + sys.cdomainSpaceName + bas.cDot; // Without the domain name.

exports.cWithoutTheDomainName = cWithoutTheDomainName;
var cWithoutTheAtSymbolAndDomainName = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the @ and domain name.

exports.cWithoutTheAtSymbolAndDomainName = cWithoutTheAtSymbolAndDomainName;
var cWithoutTheDotAndDomainName = sys.cWithoutThe + bas.cSpace + bas.cDot + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the . and domain name.

exports.cWithoutTheDotAndDomainName = cWithoutTheDotAndDomainName;
var cWithoutTheAtSymbolDotAndDomainName = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cComa + bas.cSpace + bas.cDot + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the @, . and domain name.

exports.cWithoutTheAtSymbolDotAndDomainName = cWithoutTheAtSymbolDotAndDomainName;
var cWithoutTheDotAndPrefix = sys.cWithoutThe + bas.cSpace + bas.cDot + bas.cSpace + sys.candPrefix + bas.cDot; // Without the . and prefix.

exports.cWithoutTheDotAndPrefix = cWithoutTheDotAndPrefix;
var cWithoutTheAtSymbolAndSuffix = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cSpace + sys.candSuffix + bas.cDot; // Without the @ and suffix.

exports.cWithoutTheAtSymbolAndSuffix = cWithoutTheAtSymbolAndSuffix;
var cWithoutTheDotAndSuffix = sys.cWithoutThe + bas.cSpace + bas.cDot + bas.cSpace + sys.candSuffix + bas.cDot; // Without the . and suffix.

exports.cWithoutTheDotAndSuffix = cWithoutTheDotAndSuffix;
var cWithoutTheAtSymbolDotAndPrefix = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cComa + bas.cSpace + bas.cDot + bas.cSpace + sys.candPrefix + bas.cDot; // Without the @, . and prefix.

exports.cWithoutTheAtSymbolDotAndPrefix = cWithoutTheAtSymbolDotAndPrefix;
var cWithoutTheAtSymbolDotAndSuffix = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cComa + bas.cSpace + bas.cDot + bas.cSpace + sys.candSuffix + bas.cDot; // Without the @, . and suffix.

exports.cWithoutTheAtSymbolDotAndSuffix = cWithoutTheAtSymbolDotAndSuffix;
var cWithoutTheAtSymbolDotPrefixAndSuffix = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cComa + bas.cSpace + bas.cDot + bas.cComa + bas.cSpace + wr1.cprefix + bas.cSpace + sys.candSuffix + bas.cDot; // Without the @, ., prefix and suffix.

exports.cWithoutTheAtSymbolDotPrefixAndSuffix = cWithoutTheAtSymbolDotPrefixAndSuffix;
var cWithoutThePrefixAndDomainName = sys.cWithoutThe + bas.cSpace + wr1.cprefix + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the prefix and domain name.

exports.cWithoutThePrefixAndDomainName = cWithoutThePrefixAndDomainName;
var cWithoutTheSuffixAndDomainName = sys.cWithoutThe + bas.cSpace + wr1.csuffix + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the suffix and domain name.

exports.cWithoutTheSuffixAndDomainName = cWithoutTheSuffixAndDomainName;
var cWithoutThePrefixAndSuffix = sys.cWithoutThe + bas.cSpace + wr1.cprefix + bas.cSpace + sys.candSuffix + bas.cDot; // Without the prefix and suffix.

exports.cWithoutThePrefixAndSuffix = cWithoutThePrefixAndSuffix;
var cWithoutThePrefixSuffixAndDomainName = sys.cWithoutThe + bas.cSpace + wr1.cprefix + bas.cComa + bas.cSpace + wr1.csuffix + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the prefix, suffix and domain name.

exports.cWithoutThePrefixSuffixAndDomainName = cWithoutThePrefixSuffixAndDomainName;
var cWithoutTheAtSymbolPrefixAndDomainName = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cComa + bas.cSpace + wr1.cprefix + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the @, prefix and domain name.

exports.cWithoutTheAtSymbolPrefixAndDomainName = cWithoutTheAtSymbolPrefixAndDomainName;
var cWithoutTheDotPrefixAndDomainName = sys.cWithoutThe + bas.cSpace + bas.cDot + bas.cComa + bas.cSpace + wr1.cprefix + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the ., prefix and domain name.

exports.cWithoutTheDotPrefixAndDomainName = cWithoutTheDotPrefixAndDomainName;
var cWithoutTheAtSymbolSuffixAndDomainName = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cComa + bas.cSpace + wr1.csuffix + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the @, suffix and domain name.

exports.cWithoutTheAtSymbolSuffixAndDomainName = cWithoutTheAtSymbolSuffixAndDomainName;
var cWithoutTheDotSuffixAndDomainName = sys.cWithoutThe + bas.cSpace + bas.cDot + bas.cComa + bas.cSpace + wr1.csuffix + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the ., suffix and domain name.

exports.cWithoutTheDotSuffixAndDomainName = cWithoutTheDotSuffixAndDomainName;
var cWithoutTheAtSymbolPrefixSuffixAndDomainName = sys.cWithoutThe + bas.cSpace + bas.cAt + bas.cComa + bas.cSpace + wr1.cprefix + bas.cComa + bas.cSpace + wr1.csuffix + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the @, prefix, suffix and domain name.

exports.cWithoutTheAtSymbolPrefixSuffixAndDomainName = cWithoutTheAtSymbolPrefixSuffixAndDomainName;
var cWithoutTheDotPrefixSuffixAndDomainName = sys.cWithoutThe + bas.cSpace + bas.cDot + bas.cComa + bas.cSpace + wr1.cprefix + bas.cComa + bas.cSpace + wr1.csuffix + bas.cSpace + sys.candSpaceDomainSpaceName + bas.cDot; // Without the ., prefix, suffix and domain name.

exports.cWithoutTheDotPrefixSuffixAndDomainName = cWithoutTheDotPrefixSuffixAndDomainName;
var cWithoutThePrefixSuffixAndAtSymbol = sys.cWithoutThe + bas.cSpace + wr1.cprefix + bas.cComa + bas.cSpace + wr1.csuffix + bas.cSpace + wr1.cand + bas.cSpace + bas.cAt + bas.cDot; // Without the prefix, suffix and @.

exports.cWithoutThePrefixSuffixAndAtSymbol = cWithoutThePrefixSuffixAndAtSymbol;
var cWithoutThePrefixSuffixAndDot = sys.cWithoutThe + bas.cSpace + wr1.cprefix + bas.cComa + bas.cSpace + wr1.csuffix + bas.cSpace + wr1.cand + bas.cSpace + bas.cDot + bas.cDot; // Without the prefix, suffix and ..

exports.cWithoutThePrefixSuffixAndDot = cWithoutThePrefixSuffixAndDot;
var cIndexOfTheSpace = wr1.cIndex + bas.cSpace + bas.cof + bas.cSpace + wr1.cthe + bas.cSpace; // Index of the

exports.cIndexOfTheSpace = cIndexOfTheSpace;
var cisResolvingAs = bas.cis + bas.cSpace + wr1.cresolving + bas.cSpace + bas.cas + bas.cColon + bas.cSpace; // is resolving as:

exports.cisResolvingAs = cisResolvingAs;
var cparsedStringSpaceTerm = wr1.cparsed + wr1.cString + bas.cSpace + wr1.cterm; // parsedString term

exports.cparsedStringSpaceTerm = cparsedStringSpaceTerm;
var cstring1Is = wr1.cstring + num.c1 + sys.cSpaceIsColonSpace; // string1 is:

exports.cstring1Is = cstring1Is;
var cstring2Is = wr1.cstring + num.c2 + sys.cSpaceIsColonSpace; // string2 is:

exports.cstring2Is = cstring2Is;
var cvariation0ValueIs = wr1.cvariation + num.c0 + bas.cSpace + wr1.cvalue + sys.cSpaceIsColonSpace; // variation0 value is:

exports.cvariation0ValueIs = cvariation0ValueIs;
var cvariation1ValueIs = wr1.cvariation + num.c1 + bas.cSpace + wr1.cvalue + sys.cSpaceIsColonSpace; // variation1 value is:

exports.cvariation1ValueIs = cvariation1ValueIs;
var ciValueIs = bas.ci + bas.cSpace + wr1.cvalue + sys.cSpaceIsColonSpace; // i value is:

exports.ciValueIs = ciValueIs;
var cjValueIs = bas.cj + bas.cSpace + wr1.cvalue + sys.cSpaceIsColonSpace; // j value is:

exports.cjValueIs = cjValueIs;
var cdeletionCostIs = wr1.cdeletion + wr1.cCost + sys.cSpaceIsColonSpace; // deletionCost is:

exports.cdeletionCostIs = cdeletionCostIs;
var cinsertionCostIs = wr1.cinsertion + wr1.cCost + sys.cSpaceIsColonSpace; // insertionCost is:

exports.cinsertionCostIs = cinsertionCostIs;
var csubstitutionCostIs = wr1.csubstitution + wr1.cCost + sys.cSpaceIsColonSpace; // substitutionCost is:

exports.csubstitutionCostIs = csubstitutionCostIs;
var ccamelCaseWordCountIs = wr1.ccamel + wr1.cCase + wr1.cWord + wr1.cCount + sys.cSpaceIsColonSpace; // camelCaseWordCount is:

exports.ccamelCaseWordCountIs = ccamelCaseWordCountIs;
var ccontainsAcronymIs = wr1.ccontains + wr1.cAcronym + sys.cSpaceIsColonSpace; // containsAcronym is:

exports.ccontainsAcronymIs = ccontainsAcronymIs;
var cspacesCountIs = wr1.cspaces + wr1.cCount + sys.cSpaceIsColonSpace; // spacesCount is:

exports.cspacesCountIs = cspacesCountIs;
var cperiodCountIs = wr1.cperiod + wr1.cCount + sys.cSpaceIsColonSpace; // periodCount is:

exports.cperiodCountIs = cperiodCountIs;
var cdashCountIs = wr1.cdash + wr1.cCount + sys.cSpaceIsColonSpace; // dashCount is:

exports.cdashCountIs = cdashCountIs;
var cunderscoreCountIs = wr1.cunderscore + wr1.cCount + sys.cSpaceIsColonSpace; // underscoreCount is:

exports.cunderscoreCountIs = cunderscoreCountIs;
var cplusCountIs = wr1.cplus + wr1.cCount + sys.cSpaceIsColonSpace; // plusCount is:

exports.cplusCountIs = cplusCountIs;
var cpercentCountIs = wr1.cpercent + wr1.cCount + sys.cSpaceIsColonSpace; // percentCount is:

exports.cpercentCountIs = cpercentCountIs;
var cstringDeltaValueIs = wr1.cstring + gen.cDelta + bas.cSpace + wr1.cvalue + sys.cSpaceIsColonSpace; // stringDelta value is:

exports.cstringDeltaValueIs = cstringDeltaValueIs;
var cFilenamesMatch = wr1.cFilenames + bas.cSpace + wr1.cmatch; // Filenames match

exports.cFilenamesMatch = cFilenamesMatch;
var cFilenamesDoNotMatch = wr1.cFilenames + bas.cSpace + bas.cdo + bas.cSpace + gen.cnot + bas.cSpace + wr1.cmatch; // Filenames do not match

exports.cFilenamesDoNotMatch = cFilenamesDoNotMatch;
var cconstantsLineIs = wr1.cconstants + wr1.cLine + sys.cSpaceIsColonSpace; // constants line is:

exports.cconstantsLineIs = cconstantsLineIs;
var cArrayElementsMatch = wr1.cArray + bas.cSpace + wr1.celements + bas.cSpace + wr1.cmatch; // Array elements match

exports.cArrayElementsMatch = cArrayElementsMatch;
var cArrayElementsDoNotMatch = wr1.cArray + bas.cSpace + wr1.celements + bas.cSpace + bas.cdo + bas.cSpace + gen.cnot + bas.cSpace + wr1.cmatch; // Array elements do not match

exports.cArrayElementsDoNotMatch = cArrayElementsDoNotMatch;
var clineArray2Is = wr1.cline + wr1.cArray + bas.cOpenBracket + num.c2 + bas.cCloseBracket + sys.cSpaceIsColonSpace; // lineArray[2] is:

exports.clineArray2Is = clineArray2Is;
var cSuggestedLineOfCodeIs = wr1.cSuggested + bas.cSpace + wr1.cline + bas.cSpace + bas.cof + bas.cSpace + wr1.ccode + sys.cSpaceIsColonSpace; // Suggested line of code is:

exports.cSuggestedLineOfCodeIs = cSuggestedLineOfCodeIs;
var cErrorUnknownConstantFile = wr1.cERROR + bas.cColon + bas.cSpace + wr1.cUnknown + bas.cSpace + wr1.cconstant + bas.cSpace + wr1.cfile + bas.cDot; // ERROR: Unknown constant file.

exports.cErrorUnknownConstantFile = cErrorUnknownConstantFile;
var cconstantsTypesKeysIs = wr1.cconstants + wr1.cTypes + wr1.cKeys + sys.cSpaceIsColonSpace; // constantsTypesKeys is:

exports.cconstantsTypesKeysIs = cconstantsTypesKeysIs;
var cconstantTypeKeyIs = wr1.cconstant + wr1.cType + wr1.cKey + sys.cSpaceIsColonSpace; // constantTypeKey is:

exports.cconstantTypeKeyIs = cconstantTypeKeyIs;
var cconstantTypeValuesIs = wr1.cconstant + wr1.cType + wr1.cValues + sys.cSpaceIsColonSpace; // constantTypeValues is:

exports.cconstantTypeValuesIs = cconstantTypeValuesIs;
var cconstantsKeysIs = wr1.cconstants + wr1.cKeys + sys.cSpaceIsColonSpace; // constantsKeys is:

exports.cconstantsKeysIs = cconstantsKeysIs;
var cconstantKeyIs = wr1.cconstant + wr1.cKey + sys.cSpaceIsColonSpace; // constantKey is:

exports.cconstantKeyIs = cconstantKeyIs;
var cconstantActualValueIs = wr1.cconstant + wr1.cActual + wr1.cValue + sys.cSpaceIsColonSpace; // constantActualValue is:

exports.cconstantActualValueIs = cconstantActualValueIs;
var cconstantNameIs = wr1.cconstant + wr1.cName + sys.cSpaceIsColonSpace; // constantName is:

exports.cconstantNameIs = cconstantNameIs;
var cconstantValueIs = wr1.cconstant + wr1.cValue + sys.cSpaceIsColonSpace; // constantValue is:

exports.cconstantValueIs = cconstantValueIs;
var cdeltaLengthIs = wr1.cdelta + wr1.cLength + sys.cSpaceIsColonSpace; // deltaLength is:

exports.cdeltaLengthIs = cdeltaLengthIs;
var crecursiveSubStringIs = wr1.crecursive + wr1.cSubString + sys.cSpaceIsColonSpace; // recursiveSubString is:

exports.crecursiveSubStringIs = crecursiveSubStringIs;
var cmaxStringLengthIs = gen.cmax + wr1.cString + wr1.cLength + sys.cSpaceIsColonSpace; // maxStringLength is:

exports.cmaxStringLengthIs = cmaxStringLengthIs;
var cminStringLengthIs = gen.cmin + wr1.cString + wr1.cLength + sys.cSpaceIsColonSpace; // minStringLength is:

exports.cminStringLengthIs = cminStringLengthIs;
var ccurrentMasterStringArrayElementIs = sys.ccurrentMasterStringArrayElement + sys.cSpaceIsColonSpace; // currentMasterStringArrayElement is:

exports.ccurrentMasterStringArrayElementIs = ccurrentMasterStringArrayElementIs;
var cConstantDoesNotExist = wr1.cConstant + bas.cSpace + wr1.cdoes + bas.cSpace + gen.cNOT + bas.cSpace + wr1.cexist + bas.cColon + bas.cSpace; // Constant does NOT exist:

exports.cConstantDoesNotExist = cConstantDoesNotExist;
var cConstantDoesExist = wr1.cConstant + bas.cSpace + wr1.cdoes + bas.cSpace + wr1.cexist + bas.cColon + bas.cSpace; // Constant does exist:

exports.cConstantDoesExist = cConstantDoesExist;
var cBEGIN_ithLoop = wr1.cBEGIN + bas.cSpace + bas.ci + bas.cDash + bas.cth + bas.cSpace + wr1.cloop + bas.cColon + bas.cSpace; // BEGIN i-th loop:

exports.cBEGIN_ithLoop = cBEGIN_ithLoop;
var cBEGIN_ithIteration = wr1.cBEGIN + bas.cSpace + bas.ci + bas.cDash + bas.cth + bas.cSpace + wr1.citeration + bas.cColon + bas.cSpace; // BEGIN i-th iteration:

exports.cBEGIN_ithIteration = cBEGIN_ithIteration;
var cBEGIN_jthLoop = wr1.cBEGIN + bas.cSpace + bas.cj + bas.cDash + bas.cth + bas.cSpace + wr1.cloop + bas.cColon + bas.cSpace; // BEGIN j-th loop:

exports.cBEGIN_jthLoop = cBEGIN_jthLoop;
var cBEGIN_kthIteration = wr1.cBEGIN + bas.cSpace + bas.ck + bas.cDash + bas.cth + bas.cSpace + wr1.citeration + bas.cColon + bas.cSpace; // BEGIN k-th iteration:

exports.cBEGIN_kthIteration = cBEGIN_kthIteration;
var cEND_ithLoop = wr1.cEND + bas.cSpace + bas.ci + bas.cDash + bas.cth + bas.cSpace + wr1.cloop + bas.cColon + bas.cSpace; // END i-th loop:

exports.cEND_ithLoop = cEND_ithLoop;
var cEND_ithIteration = wr1.cEND + bas.cSpace + bas.ci + bas.cDash + bas.cth + bas.cSpace + wr1.citeration + bas.cColon + bas.cSpace; // END i-th iteration:

exports.cEND_ithIteration = cEND_ithIteration;
var cEND_jthLoop = wr1.cEND + bas.cSpace + bas.cj + bas.cDash + bas.cth + bas.cSpace + wr1.cloop + bas.cColon + bas.cSpace; // END j-th loop:

exports.cEND_jthLoop = cEND_jthLoop;
var cEND_kthIteration = wr1.cEND + bas.cSpace + bas.ck + bas.cDash + bas.cth + bas.cSpace + wr1.citeration + bas.cColon + bas.cSpace; // END k-th iteration:

exports.cEND_kthIteration = cEND_kthIteration;
var ccurrentCommandIs = wr1.ccurrent + wr1.cCommand + sys.cSpaceIsColonSpace; // currentCommand is:

exports.ccurrentCommandIs = ccurrentCommandIs;
var caliasListIs = wr1.calias + wr1.cList + sys.cSpaceIsColonSpace; // aliasList is:

exports.caliasListIs = caliasListIs;
var ccurrentAliasIs = wr1.ccurrent + wr1.cAlias + sys.cSpaceIsColonSpace; // currentAlias is:

exports.ccurrentAliasIs = ccurrentAliasIs;
var cduplicateAliasCountIs = wr1.cduplicate + wr1.cAlias + wr1.cCount + sys.cSpaceIsColonSpace; // duplicateAliasCount is:

exports.cduplicateAliasCountIs = cduplicateAliasCountIs;
var cduplicateCommandAliasIs = wr1.cduplicate + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.calias + sys.cSpaceIsColonSpace; // duplicate command alias is:

exports.cduplicateCommandAliasIs = cduplicateCommandAliasIs;
var ccommandWordAliasesBeforeChangeIs = wr1.ccommand + wr1.cWord + wr1.cAliases + bas.cSpace + wr1.cBEFORE + bas.cSpace + wr1.cCHANGE + sys.cSpaceIsColonSpace; // commandWordAliases BEFORE CHANGE is:

exports.ccommandWordAliasesBeforeChangeIs = ccommandWordAliasesBeforeChangeIs;
var ccommandWordAliasesAfterChangeIs = wr1.ccommand + wr1.cWord + wr1.cAliases + wr1.cArray + bas.cSpace + wr1.cAFTER + bas.cSpace + wr1.cCHANGE + sys.cSpaceIsColonSpace; // commandWordAliasesArray AFTER CHANGE is:

exports.ccommandWordAliasesAfterChangeIs = ccommandWordAliasesAfterChangeIs;
var cmasterCommandWordAlisesArrayIs = wr1.cmaster + wr1.cCommand + wr1.cWord + wr1.cAliases + wr1.cArray + sys.cSpaceIsColonSpace; // masterCommandWordAliasesArray is:

exports.cmasterCommandWordAlisesArrayIs = cmasterCommandWordAlisesArrayIs;
var cmasterArrayIndexIs = wr1.cmaster + wr1.cArray + wr1.cIndex + sys.cSpaceIsColonSpace; // masterArrayIndex is:

exports.cmasterArrayIndexIs = cmasterArrayIndexIs;
var cCommandAliasesAre = wr1.cCommand + bas.cSpace + wr1.cAliases + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // Command Aliases are:

exports.cCommandAliasesAre = cCommandAliasesAre;
var cexpandedLehmerCodeArrayIs = wr1.cexpanded + sys.cLehmerCodeArray + sys.cSpaceIsColonSpace; // expandedLehmerCodeArray is:

exports.cexpandedLehmerCodeArrayIs = cexpandedLehmerCodeArrayIs;
var cindexOfExpansionIs = wr1.cindex + bas.cOf + wr1.cExpansion + sys.cSpaceIsColonSpace; // indexOfExpansion is:

exports.cindexOfExpansionIs = cindexOfExpansionIs;
var carrayToBeExpandedIs = wr1.carray + bas.cTo + bas.cBe + wr1.cExpanded + sys.cSpaceIsColonSpace; // arrayToBeExpanded is:

exports.carrayToBeExpandedIs = carrayToBeExpandedIs;
var climitOfExpansionIs = wr1.climit + bas.cOf + wr1.cExpansion + sys.cSpaceIsColonSpace; // limitOfExpansion is:

exports.climitOfExpansionIs = climitOfExpansionIs;
var cpushingLehmerCodeArray1ToReturnDataValue = wr1.cpushing + bas.cSpace + sys.cLehmerCodeArray + num.c1 + bas.cSpace + bas.cto + bas.cSpace + sys.creturnData + bas.cSpace + wr1.cvalue + bas.cColon + bas.cSpace; // pushing LehmerCodeArray1 to returnData value:

exports.cpushingLehmerCodeArray1ToReturnDataValue = cpushingLehmerCodeArray1ToReturnDataValue;
var creturnDataAfterPushIs = sys.creturnData + bas.cSpace + wr1.cafter + bas.cSpace + wr1.cpush + sys.cSpaceIsColonSpace; // returnData after push is:

exports.creturnDataAfterPushIs = creturnDataAfterPushIs;
var creturnDataAfterLevel1Is = sys.creturnData + bas.cSpace + wr1.cafter + bas.cSpace + wr1.clevel + bas.cSpace + num.c1 + sys.cSpaceIsColonSpace; // returnData after Level 1 is:

exports.creturnDataAfterLevel1Is = creturnDataAfterLevel1Is;
var carrayToBeExpandedDotLengthIs = wr1.carray + bas.cTo + bas.cBe + wr1.cExpanded + bas.cDot + wr1.clength + sys.cSpaceIsColonSpace; // arrayToBeExpanded.length is:

exports.carrayToBeExpandedDotLengthIs = carrayToBeExpandedDotLengthIs;
var creturnDataDotLengthIs = sys.creturnData + bas.cDot + wr1.clength + sys.cSpaceIsColonSpace; // returnData.length is:

exports.creturnDataDotLengthIs = creturnDataDotLengthIs;
var creturnDataBeforePopIs = sys.creturnData + bas.cSpace + wr1.cBEFORE + bas.cSpace + wr1.cPOP + sys.cSpaceIsColonSpace; // returnData BEFORE POP is:

exports.creturnDataBeforePopIs = creturnDataBeforePopIs;
var creturnDataAfterPopIs = sys.creturnData + bas.cSpace + wr1.cAFTER + bas.cSpace + wr1.cPOP + sys.cSpaceIsColonSpace; // returnData AFTER POP is:

exports.creturnDataAfterPopIs = creturnDataAfterPopIs;
var cmasterTempReturnDataBeforeRecursiveCallIs = wr1.cmaster + wr1.cTemp + wr1.cReturn + wr1.cData + bas.cSpace + wr1.cBEFORE + bas.cSpace + wr1.crecursive + bas.cSpace + wr1.ccall + sys.cSpaceIsColonSpace; // masterTempReturnData BEFORE recursive call is:

exports.cmasterTempReturnDataBeforeRecursiveCallIs = cmasterTempReturnDataBeforeRecursiveCallIs;
var ctempReturnData1Is = wr1.ctemp + wr1.cReturn + wr1.cData + num.c1 + sys.cSpaceIsColonSpace; // tempReturnData1 is:

exports.ctempReturnData1Is = ctempReturnData1Is;
var ctempReturnData1DotLengthIs = wr1.ctemp + wr1.cReturn + wr1.cData + num.c1 + bas.cDot + wr1.clength + sys.cSpaceIsColonSpace; // tempReturnData1.length is:

exports.ctempReturnData1DotLengthIs = ctempReturnData1DotLengthIs;
var cpushingTempReturnData1Kvalue = wr1.cpushing + bas.cSpace + wr1.ctemp + wr1.cReturn + wr1.cData + num.c1 + bas.cOpenBracket + bas.ck + bas.cCloseBracket + bas.cSpace + wr1.cvalue + bas.cColon + bas.cSpace; // pushing tempReturnData1[k] value:

exports.cpushingTempReturnData1Kvalue = cpushingTempReturnData1Kvalue;
var cmasterTempReturnDataAfterRecursiveCallIs = wr1.cmaster + wr1.cTemp + wr1.cReturn + wr1.cData + bas.cSpace + wr1.cAFTER + bas.cSpace + wr1.crecursive + bas.cSpace + wr1.ccall + sys.cSpaceIsColonSpace; // masterTempReturnData AFTER recursive call is:

exports.cmasterTempReturnDataAfterRecursiveCallIs = cmasterTempReturnDataAfterRecursiveCallIs;
var clookupIndexIs = wr1.clookup + wr1.cIndex + sys.cSpaceIsColonSpace; // lookupIndex is:

exports.clookupIndexIs = clookupIndexIs;
var clookupValueIs = wr1.clookup + wr1.cValue + sys.cSpaceIsColonSpace; // lookupValue is:

exports.clookupValueIs = clookupValueIs;
var cDataCatagoryShouldBe = wr1.cData + bas.cSpace + wr1.cCatagory + bas.cSpace + wr1.cshould + bas.cSpace + bas.cbe + bas.cColon + bas.cSpace; // Data Catagory should be:

exports.cDataCatagoryShouldBe = cDataCatagoryShouldBe;
var cDataCatagoryDetailNameShouldBe = wr1.cData + bas.cSpace + wr1.cCatagory + bas.cSpace + wr1.cDetail + bas.cSpace + wr1.cName + bas.cSpace + wr1.cshould + bas.cSpace + bas.cbe + bas.cColon + bas.cSpace; // Data Catagory Detail Name should be:

exports.cDataCatagoryDetailNameShouldBe = cDataCatagoryDetailNameShouldBe;
var cKeywordNameShouldBe = wr1.cKeyword + bas.cSpace + wr1.cName + bas.cSpace + wr1.cshould + bas.cSpace + bas.cbe + bas.cColon + bas.cSpace; // Keyword Name should be:

exports.cKeywordNameShouldBe = cKeywordNameShouldBe;
var cpathElementIs = wr1.cpath + wr1.cElement + sys.cSpaceIsColonSpace; // pathElement is:

exports.cpathElementIs = cpathElementIs;
var ccaseIEqual0 = wr1.ccase + bas.cColon + bas.cSpace + bas.ci + bas.cSpace + bas.cEqual + bas.cSpace + num.c0; // case: i = 0

exports.ccaseIEqual0 = ccaseIEqual0;
var ccasePathElementEqual = wr1.ccase + bas.cColon + bas.cSpace + wr1.cpath + wr1.cElement + bas.cSpace + bas.cEqual + bas.cSpace; // case: pathElement =

exports.ccasePathElementEqual = ccasePathElementEqual;
var ccaseElse = wr1.ccase + bas.cSpace + wr1.celse; // case else

exports.ccaseElse = ccaseElse;
var creturnDataSoFarIs = sys.creturnData + bas.cSpace + bas.cso + bas.cSpace + wr1.cfar + sys.cSpaceIsColonSpace; // returnData so far is:

exports.creturnDataSoFarIs = creturnDataSoFarIs;
var cpathArrayIs = wr1.cpath + wr1.cArray + sys.cSpaceIsColonSpace; // pathArray is:

exports.cpathArrayIs = cpathArrayIs;
var ccurrentPathElementIs = wr1.ccurrent + bas.cSpace + wr1.cpath + bas.cSpace + wr1.celement + sys.cSpaceIsColonSpace; // current path element is:

exports.ccurrentPathElementIs = ccurrentPathElementIs;
var cAttemptingToLoadXmlData = wr1.cAttempting + bas.cSpace + bas.cto + bas.cSpace + wr1.cload + bas.cSpace + gen.cXML + bas.cSpace + wr1.cdata + bas.cExclamation; // Attempting to load XML data!

exports.cAttemptingToLoadXmlData = cAttemptingToLoadXmlData;
var cAttemptingToLoadCsvData = wr1.cAttempting + bas.cSpace + bas.cto + bas.cSpace + wr1.cload + bas.cSpace + gen.cCSV + bas.cSpace + wr1.cdata + bas.cExclamation; // Attempting to load CSV data!

exports.cAttemptingToLoadCsvData = cAttemptingToLoadCsvData;
var cAttemptingToLoadJsonData = wr1.cAttempting + bas.cSpace + bas.cto + bas.cSpace + wr1.cload + bas.cSpace + gen.cJSON + bas.cSpace + wr1.cdata + bas.cExclamation; // Attempting to load JSON data!

exports.cAttemptingToLoadJsonData = cAttemptingToLoadJsonData;
var cLoadedDataIs = wr1.cLoaded + bas.cSpace + wr1.cdata + sys.cSpaceIsColonSpace; // Loaded data is:

exports.cLoadedDataIs = cLoadedDataIs;
var cattributeArrayIs = wr1.cattribute + wr1.cArray + sys.cSpaceIsColonSpace; // attributeArray is:

exports.cattributeArrayIs = cattributeArrayIs;
var cattributeArray0Is = wr1.cattribute + wr1.cArray + bas.cOpenBracket + num.c0 + bas.cCloseBracket + sys.cSpaceIsColonSpace; // attributeArray[0] is:

exports.cattributeArray0Is = cattributeArray0Is;
var cattributeArray1Is = wr1.cattribute + wr1.cArray + bas.cOpenBracket + num.c1 + bas.cCloseBracket + sys.cSpaceIsColonSpace; // attributeArray[1] is:

exports.cattributeArray1Is = cattributeArray1Is;
var carrayIs = wr1.carray + sys.cSpaceIsColonSpace; // array is:

exports.carrayIs = carrayIs;
var cvalueIs = wr1.cvalue + sys.cSpaceIsColonSpace; // value is:

exports.cvalueIs = cvalueIs;
var cmyFunctionIs = bas.cmy + wr1.cFunction + sys.cSpaceIsColonSpace; // myFunction is:

exports.cmyFunctionIs = cmyFunctionIs;
var carrayInputObjectIsNotAnArray = wr1.carray + bas.cSpace + wr1.cinput + bas.cSpace + wr1.cobject + bas.cSpace + bas.cis + bas.cSpace + gen.cnot + bas.cSpace + bas.can + bas.cSpace + wr1.carray + bas.cDot; // array input object is not an array.

exports.carrayInputObjectIsNotAnArray = carrayInputObjectIsNotAnArray;
var cTheValueWasFoundInTheArray = wr1.cThe + bas.cSpace + wr1.cvalue + bas.cSpace + wr1.cwas + bas.cSpace + wr1.cfound + bas.cSpace + bas.cin + bas.cSpace + wr1.cthe + bas.cSpace + wr1.carray + bas.cDot; // The value was found in the array.

exports.cTheValueWasFoundInTheArray = cTheValueWasFoundInTheArray;
var cTheValueWasNotFoundInTheArray = wr1.cThe + bas.cSpace + wr1.cvalue + bas.cSpace + wr1.cwas + bas.cSpace + gen.cNOT + bas.cSpace + wr1.cfound + bas.cSpace + bas.cin + bas.cSpace + wr1.cthe + bas.cSpace + wr1.carray + bas.cDot; // The value was NOT found in the array.

exports.cTheValueWasNotFoundInTheArray = cTheValueWasNotFoundInTheArray;
var coriginalStringIs = wr1.coriginal + wr1.cString + sys.cSpaceIsColonSpace; // originalString is:

exports.coriginalStringIs = coriginalStringIs;
var cindexIs = wr1.cindex + sys.cSpaceIsColonSpace; // index is:

exports.cindexIs = cindexIs;
var creplacementIs = wr1.creplacement + sys.cSpaceIsColonSpace; // replacement is:

exports.creplacementIs = creplacementIs;
var cDEPLOY_APPLICATION = wr1.cDEPLOY + bas.cUnderscore + wr1.cAPPLICATION; // DEPLOY_APPLICATION

exports.cDEPLOY_APPLICATION = cDEPLOY_APPLICATION;
var cRELEASE_APPLICATION = wr1.cRELEASE + bas.cUnderscore + wr1.cAPPLICATION; // RELEASE_APPLICATION

exports.cRELEASE_APPLICATION = cRELEASE_APPLICATION;
var cReleaseFailed = wr1.cRelease + bas.cSpace + wr1.cfailed; // Release failed
// smuggle something cinputDataIis = cinputData + bas.cOpenBracket + bas.ci + bas.cCloseBracket + sys.cSpaceIsColonSpace; // inputData[i] is:

exports.cReleaseFailed = cReleaseFailed;
var caggregateCommandStringIs = wr1.caggregate + wr1.cCommand + wr1.cString + sys.cSpaceIsColonSpace; // aggregateCommandString is:

exports.caggregateCommandStringIs = caggregateCommandStringIs;
var cmetaDataParametersIs = wr1.cmetaData + wr1.cParameters + sys.cSpaceIsColonSpace; // metaDataParameters is:

exports.cmetaDataParametersIs = cmetaDataParametersIs;
var cmetaDataParametersLengthIs = wr1.cmetaData + wr1.cParameters + bas.cSpace + wr1.clength + sys.cSpaceIsColonSpace; // metaDataParameters length is:

exports.cmetaDataParametersLengthIs = cmetaDataParametersLengthIs;
var cmetaDataPathAndFilenameIs = wr1.cmetaData + wr1.cPath + wr1.cAnd + wr1.cFilename + sys.cSpaceIsColonSpace; // metaDataPathAndFilename is:

exports.cmetaDataPathAndFilenameIs = cmetaDataPathAndFilenameIs;
var cpathAndFilenameIs = wr1.cpath + wr1.cAnd + wr1.cFilename + sys.cSpaceIsColonSpace; // pathAndFilename is:

exports.cpathAndFilenameIs = cpathAndFilenameIs;
var ccontentsAre = wr1.ccontents + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // contents are:

exports.ccontentsAre = ccontentsAre;
var ccontentsOfDare = wr1.ccontents + bas.cSpace + bas.cof + bas.cSpace + bas.cD + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // contents of D are:

exports.ccontentsOfDare = ccontentsOfDare;
var cBEGIN_theIthIterationOfInputDataArray = wr1.cBEGIN + bas.cSpace + wr1.cthe + bas.cSpace + bas.ci + bas.cDash + bas.cth + bas.cSpace + wr1.citeration + bas.cSpace + bas.cof + bas.cSpace + wr1.cthe + bas.cSpace + cinputData + bas.cSpace + wr1.carray + bas.cDot + bas.cSpace + bas.ci + sys.cSpaceIsColonSpace; // Begin the i-th iteration of the inputData array. i is:

exports.cBEGIN_theIthIterationOfInputDataArray = cBEGIN_theIthIterationOfInputDataArray;
var ccurrentRuleIs = wr1.ccurrent + wr1.cRule + sys.cSpaceIsColonSpace; // currentRule is:

exports.ccurrentRuleIs = ccurrentRuleIs;
var crulesIs = wr1.crules + sys.cSpaceIsColonSpace; // rules is:

exports.crulesIs = crulesIs;
var cruleInputDataIs = wr1.crule + cInputData + sys.cSpaceIsColonSpace; // ruleInputData is:

exports.cruleInputDataIs = cruleInputDataIs;
var cruleInputMetaData = wr1.crule + wr1.cInput + wr1.cMetaData + sys.cSpaceIsColonSpace; // ruleInputMetaData is:

exports.cruleInputMetaData = cruleInputMetaData;
var cBusinessRuleStartTimeIs = wr1.cBusiness + bas.cSpace + wr1.cRule + bas.cSpace + wr1.cStart + bas.cSpace + wr1.ctime + sys.cSpaceIsColonSpace; // Business Rule Start time is:

exports.cBusinessRuleStartTimeIs = cBusinessRuleStartTimeIs;
var cBusinessRuleEndTimeIs = wr1.cBusiness + bas.cSpace + wr1.cRule + bas.cSpace + wr1.cEnd + bas.cSpace + wr1.ctime + sys.cSpaceIsColonSpace; // Business Rule End time is:

exports.cBusinessRuleEndTimeIs = cBusinessRuleEndTimeIs;
var cBusinessRuleRunTimeIs = wr1.cBusiness + wr1.cRule + bas.cSpace + wr1.crun + bas.cDash + wr1.ctime + sys.cSpaceIsColonSpace; // BusinessRule run-time is:

exports.cBusinessRuleRunTimeIs = cBusinessRuleRunTimeIs;
var ccommandStringBeforeAttemptedDelimiterSwapIs = wr1.ccommand + wr1.cString + bas.cSpace + wr1.cbefore + bas.cSpace + wr1.cattempted + bas.cSpace + wr1.cdelimiter + bas.cSpace + wr1.cswap + sys.cSpaceIsColonSpace; // commandString before attempted delimiter swap is:

exports.ccommandStringBeforeAttemptedDelimiterSwapIs = ccommandStringBeforeAttemptedDelimiterSwapIs;
var creplaceCharacterWithCharacterRuleIs = wr1.creplace + wr1.cCharacter + wr1.cWith + wr1.cCharacter + wr1.cRule + sys.cSpaceIsColonSpace; // replaceCharacterWithCharacterRule is:

exports.creplaceCharacterWithCharacterRuleIs = creplaceCharacterWithCharacterRuleIs;
var cRuleOutputIs = wr1.cRule + bas.cSpace + wr1.coutput + sys.cSpaceIsColonSpace; // Rule output is:

exports.cRuleOutputIs = cRuleOutputIs;
var ccamelCaseCommandNameArrayIs = wr1.ccamel + wr1.cCase + wr1.cCommand + wr1.cName + wr1.cArray + sys.cSpaceIsColonSpace; // camelCaseCommandNameArray is:

exports.ccamelCaseCommandNameArrayIs = ccamelCaseCommandNameArrayIs;
var ccurrentCommandWordIs = wr1.ccurrent + bas.cSpace + wr1.ccommand + wr1.cWord + sys.cSpaceIsColonSpace; // current commandWord is:

exports.ccurrentCommandWordIs = ccurrentCommandWordIs;
var cPARSER_ERROR = wr1.cPARSER + bas.cSpace + wr1.cERROR + bas.cColon + bas.cSpace; // PARSER ERROR:

exports.cPARSER_ERROR = cPARSER_ERROR;
var ccommandAliasDataStructureIs = wr1.ccommand + wr1.cAlias + wr1.cData + wr1.cStructure + sys.cSpaceIsColonSpace; // commandAliasDataStructure is:

exports.ccommandAliasDataStructureIs = ccommandAliasDataStructureIs;
var cuserDefinedConstantIs = wr1.cuser + wr1.cDefined + wr1.cConstant + sys.cSpaceIsColonSpace; // userDefinedConstant is:

exports.cuserDefinedConstantIs = cuserDefinedConstantIs;
var cwordCountIs = wr1.cword + wr1.cCount + sys.cSpaceIsColonSpace; // wordCount is:

exports.cwordCountIs = cwordCountIs;
var cwordsArrayIs = wr1.cwords + wr1.cArray + sys.cSpaceIsColonSpace; // wordsArray is:

exports.cwordsArrayIs = cwordsArrayIs;
var cOptimizedConstantDefinitionForWord = wr1.cOptimized + bas.cSpace + wr1.cconstant + bas.cSpace + wr1.cdefinition + bas.cSpace + wr1.cfor + bas.cSpace + wr1.cword + bas.cColon + bas.cSpace; // Optimized constant definition for word:

exports.cOptimizedConstantDefinitionForWord = cOptimizedConstantDefinitionForWord;
var cuserDefinedConstantListIs = wr1.cuser + wr1.cDefined + wr1.cConstant + wr1.cList + sys.cSpaceIsColonSpace; // userDefinedConstantList is:

exports.cuserDefinedConstantListIs = cuserDefinedConstantListIs;
var cuserDefinedConstantListContainsComas = wr1.cuser + wr1.cDefined + wr1.cConstant + wr1.cList + bas.cSpace + wr1.ccontains + bas.cSpace + wr1.ccomas; // userDefinedConstantList contains comas

exports.cuserDefinedConstantListContainsComas = cuserDefinedConstantListContainsComas;
var cuserDefinedConstantsListArrayIs = wr1.cuser + wr1.cDefined + wr1.cConstants + wr1.cList + wr1.cArray + sys.cSpaceIsColonSpace; // userDefinedConstantsListArray is:

exports.cuserDefinedConstantsListArrayIs = cuserDefinedConstantsListArrayIs;
var cuserDefinedConstantsListDoesNotContainComas = wr1.cuser + wr1.cDefined + wr1.cConstant + wr1.cList + bas.cSpace + wr1.cDOES + bas.cSpace + gen.cNOT + bas.cSpace + wr1.ccontain + bas.cSpace + wr1.ccomas; // userDefinedConstantList DOES NOT contain comas

exports.cuserDefinedConstantsListDoesNotContainComas = cuserDefinedConstantsListDoesNotContainComas;
var ccommonPatternsArrayIs = wr1.ccommon + wr1.cPatterns + wr1.cArray + sys.cSpaceIsColonSpace; // commonPatternsArray is:

exports.ccommonPatternsArrayIs = ccommonPatternsArrayIs;
var cbusinessRuleCounterIs = wr1.cbusiness + wr1.cRule + wr1.cCounter + sys.cSpaceIsColonSpace; // businessRuleCounter is:

exports.cbusinessRuleCounterIs = cbusinessRuleCounterIs;
var cbusinessRulePerformanceSumIs = wr1.cbusiness + wr1.cRule + wr1.cPerformance + wr1.cSum + sys.cSpaceIsColonSpace; // businessRulePerformanceSum is:

exports.cbusinessRulePerformanceSumIs = cbusinessRulePerformanceSumIs;
var cDoneBusinessRulePerformanceSumIs = wr1.cDONE + bas.cExclamation + bas.cSpace + cbusinessRulePerformanceSumIs; // DONE! businessRulePerformanceSum is:

exports.cDoneBusinessRulePerformanceSumIs = cDoneBusinessRulePerformanceSumIs;
var caverageIs = wr1.caverage + sys.cSpaceIsColonSpace; // average is:

exports.caverageIs = caverageIs;
var cbusinessRulePerformanceStdSumIs = wr1.cbusiness + wr1.cRule + wr1.cPerformance + phn.cStd + wr1.cSum + sys.cSpaceIsColonSpace; // businessRulePerformanceStdSum is:

exports.cbusinessRulePerformanceStdSumIs = cbusinessRulePerformanceStdSumIs;
var cDoneBusinessRulePerformanceStdSumIs = wr1.cDONE + bas.cExclamation + bas.cSpace + cbusinessRulePerformanceStdSumIs; // DONE! businessRulePerformanceStdSum is:

exports.cDoneBusinessRulePerformanceStdSumIs = cDoneBusinessRulePerformanceStdSumIs;
var cstandardDevIs = wr1.cstandard + phn.cDev + sys.cSpaceIsColonSpace; // standardDev is:

exports.cstandardDevIs = cstandardDevIs;
var ccommandCounterIs = wr1.ccommand + wr1.cCounter + sys.cSpaceIsColonSpace; // commandCounter is:

exports.ccommandCounterIs = ccommandCounterIs;
var ccommandPerformanceSumIs = wr1.ccommand + wr1.cPerformance + wr1.cSum + sys.cSpaceIsColonSpace; // commandPerformanceSum is:

exports.ccommandPerformanceSumIs = ccommandPerformanceSumIs;
var cDoneCommandPerformanceSumIs = wr1.cDONE + bas.cExclamation + bas.cSpace + ccommandPerformanceSumIs; // DONE! commandPerformanceSum is:

exports.cDoneCommandPerformanceSumIs = cDoneCommandPerformanceSumIs;
var ccommandPerformanceStdSumIs = wr1.ccommand + wr1.cPerformance + phn.cStd + wr1.cSum + sys.cSpaceIsColonSpace; // commandPerformanceStdSum is:

exports.ccommandPerformanceStdSumIs = ccommandPerformanceStdSumIs;
var cDoneCommandPerformanceStdSumIs = wr1.cDONE + bas.cExclamation + bas.cSpace + ccommandPerformanceStdSumIs; // DONE! commandPerformanceStdSum is:

exports.cDoneCommandPerformanceStdSumIs = cDoneCommandPerformanceStdSumIs;
var ccolorKeysIs = wr1.ccolor + wr1.cKeys + sys.cSpaceIsColonSpace; // colorKeys is:

exports.ccolorKeysIs = ccolorKeysIs;
var ccurrentColorNameIs = wr1.ccurrent + wr1.cColor + wr1.cName + sys.cSpaceIsColonSpace; // currentColorName is:

exports.ccurrentColorNameIs = ccurrentColorNameIs;
var ccurrentColorObjectIs = wr1.ccurrent + wr1.cColor + wr1.cObject + sys.cSpaceIsColonSpace; // currentColorObject is:

exports.ccurrentColorObjectIs = ccurrentColorObjectIs;
var ccurrentColorHexValueIs = wr1.ccurrent + wr1.cColor + phn.cHex + wr1.cValue + sys.cSpaceIsColonSpace; // currentColorHexValue is:

exports.ccurrentColorHexValueIs = ccurrentColorHexValueIs;
var cruleOutputIs = wr1.crule + wr1.cOutput + sys.cSpaceIsColonSpace; // ruleOutput is:

exports.cruleOutputIs = cruleOutputIs;
var cBeginPhase1ConstantsValidation = wr1.cBEGIN + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cValidation; // BEGIN Phase 1 Constants Validation

exports.cBeginPhase1ConstantsValidation = cBeginPhase1ConstantsValidation;
var cEndPhase1ConstantsValidation = wr1.cEND + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cValidation; // END Phase 1 Constants Validation

exports.cEndPhase1ConstantsValidation = cEndPhase1ConstantsValidation;
var cBeginPhase2ConstantsValidation = wr1.cBEGIN + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cValidation; // BEGIN Phase 2 Constants Validation

exports.cBeginPhase2ConstantsValidation = cBeginPhase2ConstantsValidation;
var cEndPhase2ConstantsValidation = wr1.cEND + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cValidation; // END Phase 2 Constants Validation

exports.cEndPhase2ConstantsValidation = cEndPhase2ConstantsValidation;
var cconstantsPathIs = wr1.cconstants + wr1.cPath + sys.cSpaceIsColonSpace; // constantsPath is:

exports.cconstantsPathIs = cconstantsPathIs;
var cresolvedConstantsPath_BasicIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cBasic + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Basic is:

exports.cresolvedConstantsPath_BasicIs = cresolvedConstantsPath_BasicIs;
var cresolvedConstantsPath_BusinessIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cBusiness + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Business is:

exports.cresolvedConstantsPath_BusinessIs = cresolvedConstantsPath_BusinessIs;
var cresolvedConstantsPath_ColorIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cColor + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Color is:

exports.cresolvedConstantsPath_ColorIs = cresolvedConstantsPath_ColorIs;
var cresolvedConstantsPath_CommandIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cCommand + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Command is:

exports.cresolvedConstantsPath_CommandIs = cresolvedConstantsPath_CommandIs;
var cresolvedConstantsPath_ConfigurationIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cConfiguration + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Configuration is:

exports.cresolvedConstantsPath_ConfigurationIs = cresolvedConstantsPath_ConfigurationIs;
var cresolvedConstantsPath_CountryIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cCountry + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Country is:

exports.cresolvedConstantsPath_CountryIs = cresolvedConstantsPath_CountryIs;
var cresolvedConstantsPath_ElementIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cElement + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Element is:

exports.cresolvedConstantsPath_ElementIs = cresolvedConstantsPath_ElementIs;
var cresolvedConstantsPath_FunctionIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cFunction + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Function is:

exports.cresolvedConstantsPath_FunctionIs = cresolvedConstantsPath_FunctionIs;
var cresolvedConstantsPath_GenericIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cGeneric + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Generic is:

exports.cresolvedConstantsPath_GenericIs = cresolvedConstantsPath_GenericIs;
var cresolvedConstantsPath_IsotopeIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cIsotope + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Isotope is:

exports.cresolvedConstantsPath_IsotopeIs = cresolvedConstantsPath_IsotopeIs;
var cresolvedConstantsPath_KnotIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cKnot + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Knot is:

exports.cresolvedConstantsPath_KnotIs = cresolvedConstantsPath_KnotIs;
var cresolvedConstantsPath_LanguageIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cLanguage + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Language is:

exports.cresolvedConstantsPath_LanguageIs = cresolvedConstantsPath_LanguageIs;
var cresolvedConstantsPath_MessageIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cMessage + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Message is:

exports.cresolvedConstantsPath_MessageIs = cresolvedConstantsPath_MessageIs;
var cresolvedConstantsPath_NumericIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cNumeric + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Numeric is:

exports.cresolvedConstantsPath_NumericIs = cresolvedConstantsPath_NumericIs;
var cresolvedConstantsPath_PhonicIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cPhonic + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Phonic is:

exports.cresolvedConstantsPath_PhonicIs = cresolvedConstantsPath_PhonicIs;
var cresolvedConstantsPath_ShapeIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cShape + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Shape is:

exports.cresolvedConstantsPath_ShapeIs = cresolvedConstantsPath_ShapeIs;
var cresolvedConstantsPath_SystemIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cSystem + sys.cSpaceIsColonSpace; // resolvedConstantsPath_System is:

exports.cresolvedConstantsPath_SystemIs = cresolvedConstantsPath_SystemIs;
var cresolvedConstantsPath_UnitIs = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cUnit + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Unit is:

exports.cresolvedConstantsPath_UnitIs = cresolvedConstantsPath_UnitIs;
var cresolvedConstantsPath_Word1Is = wr1.cresolved + wr1.cConstants + wr1.cPath + bas.cUnderscore + wr1.cWord + num.c1 + sys.cSpaceIsColonSpace; // resolvedConstantsPath_Word1 is:

exports.cresolvedConstantsPath_Word1Is = cresolvedConstantsPath_Word1Is;
var cBasicConstantsPhase1Validation = wr1.cBasic + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Basic Constants Phase 1 Validation

exports.cBasicConstantsPhase1Validation = cBasicConstantsPhase1Validation;
var cBusinessConstantsPhase1Validation = wr1.cBusiness + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Business Constants Phase 1 Validation

exports.cBusinessConstantsPhase1Validation = cBusinessConstantsPhase1Validation;
var cColorConstantsPhase1Validation = wr1.cColor + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Color Constants Phase 1 Validation

exports.cColorConstantsPhase1Validation = cColorConstantsPhase1Validation;
var cCommandConstantsPhase1Validation = wr1.cCommand + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Command Constants Phase 1 Validation

exports.cCommandConstantsPhase1Validation = cCommandConstantsPhase1Validation;
var cConfigurationConstantsPhase1Validation = wr1.cConfiguration + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Configuration Constants Phase 1 Validation

exports.cConfigurationConstantsPhase1Validation = cConfigurationConstantsPhase1Validation;
var cCountryConstantsPhase1Validation = wr1.cCountry + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Country Constants Phase 1 Validation

exports.cCountryConstantsPhase1Validation = cCountryConstantsPhase1Validation;
var cElementConstantsPhase1Validation = wr1.cElement + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Element Constants Phase 1 Validation

exports.cElementConstantsPhase1Validation = cElementConstantsPhase1Validation;
var cFunctionConstantsPhase1Validation = wr1.cFunction + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Function Constants Phase 1 Validation

exports.cFunctionConstantsPhase1Validation = cFunctionConstantsPhase1Validation;
var cGenericConstantsPhase1Validation = wr1.cGeneric + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Generic Constants Phase 1 Validation

exports.cGenericConstantsPhase1Validation = cGenericConstantsPhase1Validation;
var cIsotopeConstantsPhase1Validation = wr1.cIsotope + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Isotope Constants Phase 1 Validation

exports.cIsotopeConstantsPhase1Validation = cIsotopeConstantsPhase1Validation;
var cKnotConstantsPhase1Validation = wr1.cKnot + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Knot Constants Phase 1 Validation

exports.cKnotConstantsPhase1Validation = cKnotConstantsPhase1Validation;
var cLanguageConstantsPhase1Validation = wr1.cLanguage + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Language Constants Phase 1 Validation

exports.cLanguageConstantsPhase1Validation = cLanguageConstantsPhase1Validation;
var cMessageConstantsPhase1Validation = wr1.cMessage + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Message Constants Phase 1 Validation

exports.cMessageConstantsPhase1Validation = cMessageConstantsPhase1Validation;
var cNumericConstantsPhase1Validation = wr1.cNumeric + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Numeric Constants Phase 1 Validation

exports.cNumericConstantsPhase1Validation = cNumericConstantsPhase1Validation;
var cPhonicConstantsPhase1Validation = wr1.cPhonic + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Phonic Constants Phase 1 Validation

exports.cPhonicConstantsPhase1Validation = cPhonicConstantsPhase1Validation;
var cShapeConstantsPhase1Validation = wr1.cShape + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Shape Constants Phase 1 Validation

exports.cShapeConstantsPhase1Validation = cShapeConstantsPhase1Validation;
var cSystemConstantsPhase1Validation = wr1.cSystem + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // System Constants Phase 1 Validation

exports.cSystemConstantsPhase1Validation = cSystemConstantsPhase1Validation;
var cUnitConstantsPhase1Validation = wr1.cUnit + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Unit Constants Phase 1 Validation

exports.cUnitConstantsPhase1Validation = cUnitConstantsPhase1Validation;
var cWord1ConstantsPhase1Validation = wr1.cWord + num.c1 + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c1 + bas.cSpace + wr1.cValidation; // Word1 Constants Phase 1 Validation

exports.cWord1ConstantsPhase1Validation = cWord1ConstantsPhase1Validation;
var cBasicConstantsPhase2Validation = wr1.cBasic + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Basic Constants Phase 2 Validation

exports.cBasicConstantsPhase2Validation = cBasicConstantsPhase2Validation;
var cBusinessConstantsPhase2Validation = wr1.cBusiness + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Business Constants Phase 2 Validation

exports.cBusinessConstantsPhase2Validation = cBusinessConstantsPhase2Validation;
var cColorConstantsPhase2Validation = wr1.cColor + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Color Constants Phase 2 Validation

exports.cColorConstantsPhase2Validation = cColorConstantsPhase2Validation;
var cCommandConstantsPhase2Validation = wr1.cCommand + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Command Constants Phase 2 Validation

exports.cCommandConstantsPhase2Validation = cCommandConstantsPhase2Validation;
var cConfigurationConstantsPhase2Validation = wr1.cConfiguration + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Configuration Constants Phase 2 Validation

exports.cConfigurationConstantsPhase2Validation = cConfigurationConstantsPhase2Validation;
var cCountryConstantsPhase2Validation = wr1.cCountry + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Country Constants Phase 2 Validation

exports.cCountryConstantsPhase2Validation = cCountryConstantsPhase2Validation;
var cElementConstantsPhase2Validation = wr1.cElement + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Element Constants Phase 2 Validation

exports.cElementConstantsPhase2Validation = cElementConstantsPhase2Validation;
var cFunctionConstantsPhase2Validation = wr1.cFunction + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Function Constants Phase 2 Validation

exports.cFunctionConstantsPhase2Validation = cFunctionConstantsPhase2Validation;
var cGenericConstantsPhase2Validation = wr1.cGeneric + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Generic Constants Phase 2 Validation

exports.cGenericConstantsPhase2Validation = cGenericConstantsPhase2Validation;
var cIsotopeConstantsPhase2Validation = wr1.cIsotope + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Isotope Constants Phase 2 Validation

exports.cIsotopeConstantsPhase2Validation = cIsotopeConstantsPhase2Validation;
var cKnotConstantsPhase2Validation = wr1.cKnot + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Knot Constants Phase 2 Validation

exports.cKnotConstantsPhase2Validation = cKnotConstantsPhase2Validation;
var cLanguageConstantsPhase2Validation = wr1.cLanguage + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Language Constants Phase 2 Validation

exports.cLanguageConstantsPhase2Validation = cLanguageConstantsPhase2Validation;
var cMessageConstantsPhase2Validation = wr1.cMessage + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Message Constants Phase 2 Validation

exports.cMessageConstantsPhase2Validation = cMessageConstantsPhase2Validation;
var cNumericConstantsPhase2Validation = wr1.cNumeric + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Numeric Constants Phase 2 Validation

exports.cNumericConstantsPhase2Validation = cNumericConstantsPhase2Validation;
var cPhonicConstantsPhase2Validation = wr1.cPhonic + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Phonic Constants Phase 2 Validation

exports.cPhonicConstantsPhase2Validation = cPhonicConstantsPhase2Validation;
var cShapeConstantsPhase2Validation = wr1.cShape + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Shape Constants Phase 2 Validation

exports.cShapeConstantsPhase2Validation = cShapeConstantsPhase2Validation;
var cSystemConstantsPhase2Validation = wr1.cSystem + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // System Constants Phase 2 Validation

exports.cSystemConstantsPhase2Validation = cSystemConstantsPhase2Validation;
var cUnitConstantsPhase2Validation = wr1.cUnit + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Unit Constants Phase 2 Validation

exports.cUnitConstantsPhase2Validation = cUnitConstantsPhase2Validation;
var cWord1ConstantsPhase2Validation = wr1.cWord + num.c1 + bas.cSpace + wr1.cConstants + bas.cSpace + wr1.cPhase + bas.cSpace + num.c2 + bas.cSpace + wr1.cValidation; // Word1 Constants Phase 2 Validation

exports.cWord1ConstantsPhase2Validation = cWord1ConstantsPhase2Validation;
var ccommandStringIs = wr1.ccommand + wr1.cString + sys.cSpaceIsColonSpace; // commandString is:

exports.ccommandStringIs = ccommandStringIs;
var ccommandDelimiterIs = wr1.ccommand + wr1.cDelimiter + sys.cSpaceIsColonSpace; // commandDelimiter is:

exports.ccommandDelimiterIs = ccommandDelimiterIs;
var ccommandToExecuteBeforeTheAliasIs = wr1.ccommand + bas.cTo + wr1.cExecute + bas.cSpace + wr1.cbefore + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cAlias + sys.cSpaceIsColonSpace; // commandToExecute before the Alias is:

exports.ccommandToExecuteBeforeTheAliasIs = ccommandToExecuteBeforeTheAliasIs;
var ccommandToExecuteAfterTheAliasIs = wr1.ccommand + bas.cTo + wr1.cExecute + bas.cSpace + wr1.cafter + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cAlias + sys.cSpaceIsColonSpace; // commandToExecute after the Alias is:

exports.ccommandToExecuteAfterTheAliasIs = ccommandToExecuteAfterTheAliasIs;
var cWarningTheSpecifiedCommand = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cThe + bas.cSpace + wr1.cspecified + bas.cSpace + wr1.ccommand + bas.cColon + bas.cSpace; // WARNING: The specified command:

exports.cWarningTheSpecifiedCommand = cWarningTheSpecifiedCommand;
var cdoesNotExistPleaseTryAgain = bas.cSpace + wr1.cdoes + bas.cSpace + gen.cnot + bas.cSpace + wr1.cexist + bas.cComa + bas.cSpace + wr1.cplease + bas.cSpace + wr1.ctry + bas.cSpace + wr1.cagain + bas.cExclamation; // does not exist, please try again!

exports.cdoesNotExistPleaseTryAgain = cdoesNotExistPleaseTryAgain;
var ccommandStringContainsEitherSingleQuoteOrBackTickQuote = wr1.ccommand + wr1.cString + bas.cSpace + wr1.ccontains + bas.cSpace + wr1.ceither + bas.cSpace + bas.ca + bas.cSpace + wr1.csingle + wr1.cQuote + bas.cSpace + bas.cor + bas.cSpace + bas.ca + bas.cSpace + wr1.cback + wr1.cTick + wr1.cQuote; // commandString contains either a singleQuote or a backTickQuote

exports.ccommandStringContainsEitherSingleQuoteOrBackTickQuote = ccommandStringContainsEitherSingleQuoteOrBackTickQuote;
var ccommandStringContainsSingleQuote = wr1.ccommand + wr1.cString + bas.cSpace + wr1.ccontains + bas.cSpace + bas.ca + bas.cSpace + wr1.csingle + wr1.cQuote + bas.cExclamation; // commandString contains a singleQuote!

exports.ccommandStringContainsSingleQuote = ccommandStringContainsSingleQuote;
var cnumberOfSingleQuotesIsEven = wr1.cnumber + bas.cOf + wr1.cSingle + wr1.cQuotes + bas.cSpace + bas.cis + bas.cSpace + bas.cGreaterThan + bas.cEqual + bas.cSpace + num.c2 + bas.cSpace + bas.cAndPersand + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cnumber + bas.cOf + wr1.cSingle + wr1.cQuotes + bas.cSpace + bas.cis + bas.cSpace + wr1.cEVEN + bas.cExclamation + bas.cSpace + wr1.cYAY + bas.cExclamation; // numberOfSingleQuotes is >= 2 & the numberOfSingleQuotes is EVEN! YAY!

exports.cnumberOfSingleQuotesIsEven = cnumberOfSingleQuotesIsEven;
var cFirstIndexIs = num.cFirst + bas.cSpace + wr1.cindex + sys.cSpaceIsColonSpace; // First index is:

exports.cFirstIndexIs = cFirstIndexIs;
var ccommandStringAfterTaggingTheFirstStringDelimiter = wr1.ccommand + wr1.cString + bas.cSpace + wr1.cafter + bas.cSpace + wr1.ctagging + bas.cSpace + wr1.cthe + bas.cSpace + num.cfirst + bas.cSpace + wr1.cstring + bas.cSpace + wr1.cdelimiter + bas.cColon + bas.cSpace; // commandString after tagging the first string delimiter:

exports.ccommandStringAfterTaggingTheFirstStringDelimiter = ccommandStringAfterTaggingTheFirstStringDelimiter;
var cAdditionalIndexIs = wr1.cAdditional + bas.cSpace + wr1.cindex + sys.cSpaceIsColonSpace; // Additional index is:

exports.cAdditionalIndexIs = cAdditionalIndexIs;
var coddIndex = wr1.codd + bas.cSpace + wr1.cindex; // odd index

exports.coddIndex = coddIndex;
var cevenIndex = wr1.ceven + bas.cSpace + wr1.cindex; // even index

exports.cevenIndex = cevenIndex;
var ccommandStringAfterTaggingAnOddStringDelimiter = wr1.ccommand + wr1.cString + bas.cSpace + wr1.cafter + bas.cSpace + wr1.ctagging + bas.cSpace + bas.can + bas.cSpace + wr1.codd + bas.cSpace + wr1.cstring + bas.cSpace + wr1.cdelimiter + bas.cColon + bas.cSpace; // commandString after tagging an odd string delimiter:

exports.ccommandStringAfterTaggingAnOddStringDelimiter = ccommandStringAfterTaggingAnOddStringDelimiter;
var ccommandStringAfterTaggingAnEvenStringDelimiter = wr1.ccommand + wr1.cString + bas.cSpace + wr1.cafter + bas.cSpace + wr1.ctagging + bas.cSpace + bas.can + bas.cSpace + wr1.ceven + bas.cSpace + wr1.cstring + bas.cSpace + wr1.cdelimiter + bas.cColon + bas.cSpace; // commandString after tagging an even string delimiter:

exports.ccommandStringAfterTaggingAnEvenStringDelimiter = ccommandStringAfterTaggingAnEvenStringDelimiter;
var cpreSplitCommandStringIs = phn.cpre + wr1.cSplit + wr1.cCommand + wr1.cString + sys.cSpaceIsColonSpace; // preSplitCommandString is:

exports.cpreSplitCommandStringIs = cpreSplitCommandStringIs;
var cpostSplitCommandStringIs = wr1.cpost + wr1.cSplit + wr1.cCommand + wr1.cString + bas.cOpenBracket + bas.ck + bas.cCloseBracket + sys.cSpaceIsColonSpace; // postSplitCommandString[k] is:

exports.cpostSplitCommandStringIs = cpostSplitCommandStringIs;
var cpreSplitCommandStringElementIs = phn.cpre + wr1.cSplit + wr1.cCommand + wr1.cString + wr1.cElement + sys.cSpaceIsColonSpace; // preSplitCommandStringElement is:

exports.cpreSplitCommandStringElementIs = cpreSplitCommandStringElementIs;
var cDoingStraightSplitCommandString = wr1.cDoing + bas.cSpace + bas.ca + bas.cSpace + wr1.cstraight + bas.cSpace + wr1.csplit + bas.cSpace + bas.cof + bas.cSpace + wr1.cthe + bas.cSpace + wr1.ccommand + wr1.cString + bas.cColon + bas.cSpace; // Doing a straight split of the commandString:

exports.cDoingStraightSplitCommandString = cDoingStraightSplitCommandString;
var cCommandStartTimeIs = wr1.cCommand + bas.cSpace + wr1.cStart + bas.cSpace + wr1.ctime + sys.cSpaceIsColonSpace; // Command Start time is:

exports.cCommandStartTimeIs = cCommandStartTimeIs;
var cCommandEndTimeIs = wr1.cCommand + bas.cSpace + wr1.cEnd + bas.cSpace + wr1.ctime + sys.cSpaceIsColonSpace; // Command End time is:

exports.cCommandEndTimeIs = cCommandEndTimeIs;
var cCommandRunTimeIs = wr1.cCommand + bas.cSpace + wr1.crun + bas.cDash + wr1.ctime + sys.cSpaceIsColonSpace; // Command run-time is:

exports.cCommandRunTimeIs = cCommandRunTimeIs;
var ccommandAliasesFilePathConfigurationNameIs = wr1.ccommand + wr1.cAliases + wr1.cFile + wr1.cPath + wr1.cConfiguration + wr1.cName + sys.cSpaceIsColonSpace; // commandAliasesFilePathConfigurationName is:

exports.ccommandAliasesFilePathConfigurationNameIs = ccommandAliasesFilePathConfigurationNameIs;
var ccommandIs = wr1.ccommand + sys.cSpaceIsColonSpace; // command is:

exports.ccommandIs = ccommandIs;
var ccommandToExecuteIs = wr1.ccommand + bas.cTo + wr1.cExecute + sys.cSpaceIsColonSpace; // commandToExecute is:

exports.ccommandToExecuteIs = ccommandToExecuteIs;
var ccommandArgsIs = wr1.ccommand + gen.cArgs + sys.cSpaceIsColonSpace; // commandArgs is:

exports.ccommandArgsIs = ccommandArgsIs;
var celseClauseLookingForCommandAliases = wr1.celse + bas.cDash + wr1.cclause + bas.cSpace + wr1.clooking + bas.cSpace + wr1.cfor + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.caliases + bas.cDot; // else-clause looking for command aliases.

exports.celseClauseLookingForCommandAliases = celseClauseLookingForCommandAliases;
var callCommandAliasesIs = wr1.call + wr1.cCommand + wr1.cAliases + sys.cSpaceIsColonSpace; // allCommandAliases is:

exports.callCommandAliasesIs = callCommandAliasesIs;
var ccontextNameIs = wr1.ccontext + wr1.cName + sys.cSpaceIsColonSpace; // contextName is:

exports.ccontextNameIs = ccontextNameIs;
var callXmlDataIs = wr1.call + gen.cXml + wr1.cData + sys.cSpaceIsColonSpace; // allXmlData is:

exports.callXmlDataIs = callXmlDataIs;
var cdataPathConfigurationNameIs = wr1.cdata + wr1.cPath + wr1.cConfiguration + wr1.cName + sys.cSpaceIsColonSpace; // dataPathConfigurationName is:

exports.cdataPathConfigurationNameIs = cdataPathConfigurationNameIs;
var cdataPathIs = wr1.cdata + wr1.cPath + sys.cSpaceIsColonSpace; // dataPath is:

exports.cdataPathIs = cdataPathIs;
var cfilesFoundIs = wr1.cfiles + wr1.cFound + sys.cSpaceIsColonSpace; // filesFound is:

exports.cfilesFoundIs = cfilesFoundIs;
var cfileToLoadIs = wr1.cfile + wr1.cTo + wr1.cLoad + sys.cSpaceIsColonSpace; // fileToLoad is:

exports.cfileToLoadIs = cfileToLoadIs;
var cfilesToLoadIs = wr1.cfiles + wr1.cTo + wr1.cLoad + sys.cSpaceIsColonSpace; // filesToLoad is:

exports.cfilesToLoadIs = cfilesToLoadIs;
var cdataFileToMergeIs = wr1.cdata + wr1.cFile + bas.cSpace + bas.cto + bas.cSpace + wr1.cmerge + sys.cSpaceIsColonSpace; // dataFile to merge is:

exports.cdataFileToMergeIs = cdataFileToMergeIs;
var cparsedDataFileIs = wr1.cparsed + wr1.cData + wr1.cFile + sys.cSpaceIsColonSpace; // parsedDataFile is:

exports.cparsedDataFileIs = cparsedDataFileIs;
var cexecuteBusinessRules = wr1.cexecute + bas.cSpace + wr1.cbusiness + bas.cSpace + wr1.crules + bas.cColon + bas.cSpace; // execute business rules:

exports.cexecuteBusinessRules = cexecuteBusinessRules;
var cdataFileIs = wr1.cdata + wr1.cFile + sys.cSpaceIsColonSpace; // dataFile is:

exports.cdataFileIs = cdataFileIs;
var cmergedDataIs = wr1.cmerged + wr1.cData + sys.cSpaceIsColonSpace; // mergedData is:

exports.cmergedDataIs = cmergedDataIs;
var cdebugConfigurationSettingValueIs = wr1.cdebug + wr1.cConfiguration + wr1.cSetting + wr1.cValue + sys.cSpaceIsColonSpace; // debugConfigurationSettingValue is:

exports.cdebugConfigurationSettingValueIs = cdebugConfigurationSettingValueIs;
var cclientRootPathIs = wr1.cclient + wr1.cRoot + wr1.cPath + sys.cSpaceIsColonSpace; // clientRootPath is:

exports.cclientRootPathIs = cclientRootPathIs;
var cappConfigResourcesPathIs = phn.capp + wr1.cConfig + wr1.cResources + wr1.cPath + sys.cSpaceIsColonSpace; // appConfigResourcesPath is:

exports.cappConfigResourcesPathIs = cappConfigResourcesPathIs;
var cappConfigReferencePathIs = phn.capp + wr1.cConfig + wr1.cReference + wr1.cPath + sys.cSpaceIsColonSpace; // appConfigReferencePath is:

exports.cappConfigReferencePathIs = cappConfigReferencePathIs;
var cclientMetaDataPathIs = wr1.cclient + wr1.cMetaData + wr1.cPath + sys.cSpaceIsColonSpace; // clientMetaDataPath is:

exports.cclientMetaDataPathIs = cclientMetaDataPathIs;
var cclientCommandAliasesPathIs = wr1.cclient + wr1.cCommand + wr1.cAliases + wr1.cPath + sys.cSpaceIsColonSpace; // clientCommandAliasesPath is:

exports.cclientCommandAliasesPathIs = cclientCommandAliasesPathIs;
var cclientWorkflowsPathIs = wr1.cclient + wr1.cWorkflows + wr1.cPath + sys.cSpaceIsColonSpace; // clientWorkflowsPath is:

exports.cclientWorkflowsPathIs = cclientWorkflowsPathIs;
var cframeworkRootPathIs = wr1.cframework + wr1.cRoot + wr1.cPath + sys.cSpaceIsColonSpace; // frameworkRootPath is:

exports.cframeworkRootPathIs = cframeworkRootPathIs;
var cappConfigPathIs = phn.capp + wr1.cConfig + wr1.cPath + sys.cSpaceIsColonSpace; // appConfigPath is:

exports.cappConfigPathIs = cappConfigPathIs;
var cframeworkResourcesPathIs = wr1.cframework + wr1.cResources + wr1.cPath + sys.cSpaceIsColonSpace; // frameworkResourcesPath is:

exports.cframeworkResourcesPathIs = cframeworkResourcesPathIs;
var cframeworkFullMetaDataPathIs = wr1.cframework + wr1.cFull + wr1.cMetaData + wr1.cPath + sys.cSpaceIsColonSpace; // frameworkFullMetaDataPath is:

exports.cframeworkFullMetaDataPathIs = cframeworkFullMetaDataPathIs;
var cframeworkConfigPathIs = wr1.cframework + wr1.cConfig + wr1.cPath + sys.cSpaceIsColonSpace; // frameworkConfigPath is:

exports.cframeworkConfigPathIs = cframeworkConfigPathIs;
var cframeworkCommandAliasesPathIs = wr1.cframework + wr1.cCommand + wr1.cAliases + wr1.cPath + sys.cSpaceIsColonSpace; // frameworkCommandAliasesPath is:

exports.cframeworkCommandAliasesPathIs = cframeworkCommandAliasesPathIs;
var cframeworkWorkflowsPathIs = wr1.cframework + wr1.cWorkflows + wr1.cPath + sys.cSpaceIsColonSpace; // frameworkWorkflowsPath is:

exports.cframeworkWorkflowsPathIs = cframeworkWorkflowsPathIs;
var ccommandAliasesPathIs = wr1.ccommand + wr1.cAliases + wr1.cPath + sys.cSpaceIsColonSpace; // commandAliasesPath is:

exports.ccommandAliasesPathIs = ccommandAliasesPathIs;
var cworkflowPathIs = wr1.cworkflow + wr1.cPath + sys.cSpaceIsColonSpace; // workflowPath is:

exports.cworkflowPathIs = cworkflowPathIs;
var cALL_DATA_IS = wr1.cALL + bas.cSpace + wr1.cDATA + bas.cSpace + wr1.cIS + bas.cColon + bas.cSpace; // ALL DATA is:

exports.cALL_DATA_IS = cALL_DATA_IS;
var cAllLoadedDataIs = wr1.cAll + bas.cSpace + wr1.cloaded + bas.cSpace + wr1.cdata + sys.cSpaceIsColonSpace; // All loaded data is:

exports.cAllLoadedDataIs = cAllLoadedDataIs;
var cconfigDataIs = wr1.cconfig + wr1.cData + sys.cSpaceIsColonSpace; // configData is:

exports.cconfigDataIs = cconfigDataIs;
var cERROR = wr1.cERROR + bas.cColon + bas.cSpace; // ERROR:
// ERROR: Invalid access to:

exports.cERROR = cERROR;
var cErrorInvalidAccessTo = wr1.cERROR + bas.cColon + bas.cSpace + wr1.cInvalid + bas.cSpace + wr1.caccess + bas.cSpace + wr1.cto + bas.cColon + bas.cSpace;
exports.cErrorInvalidAccessTo = cErrorInvalidAccessTo;
var crootPathIs = wr1.croot + wr1.cPath + sys.cSpaceIsColonSpace; // rootPath is:

exports.crootPathIs = crootPathIs;
var caskIs = wr1.cask + sys.cSpaceIsColonSpace; // ask is:

exports.caskIs = caskIs;
var cINPUT = wr1.cINPUT + bas.cColon + bas.cSpace; // INPUT:

exports.cINPUT = cINPUT;
var cinputIs = wr1.cinput + sys.cSpaceIsColonSpace; // input is:

exports.cinputIs = cinputIs;
var cstartTimeIs = wr1.cstart + wr1.cTime + sys.cSpaceIsColonSpace; // startTime is:

exports.cstartTimeIs = cstartTimeIs;
var cendTimeIs = wr1.cend + wr1.cTime + sys.cSpaceIsColonSpace; // endTime is:

exports.cendTimeIs = cendTimeIs;
var cdeltaTimeResultIs = wr1.cdelta + wr1.cTime + wr1.cResult + sys.cSpaceIsColonSpace; // deltaTimeResult is:

exports.cdeltaTimeResultIs = cdeltaTimeResultIs;
var cclientConfigurationIs = wr1.cclient + wr1.cConfiguration + sys.cSpaceIsColonSpace; // clientConfiguration is:
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

exports.cclientConfigurationIs = cclientConfigurationIs;
var cloadedAndMergedDataAllFilesIs = wr1.cloaded + wr1.cAnd + wr1.cMerged + wr1.cData + wr1.cAll + wr1.cFiles + sys.cSpaceIsColonSpace; // loadedAndMergedDataAllFiles is:

exports.cloadedAndMergedDataAllFilesIs = cloadedAndMergedDataAllFilesIs;
var cloadedAndMergedDataAllFilesContentsAre = wr1.cloaded + wr1.cAnd + wr1.cMerged + wr1.cData + wr1.cAll + wr1.cFiles + bas.cSpace + wr1.ccontents + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // loadedAndMergedDataAllFiles contents are:

exports.cloadedAndMergedDataAllFilesContentsAre = cloadedAndMergedDataAllFilesContentsAre;
var ccommandWorkflowFilePathConfigurationNameIs = wr1.ccommand + wr1.cWorkflow + wr1.cFile + wr1.cPath + wr1.cConfiguration + wr1.cName + sys.cSpaceIsColonSpace; // commandWorkflowFilePathConfigurationName is:

exports.ccommandWorkflowFilePathConfigurationNameIs = ccommandWorkflowFilePathConfigurationNameIs;
var ccontentsOfDataStructreIs = wr1.ccontents + bas.cSpace + bas.cof + bas.cSpace + bas.cD + bas.cDash + wr1.cdata + bas.cSpace + wr1.cstructure + sys.cSpaceIsColonSpace; // contents of D-data structure is:

exports.ccontentsOfDataStructreIs = ccontentsOfDataStructreIs;
var cclientBusinessRulesAre = wr1.cclient + wr1.cBusiness + wr1.cRules + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // clientBusinessRules are:

exports.cclientBusinessRulesAre = cclientBusinessRulesAre;
var cclientCommandsAre = wr1.cclient + wr1.cCommands + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // clientCommands are:

exports.cclientCommandsAre = cclientCommandsAre;
var ccommandAliasesPathConfigNameIs = wr1.ccommand + wr1.cAliases + wr1.cPath + wr1.cConfig + wr1.cName + sys.cSpaceIsColonSpace; // commandAliasesPathConfigName is:

exports.ccommandAliasesPathConfigNameIs = ccommandAliasesPathConfigNameIs;
var cresolvedSystemCommandsAliasesPathIs = wr1.cresolved + wr1.cSystem + wr1.cCommands + wr1.cAliases + wr1.cPath + sys.cSpaceIsColonSpace; // resolvedSystemCommandsAliasesPath is:

exports.cresolvedSystemCommandsAliasesPathIs = cresolvedSystemCommandsAliasesPathIs;
var cresolvedClientCommandsAliasesPathIs = wr1.cresolved + wr1.cClient + wr1.cCommands + wr1.cAliases + wr1.cPath + sys.cSpaceIsColonSpace; // resolvedClientCommandsAliasesPath is:

exports.cresolvedClientCommandsAliasesPathIs = cresolvedClientCommandsAliasesPathIs;
var cresolvedCustomCommandsAliasesPathIs = wr1.cresolved + wr1.cCustom + wr1.cCommands + wr1.cAliases + wr1.cPath + sys.cSpaceIsColonSpace; // resolvedCustomCommandsAliasesPath is:

exports.cresolvedCustomCommandsAliasesPathIs = cresolvedCustomCommandsAliasesPathIs;
var cworkflowPathConfigurationNameIs = wr1.cworkflow + wr1.cPath + wr1.cConfiguration + wr1.cName + sys.cSpaceIsColonSpace; // workflowPathConfigurationName is:

exports.cworkflowPathConfigurationNameIs = cworkflowPathConfigurationNameIs;
var cresolvedSystemWorkflowsPathIs = wr1.cresolved + wr1.cSystem + wr1.cWorkflows + wr1.cPath + sys.cSpaceIsColonSpace; // resolvedSystemWorkflowsPath is:

exports.cresolvedSystemWorkflowsPathIs = cresolvedSystemWorkflowsPathIs;
var cresolvedClientWorkflowsPathIs = wr1.cresolved + wr1.cClient + wr1.cWorkflows + wr1.cPath + sys.cSpaceIsColonSpace; // resolvedClientWorkflowsPath is:

exports.cresolvedClientWorkflowsPathIs = cresolvedClientWorkflowsPathIs;
var cresolvedCustomWorkflowsPathIs = wr1.cresolved + wr1.cCustom + wr1.cWorkflows + wr1.cPath + sys.cSpaceIsColonSpace; // resolvedCustomWorkflowsPath is:

exports.cresolvedCustomWorkflowsPathIs = cresolvedCustomWorkflowsPathIs;
var cbusinessRuleIs = wr1.cbusiness + wr1.cRule + sys.cSpaceIsColonSpace; // businessRule is:

exports.cbusinessRuleIs = cbusinessRuleIs;
var cruleInputIs = wr1.crule + wr1.cInput + sys.cSpaceIsColonSpace; // ruleInput is:

exports.cruleInputIs = cruleInputIs;
var cruleMetaDataIs = wr1.crule + wr1.cMetaData + sys.cSpaceIsColonSpace; // ruleMetaData is:

exports.cruleMetaDataIs = cruleMetaDataIs;
var cconfigurationNamespaceIs = wr1.cconfiguration + wr1.cName + wr1.cspace + sys.cSpaceIsColonSpace; // configurationNamespace is:

exports.cconfigurationNamespaceIs = cconfigurationNamespaceIs;
var cconfigurationNameIs = wr1.cconfiguration + wr1.cName + sys.cSpaceIsColonSpace; // configurationName is:

exports.cconfigurationNameIs = cconfigurationNameIs;
var cconfigurationValueIs = wr1.cconfiguration + wr1.cValue + sys.cSpaceIsColonSpace; // configurationValue is:

exports.cconfigurationValueIs = cconfigurationValueIs;
var creturnConfiguraitonValueIs = wr1.creturn + wr1.cConfiguration + wr1.cValue + sys.cSpaceIsColonSpace; // returnConfigurationValue is:

exports.creturnConfiguraitonValueIs = creturnConfiguraitonValueIs;
var cattributeJsonStringIs = wr1.cattribute + gen.cJson + wr1.cString + sys.cSpaceIsColonSpace; // attributeJsonString is:

exports.cattributeJsonStringIs = cattributeJsonStringIs;
var cappAttributeNameIs = gen.capp + wr1.cAttribute + wr1.cName + sys.cSpaceIsColonSpace; // appAttributeName is:

exports.cappAttributeNameIs = cappAttributeNameIs;
var cappAttributeValueIs = gen.capp + wr1.cAttribute + wr1.cValue + sys.cSpaceIsColonSpace; // appAttributeValue is:

exports.cappAttributeValueIs = cappAttributeValueIs;
var cexecuteBusinessRulesColon = wr1.cexecute + bas.cSpace + wr1.cbusiness + bas.cSpace + wr1.crules + bas.cColon + bas.cSpace; // execute business rules:

exports.cexecuteBusinessRulesColon = cexecuteBusinessRulesColon;
var cdataPathAfterBusinessRulesProcessingIs = wr1.cdata + wr1.cPath + bas.cSpace + wr1.cafter + bas.cSpace + wr1.cbusiness + bas.cSpace + wr1.crules + bas.cSpace + wr1.cprocessing + sys.cSpaceIsColonSpace; // dataPath after business rules processing is:

exports.cdataPathAfterBusinessRulesProcessingIs = cdataPathAfterBusinessRulesProcessingIs;
var cFileToLoadIs = wr1.cFile + bas.cSpace + bas.cto + bas.cSpace + wr1.cload + sys.cSpaceIsColonSpace; // File to load is:

exports.cFileToLoadIs = cFileToLoadIs;
var cfileExtensionIs = wr1.cfile + wr1.cExtension + sys.cSpaceIsColonSpace; // fileExtension is:

exports.cfileExtensionIs = cfileExtensionIs;
var cexecuteBusienssRulesColon = wr1.cexecute + wr1.cBusiness + wr1.cRules + bas.cColon + bas.cSpace; // executeBusinessRules:

exports.cexecuteBusienssRulesColon = cexecuteBusienssRulesColon;
var cloadedFileDataIs = wr1.cloaded + bas.cSpace + wr1.cfile + bas.cSpace + wr1.cdata + sys.cSpaceIsColonSpace; // loaded file data is:

exports.cloadedFileDataIs = cloadedFileDataIs;
var cBEGIN_PROCESSING_ADDITIONAL_DATA = wr1.cBEGIN + bas.cSpace + wr1.cPROCESSING + bas.cSpace + wr1.cADDITIONAL + bas.cSpace + wr1.cDATA; // BEGIN PROCESSING ADDITIONAL DATA

exports.cBEGIN_PROCESSING_ADDITIONAL_DATA = cBEGIN_PROCESSING_ADDITIONAL_DATA;
var cDONE_PROCESSING_ADDITIONAL_DATA = wr1.cDONE + bas.cSpace + wr1.cPROCESSING + bas.cSpace + wr1.cADDITIONAL + bas.cSpace + wr1.cDATA; // DONE PROCESSING ADDITIONAL DATA

exports.cDONE_PROCESSING_ADDITIONAL_DATA = cDONE_PROCESSING_ADDITIONAL_DATA;
var cMERGED_dataIs = wr1.cMERGED + bas.cSpace + wr1.cdata + sys.cSpaceIsColonSpace; // MERGED data is:

exports.cMERGED_dataIs = cMERGED_dataIs;
var cparsedDataFileContentsAre = wr1.cparsed + wr1.cData + wr1.cFile + bas.cSpace + wr1.ccontents + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // parsedDataFile contents are:

exports.cparsedDataFileContentsAre = cparsedDataFileContentsAre;
var cdataCatagoryIs = wr1.cdata + wr1.cCatagory + sys.cSpaceIsColonSpace; // dataCatagory is:

exports.cdataCatagoryIs = cdataCatagoryIs;
var cfullyParsedDataIs = wr1.cfully + bas.cSpace + wr1.cparsed + bas.cSpace + wr1.cdata + sys.cSpaceIsColonSpace; // fully parsed data is:

exports.cfullyParsedDataIs = cfullyParsedDataIs;
var cD_finalMergeIs = bas.cD + bas.cSpace + wr1.cfinal + bas.cSpace + wr1.cmerge + sys.cSpaceIsColonSpace; // D final merge is:

exports.cD_finalMergeIs = cD_finalMergeIs;
var cdataStorageContextNameIs = wr1.cdata + wr1.cStorage + wr1.cContext + wr1.cName + sys.cSpaceIsColonSpace; // dataStorageContextName is:

exports.cdataStorageContextNameIs = cdataStorageContextNameIs;
var cdataToStoreIs = wr1.cdata + bas.cTo + wr1.cStore + sys.cSpaceIsColonSpace; // dataToStore is:

exports.cdataToStoreIs = cdataToStoreIs;
var cdataCatagoryDetailsNameIs = wr1.cdata + wr1.cCatagory + wr1.cDetails + wr1.cName + sys.cSpaceIsColonSpace; // dataCatagoryDetailsName is:

exports.cdataCatagoryDetailsNameIs = cdataCatagoryDetailsNameIs;
var ctempDataIs = wr1.ctemp + wr1.cData + sys.cSpaceIsColonSpace; // tempData is:

exports.ctempDataIs = ctempDataIs;
var ctargetDataIs = wr1.ctarget + wr1.cData + sys.cSpaceIsColonSpace; // targetData is:

exports.ctargetDataIs = ctargetDataIs;
var cpageNameIs = wr1.cpage + wr1.cName + sys.cSpaceIsColonSpace; // pageName is:

exports.cpageNameIs = cpageNameIs;
var cdataToMergeIs = wr1.cdata + bas.cSpace + bas.cto + bas.cSpace + wr1.cMerge + sys.cSpaceIsColonSpace; // data to Merge is:

exports.cdataToMergeIs = cdataToMergeIs;
var cdataToMergeElementCountIs = wr1.cdata + bas.cTo + wr1.cMerge + wr1.cElement + wr1.cCount + sys.cSpaceIsColonSpace; // dataToMergeElementCount is:

exports.cdataToMergeElementCountIs = cdataToMergeElementCountIs;
var cdataToMergeElementCountIs1 = wr1.cdata + bas.cTo + wr1.cMerge + wr1.cElement + wr1.cCount + sys.cSpaceIsColonSpace + num.c1; // dataToMergeElementCount is 1

exports.cdataToMergeElementCountIs1 = cdataToMergeElementCountIs1;
var ccheckIfThePageNameIsNotAnEmptyString = wr1.ccheck + bas.cSpace + bas.cif + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cpage + wr1.cName + bas.cSpace + bas.cis + bas.cSpace + gen.cnot + bas.cSpace + bas.can + bas.cSpace + wr1.cempty + bas.cSpace + wr1.cstring; // check if the pageName is not an empty string

exports.ccheckIfThePageNameIsNotAnEmptyString = ccheckIfThePageNameIsNotAnEmptyString;
var cpageNameIsNotAnEmptyString = wr1.cpage + wr1.cName + bas.cSpace + bas.cis + bas.cSpace + gen.cnot + bas.cSpace + bas.can + bas.cSpace + wr1.cempty + bas.cSpace + wr1.cstring; // pageName is not an empty string

exports.cpageNameIsNotAnEmptyString = cpageNameIsNotAnEmptyString;
var cCheckIfTheDataCatagoryIsAnEmptyStringOrNot = wr1.cCheck + bas.cSpace + bas.cif + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cdata + wr1.cCatagory + bas.cSpace + bas.cis + bas.cSpace + bas.can + bas.cSpace + wr1.cempty + bas.cSpace + wr1.cstring + bas.cSpace + bas.cor + bas.cSpace + gen.cnot; // Check if the dataCatagory is an empty string or not

exports.cCheckIfTheDataCatagoryIsAnEmptyStringOrNot = cCheckIfTheDataCatagoryIsAnEmptyStringOrNot;
var cdataCatagoryIsNotAnEmptyString = wr1.cdata + wr1.cCatagory + bas.cSpace + bas.cis + bas.cSpace + gen.cnot + bas.cSpace + bas.can + bas.cSpace + wr1.cempty + bas.cSpace + wr1.cstring + bas.cExclamation; // dataCatagory is not an empty string!

exports.cdataCatagoryIsNotAnEmptyString = cdataCatagoryIsNotAnEmptyString;
var cdataCatagoryIsAnEmptyString = wr1.cdata + wr1.cCatagory + bas.cSpace + bas.cIS + bas.cSpace + bas.can + bas.cSpace + wr1.cempty + bas.cSpace + wr1.cstring + bas.cExclamation; // dataCatagory IS an empty string!

exports.cdataCatagoryIsAnEmptyString = cdataCatagoryIsAnEmptyString;
var ctargetDataContentIs = wr1.ctarget + wr1.cData + bas.cSpace + wr1.ccontent + sys.cSpaceIsColonSpace; // targetData content is:

exports.ctargetDataContentIs = ctargetDataContentIs;
var cafterAttemptToMergeResultsAre = wr1.cafter + bas.cSpace + wr1.cattempt + bas.cSpace + bas.cto + bas.cSpace + wr1.cmerge + bas.cComa + bas.cSpace + wr1.cresults + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // after attempt to merge, results are:

exports.cafterAttemptToMergeResultsAre = cafterAttemptToMergeResultsAre;
var cMergedDataIs = wr1.cMerged + bas.cSpace + wr1.cdata + sys.cSpaceIsColonSpace; // Merged data is:

exports.cMergedDataIs = cMergedDataIs;
var cpageNameIsAnEmptyString = wr1.cpage + wr1.cName + bas.cSpace + bas.cis + bas.cSpace + bas.can + bas.cSpace + wr1.cempty + bas.cSpace + wr1.cstring; // pageName is an empty string

exports.cpageNameIsAnEmptyString = cpageNameIsAnEmptyString;
var cCaughtTheSpecialCaseThatWeAreMergingFlatList = wr1.cCaught + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cspecial + bas.cSpace + wr1.ccase + bas.cSpace + wr1.cthat + bas.cSpace + bas.cwe + bas.cSpace + wr1.care + bas.cSpace + wr1.cmerging + bas.cSpace + bas.ca + bas.cSpace + wr1.cflat + bas.cSpace + wr1.clist + bas.cDot; // Caught the special case that we are merging a flat list.

exports.cCaughtTheSpecialCaseThatWeAreMergingFlatList = cCaughtTheSpecialCaseThatWeAreMergingFlatList;
var cinsideTheForLoop = wr1.cinside + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cfor + bas.cDash + wr1.cloop; // inside the for-loop

exports.cinsideTheForLoop = cinsideTheForLoop;
var ckeyIs = wr1.ckey + sys.cSpaceIsColonSpace; // key is:

exports.ckeyIs = ckeyIs;
var ctargetDataIsModifiedInTheInputPassByReferenceVariableContentIs = wr1.ctarget + wr1.cData + bas.cSpace + bas.cis + bas.cSpace + wr1.cmodified + bas.cSpace + bas.cin + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cinput + bas.cSpace + wr1.cpass + bas.cDash + bas.cby + bas.cDash + wr1.creference + bas.cSpace + wr1.cvariable + bas.cSpace + wr1.ccontent + sys.cSpaceIsColonSpace; // targetData is modified in the input pass-by-reference variable content is:

exports.ctargetDataIsModifiedInTheInputPassByReferenceVariableContentIs = ctargetDataIsModifiedInTheInputPassByReferenceVariableContentIs;
var cdataObjectValueIs = wr1.cdata + wr1.cObject + bas.cSpace + wr1.cvalue + sys.cSpaceIsColonSpace; // dataObject value is:

exports.cdataObjectValueIs = cdataObjectValueIs;
var celementNameIs = wr1.celement + wr1.cName + sys.cSpaceIsColonSpace; // elementName is:

exports.celementNameIs = celementNameIs;
var cdataObjectIs = wr1.cdata + wr1.cObject + sys.cSpaceIsColonSpace; // dataObject is:

exports.cdataObjectIs = cdataObjectIs;
var celementNamePatternIs = wr1.celement + wr1.cName + wr1.cPattern + sys.cSpaceIsColonSpace; // elementNamePattern is:

exports.celementNamePatternIs = celementNamePatternIs;
var celementCountIs = wr1.celement + wr1.cCount + sys.cSpaceIsColonSpace; // elementCount is:

exports.celementCountIs = celementCountIs;
var cERROR_Colon = wr1.cERROR + bas.cColon + bas.cSpace; // ERROR:

exports.cERROR_Colon = cERROR_Colon;
var cfileAndPathToLoadFromIs = wr1.cfile + bas.cSpace + wr1.cand + bas.cSpace + wr1.cpath + bas.cSpace + bas.cto + bas.cSpace + wr1.cload + bas.cSpace + wr1.cfrom + sys.cSpaceIsColonSpace; // file and path to load from is:

exports.cfileAndPathToLoadFromIs = cfileAndPathToLoadFromIs;
var cDoneLoadingDataFrom = wr1.cDONE + bas.cSpace + wr1.cloading + bas.cSpace + wr1.cdata + bas.cSpace + wr1.cfrom + bas.cColon + bas.cSpace; // DONE loading data from:

exports.cDoneLoadingDataFrom = cDoneLoadingDataFrom;
var cfileAndPathToWriteDataToIs = wr1.cfile + bas.cSpace + wr1.cand + bas.cSpace + wr1.cpath + bas.cSpace + bas.cto + bas.cSpace + wr1.cwrite + bas.cSpace + wr1.cdata + bas.cSpace + bas.cto + bas.cSpace + bas.cis + bas.cColon + bas.cSpace; // file and path to write data to is:

exports.cfileAndPathToWriteDataToIs = cfileAndPathToWriteDataToIs;
var cdataToWriteIs = wr1.cdata + bas.cSpace + bas.cto + bas.cSpace + wr1.cwrite + sys.cSpaceIsColonSpace; // data to write is:

exports.cdataToWriteIs = cdataToWriteIs;
var cDataWasWrittenToTheFile = wr1.cData + bas.cSpace + wr1.cwas + bas.cSpace + wr1.cwritten + bas.cSpace + bas.cto + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cfile + bas.cColon + bas.cSpace; // Data was written to the file:

exports.cDataWasWrittenToTheFile = cDataWasWrittenToTheFile;
var cPathThatShouldBeScannedIs = wr1.cPath + bas.cSpace + wr1.cthat + bas.cSpace + wr1.cshould + bas.cSpace + bas.cbe + bas.cSpace + wr1.cscanned + sys.cSpaceIsColonSpace; // Path that should be scanned is:

exports.cPathThatShouldBeScannedIs = cPathThatShouldBeScannedIs;
var cfilesFoundAre = wr1.cfiles + bas.cSpace + wr1.cfound + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // files found are:

exports.cfilesFoundAre = cfilesFoundAre;
var cdirectorIs = wr1.cdirectory + sys.cSpaceIsColonSpace; // directory is:

exports.cdirectorIs = cdirectorIs;
var cdirectoryPathIs = wr1.cdirectory + wr1.cPath + sys.cSpaceIsColonSpace; // directoryPath is:

exports.cdirectoryPathIs = cdirectoryPathIs;
var csourceFolderIs = wr1.csource + wr1.cFolder + sys.cSpaceIsColonSpace; // sourceFolder is:

exports.csourceFolderIs = csourceFolderIs;
var cdestinationFolderIs = wr1.cdestination + wr1.cFolder + sys.cSpaceIsColonSpace; // destinationFolder is:

exports.cdestinationFolderIs = cdestinationFolderIs;
var ccopySuccessIs = wr1.ccopy + wr1.cSuccess + sys.cSpaceIsColonSpace; // copySuccess is:

exports.ccopySuccessIs = ccopySuccessIs;
var ccurrentVersionIs = wr1.ccurrent + bas.cSpace + wr1.cversion + sys.cSpaceIsColonSpace; // current version is:

exports.ccurrentVersionIs = ccurrentVersionIs;
var creleasedArchiveFilesListIs = wr1.creleased + bas.cSpace + wr1.carchive + bas.cSpace + wr1.cfiles + bas.cSpace + wr1.clist + sys.cSpaceIsColonSpace; // released archive files list is:

exports.creleasedArchiveFilesListIs = creleasedArchiveFilesListIs;
var cfileIs = wr1.cfile + sys.cSpaceIsColonSpace; // file is:

exports.cfileIs = cfileIs;
var cfileNameIs = wr1.cfile + wr1.cName + sys.cSpaceIsColonSpace; // fileName is:

exports.cfileNameIs = cfileNameIs;
var creleaseFilesListIs = wr1.crelease + bas.cSpace + wr1.cfiles + bas.cSpace + wr1.clist + sys.cSpaceIsColonSpace; // release files list is:

exports.creleaseFilesListIs = creleaseFilesListIs;
var creleaseDateTimeStampIs = wr1.crelease + bas.cSpace + wr1.cdate + bas.cDash + wr1.ctime + bas.cSpace + wr1.cstamp + sys.cSpaceIsColonSpace; // release date-time stamp is:

exports.creleaseDateTimeStampIs = creleaseDateTimeStampIs;
var creleaseFileNameIs = wr1.crelease + bas.cSpace + wr1.cfile + wr1.cName + sys.cSpaceIsColonSpace; // release fileName is:

exports.creleaseFileNameIs = creleaseFileNameIs;
var cDoneWritingTheZipFile = wr1.cDone + bas.cSpace + wr1.cwriting + bas.cSpace + wr1.cthe + bas.cSpace + gen.czip + bas.cSpace + wr1.cfile + bas.cColon + bas.cSpace; // Done writing the zip file:

exports.cDoneWritingTheZipFile = cDoneWritingTheZipFile;
var cSetTheReturnPackageSuccessFlagToTrue = wr1.cSet + bas.cSpace + wr1.cthe + bas.cSpace + wr1.creturn + bas.cSpace + wr1.cpackage + wr1.cSuccess + bas.cSpace + wr1.cflag + bas.cSpace + bas.cto + bas.cSpace + gen.cTRUE; // Set the return packageSuccess flag to TRUE

exports.cSetTheReturnPackageSuccessFlagToTrue = cSetTheReturnPackageSuccessFlagToTrue;
var ccurrentVersionAlreadyReleased = wr1.ccurrent + bas.cSpace + wr1.cversion + bas.cSpace + wr1.calready + bas.cSpace + wr1.creleased; // current version already released

exports.ccurrentVersionAlreadyReleased = ccurrentVersionAlreadyReleased;
var cpackageSuccessIs = wr1.cpackage + wr1.cSuccess + sys.cSpaceIsColonSpace; // packageSuccess is:

exports.cpackageSuccessIs = cpackageSuccessIs;
var cRootPathBeforeProcessingIs = wr1.cRoot + wr1.cPath + bas.cSpace + wr1.cbefore + bas.cSpace + wr1.cprocessing + sys.cSpaceIsColonSpace; // RootPath before processing is:

exports.cRootPathBeforeProcessingIs = cRootPathBeforeProcessingIs;
var cRootPathAfterProcessingIs = wr1.cRoot + wr1.cPath + bas.cSpace + wr1.cafter + bas.cSpace + wr1.cprocessing + sys.cSpaceIsColonSpace; // RootPath after processing is:

exports.cRootPathAfterProcessingIs = cRootPathAfterProcessingIs;
var cSourceIs = wr1.csource + sys.cSpaceIsColonSpace; // source is:

exports.cSourceIs = cSourceIs;
var ctargetIs = wr1.ctarget + sys.cSpaceIsColonSpace; // target is:

exports.ctargetIs = ctargetIs;
var cErrorCouldNotCopyFile = wr1.cERROR + bas.cColon + bas.cSpace + wr1.cCould + bas.cSpace + gen.cnot + bas.cSpace + wr1.ccopy + bas.cSpace + wr1.cfile + bas.cColon + bas.cSpace; // ERROR: Could not copy file:

exports.cErrorCouldNotCopyFile = cErrorCouldNotCopyFile;
var cErrorCouldNotCreateFolder = wr1.cERROR + bas.cColon + bas.cSpace + wr1.cCould + bas.cSpace + gen.cnot + bas.cSpace + wr1.ccreate + bas.cSpace + wr1.cfolder + bas.cColon + bas.cSpace; // ERROR: Could not create folder:

exports.cErrorCouldNotCreateFolder = cErrorCouldNotCreateFolder;
var csuccessfulCopyIs = wr1.csuccessful + wr1.cCopy + sys.cSpaceIsColonSpace; // successfulCopy is:

exports.csuccessfulCopyIs = csuccessfulCopyIs;
var cErrorCouldNotCopyFolderContents = wr1.cERROR + bas.cColon + bas.cSpace + wr1.cCould + bas.cSpace + gen.cnot + bas.cSpace + wr1.ccopy + bas.cSpace + wr1.cfolder + bas.cSpace + wr1.ccontents + bas.cColon + bas.cSpace; // ERROR: Could not copy folder contents:

exports.cErrorCouldNotCopyFolderContents = cErrorCouldNotCopyFolderContents;
var cargumentValueIs = wr1.cargument + wr1.cValue + sys.cSpaceIsColonSpace; // argumentValue is:

exports.cargumentValueIs = cargumentValueIs;
var cconsolidatedArgumentModeIs = wr1.cconsolidated + wr1.cArgument + wr1.cMode + sys.cSpaceIsColonSpace; // consolidatedArgumentMode is:

exports.cconsolidatedArgumentModeIs = cconsolidatedArgumentModeIs;
var cPushingArgumentValueToReturnDataAsArrayElement = wr1.cPushing + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cargument + wr1.cValue + bas.cSpace + bas.cto + bas.cSpace + wr1.cthe + bas.cSpace + wr1.creturn + wr1.cData + bas.cSpace + bas.cas + bas.cSpace + bas.can + bas.cSpace + wr1.carray + bas.cSpace + wr1.celement; // Pushing the argumentValue to the returnData as an array element

exports.cPushingArgumentValueToReturnDataAsArrayElement = cPushingArgumentValueToReturnDataAsArrayElement;
var cargumentValueLengthGreaterThanZero = wr1.cargument + wr1.cValue + bas.cDot + wr1.clength + bas.cSpace + bas.cGreaterThan + bas.cSpace + num.c0; // argumentValue.length > 0

exports.cargumentValueLengthGreaterThanZero = cargumentValueLengthGreaterThanZero;
var cCallingAnalyzeArgumentIndexIs = wr1.cCalling + bas.cSpace + wr1.canalyze + wr1.cArgument + wr1.cIndex + sys.cSpaceIsColonSpace; // Calling analyzeArgumentIndex is:

exports.cCallingAnalyzeArgumentIndexIs = cCallingAnalyzeArgumentIndexIs;
var cReturnArgumentValueSameAsItWasPassedIn = wr1.cReturn + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cargument + wr1.cValue + bas.cSpace + wr1.cthe + bas.cSpace + wr1.csame + bas.cSpace + bas.cas + bas.cSpace + bas.cit + bas.cSpace + wr1.cwas + bas.cSpace + wr1.cpassed + bas.cSpace + bas.cin + bas.cDot; // Return the argumentValue the same as it was passed in.

exports.cReturnArgumentValueSameAsItWasPassedIn = cReturnArgumentValueSameAsItWasPassedIn;
var cCheckIfThereAreBracketsOrNoBrackets = wr1.cCheck + bas.cSpace + bas.cif + bas.cSpace + wr1.cthere + bas.cSpace + wr1.care + bas.cSpace + wr1.cbrackets + bas.cSpace + bas.cor + bas.cSpace + bas.cno + bas.cSpace + wr1.cbrackets + bas.cDot; // Check if there are brackets or no brackets.

exports.cCheckIfThereAreBracketsOrNoBrackets = cCheckIfThereAreBracketsOrNoBrackets;
var cBracketsWereFound = wr1.cBrackets + bas.cSpace + wr1.cwere + bas.cSpace + wr1.cfound; // Brackets were found

exports.cBracketsWereFound = cBracketsWereFound;
var cCheckIfThereIsRegularExpressionOrNot = wr1.cCheck + bas.cSpace + bas.cif + bas.cSpace + wr1.cthere + bas.cSpace + bas.cis + bas.cSpace + bas.ca + bas.cSpace + wr1.cRegular + bas.cSpace + wr1.cExpression + bas.cSpace + bas.cor + bas.cSpace + gen.cnot + bas.cDot; // Check if there is a Regular Expression or not.

exports.cCheckIfThereIsRegularExpressionOrNot = cCheckIfThereIsRegularExpressionOrNot;
var cRegularExpressionWasFound = bas.cA + bas.cSpace + wr1.cregular + bas.cSpace + wr1.cexpression + bas.cSpace + wr1.cwas + bas.cSpace + wr1.cfound + bas.cExclamation; // A regular expression was found!

exports.cRegularExpressionWasFound = cRegularExpressionWasFound;
var cNoRegExpFound = bas.cNO + bas.cSpace + gen.cRegExp + bas.cSpace + wr1.cfound + bas.cExclamation; // NO RegExp found!

exports.cNoRegExpFound = cNoRegExpFound;
var cBracketsAreFound = wr1.cBrackets + bas.cSpace + wr1.cARE + bas.cSpace + wr1.cfound + bas.cExclamation; // Brackets ARE found!

exports.cBracketsAreFound = cBracketsAreFound;
var cNoSecondaryCommandArgumentDelimiters = bas.cNO + bas.cSpace + wr1.csecondary + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cargument + bas.cSpace + wr1.cdelimiters + bas.cDot; // NO secondary command argument delimiters.

exports.cNoSecondaryCommandArgumentDelimiters = cNoSecondaryCommandArgumentDelimiters;
var cregularExpressionIs = wr1.cregular + bas.cSpace + wr1.cexpression + sys.cSpaceIsColonSpace; // regular expression is:

exports.cregularExpressionIs = cregularExpressionIs;
var cregExValueIs = gen.cregEx + wr1.cValue + sys.cSpaceIsColonSpace; // regExValue is:

exports.cregExValueIs = cregExValueIs;
var cregularExpressionFlagsAre = wr1.cregular + bas.cSpace + wr1.cexpression + bas.cSpace + wr1.cflags + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // regular expression flags are:

exports.cregularExpressionFlagsAre = cregularExpressionFlagsAre;
var cregExFlagsIs = gen.cregEx + wr1.cFlags + sys.cSpaceIsColonSpace; // regExFlags is:

exports.cregExFlagsIs = cregExFlagsIs;
var cargumentValueContainsTheDelimiterLetsSplitIt = wr1.cargument + wr1.cValue + bas.cSpace + wr1.ccontains + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cdelimiter + bas.cComa + bas.cSpace + wr1.clets + bas.cSpace + wr1.csplit + bas.cSpace + bas.cit + bas.cExclamation; // argumentValue contains the delimiter, lets split it!

exports.cargumentValueContainsTheDelimiterLetsSplitIt = cargumentValueContainsTheDelimiterLetsSplitIt;
var cargumentValueAfterAttemptingToRemoveOpenBracketFromAllArrayElementsIs = wr1.cargument + wr1.cValue + bas.cSpace + wr1.cafter + bas.cSpace + wr1.cattempting + bas.cSpace + bas.cto + bas.cSpace + wr1.cremove + bas.cSpace + bas.ca + bas.cSpace + wr1.copen + bas.cSpace + wr1.cbracket + bas.cSpace + wr1.cfrom + bas.cSpace + wr1.call + bas.cSpace + wr1.carray + bas.cSpace + wr1.celements + sys.cSpaceIsColonSpace; // argumentValue after attempting to remove a open bracket from all array elements is:

exports.cargumentValueAfterAttemptingToRemoveOpenBracketFromAllArrayElementsIs = cargumentValueAfterAttemptingToRemoveOpenBracketFromAllArrayElementsIs;
var cargumentValueAfterAttemptingToRemoveCloseBracketFromAllArrayElementsIs = wr1.cargument + wr1.cValue + bas.cSpace + wr1.cafter + bas.cSpace + wr1.cattempting + bas.cSpace + bas.cto + bas.cSpace + wr1.cremove + bas.cSpace + bas.ca + bas.cSpace + wr1.cclose + bas.cSpace + wr1.cbracket + bas.cSpace + wr1.cfrom + bas.cSpace + wr1.call + bas.cSpace + wr1.carray + bas.cSpace + wr1.celements + sys.cSpaceIsColonSpace; // argumentValue after attempting to remove a close bracket from all array elements is:

exports.cargumentValueAfterAttemptingToRemoveCloseBracketFromAllArrayElementsIs = cargumentValueAfterAttemptingToRemoveCloseBracketFromAllArrayElementsIs;
var csecondaryCommandArgsDelimiterIs = wr1.csecondary + wr1.cCommand + gen.cArgs + wr1.cDelimiter + sys.cSpaceIsColonSpace; // secondaryCommandArgsDelimiter is:

exports.csecondaryCommandArgsDelimiterIs = csecondaryCommandArgsDelimiterIs;
var cargumentArrayIs = wr1.cargument + wr1.cArray + sys.cSpaceIsColonSpace; // argumentArray is:

exports.cargumentArrayIs = cargumentArrayIs;
var cformattingIs = wr1.cformatting + sys.cSpaceIsColonSpace; // formatting is:

exports.cformattingIs = cformattingIs;
var cdeltaTimeIs = wr1.cdelta + wr1.cTime + sys.cSpaceIsColonSpace; // deltaTime is:

exports.cdeltaTimeIs = cdeltaTimeIs;
var cformatIs = wr1.cformat + sys.cSpaceIsColonSpace; // format is:

exports.cformatIs = cformatIs;
var creturnDeltaTimeIs = wr1.creturn + wr1.cDelta + wr1.cTime + sys.cSpaceIsColonSpace; // returnDeltaTime is:

exports.creturnDeltaTimeIs = creturnDeltaTimeIs;
var csleepTimeIs = wr1.csleep + wr1.cTime + sys.cSpaceIsColonSpace; // sleepTime is:

exports.csleepTimeIs = csleepTimeIs;
var cworkflowNameIs = wr1.cworkflow + wr1.cName + sys.cSpaceIsColonSpace; // workflowName is:

exports.cworkflowNameIs = cworkflowNameIs;
var ccurrentWorkflowIs = wr1.ccurrent + wr1.cWorkflow + sys.cSpaceIsColonSpace; // currentWorkflow is:

exports.ccurrentWorkflowIs = ccurrentWorkflowIs;
var cworkflowValueIs = wr1.cworkflow + wr1.cValue + sys.cSpaceIsColonSpace; // workflowValue is:

exports.cworkflowValueIs = cworkflowValueIs;
var cdataHivePathArrayIs = wr1.cdata + wr1.cHive + wr1.cPath + wr1.cArray + sys.cSpaceIsColonSpace; // dataHivePathArray is:

exports.cdataHivePathArrayIs = cdataHivePathArrayIs;
var ccontentsOfLeafDataHiveElementIs = wr1.ccontents + bas.cSpace + bas.cof + bas.cSpace + wr1.cleaf + wr1.cData + wr1.cHive + wr1.cElement + sys.cSpaceIsColonSpace; // contents of leafDataHiveElement is:

exports.ccontentsOfLeafDataHiveElementIs = ccontentsOfLeafDataHiveElementIs;
var centryIs = wr1.centry + sys.cSpaceIsColonSpace; // entry is:

exports.centryIs = centryIs;
var cattributeValueIs = wr1.cattribute + wr1.cValue + sys.cSpaceIsColonSpace; // attributeValue is:

exports.cattributeValueIs = cattributeValueIs;
var ckey1Is = wr1.ckey + num.c1 + sys.cSpaceIsColonSpace; // key1 is:

exports.ckey1Is = ckey1Is;
var ckey2Is = wr1.ckey + num.c2 + sys.cSpaceIsColonSpace; // key2 is:

exports.ckey2Is = ckey2Is;
var centityIs = wr1.centity + sys.cSpaceIsColonSpace; // entity is:

exports.centityIs = centityIs;
var cqueueNameSpaceIs = wr1.cqueue + wr1.cName + wr1.cSpace + sys.cSpaceIsColonSpace; // queueNameSpace is:

exports.cqueueNameSpaceIs = cqueueNameSpaceIs;
var cstackNameSpaceIs = wr1.cstack + wr1.cName + wr1.cSpace + sys.cSpaceIsColonSpace; // stackNameSpace is:

exports.cstackNameSpaceIs = cstackNameSpaceIs;
var cWarningStackColon = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cStack + bas.cColon + bas.cSpace; // WARNING: Stack:

exports.cWarningStackColon = cWarningStackColon;
var cAlreadyExists = bas.cSpace + wr1.cALREADY + bas.cSpace + wr1.cexist + bas.cExclamation; // ALREADY exist!

exports.cAlreadyExists = cAlreadyExists;
var cdoesNotExist = bas.cSpace + wr1.cdoes + bas.cSpace + gen.cnot + bas.cSpace + wr1.cexist + bas.cExclamation; // does not exist!

exports.cdoesNotExist = cdoesNotExist;
var cisEmpty = bas.cSpace + bas.cis + bas.cSpace + wr1.cempty + bas.cExclamation; // is empty!

exports.cisEmpty = cisEmpty;
var cContentsOfTheStackNamespace = wr1.cContents + bas.cSpace + bas.cof + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cstack + bas.cSpace + wr1.cname + wr1.cspace + bas.cColon + bas.cSpace; // Contents of the stack namespace:

exports.cContentsOfTheStackNamespace = cContentsOfTheStackNamespace;
var cwordDelimiterIs = wr1.cword + wr1.cDelimiter + sys.cSpaceIsColonSpace; // wordDelimiter is:

exports.cwordDelimiterIs = cwordDelimiterIs;
var cstringContainsAcronymIs = wr1.cstring + wr1.cContains + wr1.cAcronym + sys.cSpaceIsColonSpace; // stringContainsAcronym is:

exports.cstringContainsAcronymIs = cstringContainsAcronymIs;
var cErrorZipPackageReleaseFailed = wr1.cERROR + bas.cColon + bas.cSpace + gen.cZip + bas.cSpace + wr1.cpackage + bas.cSpace + wr1.crelease + bas.cSpace + wr1.cfailed + bas.cColon + bas.cSpace; // ERROR: Zip package release failed:

exports.cErrorZipPackageReleaseFailed = cErrorZipPackageReleaseFailed;
var cminimumColorRangeIs = wr1.cminimum + wr1.cColor + wr1.cRange + sys.cSpaceIsColonSpace; // minimumColorRange is:

exports.cminimumColorRangeIs = cminimumColorRangeIs;
var cmaximumColorRangeIs = wr1.cmaximum + wr1.cColor + wr1.cRange + sys.cSpaceIsColonSpace; // maximumColorRange is:

exports.cmaximumColorRangeIs = cmaximumColorRangeIs;
var callSystemConstantsValidationDataIs = wr1.call + wr1.cSystem + wr1.cConstants + wr1.cValidation + wr1.cData + sys.cSpaceIsColonSpace; // allSystemConstantsValidationData is:

exports.callSystemConstantsValidationDataIs = callSystemConstantsValidationDataIs;
var callClientConstantsValidationDataIs = wr1.call + wr1.cClient + wr1.cConstants + wr1.cValidation + wr1.cData + sys.cSpaceIsColonSpace; // allClientConstantsValidationData is:

exports.callClientConstantsValidationDataIs = callClientConstantsValidationDataIs;
var cconstantLibraryDataIs = wr1.cconstant + wr1.cLibrary + wr1.cData + sys.cSpaceIsColonSpace; // constantLibraryData is:

exports.cconstantLibraryDataIs = cconstantLibraryDataIs;
var cclientValidationDataIs = wr1.cclient + wr1.cValidation + wr1.cData + sys.cSpaceIsColonSpace; // clientValidationData is:

exports.cclientValidationDataIs = cclientValidationDataIs;
var carrayValidationDataIs = wr1.carray + wr1.cValidation + wr1.cData + sys.cSpaceIsColonSpace; // arrayValidationData is:

exports.carrayValidationDataIs = carrayValidationDataIs;
var cfilesListLimitIs = wr1.cfiles + wr1.cList + wr1.cLimit + sys.cSpaceIsColonSpace; // filesListLimit is:

exports.cfilesListLimitIs = cfilesListLimitIs;
var cenableLimitIs = wr1.cenable + wr1.cLimit + sys.cSpaceIsColonSpace; // enableLimit is:

exports.cenableLimitIs = cenableLimitIs;
var cfilesLimitIs = wr1.cfiles + wr1.cLimit + sys.cSpaceIsColonSpace; // filesLimit is:

exports.cfilesLimitIs = cfilesLimitIs;
var cinputDataRightBeforeProcessingIs = cinputData + bas.cSpace + wr1.cright + bas.cSpace + wr1.cbefore + bas.cSpace + wr1.cprocessing + sys.cSpaceIsColonSpace; // inputData right before processing is:

exports.cinputDataRightBeforeProcessingIs = cinputDataRightBeforeProcessingIs;
var cnumberIs = wr1.cnumber + sys.cSpaceIsColonSpace; // number is:

exports.cnumberIs = cnumberIs;
var capplicationMetaDataPathAndFilenameIs = wr1.capplication + wr1.cMetaData + wr1.cPath + wr1.cAnd + wr1.cFilename + sys.cSpaceIsColonSpace; // applicationMetaDataPathAndFilename is:

exports.capplicationMetaDataPathAndFilenameIs = capplicationMetaDataPathAndFilenameIs;
var cframeworkMetaDataPathAndFilenameIs = wr1.cframework + wr1.cMetaData + wr1.cPath + wr1.cAnd + wr1.cFilename + sys.cSpaceIsColonSpace; // frameworkMetaDataPathAndFilename is:

exports.cframeworkMetaDataPathAndFilenameIs = cframeworkMetaDataPathAndFilenameIs;
var capplicationMetaDataIs = wr1.capplication + wr1.cMetaData + sys.cSpaceIsColonSpace; // applicationMetaData is:

exports.capplicationMetaDataIs = capplicationMetaDataIs;
var cframeworkMetaDataIs = wr1.cframework + wr1.cMetaData + sys.cSpaceIsColonSpace; // frameworkMetaData is:

exports.cframeworkMetaDataIs = cframeworkMetaDataIs;
var cApplicationNameIs = wr1.cApplication + wr1.cName + sys.cSpaceIsColonSpace; // ApplicationName is:

exports.cApplicationNameIs = cApplicationNameIs;
var cApplicationVersionNumberIs = wr1.cApplication + wr1.cVersion + wr1.cNumber + sys.cSpaceIsColonSpace; // ApplicationVersionNumber is:

exports.cApplicationVersionNumberIs = cApplicationVersionNumberIs;
var cApplicationDescriptionIs = wr1.cApplication + wr1.cDescription + sys.cSpaceIsColonSpace; // ApplicationDescription is:

exports.cApplicationDescriptionIs = cApplicationDescriptionIs;
var cFrameworkNameIs = wr1.cFramework + wr1.cName + sys.cSpaceIsColonSpace; // FrameworkName is:

exports.cFrameworkNameIs = cFrameworkNameIs;
var cFrameworkVersionNumberIs = wr1.cFramework + wr1.cVersion + wr1.cNumber + sys.cSpaceIsColonSpace; // FrameworkVersionNumber is:

exports.cFrameworkVersionNumberIs = cFrameworkVersionNumberIs;
var cFrameworkDescriptionIs = wr1.cFramework + wr1.cDescription + sys.cSpaceIsColonSpace; // FrameworkDescription is:

exports.cFrameworkDescriptionIs = cFrameworkDescriptionIs;
var csessionDateTimeStampIs = wr1.csession + wr1.cDate + wr1.cTime + wr1.cStamp + sys.cSpaceIsColonSpace; // sessionDateTimeStamp is:

exports.csessionDateTimeStampIs = csessionDateTimeStampIs;
var clogFileNameIs = wr1.clog + wr1.cFileName + sys.cSpaceIsColonSpace; // logFileName is:

exports.clogFileNameIs = clogFileNameIs;
var cprimaryCommandDelimiterIs = wr1.cprimary + wr1.cCommand + wr1.cDelimiter + sys.cSpaceIsColonSpace; // primaryCommandDelimiter is:

exports.cprimaryCommandDelimiterIs = cprimaryCommandDelimiterIs;
var csecondaryCommandDelimiterIs = wr1.csecondary + wr1.cCommand + wr1.cDelimiter + sys.cSpaceIsColonSpace; // secondaryCommandDelimiter is:

exports.csecondaryCommandDelimiterIs = csecondaryCommandDelimiterIs;
var ctertiaryCommandDelimiterIs = wr1.ctertiary + wr1.cCommand + wr1.cDelimiter + sys.cSpaceIsColonSpace; // tertiaryCommandDelimiter is:

exports.ctertiaryCommandDelimiterIs = ctertiaryCommandDelimiterIs;
var ccommandSequencerCommandToEnqueueIs = wr1.ccommand + wr1.cSequencer + bas.cSpace + wr1.cCommand + bas.cSpace + bas.cTo + bas.cSpace + wr1.cEnqueue + sys.cSpaceIsColonSpace; // commandSequencer Command To Enqueue is:

exports.ccommandSequencerCommandToEnqueueIs = ccommandSequencerCommandToEnqueueIs;
var cWarningMessageIsUndefined = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cmessage + bas.cSpace + wr1.cis + bas.cSpace + wr1.cundefined; // WARNING: message is undefined

exports.cWarningMessageIsUndefined = cWarningMessageIsUndefined;
var cclassPathIs = wr1.cclass + wr1.cPath + sys.cSpaceIsColonSpace; // classPath is:

exports.cclassPathIs = cclassPathIs;
var cargsArrayContainsRegEx1Is = gen.cargs + wr1.cArray + wr1.cContains + wr1.cRegEx + num.c1 + sys.cSpaceIsColonSpace; // argsArrayContainsRegEx1 is:

exports.cargsArrayContainsRegEx1Is = cargsArrayContainsRegEx1Is;
var cargsArrayContainsRegEx2Is = gen.cargs + wr1.cArray + wr1.cContains + wr1.cRegEx + num.c2 + sys.cSpaceIsColonSpace; // argsArrayContainsRegEx2 is:

exports.cargsArrayContainsRegEx2Is = cargsArrayContainsRegEx2Is;
var cargsArrayContainsColonIs = gen.cargs + wr1.cArray + wr1.cContains + wr1.cColon + sys.cSpaceIsColonSpace; // argsArrayContainsColon is:

exports.cargsArrayContainsColonIs = cargsArrayContainsColonIs;
var cfileToSaveToIs = wr1.cfile + wr1.cTo + wr1.cSave + wr1.cTo + sys.cSpaceIsColonSpace; // fileToSaveTo is:

exports.cfileToSaveToIs = cfileToSaveToIs;
var cdataToWriteOutIs = wr1.cdata + wr1.cTo + wr1.cWrite + wr1.cOut + sys.cSpaceIsColonSpace; // dataToWriteOut is:

exports.cdataToWriteOutIs = cdataToWriteOutIs;
var clogFilePathAndNameIs = gen.clog + wr1.cFile + wr1.cPath + wr1.cAnd + wr1.cName + sys.cSpaceIsColonSpace; // logFilePathAndName is:

exports.clogFilePathAndNameIs = clogFilePathAndNameIs;
var cmetaDataOutputIs = wr1.cmetaData + wr1.cOutput + sys.cSpaceIsColonSpace; // metaDataOutput is:

exports.cmetaDataOutputIs = cmetaDataOutputIs;
var callCommandAliasesDataIs = wr1.call + wr1.cCommand + wr1.cAliases + wr1.cData + sys.cSpaceIsColonSpace; // allCommandAliasesData is:

exports.callCommandAliasesDataIs = callCommandAliasesDataIs;
var cresolvedFrameworkConstantsPathActualIs = wr1.cresolved + wr1.cFramework + wr1.cConstants + wr1.cPath + wr1.cActual + sys.cSpaceIsColonSpace; // resolvedFrameworkConstantsPathActual is:

exports.cresolvedFrameworkConstantsPathActualIs = cresolvedFrameworkConstantsPathActualIs;
var cresolvedClientConstantsPathActualIs = wr1.cresolved + wr1.cClient + wr1.cConstants + wr1.cPath + wr1.cActual + sys.cSpaceIsColonSpace; // resolvedClientConstantsPathActual is:

exports.cresolvedClientConstantsPathActualIs = cresolvedClientConstantsPathActualIs;
var cframeworkConstantsValidationDataIs = wr1.cframework + wr1.cConstants + wr1.cValidation + wr1.cData + sys.cSpaceIsColonSpace; // frameworkConstantsValidationData is:

exports.cframeworkConstantsValidationDataIs = cframeworkConstantsValidationDataIs;
var capplicationConstantsValidationDataIs = wr1.capplication + wr1.cConstants + wr1.cValidation + wr1.cData + sys.cSpaceIsColonSpace; // applicationConstantsValidationData is:

exports.capplicationConstantsValidationDataIs = capplicationConstantsValidationDataIs;
var cActualColonDoublePercent = bas.cDoubleQuote + wr1.cActual + bas.cDoubleQuote + bas.cColon + bas.cSpace + bas.cDoubleQuote + bas.cDoublePercent + bas.cDoubleQuote + bas.cComa; // "Actual": "%%",

exports.cActualColonDoublePercent = cActualColonDoublePercent;
var callCommandWorkflowsDataIs = wr1.call + wr1.cCommand + wr1.cWorkflows + wr1.cData + sys.cSpaceIsColonSpace; // allCommandWorkflowsData is:

exports.callCommandWorkflowsDataIs = callCommandWorkflowsDataIs;
var csourceDestinationArrayIs = wr1.csource + wr1.cDestination + wr1.cArray + sys.cSpaceIsColonSpace; // sourceDestinationArray is:

exports.csourceDestinationArrayIs = csourceDestinationArrayIs;
var cfilterArrayIs = wr1.cfilter + wr1.cArray + sys.cSpaceIsColonSpace; // filterArray is:
// Capture the session date-time-stamp so we can determine a log file name.

exports.cfilterArrayIs = cfilterArrayIs;
var cCaptureSessionDateTimeStampLogFileName = wr1.cCapture + bas.cSpace + wr1.cthe + bas.cSpace + wr1.csession + bas.cSpace + wr1.cdate + bas.cDash + wr1.ctime + bas.cDash + wr1.cstamp + bas.cSpace + bas.cso + bas.cSpace + wr1.cwe + bas.cSpace + wr1.ccan + bas.cSpace + wr1.cdetermine + bas.cSpace + bas.ca + bas.cSpace + wr1.clog + bas.cSpace + wr1.cfile + bas.cSpace + wr1.cname + bas.cDot; // WARNING: Some rules do not exist:

exports.cCaptureSessionDateTimeStampLogFileName = cCaptureSessionDateTimeStampLogFileName;
var cProcessRulesWarningSomeRulesDoNotExist = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cSome + bas.cSpace + wr1.crules + bas.cSpace + wr1.cdo + bas.cSpace + gen.cnot + bas.cSpace + wr1.cexist + bas.cColon + bas.cSpace; // WARNING: Mixed string. Cannot determine what delimiter should be used to break up the string into words.

exports.cProcessRulesWarningSomeRulesDoNotExist = cProcessRulesWarningSomeRulesDoNotExist;
var cDetermineWordDelimiterMessage1 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cMixed + bas.cSpace + wr1.cstring + bas.cDot + bas.cSpace; // WARNING: Mixed string.

exports.cDetermineWordDelimiterMessage1 = cDetermineWordDelimiterMessage1;
var cDetermineWordDelimiterMessage2 = wr1.cCannot + bas.cSpace + wr1.cdetermine + bas.cSpace + wr1.cwhat + bas.cSpace + wr1.cdelimiter + bas.cSpace + wr1.cshould + bas.cSpace; // Cannot determine what delimiter should

exports.cDetermineWordDelimiterMessage2 = cDetermineWordDelimiterMessage2;
var cDetermineWordDelimiterMessage3 = bas.cbe + bas.cSpace + wr1.cused + bas.cSpace + bas.cto + bas.cSpace + wr1.cbreak + bas.cSpace + bas.cup + bas.cSpace + wr1.cthe + bas.cSpace; // be used to break up the

exports.cDetermineWordDelimiterMessage3 = cDetermineWordDelimiterMessage3;
var cDetermineWordDelimiterMessage4 = wr1.cstring + bas.cSpace + wr1.cinto + bas.cSpace + wr1.cwords + bas.cDot; // string into words.
// WARNING: Mixed string. Cannot determine how words are delimited in the string. Unable to count words.

exports.cDetermineWordDelimiterMessage4 = cDetermineWordDelimiterMessage4;
var cGetWordCountInStringMessage1 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cMixed + bas.cSpace + wr1.cstring + bas.cDot + bas.cSpace; // WARNING: Mixed string.

exports.cGetWordCountInStringMessage1 = cGetWordCountInStringMessage1;
var cGetWordCountInStringMessage2 = wr1.cCannot + bas.cSpace + wr1.cdetermine + bas.cSpace + wr1.chow + bas.cSpace + wr1.cwords + bas.cSpace + wr1.care + bas.cSpace + wr1.cdelimited + bas.cSpace; // Cannot determine how words are delimited

exports.cGetWordCountInStringMessage2 = cGetWordCountInStringMessage2;
var cGetWordCountInStringMessage3 = bas.cin + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cstring + bas.cDot + bas.cSpace + wr1.cUnable + bas.cSpace + bas.cto + bas.cSpace + wr1.ccount + bas.cSpace + wr1.cwords + bas.cDot; // in the string. Unable to count words.
// WARNING: Mixed string. Cannot get words from the string. Unable to determine words.

exports.cGetWordCountInStringMessage3 = cGetWordCountInStringMessage3;
var cGetWordsArrayFromStringMessage1 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cMixed + bas.cSpace + wr1.cstring + bas.cDot + bas.cSpace; // WARNING: Mixed string.

exports.cGetWordsArrayFromStringMessage1 = cGetWordsArrayFromStringMessage1;
var cGetWordsArrayFromStringMessage2 = wr1.cCannot + bas.cSpace + wr1.cget + bas.cSpace + wr1.cwords + bas.cSpace + wr1.cfrom + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cstring + bas.cDot + bas.cSpace; // Cannot get words from the string.

exports.cGetWordsArrayFromStringMessage2 = cGetWordsArrayFromStringMessage2;
var cGetWordsArrayFromStringMessage3 = wr1.cUnable + bas.cSpace + bas.cto + bas.cSpace + wr1.cdetermine + bas.cSpace + wr1.cwords + bas.cDot; // Unable to determine words.
// Please enter a named command where the first word starts with a lower case letter and all other words in the named command start with an upper case letter:

exports.cGetWordsArrayFromStringMessage3 = cGetWordsArrayFromStringMessage3;
var cCommandNamePrompt1 = wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cnamed + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cwhere + bas.cSpace; // Please enter a named command where

exports.cCommandNamePrompt1 = cCommandNamePrompt1;
var cCommandNamePrompt2 = wr1.cthe + bas.cSpace + num.cfirst + bas.cSpace + wr1.cword + bas.cSpace + wr1.cstarts + bas.cSpace + wr1.cwith + bas.cSpace + bas.ca + bas.cSpace; // the first word starts with a

exports.cCommandNamePrompt2 = cCommandNamePrompt2;
var cCommandNamePrompt3 = wr1.clower + bas.cSpace + wr1.ccase + bas.cSpace + wr1.cletter + bas.cSpace + wr1.cand + bas.cSpace + wr1.call + bas.cSpace + wr1.cother + bas.cSpace; // lower case letter and all other

exports.cCommandNamePrompt3 = cCommandNamePrompt3;
var cCommandNamePrompt4 = wr1.cwords + bas.cSpace + bas.cin + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cnamed + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cstart + bas.cSpace; // words in the named command start

exports.cCommandNamePrompt4 = cCommandNamePrompt4;
var cCommandNamePrompt5 = wr1.cwith + bas.cSpace + bas.can + bas.cSpace + wr1.cupper + bas.cSpace + wr1.ccase + bas.cSpace + wr1.cletter + bas.cColon + bas.cSpace; // with an upper case letter:
// Please enter a list of command word abreviations/acronyms/aliases for the command word:

exports.cCommandNamePrompt5 = cCommandNamePrompt5;
var cCommandWordAliasPrompt1 = wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.clist + bas.cSpace + bas.cof + bas.cSpace + wr1.ccommand + bas.cSpace;
exports.cCommandWordAliasPrompt1 = cCommandWordAliasPrompt1;
var cCommandWordAliasPrompt2 = wr1.cword + bas.cSpace + wr1.cabreviations + bas.cForwardSlash + wr1.cacronyms + bas.cForwardSlash + wr1.caliases + bas.cSpace;
exports.cCommandWordAliasPrompt2 = cCommandWordAliasPrompt2;
var cCommandWordAliasPrompt3 = wr1.cfor + bas.cSpace + wr1.cthe + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cword + bas.cColon + bas.cSpace; // Please enter a string you would like to define as a constant in the constants system:

exports.cCommandWordAliasPrompt3 = cCommandWordAliasPrompt3;
var cConstantPrompt1 = wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cstring + bas.cSpace + wr1.cyou + bas.cSpace + wr1.cwould + bas.cSpace; // Please enter a string you would

exports.cConstantPrompt1 = cConstantPrompt1;
var cConstantPrompt2 = wr1.clike + bas.cSpace + bas.cto + bas.cSpace + wr1.cdefine + bas.cSpace + bas.cas + bas.cSpace + bas.ca + bas.cSpace + wr1.cconstant + bas.cSpace; // like to define as a constant

exports.cConstantPrompt2 = cConstantPrompt2;
var cConstantPrompt3 = bas.cin + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cconstants + bas.cSpace + wr1.csystem + bas.cColon + bas.cSpace; // in the constants system:
// Please enter a coma separated list of strings you would like to define in the constants system:

exports.cConstantPrompt3 = cConstantPrompt3;
var cConstantsListPrompt1 = wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.ccoma + bas.cSpace + wr1.cseparated + bas.cSpace + wr1.clist + bas.cSpace + bas.cof + bas.cSpace;
exports.cConstantsListPrompt1 = cConstantsListPrompt1;
var cConstantsListPrompt2 = wr1.cstrings + bas.cSpace + wr1.cyou + bas.cSpace + wr1.cwould + bas.cSpace + wr1.clike + bas.cSpace + bas.cto + bas.cSpace + wr1.cdefine + bas.cSpace + bas.cin + bas.cSpace;
exports.cConstantsListPrompt2 = cConstantsListPrompt2;
var cConstantsListPrompt3 = wr1.cthe + bas.cSpace + wr1.cconstants + bas.cSpace + wr1.csystem + bas.cColon + bas.cSpace; // Please enter a coma separated list of strings you would like to search for common patterns:

exports.cConstantsListPrompt3 = cConstantsListPrompt3;
var cConstantsListPatternSearchPrompt1 = wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.ccoma + bas.cSpace + wr1.cseparated + bas.cSpace + wr1.clist + bas.cSpace + bas.cof + bas.cSpace; // Please enter a coma separated list of

exports.cConstantsListPatternSearchPrompt1 = cConstantsListPatternSearchPrompt1;
var cConstantsListPatternSearchPrompt2 = wr1.cstrings + bas.cSpace + wr1.cyou + bas.cSpace + wr1.cwould + bas.cSpace + wr1.clike + bas.cSpace + bas.cto + bas.cSpace + wr1.csearch + bas.cSpace + wr1.cfor + bas.cSpace; // strings you would like to search for

exports.cConstantsListPatternSearchPrompt2 = cConstantsListPatternSearchPrompt2;
var cConstantsListPatternSearchPrompt3 = wr1.ccommon + bas.cSpace + wr1.cpatterns + bas.cColon + bas.cSpace; // common patterns:
// ERROR: Attempted to generate a suggested line of code to validate the constant, ' +
// 'but the constant is not formatted correctly, it should begin with a lower case "c". ' +
// 'Please reformat the constant correctly so a line of code can be generated for you.

exports.cConstantsListPatternSearchPrompt3 = cConstantsListPatternSearchPrompt3;
var cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage1 = wr1.cERROR + bas.cColon + bas.cSpace + wr1.cAttempted + bas.cSpace + bas.cto + bas.cSpace + wr1.cgenerate + bas.cSpace + bas.ca + bas.cSpace + wr1.csuggested + bas.cSpace; // ERROR: Attempted to generate a suggested

exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage1 = cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage1;
var cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage2 = wr1.cline + bas.cSpace + bas.cof + bas.cSpace + wr1.ccode + bas.cSpace + bas.cto + bas.cSpace + wr1.cvalidate + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cconstant + bas.cComa + bas.cSpace; // line of code to validate the constant,

exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage2 = cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage2;
var cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage3 = wr1.cbut + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cconstant + bas.cSpace + bas.cis + bas.cSpace + gen.cnot + bas.cSpace + wr1.cformatted + bas.cSpace + wr1.ccorrectly + bas.cComa + bas.cSpace; // but the constant is not formatted correctly,

exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage3 = cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage3;
var cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage4 = bas.cit + bas.cSpace + wr1.cshould + bas.cSpace + wr1.cbegin + bas.cSpace + wr1.cwith + bas.cSpace + bas.ca + bas.cSpace + wr1.clower + bas.cSpace + wr1.ccase + bas.cSpace + bas.cDoubleQuote + bas.cc + bas.cDoubleQuote + bas.cDot + bas.cSpace; // it should begin with a lower case "c".

exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage4 = cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage4;
var cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage5 = wr1.cPlease + bas.cSpace + wr1.creformat + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cconstant + bas.cSpace + wr1.ccorrectly + bas.cSpace + bas.cso + bas.cSpace + bas.ca + bas.cSpace; // Please reformat the constant correctly so a

exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage5 = cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage5;
var cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage6 = wr1.cline + bas.cSpace + bas.cof + bas.cSpace + wr1.ccode + bas.cSpace + wr1.ccan + bas.cSpace + bas.cbe + bas.cSpace + wr1.cgenerated + bas.cSpace + wr1.cfor + bas.cSpace + wr1.cyou + bas.cDot; // line of code can be generated for you.

exports.cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage6 = cDetermineSuggestedConstantsValidationLineOfCodeErrorMessage6;
var cSearchForPatternsInStringArrayMessage1 = sys.ccurrentMasterStringArrayElement + bas.cSpace + wr1.cdoes + bas.cSpace + gen.cnot + bas.cSpace + wr1.ccontain + bas.cSpace + bas.ca + bas.cSpace + wr1.cspace + bas.cSpace + wr1.ccharacter; // currentMasterStringArrayElement does not contain a space character
// WARNING: The current string being searched contains a space character, we are going to skip comparison.

exports.cSearchForPatternsInStringArrayMessage1 = cSearchForPatternsInStringArrayMessage1;
var cSearchForPatternsInStringArrayMessage2 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cThe + bas.cSpace + wr1.ccurrent + bas.cSpace + wr1.cstring + bas.cSpace + wr1.cbeing + bas.cSpace + wr1.csearched + bas.cSpace + wr1.ccontains + bas.cSpace + bas.ca + bas.cSpace + wr1.cspace + bas.cSpace + wr1.ccharacter + bas.cComa + bas.cSpace; // WARNING: The current string being searched contains a space character,

exports.cSearchForPatternsInStringArrayMessage2 = cSearchForPatternsInStringArrayMessage2;
var cSearchForPatternsInStringArrayMessage3 = bas.cwe + bas.cSpace + wr1.care + bas.cSpace + wr1.cgoing + bas.cSpace + bas.cto + bas.cSpace + wr1.cskip + bas.cSpace + wr1.ccomparison + bas.cDot; // we are going to skip comparison.
// WARNING: InputData was not an array or had an empty array.

exports.cSearchForPatternsInStringArrayMessage3 = cSearchForPatternsInStringArrayMessage3;
var cSearchForPatternsInStringArrayMessage4 = wr1.cWARNING + bas.cColon + bas.cSpace + cInputData + bas.cSpace + wr1.cwas + bas.cSpace + gen.cnot + bas.cSpace + bas.can + bas.cSpace + wr1.carray + bas.cSpace + bas.cor + bas.cSpace + wr1.chad + bas.cSpace + bas.can + bas.cSpace + wr1.cempty + bas.cSpace + wr1.carray + bas.cDot; // WARNING: InputData was not an array or had an empty array.
// WARNING: No data to load, please specify a valid path & filename!

exports.cSearchForPatternsInStringArrayMessage4 = cSearchForPatternsInStringArrayMessage4;
var cLoadDataFileMessage1 = wr1.cWARNING + bas.cColon + bas.cSpace + bas.cNo + bas.cSpace + wr1.cdata + bas.cSpace + bas.cto + bas.cSpace + wr1.cload + bas.cComa + bas.cSpace; // WARNING: No data to load,

exports.cLoadDataFileMessage1 = cLoadDataFileMessage1;
var cloadDataFileMessage2 = wr1.cplease + bas.cSpace + wr1.cspecify + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.cpath + bas.cSpace + bas.cAndPersand + bas.cSpace + wr1.cfilename + bas.cExclamation; // please specify a valid path & filename!

exports.cloadDataFileMessage2 = cloadDataFileMessage2;
var cloadDataFileMessage3 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cInvalid + bas.cSpace + wr1.cfile + bas.cSpace + wr1.cformat + bas.cComa + bas.cSpace + wr1.cfile + bas.cSpace + wr1.cformats + bas.cSpace + wr1.csupported + bas.cSpace + wr1.care + bas.cColon + bas.cSpace; // WARNING: Invalid file format, file formats supported are:
// WARNING: No data to save, please specify a valid path & filename!

exports.cloadDataFileMessage3 = cloadDataFileMessage3;
var csaveDataFileMessage1 = wr1.cWARNING + bas.cColon + bas.cSpace + bas.cNo + bas.cSpace + wr1.cdata + bas.cSpace + bas.cto + bas.cSpace + wr1.csave + bas.cComa + bas.cSpace; // WARNING: No data to save,

exports.csaveDataFileMessage1 = csaveDataFileMessage1;
var ccommandSequencerMessage1 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cnominal + bas.cDot + wr1.ccommand + wr1.cSequencer + bas.cColon + bas.cSpace + wr1.cThe + bas.cSpace + wr1.cspecified + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cwas + bas.cSpace + gen.cnot + bas.cSpace + wr1.cfound + bas.cComa + bas.cSpace; // WARNING: nominal.commandSequencer: The specified command was not found,

exports.ccommandSequencerMessage1 = ccommandSequencerMessage1;
var ccommandSequencerMessage2 = wr1.cplease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cand + bas.cSpace + wr1.ctry + bas.cSpace + wr1.cagain + bas.cDot; // please enter a valid command and try again.

exports.ccommandSequencerMessage2 = ccommandSequencerMessage2;
var cworkflowMessage1 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cnominal + bas.cDot + wr1.cworkflow + bas.cColon + bas.cSpace + wr1.cThe + bas.cSpace + wr1.cspecified + bas.cSpace + wr1.cworkflow + bas.cColon + bas.cSpace; // WARNING: nominal.workflow: The specified workflow:

exports.cworkflowMessage1 = cworkflowMessage1;
var cworkflowMessage2 = bas.cSpace + wr1.cwas + bas.cSpace + gen.cnot + bas.cSpace + wr1.cfound + bas.cSpace + bas.cin + bas.cSpace + wr1.ceither + bas.cSpace + wr1.cthe + bas.cSpace + wr1.csystem + bas.cSpace + wr1.cdefined + bas.cSpace + wr1.cworkflows + bas.cComa + bas.cSpace + bas.cor + bas.cSpace + wr1.cclient + bas.cSpace + wr1.cdefined + bas.cSpace + wr1.cworkflows + bas.cDot; // was not found in either the system defined workflows, or client defined workflows.

exports.cworkflowMessage2 = cworkflowMessage2;
var cworkflowMessage3 = bas.cSpace + wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.cworkflow + bas.cSpace + wr1.cname + bas.cSpace + wr1.cand + bas.cSpace + wr1.ctry + bas.cSpace + wr1.cagain + bas.cDot; // Please enter a valid workflow name and try again.
// After attempting to replace the secondaryCommandArgsDelimiter with the primaryCommandDelimiter commandString is:

exports.cworkflowMessage3 = cworkflowMessage3;
var ccommandGeneratorMessage1 = wr1.cAfter + bas.cSpace + wr1.cattempting + bas.cSpace + bas.cto + bas.cSpace + wr1.creplace + bas.cSpace + wr1.cthe + bas.cSpace + wr1.csecondary + wr1.cCommand + gen.cArgs + wr1.cDelimiter + bas.cSpace + wr1.cwith + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cprimary + wr1.cCommand + wr1.cDelimiter + bas.cSpace + wr1.ccommand + wr1.cString + sys.cSpaceIsColonSpace; // After attempting to replace the tertiaryCommandDelimiter with the secondaryCommandArgsDelimiter commandString is:

exports.ccommandGeneratorMessage1 = ccommandGeneratorMessage1;
var ccommandGeneratorMessage2 = wr1.cAfter + bas.cSpace + wr1.cattempting + bas.cSpace + bas.cto + bas.cSpace + wr1.creplace + bas.cSpace + wr1.cthe + bas.cSpace + wr1.ctertiary + wr1.cCommand + wr1.cDelimiter + bas.cSpace + wr1.cwith + bas.cSpace + wr1.cthe + bas.cSpace + wr1.csecondary + wr1.cCommand + gen.cArgs + wr1.cDelimiter + bas.cSpace + wr1.ccommand + wr1.cString + sys.cSpaceIsColonSpace; // WARNING: nominal.commandGenerator: Must enter a number greater than 0, number entered:

exports.ccommandGeneratorMessage2 = ccommandGeneratorMessage2;
var ccommandGeneratorMessage3 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cnominal + bas.cDot + wr1.ccommand + wr1.cGenerator + bas.cColon + bas.cSpace + wr1.cMust + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cnumber + bas.cSpace + wr1.cgreater + bas.cSpace + wr1.cthan + bas.cSpace + num.c0 + bas.cComa + bas.cSpace + wr1.cnumber + bas.cSpace + wr1.centered + bas.cColon + bas.cSpace; // WARNING: nominal.commandGenerator: Number entered for the number of commands to generate is not a number:

exports.ccommandGeneratorMessage3 = ccommandGeneratorMessage3;
var ccommandGeneratorMessage4 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cnominal + bas.cDot + wr1.ccommand + wr1.cGenerator + bas.cColon + bas.cSpace + wr1.cNumber + bas.cSpace + wr1.centered + bas.cSpace + wr1.cfor + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cnumber + bas.cSpace + bas.cof + bas.cSpace + wr1.ccommands + bas.cSpace + bas.cto + bas.cSpace + wr1.cgenerate + bas.cSpace + bas.cis + bas.cSpace + gen.cnot + bas.cSpace + bas.ca + bas.cSpace + wr1.cnumber + bas.cColon + bas.cSpace; // WARNING: nominal.commandGenerator: The specified command:

exports.ccommandGeneratorMessage4 = ccommandGeneratorMessage4;
var ccommandGeneratorMessage5 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cnominal + bas.cDot + wr1.ccommand + wr1.cGenerator + bas.cColon + bas.cSpace + wr1.cThe + bas.cSpace + wr1.cspecified + bas.cSpace + wr1.ccommand + bas.cColon + bas.cSpace; // was not found, please enter a valid command and try again.

exports.ccommandGeneratorMessage5 = ccommandGeneratorMessage5;
var ccommandGeneratorMessage6 = bas.cSpace + wr1.cwas + bas.cSpace + gen.cnot + bas.cSpace + wr1.cfound + bas.cComa + bas.cSpace + wr1.cplease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cand + bas.cSpace + wr1.ctry + bas.cSpace + wr1.cagain + bas.cDot; // Command can be called by passing parameters and bypass the prompt system.

exports.ccommandGeneratorMessage6 = ccommandGeneratorMessage6;
var ccommandAliasGeneratorMessage1 = wr1.cCommand + bas.cSpace + wr1.ccan + bas.cSpace + bas.cbe + bas.cSpace + wr1.ccalled + bas.cSpace + bas.cby + bas.cSpace + wr1.cpassing + bas.cSpace + wr1.cparameters + bas.cSpace + wr1.cand + bas.cSpace + wr1.cbypass + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cprompt + bas.cSpace + wr1.csystem + bas.cDot; // EXAMPLE: {"constants":"c,const","Generator":"g,gen,genrtr","List":"l,lst"}

exports.ccommandAliasGeneratorMessage1 = ccommandAliasGeneratorMessage1;
var ccommandAliasGeneratorMessage2 = wr1.cEXAMPLE + bas.cColon + bas.cSpace + bas.cOpenCurlyBrace + bas.cDoubleQuote + wr1.cconstants + bas.cDoubleQuote + bas.cColon + bas.cDoubleQuote + bas.cc + bas.cComa + gen.cconst + bas.cDoubleQuote + bas.cComa + bas.cDoubleQuote + wr1.cGenerator + bas.cDoubleQuote + bas.cColon + bas.cDoubleQuote + bas.cg + bas.cComa + phn.cgen + bas.cComa + phn.cgen + bas.crt + bas.cr + bas.cDoubleQuote + bas.cComa + bas.cDoubleQuote + wr1.cList + bas.cDoubleQuote + bas.cColon + bas.cDoubleQuote + bas.cl + bas.cComa + bas.cls + bas.ct + bas.cDoubleQuote + bas.cCloseCurlyBrace; // INVALID INPUT: Please enter a valid camel-case command name.

exports.ccommandAliasGeneratorMessage2 = ccommandAliasGeneratorMessage2;
var ccommandAliasGeneratorMessage3 = wr1.cINVALID + bas.cSpace + wr1.cINPUT + bas.cColon + bas.cSpace + wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.ccamel + bas.cDash + wr1.ccase + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cname + bas.cDot; // INVALID INPUT: Please enter a valid command word alias list.

exports.ccommandAliasGeneratorMessage3 = ccommandAliasGeneratorMessage3;
var ccommandAliasGeneratorMessage4 = wr1.cINVALID + bas.cSpace + wr1.cINPUT + bas.cColon + bas.cSpace + wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cword + bas.cSpace + wr1.calias + bas.cSpace + wr1.clist + bas.cDot; // INVALID COMMAND INPUT: Please enter valid command data when trying to call with parameters.

exports.ccommandAliasGeneratorMessage4 = ccommandAliasGeneratorMessage4;
var ccommandAliasGeneratorMessage5 = wr1.cINVALID + bas.cSpace + wr1.cCOMMAND + bas.cSpace + wr1.cINPUT + bas.cColon + bas.cSpace + wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cdata + bas.cSpace + wr1.cwhen + bas.cSpace + wr1.ctrying + bas.cSpace + bas.cto + bas.cSpace + wr1.ccall + bas.cSpace + wr1.cwith + bas.cSpace + wr1.cparameters + bas.cDot; // INVALID INPUT: Please enter a valid constant value that contains more than 4 characters.

exports.ccommandAliasGeneratorMessage5 = ccommandAliasGeneratorMessage5;
var cconstantsGeneratorMessage1 = wr1.cINVALID + bas.cSpace + wr1.cINPUT + bas.cColon + bas.cSpace + wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.cconstant + bas.cSpace + wr1.cvalue + bas.cSpace + wr1.cthat + bas.cSpace + wr1.ccontains + bas.cSpace + wr1.cmore + bas.cSpace + wr1.cthan + bas.cSpace + num.c4 + bas.cSpace + wr1.ccharacters + bas.cDot; // WARNING: The constant has already been defined in the following library(ies):

exports.cconstantsGeneratorMessage1 = cconstantsGeneratorMessage1;
var cconstantsGeneratorMessage2 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cThe + bas.cSpace + wr1.cconstant + bas.cSpace + wr1.chas + bas.cSpace + wr1.calready + bas.cSpace + wr1.cbeen + bas.cSpace + wr1.cdefined + bas.cSpace + bas.cin + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cfollowing + bas.cSpace + wr1.clibrary + bas.cOpenParenthesis + phn.cies + bas.cCloseParenthesis + bas.cColon + bas.cSpace; // The enableConstantsValidation flag is disabled.

exports.cconstantsGeneratorMessage2 = cconstantsGeneratorMessage2;
var cconstantsGeneratorMessage3 = wr1.cThe + bas.cSpace + wr1.cenable + wr1.cConstants + wr1.cValidation + bas.cSpace + wr1.cflag + bas.cSpace + wr1.cis + bas.cSpace + wr1.cdisabled + bas.cDot + bas.cSpace; // Enable this flag in the configuration settings to activate this command.

exports.cconstantsGeneratorMessage3 = cconstantsGeneratorMessage3;
var cconstantsGeneratorMessage4 = wr1.cEnable + bas.cSpace + wr1.cthis + bas.cSpace + wr1.cflag + bas.cSpace + wr1.cin + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cconfiguration + bas.cSpace + wr1.csettings + bas.cSpace + wr1.cto + bas.cSpace + wr1.cactivate + bas.cSpace + wr1.cthis + bas.cSpace + wr1.ccommand + bas.cDot; // INVALID INPUT: Please enter a valid constant list.

exports.cconstantsGeneratorMessage4 = cconstantsGeneratorMessage4;
var cconstantsGeneratorListMessage1 = wr1.cINVALID + bas.cSpace + wr1.cINPUT + bas.cColon + bas.cSpace + wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.cconstant + bas.cSpace + wr1.clist + bas.cDot; // PASSED: All duplicate command aliases validation tests!

exports.cconstantsGeneratorListMessage1 = cconstantsGeneratorListMessage1;
var cvalidateCommandAliasesMessage1 = wr1.cPASSED + bas.cColon + bas.cSpace + wr1.cAll + bas.cSpace + wr1.cduplicate + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.caliases + bas.cSpace + wr1.cvalidation + bas.cSpace + wr1.ctests + bas.cExclamation; // About to call the rule broker to process on the number of single quotes

exports.cvalidateCommandAliasesMessage1 = cvalidateCommandAliasesMessage1;
var cgetCommandArgsMessage1 = wr1.cAbout + bas.cSpace + bas.cto + bas.cSpace + wr1.ccall + bas.cSpace + wr1.cthe + bas.cSpace + wr1.crule + bas.cSpace + wr1.cbroker + bas.cSpace + bas.cto + bas.cSpace + wr1.cprocess + bas.cSpace + bas.con + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cnumber + bas.cSpace + bas.cof + bas.cSpace + wr1.csingle + bas.cSpace + wr1.cquotes + bas.cSpace; // About to call the rule broker to process on the number of single quotes
// and determine if it-be even or odd

exports.cgetCommandArgsMessage1 = cgetCommandArgsMessage1;
var cgetCommandArgsMessage2 = wr1.cand + bas.cSpace + wr1.cdetermine + bas.cSpace + bas.cif + bas.cSpace + bas.cit + bas.cDash + bas.cbe + bas.cSpace + wr1.ceven + bas.cSpace + bas.cor + bas.cSpace + wr1.codd; // WARNING: Command does not exist, please enter a valid command and try again!

exports.cgetCommandArgsMessage2 = cgetCommandArgsMessage2;
var cexecuteCommandMessage1 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.cCommand + bas.cSpace + wr1.cdoes + bas.cSpace + gen.cnot + bas.cSpace + wr1.cexist + bas.cComa + bas.cSpace + wr1.cplease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.ccommand + bas.cSpace + wr1.cand + bas.cSpace + wr1.ctry + bas.cSpace + wr1.cagain + bas.cExclamation; // WARNING: lexical.parseBusinessRuleArgument: Invalid combination of inputs to the lexical.parseBusinessRuleArgument function!

exports.cexecuteCommandMessage1 = cexecuteCommandMessage1;
var cparseBusinessRuleArgumentMessage1 = wr1.cWARNING + bas.cColon + bas.cSpace + wr1.clexical + bas.cDot + wr1.cparse + wr1.cBusiness + wr1.cRule + wr1.cArgument + bas.cColon + bas.cSpace + wr1.cInvalid + bas.cSpace + wr1.ccombination + bas.cSpace + bas.cof + bas.cSpace + wr1.cinputs + bas.cSpace + bas.cto + bas.cSpace + wr1.cthe + bas.cSpace + wr1.clexical + bas.cDot + wr1.cparse + wr1.cBusiness + wr1.cRule + wr1.cArgument + bas.cSpace + wr1.cfunction + bas.cExclamation + bas.cSpace;
exports.cparseBusinessRuleArgumentMessage1 = cparseBusinessRuleArgumentMessage1;
var cparseBusinessRuleArgumentMessage2 = wr1.cPlease + bas.cSpace + wr1.cadjust + bas.cSpace + wr1.cinputs + bas.cSpace + wr1.cand + bas.cSpace + wr1.ctry + bas.cSpace + wr1.cagain + bas.cDot; //Please adjust inputs and try again.
// Caught the case the user may have only specified a single data hive, such as the configuration data hive.

exports.cparseBusinessRuleArgumentMessage2 = cparseBusinessRuleArgumentMessage2;
var cprintDataHiveAttributesMessage1 = wr1.cCaught + bas.cSpace + wr1.cthe + bas.cSpace + wr1.ccase + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cuser + bas.cSpace + wr1.cmay + bas.cSpace + wr1.chave + bas.cSpace + wr1.conly + bas.cSpace + wr1.cspecified + bas.cSpace + bas.ca + bas.cSpace + wr1.csingle + bas.cSpace + wr1.cdata + bas.cSpace + wr1.chive + bas.cComa + bas.cSpace;
exports.cprintDataHiveAttributesMessage1 = cprintDataHiveAttributesMessage1;
var cprintDataHiveAttributesMessage2 = wr1.csuch + bas.cSpace + bas.cas + bas.cSpace + wr1.cthe + bas.cSpace + wr1.cconfiguration + bas.cSpace + wr1.cdata + bas.cSpace + wr1.chive + bas.cDot; // ERROR: Please enter a valid name.space.attributeName for the system to print out attribute data from.

exports.cprintDataHiveAttributesMessage2 = cprintDataHiveAttributesMessage2;
var cprintDataHiveAttributesMessage3 = wr1.cERROR + bas.cColon + bas.cSpace + wr1.cPlease + bas.cSpace + wr1.center + bas.cSpace + bas.ca + bas.cSpace + wr1.cvalid + bas.cSpace + wr1.cname + bas.cDot + wr1.cspace + bas.cDot + wr1.cattribute + wr1.cName + bas.cSpace + wr1.cfor + bas.cSpace + wr1.cthe + bas.cSpace + wr1.csystem + bas.cSpace + bas.cto + bas.cSpace + wr1.cprint + bas.cSpace + wr1.cout + bas.cSpace + wr1.cattribute + bas.cSpace + wr1.cdata + bas.cSpace + wr1.cfrom + bas.cDot; // Nothing to echo.

exports.cprintDataHiveAttributesMessage3 = cprintDataHiveAttributesMessage3;
var cNothingToEcho = wr1.cNothing + bas.cSpace + bas.cto + bas.cSpace + wr1.cecho + bas.cDot; // Nothing to echo.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 'Caught the case that the input string contains the global carriage return term.'

exports.cNothingToEcho = cNothingToEcho;
var cprompt01 = 'prompt01'; // 'index of the carriage return character: '

exports.cprompt01 = cprompt01;
var cprompt02 = 'prompt02'; // 'Caught the case that the string includes a carriage return and new line characters.'

exports.cprompt02 = cprompt02;
var cprompt03 = 'prompt03'; // '!file.includes(undefined)'

exports.cprompt03 = cprompt03;
var cprintMessageToFile01 = 'printMessageToFile01'; // 'ERROR: Failure to log to file: '

exports.cprintMessageToFile01 = cprintMessageToFile01;
var cprintMessageToFile02 = 'printMessageToFile02'; // 'ERROR: Log File includes undefined.'

exports.cprintMessageToFile02 = cprintMessageToFile02;
var cprintMessageToFile03 = 'printMessageToFile03'; // Coded System Messages
// EXAMPLE:
// '!mergedData[wr1.csystem] && !D[wr1.csystem] === true'

exports.cprintMessageToFile03 = cprintMessageToFile03;