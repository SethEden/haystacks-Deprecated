"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cSpanish = exports.cRussian = exports.cPortuguese = exports.cPolish = exports.cMiscellaneous = exports.cKorean = exports.cJapanese = exports.cItalian = exports.cHungarian = exports.cFrench = exports.cEnglish = exports.cCzech = exports.cChineseTraditional = exports.cChineseSimplified = exports.cChinese = void 0;

var bas = _interopRequireWildcard(require("./basic.constants.js"));

var ctr = _interopRequireWildcard(require("./country.constants.js"));

var phn = _interopRequireWildcard(require("./phonic.constants.js"));

var wr1 = _interopRequireWildcard(require("./word1.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file language.constants.js
 * @module language.constants
 * @description Contains many re-usable language constants.
 * @requires module:basic.constants
 * @requires module:country-constants
 * @requires module:phonic.constants
 * @requires module:word1.constants
 * @author Seth Hollingsead
 * @date 2021/11/15
 * @copyright Copyright © 2021-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// Languages
var cChinese = phn.cChi + bas.cn + phn.cese; // Chinese

exports.cChinese = cChinese;
var cChineseSimplified = cChinese + wr1.cSimplified; // ChineseSimplified

exports.cChineseSimplified = cChineseSimplified;
var cChineseTraditional = cChinese + wr1.cTraditional; // ChineseTraditional

exports.cChineseTraditional = cChineseTraditional;
var cCzech = bas.cCz + bas.ce + bas.cch; // Czech

exports.cCzech = cCzech;
var cEnglish = bas.cEn + bas.cgl + phn.cish; // English

exports.cEnglish = cEnglish;
var cFrench = bas.cFr + bas.cen + bas.cch; // French
// cGerman = bas.cGe + bas.cr + cman; // German // Defined above in the countries section

exports.cFrench = cFrench;
var cHungarian = wr1.cHung + bas.car + phn.cian; // Hungarian

exports.cHungarian = cHungarian;
var cItalian = bas.cIt + bas.cal + phn.cian; // Italian

exports.cItalian = cItalian;
var cJapanese = ctr.cJapan + phn.cese; // Japanese

exports.cJapanese = cJapanese;
var cKorean = bas.cKo + bas.cre + bas.can; // Korean

exports.cKorean = cKorean;
var cMiscellaneous = phn.cMis + wr1.ccell + bas.can + phn.ceous; // Miscellaneous

exports.cMiscellaneous = cMiscellaneous;
var cPolish = bas.cPo + bas.cl + phn.cish; // Polish

exports.cPolish = cPolish;
var cPortuguese = wr1.cPort + bas.cug + bas.cu + phn.cese; // Portuguese

exports.cPortuguese = cPortuguese;
var cRussian = bas.cRu + bas.css + phn.cian; // Russian

exports.cRussian = cRussian;
var cSpanish = bas.cSp + bas.can + phn.cish; // Spanish

exports.cSpanish = cSpanish;