"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _commandBroker = _interopRequireDefault(require("../../brokers/commandBroker.js"));

var _dataBroker = _interopRequireDefault(require("../../brokers/dataBroker.js"));

var _ruleBroker = _interopRequireDefault(require("../../brokers/ruleBroker.js"));

var _workflowBroker = _interopRequireDefault(require("../../brokers/workflowBroker.js"));

var bas = _interopRequireWildcard(require("../../constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("../../constants/business.constants.js"));

var cmd = _interopRequireWildcard(require("../../constants/command.constants.js"));

var cfg = _interopRequireWildcard(require("../../constants/configuration.constants.js"));

var fnc = _interopRequireWildcard(require("../../constants/function.constants.js"));

var gen = _interopRequireWildcard(require("../../constants/generic.constants.js"));

var msg = _interopRequireWildcard(require("../../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../../constants/word1.constants.js"));

var _configurator = _interopRequireDefault(require("../../executrix/configurator.js"));

var _fileOperations = _interopRequireDefault(require("../../executrix/fileOperations.js"));

var _lexical = _interopRequireDefault(require("../../executrix/lexical.js"));

var _loggers = _interopRequireDefault(require("../../executrix/loggers.js"));

var _prompt = _interopRequireDefault(require("../../executrix/prompt.js"));

var _timers = _interopRequireDefault(require("../../executrix/timers.js"));

var _data = _interopRequireDefault(require("../../structures/data.js"));

var _queue = _interopRequireDefault(require("../../structures/queue.js"));

var _stack = _interopRequireDefault(require("../../structures/stack.js"));

var _figlet = _interopRequireDefault(require("figlet"));

var math = _interopRequireWildcard(require("mathjs"));

var _path = _interopRequireDefault(require("path"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

/**
 * @file nominal.js
 * @module nominal
 * @description Contains all of the nominal system commands.
 * @requires module:commandBroker
 * @requires module:dataBroker
 * @requires module:ruleBroker
 * @requires module:workflowBroker
 * @requires module:basic.constants
 * @requires module:business.constants
 * @requires module:command.constants
 * @requires module:configuration.constants
 * @requires module:generic.constants
 * @requires module:message.constants
 * @requires module:system.constants
 * @requires module:word1.constants
 * @requires module:configurator
 * @requires module:fileOperations
 * @requires module:lexical
 * @requires module:loggers
 * @requires module:prompt
 * @requires module:timers
 * @requires module:data
 * @requires module:queue
 * @requires module:stack
 * @requires {@link https://www.npmjs.com/package/prompt-sync|prompt-sync}
 * @requires {@link https://www.npmjs.com/package/figlet|figlet}
 * @requires {@link https://mathjs.org/index.html|math}
 * @requires {@link https://www.npmjs.com/package/path|path}
 * @author Seth Hollingsead
 * @date 2022/02/04
 * @copyright Copyright © 2022-… by Seth Hollingsead. All rights reserved
 */
// Internal imports
// External imports
// import prompt from 'prompt-sync';
var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // commandsBlob.commands.nominal.


var namespacePrefix = sys.ccommandsBlob + bas.cDot + wr1.ccommands + bas.cDot + baseFileName + bas.cDot; // prompt();

/**
 * @function echoCommand
 * @description Returns the input as the output without any changes.
 * @param {array<boolean|string|integer} inputData String that shoudl be echoed.
 * inputData[0] === 'echoCommand'
 * @param {string} inputMetaData Not used for this business rule.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/04
 */

var echoCommand = function echoCommand(inputData, inputMetaData) {
  var functionName = echoCommand.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  if (inputData) {
    inputData.shift();
    console.log(inputData.join(bas.cSpace));
  } else {
    // Nothing to echo.
    console.log(msg.cNothingToEcho);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + JSON.stringify(returnData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function exit
 * @description Returns false so the entire application can exit.
 * @param {array<boolean|string|integer} inputData Not used for thsi command.
 * inputData[0] === 'exit'
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} False to indicate that the application should exit.
 * @author Seth Hollingsead
 * @date 2022/02/04
 */


var exit = function exit(inputData, inputMetaData) {
  var functionName = exit.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = false;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function version
 * @description Dispalys the current version number for the current application.
 * @param {array<boolean|string|integer>} inputData Not used for this command.
 * inputData[0] = 'version'
 * inputData[1] === 'application|framework' (optional)
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/04
 */


var version = function version(inputData, inputMetaData) {
  var functionName = version.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;
  var configVersion = '';
  var appContext = '';

  if (inputData.length === 2) {
    appContext = inputData[1];

    if (appContext.toUpperCase() === wr1.cAPPLICATION) {
      configVersion = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cApplicationVersionNumber);
    } else if (appContext.toUpperCase() === wr1.cFRAMEWORK) {
      configVersion = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cFrameworkVersionNumber);
    } else {
      configVersion = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cApplicationVersionNumber);
    }
  } else {
    configVersion = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cApplicationVersionNumber);
  }

  console.log(configVersion);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function about
 * @description Displays the message about the current application.
 * @param {array<boolean|string|integer} inputData Not used for this command.
 * inputData[0] === 'about'
 * inputData[1] === 'application|framework' (optional)
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/04
 */


var about = function about(inputData, inputMetaData) {
  var functionName = about.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;
  var configDescription = '';
  var appContext = '';

  if (inputData.length === 2) {
    appContext = inputData[1];

    if (appContext.toUpperCase() === wr1.cAPPLICATION) {
      configDescription = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cApplicationDescription);
    } else if (appContext.toUpperCase() === wr1.cFRAMEWORK) {
      configDescription = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cFrameworkDescription);
    } else {
      configDescription = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cApplicationDescription);
    }
  } else {
    configDescription = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cApplicationDescription);
  }

  console.log(configDescription);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function name
 * @description Displays the name of the current application in standard font format, nothing special.
 * Optional argument to output in figlet font.
 * @param {array<boolean|string|integer>} inputData An array that could really contain anything depending
 * on what the user entered, but the functino converts and filters out for a boolean
 * True or False value internally to the function.
 * inputData[0] === 'name'
 * inputData[1] === 'application|framework' (optional)
 * inputData[2] === 'true|false' (optional)
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/04
 */


var name = function name(inputData, inputMetaData) {
  var functionName = name.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;
  var reportedName = '';
  var figletFont = '';
  var appContext = '';
  var useFancyFont = false;
  var rules = [];
  rules[0] = biz.cstringToDataType;

  if (inputData.length === 2) {
    appContext = inputData[1];
  }

  if (inputData.length === 3) {
    appContext = inputData[1];
    useFancyFont = _ruleBroker["default"].processRules(inputData[2], '', rules);
  }

  if (appContext !== '') {
    if (appContext.toUpperCase() === wr1.cAPPLICATION) {
      reportedName = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cApplicationName);
    } else if (appContext.toUpperCase() === wr1.cFRAMEWORK) {
      reportedName = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cFrameworkName);
    } else {
      reportedName = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cApplicationName);
    }
  } else {
    reportedName = _configurator["default"].getConfigurationSetting(wr1.csystem, sys.cApplicationName);
  }

  if (useFancyFont === true) {
    figletFont = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cfigletFont);
    console.log(_figlet["default"].textSync(reportedName, {
      font: figletFont,
      horizontalLayout: sys.cfull
    }));
  } else {
    console.log(reportedName);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function clearScreen
 * @description Clears all data from the console cache by printing a bunch of blank lines to the screen.
 * @param {string} inputData Not used for this command.
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/04
 */


var clearScreen = function clearScreen(inputData, inputMetaData) {
  var functionName = clearScreen.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // loggers.consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));
  // loggers.consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + JSON.stringify(inputMetaData));


  var returnData = true; // console.clear(); // This will clear the screen, but not the cache, you can still scroll up and see the previous commands.
  // process.stdout.write('\u001B[2J\u-001B[0;0f'); // Same as above.

  process.stdout.write("\x1B[H\x1B[2J\x1B[3J");

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function help
 * @description Displays all the information about all of the commands in the system,
 * including both system defined commands and client defined commands.
 * @param {array<boolean|string|integer>} inputData Not used for this command.
 * inputData[0] = 'help'
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/22
 */


var help = function help(inputData, inputMetaData) {
  var functionName = help.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  var returnData = true;

  _loggers["default"].consoleTableLog(baseFileName + bas.cDot + functionName, _data["default"][sys.cCommandsAliases][wr1.cCommands], [wr1.cName, wr1.cDescription]);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function workflowHelp
 * @description Displays all the information about all the workflows in the system,
 * including both system defined workflows & client defined workflows.
 * @param {array<boolean|string|integer>} inputData Not used for this command.
 * inputData[0] = 'workflowHelp'
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/22
 */


var workflowHelp = function workflowHelp(inputData, inputMetaData) {
  var functionName = workflowHelp.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  var returnData = true;

  _loggers["default"].consoleTableLog(baseFileName + bas.cDot + functionName, _data["default"][sys.cCommandWorkflows][wr1.cWorkflows], [wr1.cName]);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function commandSequencer
 * @description Takes an arguments array where the second array object would contain a list of
 * commands that should be enqueued to the command queue.
 * @param {array<boolean|string|integer>} inputData An array that could actually contain anything,
 * depending on what the user entered. But the function filters all of that internally and
 * extracts the case the user has entered a list of commands that should be enqueued to the command queue.
 * inputData[0] === 'commandSequencer'
 * inputData[1] === command string 1
 * inputData[2] === command string 2
 * inputData[n] === command string n
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/22
 */


var commandSequencer = function commandSequencer(inputData, inputMetaData) {
  var functionName = commandSequencer.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  for (var i = 1; i < inputData.length; i++) {
    var commandString = inputData[i];

    var primaryCommandDelimiter = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cprimaryCommandDelimiter);

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cprimaryCommandDelimiterIs + primaryCommandDelimiter);

    if (primaryCommandDelimiter === null || primaryCommandDelimiter !== primaryCommandDelimiter || primaryCommandDelimiter === undefined) {
      primaryCommandDelimiter = bas.cSpace;
    }

    var secondaryCommandArgsDelimiter = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.csecondaryCommandDelimiter);

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.csecondaryCommandDelimiterIs + secondaryCommandArgsDelimiter);

    var tertiaryCommandDelimiter = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.ctertiaryCommandDelimiter);

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ctertiaryCommandDelimiterIs + tertiaryCommandDelimiter); // Replace 2nd & rd level delimiters and down-increemnt them so we are dealing with command strings that can actually be executed.


    var regEx1 = new RegExp(secondaryCommandArgsDelimiter, bas.cg);
    commandString = commandString.replace(regEx1, primaryCommandDelimiter); // console.log('commandString after secondaryCommandArgsDelimiter replace with primaryCommandDelimiter is: ' + commandString);

    if (commandString.includes(tertiaryCommandDelimiter)) {
      var regEx2 = new RegExp(tertiaryCommandDelimiter, bas.cg);
      commandString = commandString.replace(regEx2, secondaryCommandArgsDelimiter); // console.log('commandString after tertiaryCommandDelimiter replace with secondaryCommandArgsDelimiter is: ' + commandString);
    }

    var currentCommand = _commandBroker["default"].getValidCommand(commandString, primaryCommandDelimiter);

    var commandArgs = _commandBroker["default"].getCommandArgs(commandString, primaryCommandDelimiter); // We need to recompose the command arguments for the current command using the sys.cPrimaryCommandDelimiter.


    if (currentCommand !== false) {
      for (var j = 1; j < commandArgs.length; j++) {
        currentCommand = currentCommand + primaryCommandDelimiter + commandArgs[j];
      } // End-for (let j = 1; j < commandArgs.length; j++)


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandSequencerCommandToEnqueueIs + currentCommand);

      _queue["default"].enqueue(sys.cCommandQueue, currentCommand);
    } else {
      // End-if (currentCommand !== false)
      // WARNING: nominal.commandSequencer: The specified command was not found, please enter a valid command and try again.
      console.log(msg.ccommandSequencerMessage1 + msg.ccommandSequencerMessage2);
    }
  } // End-for (let i = 1; i < inputData.length; i++)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function workflow
 * @description Takes an arguments array where the second array object would contain a workflow name.
 * We will lookup the named workflow in the D-data structure and send that workflow to a cal to the command sequencer.
 * Which will in-turn convert the list of commands in that workflow into commands that are enqueued to the command queue.
 * @param {array<boolean|string|integer>} inputData An array that could actually contain anything,
 * depending on what the user entered. But the function filters all of that internally and
 * extracts the case the user has entered a workflow name, that we should use to look up the workflow in the D-data structure.
 * inputData[0] === 'workflow'
 * inputData[1] === workflowName
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/2/24
 */


var workflow = function workflow(inputData, inputMetaData) {
  var functionName = workflow.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;
  var workflowName = inputData[1];

  var workflowValue = _workflowBroker["default"].getWorkflow(workflowName);

  if (workflowValue !== false) {
    _queue["default"].enqueue(sys.cCommandQueue, workflowValue);
  } else {
    // WARNING: nominal.workflow: The specified workflow:
    // was not found in either the system defined workflows, or client defined workflows.
    // Please enter a valid workflow name and try again.
    console.log(msg.cworkflowMessage1 + workflowName + bas.cComa + msg.cworkflowMessage2 + msg.cworkflowMessage3);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function printDataHive
 * @description Prints out all the data contents of a particular data hive in the D-data structure.
 * If no hive is specified then the entire D-data structure will be printed.
 * @param {array<boolean|string|integer} inputData An array that could actually contain anything,
 * depending on what the user entered. But the function filters all of that internally and
 * extracts the case the user has entered a dat hive name at the top level of the D-data structure.
 * Examples: Configuration, Workflows, Colors, cCommandAliases, etc...
 * inputData[0] === 'printDataHive'
 * inputData[1] === dataHiveName
 * @NOTE This function is now going to support printing specific child data-hives.
 * Example: ConstantsValidationData.ColorConstantsValidation
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/24
 */


var printDataHive = function printDataHive(inputData, inputMetaData) {
  var functionName = printDataHive.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  var printDataHiveToLogFileConfigSetting = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cprintDataHiveToLogFile);

  var logFilePathAndName = ''; // if (printDataHiveToLogFileConfigSetting === true) {

  logFilePathAndName = _loggers["default"].getLogFileNameAndPath(); // logFilePathAndName is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.clogFilePathAndNameIs + logFilePathAndName); // }


  if (inputData && inputData[1].includes(bas.cDot) === true) {
    var dataHivePathArray = inputData[1].split(bas.cDot);
    var leafDataHiveElement = _data["default"]; // dataHivePathArray is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataHivePathArrayIs + JSON.stringify(dataHivePathArray)); // This for-loop should let us drill down in the D-Data structure followign the path that was provided.
    // This assumes the namespace style path provided is a valid heirarchy in the D-Data Structure.


    for (var i = 0; i < dataHivePathArray.length; i++) {
      // BEGIN i-th iteration:
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_ithIteration + i);

      leafDataHiveElement = leafDataHiveElement[dataHivePathArray[i]]; // contents of leafDataHiveElement is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontentsOfLeafDataHiveElementIs + JSON.stringify(leafDataHiveElement)); // END i-th iteration:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_ithIteration + i);
    }

    console.log(inputData[1] + bas.cSpace + msg.ccontentsAre + JSON.stringify(leafDataHiveElement));

    if (printDataHiveToLogFileConfigSetting === true) {
      _loggers["default"].printMessageToFile(logFilePathAndName, inputData[1] + bas.cSpace + msg.ccontentsAre + JSON.stringify(leafDataHiveElement));
    }
  } else {
    if (_data["default"][inputData[1]] !== undefined) {
      // contents are:
      console.log(inputData[1] + bas.cSpace + msg.ccontentsAre + JSON.stringify(_data["default"][inputData[1]]));

      if (printDataHiveToLogFileConfigSetting === true) {
        _loggers["default"].printMessageToFile(logFilePathAndName, inputData[1] + bas.cSpace + msg.ccontentsAre + JSON.stringify(_data["default"][inputData[1]]));
      }
    } else {
      // contents of D are:
      console.log(msg.ccontentsOfDare + JSON.stringify(_data["default"]));

      if (printDataHiveToLogFileConfigSetting === true) {
        _loggers["default"].printMessageToFile(logFilePathAndName, msg.ccontentsOfDare + JSON.stringify(_data["default"]));
      }
    }
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function printDataHiveAttributes
 * @description Prints out all of the attributes for a given specified data-set from the D-data structure.
 * @param {array<boolean|string|integer} inputData An array that could actually contain anything,
 * depending on what the user entered. But the function filters all of that internally and
 * extracts the case the user has entered a data hive or leaf data structure in the heirarchy and
 * a name of an attribute where all values should be printed.
 * Examples ConstantsValidationData.ColorConstantsValidation.Actual
 * inputData[0] === 'printDataHiveAttributes'
 * inputData[1] === ConstantsValidationData.ColorConstantsValidation.Actual
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/24
 */


var printDataHiveAttributes = function printDataHiveAttributes(inputData, inputMetaData) {
  var functionName = printDataHiveAttributes.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  if (inputData && inputData.length > 1) {
    if (inputData[1].includes(bas.cDot) === true) {
      var dataHivePathArray = inputData[1].split(bas.cDot);
      var leafDataHiveElement = _data["default"]; // dataHivePathArray is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdataHivePathArrayIs + JSON.stringify(dataHivePathArray)); // This for-loop should let us drill down in the D-Data structue following the path that was provided.
      // This assumes the namespace style path provided is a valid heirarchy in the D-Data Structure.
      // Make sure we don't try to grab the very last term of the namespace. See note below.


      for (var i = 0; i < dataHivePathArray.length - 1; i++) {
        // BEGIN i-th iteration:
        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_ithIteration + i);

        leafDataHiveElement = leafDataHiveElement[dataHivePathArray[i]]; // contents of leafDataHiveElement is:

        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccontentsOfLeafDataHiveElementIs + JSON.stringify(leafDataHiveElement)); // END i-th iteration:


        _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_ithIteration + i);
      } // End-for (let i = 0; i < dataHivePathArray.length - 1; i++)


      _loggers["default"].consoleLog(namespacePrefix + functionName, inputData[1] + bas.cSpace + msg.ccontentsAre + JSON.stringify(leafDataHiveElement));

      var attributeName = dataHivePathArray[dataHivePathArray.length - 1];

      if (leafDataHiveElement && leafDataHiveElement.length > 0) {
        var leafDataHiveElementKeys1 = Object.keys(leafDataHiveElement);

        for (var j = 0; j < leafDataHiveElement.length; j++) {
          var dataEntry = leafDataHiveElement[j];

          if (dataEntry) {
            if (attributeName.toLowerCase() === wr1.centity) {
              // entity is:
              console.log(msg.centryIs + JSON.stringify(dataEntry));
            } else {
              if (dataEntry[attributeName]) {
                // attributeValue is:
                console.log(msg.cattributeValueIs + dataEntry[attributeName]);
              } // End-if (dataEntry[attributeName])

            }
          } // End-if (dataEntry)

        } // End-for (let j = 0; j < leafDataHiveElement.length; j++)

      } else {
        var leafDataHiveElementKeys2 = Object.keys(leafDataHiveElement);
        leafDataHiveElementKeys2.forEach(function (key2) {
          if (attributeName.toLowerCase() === wr1.ckey) {
            // key2 is:
            console.log(msg.ckey2Is + key2);
          } else if (attributeName.toLowerCase() === wr1.centity) {
            // entity is:
            console.log(msg.centityIs + JSON.stringify(leafDataHiveElement[key2]));
          } else {
            var dataEntry2 = leafDataHiveElement[key2];

            if (dataEntry2) {
              // attributeValue is:
              console.log(msg.cattributeValueIs + dataEntry2[attributeName]);
            } // End-if (dataEntry2)

          }
        });
      }
    } else {
      // End-if (inputData[1].includes(bas.cDot) === true)
      // This is the case that the user has probably just specified a single data hive
      // that might not have specific attribute names such as the configuration data.
      console.log(msg.cprintDataHiveAttributesMessage1 + msg.cprintDataHiveAttributesMessage2);
    }
  } else {
    // End-if (inputData && inputData.length > 1)
    console.log(msg.cprintDataHiveAttributesMessage3);
  } // End-else condition if (inputData && inputData.length > 1)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function clearDataStorage
 * @description Completely wipes out all the data stored in the DataStorage data hive of the D data structure.
 * @param {array<boolean|string|integer>} inputData An array that could actually contain anything,
 * depending on what the user entered. But the function filters all of that internally and
 * extracts the case the user has entered a data storage name to clear.
 * If none is provided, the all data storage will be cleared!
 * inputData[0] === 'clearDataStorage'
 * inputData[1] === myDataStorage
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/24
 */


var clearDataStorage = function clearDataStorage(inputData, inputMetaData) {
  var functionName = clearDataStorage.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  if (inputData[1] !== undefined) {
    _dataBroker["default"].clearData(inputData[1]);
  } else {
    _dataBroker["default"].clearData('');
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function businessRule
 * @description Executes a user specified business rule with some input.
 * @param {array<boolean|string|integer>} inputData An array that could actually contain anything,
 * depending on what the user entered. But the function filters all of that internally and
 * extracts the case the user has entered a busienss rule name and perhpas some rule inputs.
 * inputData[0] === 'businessRule'
 * inputData[1] === rule 1 (including arguments with secondary delimiter)
 * inputData[2] === rule 2 (including arguments with secondary delimiter)
 * inputData[n] === rule n (including arguments with secondary delimiter)
 * @NOTE There are 2 ways this system can work, the user can either call each rule with it's own inputs,
 * or the user can leverage the rule system itself to pass the outputs from rule 1 as inputs to rule 2, etc...
 * This command will only always take the arguments for the first business rule as inputs and let the business rules system
 * pass the outputs as inputs as discussed above.
 * It is assumed if the user wanted to execute a sequence of business rules each with their own inputs,
 * then the user should use the command sequencer in combination with this function
 * to call a series of busienss rules each with their own inputs.
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/24
 * @NOTE When executing the business rule: replaceCharacterWithCharacter with a regular expression such as: regEx:[+]:flags:g
 * Consider the following link that describes how the regEx & flags are parsed by the lexical.
 * {@link https://stackoverflow.com/questions/874709/converting-user-input-string-to-regular-expression}
 */


var businessRule = function businessRule(inputData, inputMetaData) {
  var functionName = businessRule.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  var secondaryCommandArgsDelimiter = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.csecondaryCommandDelimiter);

  var rules = [];
  var ruleInputData, ruleInputMetaData;
  var ruleOutput = '';
  var addedARule = false;

  var businessRuleOutput = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableBusinessRuleOutput);

  var businessRuleMetricsEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableBusinessRulePerformanceMetrics);

  var businessRuleStartTime = '';
  var businessRuleEndTime = '';
  var businessRuleDeltaTime = '';
  var argsArrayContainsCharacterRule = [];
  var removeBracketsFromArgsArrayRule = [];
  argsArrayContainsCharacterRule[0] = biz.cdoesArrayContainCharacter;
  removeBracketsFromArgsArrayRule[0] = biz.cremoveCharacterFromArray; // First go through each rule that should be executed and determine if
  // there are any inputs that need to be passed into the business rule.

  for (var i = 1; i < inputData.length; i++) {
    // Begin the i-th iteration fo the inputData array. i is:
    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_theIthIterationOfInputDataArray + i);

    var currentRuleArg = inputData[i]; // Check to see if this rule has inputs separate from the rule name.
    // currentRule is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccurrentRuleIs + JSON.stringify(currentRuleArg));

    var ruleArgs = [];

    if (i === 1) {
      rules = _lexical["default"].parseBusinessRuleArgument(currentRuleArg, i);
    } else if (i === 2) {
      ruleInputData = _lexical["default"].parseBusinessRuleArgument(currentRuleArg, i);
    } else if (i === 3 && inputData.length <= 4) {
      ruleInputMetaData = _lexical["default"].parseBusinessRuleArgument(currentRuleArg, i);
    } else if (i === 3 && inputData.length > 4) {
      // // In this case all of the arguments will have been combined into a single array and added to the ruleInputData.
      ruleInputMetaData = [];

      for (var j = 3; j <= inputData.length - 1; j++) {
        var currentRuleArrayArg = inputData[j];

        var tempArg = _lexical["default"].parseBusinessRuleArgument(currentRuleArrayArg, j); // console.log('tempArg is: ' + tempArg);


        if (tempArg) {
          ruleInputMetaData.push(tempArg);
        }
      } // End-for (let j = inputData.length - 1; j > 2; j--)


      break;
    } // End-Else-if (i === 3 && inputData.length > 4)

  } // End-for (let i = 1; i < inputData.length; i++)
  // rules is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.crulesIs + JSON.stringify(rules)); // ruleInputData is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cruleInputDataIs + ruleInputData); // ruleInputMetaData is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cruleInputMetaData + JSON.stringify(ruleInputMetaData));

  if (businessRuleMetricsEnabled === true) {
    // Here we will capture the start time of the business rule we are about to execute.
    // After executing we will capture the end time and then
    // compare the difference to determine how many milliseconds it took to run the business rule.
    businessRuleStartTime = _timers["default"].getNowMoment(gen.cYYYYMMDD_HHmmss_SSS); // Business Rule Start time is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBusinessRuleStartTimeIs + businessRuleStartTime);
  } // End-if (businessRuleMetricsEnabled === true)


  ruleOutput = _ruleBroker["default"].processRules(ruleInputData, ruleInputMetaData, rules);

  if (businessRuleMetricsEnabled === true) {
    var performanceTrackingObject = {};
    businessRuleEndTime = _timers["default"].getNowMoment(gen.cYYYYMMDD_HHmmss_SSS); // BusinessRule End time is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBusinessRuleEndTimeIs + businessRuleEndTime); // Now compute the delta time so we know how long it took to run that busienss rule.


    businessRuleDeltaTime = _timers["default"].computeDeltaTime(businessRuleStartTime, businessRuleEndTime); // BusinessRule run-time is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBusinessRuleRunTimeIs + businessRuleDeltaTime); // Check to make sure the business rule performance trackign stack exists or does not exist.


    if (_data["default"][cfg.cbusinessRulesPerformanceTrackingStack] === undefined) {
      _stack["default"].initStack(cfg.cbusinessRulesPerformanceTrackingStack);
    }

    if (_data["default"][cfg.cbusinessRulesNamesPerformanceTrackingStack] === undefined) {
      _stack["default"].initStack(cfg.cbusinessRulesNamesPerformanceTrackingStack);
    }

    performanceTrackingObject = {
      Name: rules[0],
      RunTime: businessRuleDeltaTime
    };

    if (_stack["default"].contains(cfg.cbusinessRulesNamesPerformanceTrackingStack, rules[0]) === false) {
      _stack["default"].push(cfg.cbusinessRulesNamesPerformanceTrackingStack, rules[0]);
    }

    _stack["default"].push(cfg.cbusinessRulesPerformanceTrackingStack, performanceTrackingObject); // stack.print(cfg.cBusinessRulePerformanceTrackingStack);
    // stack.print(cfg.cBusinessRuleNamesPerformanceTrackingStack);

  } // End-if (businessRuleMetricsEnabled === true)


  if (businessRuleOutput === true) {
    // Rule output is:
    console.log(msg.cRuleOutputIs + JSON.stringify(ruleOutput));
  }

  businessRuleStartTime = '';
  businessRuleEndTime = '';
  businessRuleDeltaTime = '';

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function commandGenerator
 * @description Takes a set of input parameters such as a command and the number of times it should be executed.
 * Then this command will enqueue that command that number of times to the command queue.
 * @param {array<boolean|string|integer>} inputData An array that could actually contain anything,
 * depending on what the user entered. But the function filters all of that internally and
 * extracts the command that should be executed and the number of times it should be executed.
 * inputData[0] === 'commandGenerator'
 * inputData[1] === command string
 * inputData[2] === number of times to enqueue the above command string
 * @param {string} inputMetaData Not sued for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/24
 */


var commandGenerator = function commandGenerator(inputData, inputMetaData) {
  var functionName = commandGenerator.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;
  var foundLegitNumber = false;
  var legitNumberIndex = -1;
  var replaceCharacterWithCharacterRule = [];
  replaceCharacterWithCharacterRule[0] = biz.creplaceCharacterWithCharacter;

  var primaryCommandDelimiter = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cPrimaryCommandDelimiter);

  if (primaryCommandDelimiter === null || primaryCommandDelimiter !== primaryCommandDelimiter || primaryCommandDelimiter === undefined) {
    primaryCommandDelimiter = bas.cSpace;
  }

  var secondaryCommandArgsDelimiter = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.csecondaryCommandDelimiter);

  var tertiaryCommandDelimiter = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.ctertiaryCommandDelimiter);

  var commandString = '';

  if (inputData.length === 3) {
    commandString = inputData[1];
  } else if (inputData.length >= 4) {
    for (var i = 1; i < inputData.length - 1; i++) {
      if (i === 1) {
        commandString = inputData[1];
      } else {
        commandString = commandString + bas.cBackTickQuote + inputData[i].trim() + bas.cBackTickQuote;
      }
    } // End-for (let i = 1; i < inputData.length - 2; i++)

  } // NOTE: the str.replace only replaces the first instance of a string value, not all values.
  // but we might have another issue in the sense that if the string begins and ends with "[" & "]" respectively,
  // we might not want to replace those characters.
  // Because it might be that the command should take responsibility or that in such a special case,
  // i.e. treating the whole block as a single array and doing it's own split operation.
  // commandString = commandString.replace(secondaryCommandArgsDelimiter, primaryCommandDelimiter);
  // commandString = commandString.replace(tertiaryCommandDelimiter, secondaryCommandArgsDelimiter);
  // commandString before attempted delimiter swap is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandStringBeforeAttemptedDelimiterSwapIs + commandString); // replaceCharacterWithCharacterRule is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creplaceCharacterWithCharacterRuleIs + JSON.stringify(replaceCharacterWithCharacterRule)); // let secondaryCommandDelimiterRegEx = new RegExp(bas.cBackSlash + secondaryCommandArgsDelimiter, bas.cg);


  var secondaryCommandDelimiterRegEx = new RegExp("[".concat(secondaryCommandArgsDelimiter, "]"), bas.cg);
  commandString = _ruleBroker["default"].processRules(commandString, [secondaryCommandArgsDelimiter, primaryCommandDelimiter], replaceCharacterWithCharacterRule); // After attempting to replace the secondaryCommandArgsDelimiter with the primaryCommandDelimiter commandString is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandGeneratorMessage1 + commandString); // let tertiaryCommandDelimiterRegEx = new RegExp(bas.cBackSlash + tertiaryCommandDelimiter, bas.cg);


  var tertiaryCommandDelimiterRegEx = new RegExp("[".concat(tertiaryCommandDelimiter, "]"), bas.cg);
  commandString = _ruleBroker["default"].processRules(commandString, [tertiaryCommandDelimiter, secondaryCommandArgsDelimiter], replaceCharacterWithCharacterRule); // After attempting to replace the teriaryCommandDelimiter with the secondaryCommandArgsDelimiter commandString is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandGeneratorMessage2 + commandString);

  var currentCommand = _commandBroker["default"].getValidCommand(commandString, primaryCommandDelimiter);

  var commandArgs = _commandBroker["default"].getCommandArgs(commandString, primaryCommandDelimiter);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccurrentCommandIs + currentCommand);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandArgsIs + JSON.stringify(commandArgs));

  if (currentCommand !== false) {
    if (inputData.length >= 3) {
      for (var j = 2; j <= inputData.length - 1; j++) {
        if (isNaN(inputData[j].trim()) === false) {
          foundLegitNumber = true;
          legitNumberIndex = j;
          break;
        }
      } // End-for (let i = 2; i <= inputData.length - 1; i++)

    } // End-if (inputData.length >= 3)


    if (isNaN(inputData[legitNumberIndex]) === false) {
      // Make sure the user passed in a number for the second argument.
      var numberOfCommands = parseInt(inputData[legitNumberIndex]);

      if (numberOfCommands > 0) {
        for (var _i = 0; _i < numberOfCommands; _i++) {
          _queue["default"].enqueue(sys.cCommandQueue, commandString);
        }
      } else {
        // WARNING: nominal.commandGenerator: Must enter a number greater than 0, number entered:
        console.log(mg.ccommandGeneratorMessage3 + numberOfCommands);
      }
    } else {
      // WARNING: nominal.commandGenerator: Number entered for the number of commands to generate is not a number:
      console.log(msg.ccommandGeneratorMessage4 + inputData[2]);
    }
  } else {
    // WARNING: nominal.commandGenerator: The specified command:
    // was not found, please enter a valid command and try again.
    console.log(msg.ccommandGeneratorMessage5 + commandString + msg.ccommandGeneratorMessage6);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function commandAliasGenerator
 * @description Requests a set of inputs from the user for a command name,
 * and a series of command words and a list of command word acronyms.
 * The command then calls a series of business rules to in-turn generate all
 * possible combinations of command words and command word acronyms.
 * @param {array<object|boolean|string|integer>} inputData An array that could actually contain anything,
 * depending on what the user entered. But the function filters all of that internally and
 * parses the data string object into a JSON object with values that are the command words and command word abreviations.
 * inputData[0] === 'commandAliasGenerator'
 * inputData[1] === A JSON object containing the data necessary for defining all command words and command aliases.
 * @NOTE Test string for argument driven interface for this command:
 * {"constants":"c,const","Generator":"g,gen,genrtr","List":"l,lst"}
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/02/25
 */


var commandAliasGenerator = function commandAliasGenerator(inputData, inputMetaData) {
  var functionName = commandAliasGenerator.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;
  var commandName = '';
  var commandWordAliasList = '';
  var validCommandName = false;
  var validCommandWordAliasList = false;
  var validCommandInput = false;
  var commandAliasDataStructure = {};
  var commandNameParsingRule = [];
  var camelCaseToArrayRule = [];
  var commandWordAliasListParsingRule = [];
  var generateCommandAliasesRule = [];
  commandNameParsingRule[0] = biz.cisValidCommandNameString;
  camelCaseToArrayRule[0] = biz.cconvertCamelCaseStringToArray;
  commandWordAliasListParsingRule[0] = biz.cisStringList;
  generateCommandAliasesRule[0] = biz.cgenerateCommandAliases; // Command can be called by passing parameters and bypass the prompt system.

  console.log(msg.ccommandAliasGeneratorMessage1); // EXAMPLE: {"constants":"c,const","Generator":"g,gen,genrtr","List":"l,lst"}

  console.log(msg.ccommandAliasGeneratorMessage2);

  if (inputData.length === 0) {
    while (validCommandName === false) {
      console.log(msg.cCommandNamePrompt1);
      console.log(msg.cCommandNamePrompt2);
      console.log(msg.cCommandNamePrompt3);
      console.log(msg.cCommandNamePrompt4);
      console.log(msg.cCommandNamePrompt5);
      commandName = _prompt["default"].prompt(bas.cGreaterThan);
      validCommandName = _ruleBroker["default"].processRules(commandName, '', commandNameParsingRule);

      if (validCommandName === false) {
        // INVALID INPUT: Please enter a valid camel-case command name.
        console.log(msg.ccommandAliasGeneratorMessage3);
      } // End-if (validCommandName === false)

    } // End-while (validCommandName === false)


    var camelCaseCommandNameArray = _ruleBroker["default"].processRules(commandName, '', camelCaseToArrayRule); // camelCaseCommandNameArray is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccamelCaseCommandNameArrayIs + JSON.stringify(camelCaseCommandNameArray));

    for (var i = 0; i < camelCaseCommandNameArray.length; i++) {
      var commandWord = camelCaseCommandNameArray[i]; // current commandWord is:

      console.log(msg.ccurrentCommandWordIs + commandWord);
      validCommandWordAliasList = false;

      if (commandWord !== '') {
        commandAliasDataStructure[commandWord] = {};

        while (validCommandWordAliasList === false) {
          console.log(msg.cCommandWordAliasPrompt1);
          console.log(msg.cCommandWordAliasPrompt2);
          console.log(msg.cCommandWordAliasPrompt3 + bas.cSpace + commandWord);
          commandWordAliasList = _prompt["default"].prompt(bas.cGreaterThan);
          validCommandWordAliasList = _ruleBroker["default"].processRules(commandWordAliasList, '', commandWordAliasListParsingRule);

          if (vaidCommandWordAliasList === false) {
            // INVALID INPUT: Please enter a valid command word alias list.
            console.log(msg.ccommandAliasGeneratorMessage4);
          } else if (commandWordAliasList !== '') {
            // As long as the user entered something we shoudl be able to proceed!
            validCommandWordAliasList = true;
          }
        } // End-while (validCommandWordAliasList === false)


        commandAliasDataStructure[commandWord] = commandWordAliasList;
        validCommandInput = true;
      } // End-if (commandWord !== '')

    } // End-for (let i = 0; i < camelCaseCommandNameArray.length; i++)

  } else if (inputData.length === 2) {
    try {
      commandAliasDataStructure = JSON.parse(inputData[1]);
      validCommandInput = true;
    } catch (err) {
      // PARSER ERROR:
      console.log(msg.cPARSER_ERROR + err.message); // INVALID COMMAND INPUT: Please enter valid command data when trying to call with parameters.

      console.log(msg.ccommandAliasGeneratorMessage5); // EXAMPLE: {"constants":"c,const","Generator":"g,gen,genrtr","List":"l,lst"}

      console.log(msg.ccommandAliasGeneratorMessage2);
    }
  } else {
    // INVALID COMMAND INPUT: Please enter valid command data when trying to call with parameters.
    console.log(msg.ccommandAliasGeneratorMessage5); // EXAMPLE: {"constants":"c,const","Generator":"g,gen,genrtr","List":"l,lst"}

    console.log(msg.ccommandAliasGeneratorMessage2);
  }

  if (validCommandInput === true) {
    // commandAliasDataStructure is:
    _loggers["default"].consoleLog(namespacePrefix, functionName, msg.ccommandAliasDataStructureIs + JSON.stringify(commandAliasDataStructure)); // At this point the user should have entered all valid data and we should be ready to proceed.
    // TODO: Start generating all the possible combinations of the command words and command word aliases.
    // Pass the data object to a business rule to do the above task.


    var commandAliases = _ruleBroker["default"].processRules(commandAliasDataStructure, '', generateCommandAliasesRule);
  } // End-if (validCommandInput === true)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function constantsGenerator
 * @description Requests a string input the user would like to have converted nto a constant,
 * while determining the most optimized way to define the new constant based on existing constants.
 * Also checks to see if that new constant is already defined in the constants system.
 * @param {string} inputData Parameterized constant to generate for.
 * @param {string} inputMetaData Not used for this business rule.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/03/30
 */


var constantsGenerator = function constantsGenerator(inputData, inputMetaData) {
  var functionName = constantsGenerator.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableConstantsValidation) === true) {
    var validEntry = false;
    var userDefinedConstant = '';
    var validConstantRule = [];
    var doesConstantExistRule = [];
    var getConstantTypeRule = [];
    var constantsFulfillmentSystemRule = [];
    var wordsCountRule = [];
    var wordsArrayRule = [];
    var recombineArrayInputRule = [];
    validConstantRule[0] = biz.cisConstantValid;
    doesConstantExistRule[0] = biz.cdoesConstantExist;
    getConstantTypeRule[0] = biz.cgetConstantType;
    constantsFulfillmentSystemRule[0] = biz.cconstantsFulfillmentSystem;
    wordsCountRule[0] = biz.cgetWordCountInString;
    wordsArrayRule[0] = biz.cgetWordsArrayFromString;
    recombineArrayInputRule[0] = biz.crecombineStringArrayWithSpaces;

    if (inputData.length === 0) {
      while (validEntry === false) {
        console.log(msg.cConstantPrompt1);
        console.log(msg.cConstantPrompt2);
        console.log(msg.cConstantPrompt3);
        userDefinedConstant = _prompt["default"].prompt(bas.cGreaterThan);
        validEntry = _ruleBroker["default"].processRules(userDefinedConstant, '', validConstantRule);

        if (validEntry === false) {
          // INVALID INPUT: Please enter a valid constant value that contains more than 4 characters.
          console.log(msg.cconstantsGeneratorMessage1);
        }
      } // End-while (validEntry === false)

    } else if (inputData.length === 2) {
      userDefinedConstant = inputData[1];
    } else {
      // We need to recombine all of the array elements after the 0-th element into a single string with spaces inbetween.
      userDefinedConstant = _ruleBroker["default"].processRules(inputData, '', recombineArrayInputRule);
    } // userDefinedConstant is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cuserDefinedConstantIs + userDefinedConstant); // First lets check if the constant is already defined, so we can warn the user.
    // NOTE: It could be that the developer is just lookng to optimize the existing constant,
    // but if not, a warning to the user would be a good idea!


    var doesConstantExist = _ruleBroker["default"].processRules(userDefinedConstant, '', doesConstantExistRule);

    if (doesConstantExist === true) {
      var constantType = _ruleBroker["default"].processRules(userDefinedConstant, '', getConstantTypeRule); // WARNING: The constant has already been defined in the following library(ies):


      console.log(msg.cconstantsGeneratorMessage2 + constantType);
    }

    userDefinedConstant = userDefinedConstant.trim();

    var wordCount = _ruleBroker["default"].processRules(userDefinedConstant, '', wordsCountRule); // wordCount is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cwordCountIs + wordCount); // Now begin the fulfillment algorithm.


    if (wordCount > 1) {
      var wordsArray = _ruleBroker["default"].processRules(userDefinedConstant, '', wordsArrayRule);

      for (var j = 0; j < wordsArray.length; j++) {
        // Optimized constant definition for word:
        console.log(msg.cOptimizedConstantDefinitionForWord + bas.cc + wordsArray[j] + bas.cSpace + bas.cEqual + bas.cSpace + _ruleBroker["default"].processRules(wordsArray[j].trim(), wordsArray[j].trim(), constantsFulfillmentSystemRule));
      } // End-for (let j = 0; j < wordsArray.length; j++)

    } else {
      // There is only a single word to process.
      // output a proper line of code:
      // export const csomething = wr1.csome + wr1.cthing; // something
      console.log(wr1.cexport + bas.cSpace + gen.cconst + bas.cSpace + bas.cc + userDefinedConstant + bas.cSpace + bas.cEqual + bas.cSpace + _ruleBroker["default"].processRules(userDefinedConstant, userDefinedConstant, constantsFulfillmentSystemRule) + bas.cSemiColon + bas.cSpace + bas.cDoubleForwardSlash + bas.cSpace + userDefinedConstant);
    }
  } else {
    // The enableConstantsValidation flag is disabled. Enable this flag in the configuration settings to activate this command.
    console.log(msg.ccconstantsGeneratorMessage3 + msg.cconstantsGeneratorMessage4);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function constantsGeneratorList
 * @description Calls the constantsGenerator command to iterate over a list of constants and generate many constants sequentially.
 * @NOTE This function will also walk the list and determine if there are any common strings
 * internal to the list that could be defined as new constants to help with the optimization process.
 * @NOTE Testing string: constGenL somethingXML,whatever that is,A basic NodeJS template App,that can easily
 * @param {string} inputData Parameterized coma delimited list of constants to be auto-generated
 * @param {string} inputMetaData Not used for this business rule.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/03/30
 */


var constantsGeneratorList = function constantsGeneratorList(inputData, inputMetaData) {
  var functionName = constantsGeneratorList.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableConstantsValidation) === true) {
    var validEntry = false;
    var userDefinedConstantList = '';
    var validConstantRule = [];
    var recombineArrayInputRule = [];
    validConstantRule[0] = biz.cisConstantValid;
    recombineArrayInputRule[0] = biz.crecombineStringArrayWithSpaces;

    if (inputData.length === 0) {
      while (validEntry === false) {
        console.log(msg.cConstantsListPrompt1);
        console.log(msg.cConstantsListPrompt2);
        console.log(msg.cConstantsListPrompt3);
        userDefinedConstantList = _prompt["default"].prompt(bas.cGreaterThan);
        validEntry = _ruleBroker["default"].processRules(userDefinedConstantList, '', validConstantRule);

        if (validEntry === false) {
          // INVALID INPUT: Please enter a valid constant list.
          console.log(msg.cconstantsGeneratorListMessage1);
        }
      } // End-while (validEntry === false)

    } else if (inputData.length === 2) {
      userDefinedConstantList = inputData[1];
    } else {
      // Combine all of the input parameters back into a single string then we will parse it for coma's into an array.
      // The array elements will then be used to enqueue the command constantsGenerator.
      userDefinedConstantList = _ruleBroker["default"].processRules(inputData, '', recombineArrayInputRule);
    } // userDefinedConstantList is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cuserDefinedConstantListIs + userDefinedConstantList);

    if (userDefinedConstantList.includes(bas.cComa) === true) {
      // userDefinedConstantList contains comas
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cuserDefinedConstantListContainsComas);

      var userDefinedConstantsListArray = userDefinedConstantList.split(bas.cComa); // userDefinedConstantsListArray is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cuserDefinedConstantsListArrayIs + JSON.stringify(userDefinedConstantsListArray));

      if (userDefinedConstantsListArray.length > 1) {
        for (var i = 0; i < userDefinedConstantsListArray.length; i++) {
          _queue["default"].enqueue(sys.cCommandQueue, cmd.cconstantsGenerator + bas.cSpace + userDefinedConstantsListArray[i].trim());
        }
      } else if (userDefinedConstantsLIsArray.length === 1) {
        // Just enqueue the constants Generator command with the input directly.
        _queue["default"].enqueue(sys.cCommandQueue, cmd.cconstantsGenerator + bas.cSpace + userDefinedConstantsListArray[0].trim());
      }
    } else {
      // userDefinedConstantsList DOES NOT contain comas
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cuserDefinedConstantsListDoesNotContainComas);

      _queue["default"].enqueue(sys.cCommandQueue, cmd.cconstantsGenerator + bas.cSpace + userDefinedConstantList.trim());
    }
  } else {
    // The enableConstantsValidation flag is disabled. Enable this flag in the configuration settings to activate this command.
    console.log(msg.ccconstantsGeneratorMessage3 + msg.cconstantsGeneratorMessage4);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function constantsPatternRecognizer
 * @description Walks through a list of constants lookng for patterns internal to the strings.
 * @param {string} inputData Parameterized coma delimited list of constants to be
 * passed through pattern recognition to find common strings among them.
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/03/31
 */


var constantsPatternRecognizer = function constantsPatternRecognizer(inputData, inputMetaData) {
  var functionName = constantsPatternRecognizer.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableConstantsValidation) === true) {
    var validEntry = false;
    var userDefinedConstantList = '';
    var validConstantRule = [];
    var recombineArrayInputRule = [];
    var wordsArrayFromStringRule = [];
    var searchForPatternsInStringArrayRule = [];
    var validatePatternsNeedImplementationRule = [];
    var wordsArray = [];
    var commonPatternsArray = [];
    validConstantRule[0] = biz.cisConstantValid;
    recombineArrayInputRule[0] = biz.crecombineStringArrayWithSpaces;
    wordsArrayFromStringRule[0] = biz.cgetWordsArrayFromString;
    searchForPatternsInStringArrayRule[0] = biz.csearchForPatternsInStringArray;
    validatePatternsNeedImplementationRule[0] = biz.cvalidatePatternsThatNeedImplementation;

    if (inputData.length === 0) {
      while (validEntry === false) {
        console.log(msg.cConstantsListPatternSearchPrompt1);
        console.log(msg.cConstantsListPatternSearchPrompt2);
        console.log(msg.cConstantsListPatternSearchPrompt3);
        userDefinedConstantList = _prompt["default"].prompt(bas.cGreaterThan);
        validEntry = _ruleBroker["default"].processRules(userDefinedConstantList, '', validConstantRule);

        if (validEntry === false) {
          // INVALID INPUT: Please enter a valid constant list.
          console.log(msg.cconstantsGeneratorListMessage1);
        }
      } // End-while (validEntry === false)

    } else if (inputData.length === 2) {
      userDefinedConstantList = inputData[1];
    } else {
      // Combine all of the input parameters back into a single string then we will parse it for coma's into an array.
      // The array elements will then be used to enqueue the command constantsGenerator.
      userDefinedConstantList = _ruleBroker["default"].processRules(inputData, '', recombineArrayInputRule);
    } // userDefinedConstantLiset is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cuserDefinedConstantListIs + userDefinedConstantList);

    if (userDefinedConstantList.includes(bas.cComa) === true) {
      wordsArray = userDefinedConstantList.split(bas.cComa);
    } else {
      // userDefinedConstantList DOES NOT contain comas
      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cuserDefinedConstantsListDoesNotContainComas); // Check and see if there is another delimiter we can use to break up the string into an array,
      // such as a space character, Maybe the user entered a sentence and would like all the words of the sentence to be optimized.


      wordsArray = _ruleBroker["default"].processRules(userDefinedConstantList, '', wordsArrayFromStringRule);
    } // wordsArray is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cwordsArrayIs + JSON.stringify(wordsArray));

    commonPatternsArray = _ruleBroker["default"].processRules(wordsArray, '', searchForPatternsInStringArrayRule); // commonPatternsArray is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommonPatternsArrayIs + JSON.stringify(commonPatternsArray)); // This next call will compare the identified string patterns with existing constants, and highlight which ones are not yet implemented.


    var newConstantsList = _ruleBroker["default"].processRules(commonPatternsArray, '', validatePatternsNeedImplementationRule);

    var constantsPatternGenerationSetting = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableConstantsPatternGeneration);

    if (constantsPatternGenerationSetting === true) {
      _queue["default"].enqueue(sys.cCommandQueue, cmd.cconstantsGeneratorList + bas.cSpace + newConstantsList);
    }
  } else {
    // The enableConstantsValidation flag is disabled. Enable this flag in the configuration settings to activate this command.
    console.log(msg.ccconstantsGeneratorMessage3 + msg.cconstantsGeneratorMessage4);
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function businessRulesMetrics
 * @description A command to compute business rule metrics for each of the
 * business rules that were called in a sequence of call(s) or workflow(s).
 * @param {string} inputData Not used for this command.
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/03/03
 */


var businessRulesMetrics = function businessRulesMetrics(inputData, inputMetaData) {
  var functionName = businessRulesMetrics.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  var businessRuleMetricsEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableBusinessRulePerformanceMetrics);

  if (businessRuleMetricsEnabled === true) {
    var businessRuleCounter = 0;
    var businessRulePerformanceSum = 0;
    var businessRulePerformanceStdSum = 0;
    var average = 0;
    var standardDev = 0; // Here we iterate over all of the business rules that were added to the sys.cBusinessRulePerformanceTrackingStack.

    for (var i = 0; i < _stack["default"].length(cfg.cbusinessRulesNamesPerformanceTrackingStack); i++) {
      businessRuleCounter = 0; // Reset it to zero, because we are beginning again with another busienss rule name.

      businessRulePerformanceSum = 0;
      businessRulePerformanceStdSum = 0;
      average = 0;
      standardDev = 0; // Here we will not iterate over all of the contents of all of the busienss rule performance numbers and
      // do the necessary math for each business rule according to the parent loop.

      var currentBusinessRuleName = _data["default"][cfg.cbusinessRulesNamesPerformanceTrackingStack][i];

      for (var j = 0; j < _stack["default"].length(cfg.cbusinessRulesPerformanceTrackingStack); j++) {
        if (_data["default"][cfg.cbusinessRulesPerformanceTrackingStack][j][wr1.cName] === currentBusinessRuleName) {
          businessRuleCounter = businessRuleCounter + 1; // businessRuleCounter is:

          _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cbusinessRuleCounterIs + businessRuleCounter);

          businessRulePerformanceSum = businessRulePerformanceSum + _data["default"][cfg.cbusinessRulesPerformanceTrackingStack][j][sys.cRunTime]; // businessRulePerformanceSum is:

          _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cbusinessRulePerformanceSumIs + businessRulePerformanceSum);
        } // End-if (D[cfg.cBusinessRulePerformanceTrackingStack][j][wr1.cName] === currentBusinessRuleName)

      } // End-for (let j = 0; j < stack.length(cfg.cBusinessRulePerformanceTrackingStack); j++)
      // DONE! businessRulePerformanceSum is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cDoneBusinessRulePerformanceSumIs + businessRulePerformanceSum);

      average = businessRulePerformanceSum / businessRuleCounter; // average is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.caverageIs + average); // Now go back through them all so we can compute the standard deviation.


      for (var k = 0; k < _stack["default"].length(cfg.cbusinessRulesPerformanceTrackingStack); k++) {
        if (_data["default"][cfg.cbusinessRulesPerformanceTrackingStack][k][wr1.cName] === currentBusinessRuleName) {
          businessRulePerformanceStdSum = businessRulePerformanceStdSum + math.pow(_data["default"][cfg.cbusinessRulesPerformanceTrackingStack][k][sys.cRunTime] - average, 2); // businessRulePerformanceStdSum is:

          _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cbusinessRulePerformanceStdSumIs + businessRulePerformanceStdSum);
        } // End-if (D[cfg.cBusinessRulePerformanceTrackingStack][k][wr1.cName] === currentBusinessRuleName)

      } // End-for (let k = 0; k < stack.length(cfg.cBusinessRulePerformanceTrackingStack); k++)
      // DONE! businessRulePerformanceStdSum is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cDoneBusinessRulePerformanceStdSumIs + businessRulePerformanceStdSum);

      standardDev = math.sqrt(businessRulePerformanceStdSum / businessRuleCounter); // standardDev is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstandardDevIs + standardDev);

      if (_data["default"][cfg.cbusinessRulesPerformanceAnalysisStack] === undefined) {
        _stack["default"].initStack(cfg.cbusinessRulesPerformanceAnalysisStack);
      }

      _stack["default"].push(cfg.cbusinessRulesPerformanceAnalysisStack, {
        Name: currentBusinessRuleName,
        Average: average,
        StandardDeviation: standardDev
      });
    } // End-for (let i = 0; i < stack.length(cfg.cBusinessRulesNamesPerformanceTrackingStack); i++)


    _loggers["default"].consoleTableLog('', _data["default"][cfg.cbusinessRulesPerformanceAnalysisStack], [wr1.cName, wr1.cAverage, sys.cStandardDeviation]);

    _stack["default"].clearStack(cfg.cbusinessRulesPerformanceAnalysisStack); // We need to have a flag that will enable the user to determine if the data should be cleared after the analysis is complete.
    // It might be that the user wants to do somethign else with this data in memory after it's done.


    if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cclearBusinessRulesPerformanceDataAfterAnalysis) === true) {
      _stack["default"].clearStack(cfg.cbusinessRulesPerformanceTrackingStack);

      _stack["default"].clearStack(cfg.cbusinessRulesNamesPerformanceTrackingStack);
    }
  } // End-if (businessRuleMetricsEnabled === true)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function commandMetrics
 * @description A command to compute command metrics for each of the commands that were called in a sequence of call(s) or workfow(s).
 * @param {string} inputData Not used for this command.
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/03/11
 */


var commandMetrics = function commandMetrics(inputData, inputMetaData) {
  var functionName = commandMetrics.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  var commandMetricsEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableCommandPerformanceMetrics);

  if (commandMetricsEnabled === true) {
    var commandCounter = 0;
    var commandPerformanceSum = 0;
    var commandPerformanceStdSum = 0;
    var average = 0;
    var standardDev = 0; // Here we iterate over all of the commands that were added to the cfg.ccommandsPerformanceTrackingStack.

    for (var i = 0; i < _stack["default"].length(cfg.ccommandNamesPerformanceTrackingStack); i++) {
      commandCounter - 0;
      commandPerformanceSum = 0;
      commandPerformanceStdSum = 0;
      average = 0;
      standardDev = 0; // Here we will now iterate over all of the contents of all the command performance numbers and
      // do the necessary math for each command according to the parent loop.

      var currentCommandName = _data["default"][cfg.ccommandNamesPerformanceTrackingStack][i];

      for (var j = 0; j < _stack["default"].length(cfg.ccommandsPerformanceTrackingStack); j++) {
        if (_data["default"][cfg.ccommandsPerformanceTrackingStack][j][wr1.cName] === currentCommandName) {
          commandCounter = commandCounter + 1; // commandCounter is:

          _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandCounterIs + commandCounter);

          commandPerformanceSum = commandPerformanceSum + _data["default"][cfg.ccommandsPerformanceTrackingStack][j][sys.cRunTime]; // commandPerformanceSum is:

          _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandPerformanceSumIs + commandPerformanceSum);
        } // End-if (D[cfg.ccommandsPerformanceTrackingStack][j][wr1.cName] === currentCommandName)

      } // End-for (let j = 0; j < stack.length(cfg.ccommandsPerformanceTrackingStack); j++)
      // DONE! commandPerformanceSum is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cDoneCommandPerformanceSumIs + commandPerformanceSum);

      average = commandPerformanceSum / commandCounter; // average is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.caverageIs + average); // Now go back through them allso we can compute the standard deviation.


      for (var k = 0; k < _stack["default"].length(cfg.ccommandsPerformanceTrackingStack); k++) {
        if (_data["default"][cfg.ccommandsPerformanceTrackingStack][k][wr1.cName] === currentCommandName) {
          commandPerformanceStdSum = commandPerformanceStdSum + math.pow(_data["default"][cfg.ccommandsPerformanceTrackingStack][k][sys.cRunTime] - average, 2); // commandPerformanceStdSum is:

          _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccommandPerformanceStdSumIs + commandPerformanceStdSum);
        } // End-if (D[cfg.ccommandsPerformanceTrackingStack][k][wr1.cName] === currentCommandName)

      } // End-for (let k = 0; k < stack.length(cfg.ccommandsPerformanceTrackingStack); k++)
      // DONE! commandPerformanceStdSum is:


      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cDoneCommandPerformanceStdSumIs + commandPerformanceStdSum);

      standardDev = math.sqrt(commandPerformanceStdSum / commandCounter); // standardDev is:

      _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstandardDevIs + standardDev);

      if (_data["default"][cfg.ccommandsPerformanceAnalysisStack] === undefined) {
        _stack["default"].initStack(cfg.ccommandsPerformanceAnalysisStack);
      }

      _stack["default"].push(cfg.ccommandsPerformanceAnalysisStack, {
        Name: currentCommandName,
        Average: average,
        StandardDeviation: standardDev
      });
    } // End-for (let i = 0; i < stack.length(cfg.ccommandNamesPerformanceTrackingStack); i++)


    _loggers["default"].consoleTableLog('', _data["default"][cfg.ccommandsPerformanceAnalysisStack], [wr1.cName, wr1.cAverage, sys.cStandardDeviation]);

    _stack["default"].clearStack(cfg.ccommandsPerformanceAnalysisStack); // We need to have a flag that will enable the user to determine if the data should be cleared afer the analysis is complete.
    // It might be that the user wants to do something else with this data in memory after it's done.


    if (_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cclearCommandPerformanceDataAfterAnalysis) === true) {
      _stack["default"].clearStack(cfg.ccommandsPerformanceTrackingStack);

      _stack["default"].clearStack(cfg.ccommandNamesPerformanceTrackingStack);
    }
  } // End-if (commandMetricsEnabled === true)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function saveConfiguration
 * @description Saves out all of the configuration data to a JSON file so custom user settings can be persisted between sessions.
 * @param {string} inputData Not used for this command.
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/03/11
 */


var saveConfiguration = function saveConfiguration(inputData, inputMetaData) {
  var functionName = saveConfiguration.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;

  _dataBroker["default"].writeJsonDataToFile(_configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cappConfigPath) + wr1.cconfig + gen.cDotjson, JSON.stringify(_data["default"]));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};
/**
 * @function convertColors
 * @description Converts all of the color hexidecimal values into RGB color values.
 * @param {string} inputData Not used for this command.
 * @param {string} inputMetaData Not used for this command.
 * @return {boolean} True to indicate that the application should not exit.
 * @author Seth Hollingsead
 * @date 2022/03/11
 * @reference {@Link: https://github.com/paularmstrong/normalizr/issues/15}
 */


var convertColors = function convertColors(inputData, inputMetaData) {
  var functionName = convertColors.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputDataIs + JSON.stringify(inputData));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputMetaDataIs + inputMetaData);

  var returnData = true;
  var colorConversionRule = [];
  colorConversionRule[0] = biz.creplaceCharacterWithCharacter;
  colorConversionRule[1] = biz.chex2rgbConversion;
  var colorKeys = Object.keys(_data["default"][wr1.ccolors][sys.cColorData]); // colorKeys is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccolorKeysIs + JSON.stringify(colorKeys));

  for (var i = 0; i < colorKeys.length; i++) {
    var currentColorName = colorKeys[i]; // currentColorName is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccurrentColorNameIs + currentColorName);

    var currentColorObject = _data["default"][wr1.ccolors][sys.cColorData][currentColorName]; // currentColorObject is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccurrentColorObjectIs + JSON.stringify(currentColorObject));

    var currentColorHexValue = currentColorObject[sys.cHexValue]; // currentColorHexValue is:

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.ccurrentColorHexValueIs + currentColorHexValue);

    var ruleOutput = _ruleBroker["default"].processRules(currentColorHexValue, [bas.cHash, ''], colorConversionRule); // ruleOutput is:


    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cruleOutputIs + ruleOutput);

    console.log(currentColorName + bas.cComa + currentColorHexValue + bas.cComa + ruleOutput[0] + bas.cComa + ruleOutput[1] + bas.cComa + ruleOutput[2]);
  } // End-for (let i = 0; i < colorKeys.length; i++)


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDataIs + returnData);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnData;
};

var _default = {
  echoCommand: echoCommand,
  exit: exit,
  version: version,
  about: about,
  name: name,
  clearScreen: clearScreen,
  help: help,
  workflowHelp: workflowHelp,
  commandSequencer: commandSequencer,
  workflow: workflow,
  printDataHive: printDataHive,
  printDataHiveAttributes: printDataHiveAttributes,
  clearDataStorage: clearDataStorage,
  businessRule: businessRule,
  commandGenerator: commandGenerator,
  commandAliasGenerator: commandAliasGenerator,
  constantsGenerator: constantsGenerator,
  constantsGeneratorList: constantsGeneratorList,
  constantsPatternRecognizer: constantsPatternRecognizer,
  businessRulesMetrics: businessRulesMetrics,
  commandMetrics: commandMetrics,
  saveConfiguration: saveConfiguration,
  convertColors: convertColors
};
exports["default"] = _default;