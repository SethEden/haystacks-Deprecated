"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _integrationTests = _interopRequireDefault(require("./commands/integrationTests.js"));

var _nominal = _interopRequireDefault(require("./commands/nominal.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var cmd = _interopRequireWildcard(require("../constants/command.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _path = _interopRequireDefault(require("path"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // commandsBlob.commandsLibrary.


var namespacePrefix = sys.ccommandsBlob + bas.cDot + baseFileName + bas.cDot;
/**
 * @function initCommandsLibrary
 * @description Initializes the commands function data structure on D.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/04
 * @NOTE Pelase be aware taht the Commands and BusinessRules data fields in the
 * D-data structure are going to display as empty when printing out the D data structure even when using JSON.stringify().
 * This is because the functions cannot really be serialized in any way. It actually kind of makes sense,
 * but could be really confusing if you are struggling trying to debug commands or business rules that do not appear to exist.
 */

function initCommandsLibrary() {
  var _D$wr1$cCommands;

  var functionName = initCommandsLibrary.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _data["default"][wr1.cCommands] = {};
  _data["default"][wr1.cCommands] = (_D$wr1$cCommands = {}, _defineProperty(_D$wr1$cCommands, cmd.cechoCommand, function (inputData, inputMetaData) {
    return _nominal["default"].echoCommand(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, wr1.cexit, function (inputData, inputMetData) {
    return _nominal["default"].exit(inputData, inputMetData);
  }), _defineProperty(_D$wr1$cCommands, wr1.cversion, function (inputData, inputMetaData) {
    return _nominal["default"].version(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, wr1.cabout, function (inputData, inputMetaData) {
    return _nominal["default"].about(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, wr1.cname, function (inputData, inputMetaData) {
    return _nominal["default"].name(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cclearScreen, function (inputData, inputMetaData) {
    return _nominal["default"].clearScreen(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, wr1.chelp, function (inputData, inputMetaData) {
    return _nominal["default"].help(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cworkflowHelp, function (inputData, inputMetaData) {
    return _nominal["default"].workflowHelp(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.ccommandSequencer, function (inputData, inputMetaData) {
    return _nominal["default"].commandSequencer(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, wr1.cworkflow, function (inputData, inputMetaData) {
    return _nominal["default"].workflow(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cprintDataHive, function (inputData, inputMetaData) {
    return _nominal["default"].printDataHive(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cprintDataHiveAttributes, function (inputData, inputMetaData) {
    return _nominal["default"].printDataHiveAttributes(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cclearDataStorage, function (inputData, inputMetaData) {
    return _nominal["default"].clearDataStorage(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cbusinessRule, function (inputData, inputMetaData) {
    return _nominal["default"].businessRule(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.ccommandGenerator, function (inputData, inputMetaData) {
    return _nominal["default"].commandGenerator(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.ccommandAliasGenerator, function (inputData, inputMetaData) {
    return _nominal["default"].commandAliasGenerator(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cconstantsGenerator, function (inputData, inputMetaData) {
    return _nominal["default"].constantsGenerator(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cconstantsGeneratorList, function (inputData, inputMetaData) {
    return _nominal["default"].constantsGeneratorList(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cconstantsPatternRecognizer, function (inputData, inputMetaData) {
    return _nominal["default"].constantsPatternRecognizer(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cbusinessRulesMetrics, function (inputData, inputMetaData) {
    return _nominal["default"].businessRulesMetrics(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.ccommandMetrics, function (inputData, inputMetaData) {
    return _nominal["default"].commandMetrics(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.csaveConfiguration, function (inputData, inputMetaData) {
    return _nominal["default"].saveConfiguration(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cconvertColors, function (inputData, inputMetaData) {
    return _nominal["default"].convertColors(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cvalidateConstants, function (inputData, inputMetaData) {
    return _integrationTests["default"].validateConstants(inputData, inputMetaData);
  }), _defineProperty(_D$wr1$cCommands, cmd.cvalidateCommandAliases, function (inputData, inputMetaData) {
    return _integrationTests["default"].validateCommandAliases(inputData, inputMetaData);
  }), _D$wr1$cCommands);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;

var _default = _defineProperty({}, fnc.cinitCommandsLibrary, function () {
  return initCommandsLibrary();
});

exports["default"] = _default;