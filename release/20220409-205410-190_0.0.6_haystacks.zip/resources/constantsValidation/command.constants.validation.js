"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.commandConstantsValidation = void 0;

var cmd = _interopRequireWildcard(require("../../constants/command.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file command.constants.validation.js
 * @module command.constants.validation
 * @description Contains all validations for system command constants.
 * @requires module:command.constants
 * @date 2022/03/20
 * @copyright Copyright © 2022-… by Seth Hollingsead. All rights reserved
 */
// Internal imports

/**
 * @function commandConstantsValidation
 * @description Initializes the command constants validation data objects array.
 * @return {void}
 * @author Seth Hollingsead
 * @DATE 2022/03/20
 */
var commandConstantsValidation = [// Generic Commands constants
// ***********************************************
// Nominal commands in order
// ***********************************************
{
  Name: 'cechoCommand',
  Actual: cmd.cechoCommand,
  Expected: 'echoCommand'
}, {
  Name: 'cEchoCommand',
  Actual: cmd.cEchoCommand,
  Expected: 'EchoCommand'
}, {
  Name: 'cclearScreen',
  Actual: cmd.cclearScreen,
  Expected: 'clearScreen'
}, {
  Name: 'cworkflowHelp',
  Actual: cmd.cworkflowHelp,
  Expected: 'workflowHelp'
}, {
  Name: 'ccommandSequencer',
  Actual: cmd.ccommandSequencer,
  Expected: 'commandSequencer'
}, {
  Name: 'cprintDataHive',
  Actual: cmd.cprintDataHive,
  Expected: 'printDataHive'
}, {
  Name: 'cprintDataHiveAttributes',
  Actual: cmd.cprintDataHiveAttributes,
  Expected: 'printDataHiveAttributes'
}, {
  Name: 'cclearDataStorage',
  Actual: cmd.cclearDataStorage,
  Expected: 'clearDataStorage'
}, {
  Name: 'cbusinessRule',
  Actual: cmd.cbusinessRule,
  Expected: 'businessRule'
}, {
  Name: 'ccommandGenerator',
  Actual: cmd.ccommandGenerator,
  Expected: 'commandGenerator'
}, {
  Name: 'ccommandAliasGenerator',
  Actual: cmd.ccommandAliasGenerator,
  Expected: 'commandAliasGenerator'
}, {
  Name: 'cconstantsGenerator',
  Actual: cmd.cconstantsGenerator,
  Expected: 'constantsGenerator'
}, {
  Name: 'cconstantsGeneratorList',
  Actual: cmd.cconstantsGeneratorList,
  Expected: 'constantsGeneratorList'
}, {
  Name: 'cconstantsPatternRecognizer',
  Actual: cmd.cconstantsPatternRecognizer,
  Expected: 'constantsPatternRecognizer'
}, {
  Name: 'cbusinessRulesMetrics',
  Actual: cmd.cbusinessRulesMetrics,
  Expected: 'businessRulesMetrics'
}, {
  Name: 'ccommandMetrics',
  Actual: cmd.ccommandMetrics,
  Expected: 'commandMetrics'
}, {
  Name: 'csaveConfiguration',
  Actual: cmd.csaveConfiguration,
  Expected: 'saveConfiguration'
}, {
  Name: 'cconvertColors',
  Actual: cmd.cconvertColors,
  Expected: 'convertColors'
}, // ***********************************************
// Integration Test commands in order
// ***********************************************
{
  Name: 'cvalidateConstants',
  Actual: cmd.cvalidateConstants,
  Expected: 'validateConstants'
}, {
  Name: 'cvalidateCommandAliases',
  Actual: cmd.cvalidateCommandAliases,
  Expected: 'validateCommandAliases'
}, // ********************************
// System defined workflows
// ********************************
{
  Name: 'cStartupWorkflow',
  Actual: cmd.cStartupWorkflow,
  Expected: 'Workflow startup'
}, {
  Name: 'cFrameworkDetailsWorkflow',
  Actual: cmd.cFrameworkDetailsWorkflow,
  Expected: 'Workflow frameworkDetails'
}];
exports.commandConstantsValidation = commandConstantsValidation;