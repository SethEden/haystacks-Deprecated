"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.languageConstantsValidation = void 0;

var lng = _interopRequireWildcard(require("../../constants/language.constants.js"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/**
 * @file language.constants.validation.js
 * @module language.constants.validation
 * @description Contains all validations for named language constants.
 * @requires module:language.constants
 * @author Seth Hollingsead
 * @date 2022/03/20
 * @copyright Copyright © 2022-… by Seth Hollingsead. All rights reserved
 */
// Internal imports

/**
 * @function languageConstantsValidation
 * @description Initializes the language constants validation data objects array.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/03/20
 */
var languageConstantsValidation = [// Languages
{
  Name: 'cChinese',
  Actual: lng.cChinese,
  Expected: 'Chinese'
}, {
  Name: 'cChineseSimplified',
  Actual: lng.cChineseSimplified,
  Expected: 'ChineseSimplified'
}, {
  Name: 'cChineseTraditional',
  Actual: lng.cChineseTraditional,
  Expected: 'ChineseTraditional'
}, {
  Name: 'cCzech',
  Actual: lng.cCzech,
  Expected: 'Czech'
}, {
  Name: 'cEnglish',
  Actual: lng.cEnglish,
  Expected: 'English'
}, {
  Name: 'cFrench',
  Actual: lng.cFrench,
  Expected: 'French'
}, {
  Name: 'cHungarian',
  Actual: lng.cHungarian,
  Expected: 'Hungarian'
}, {
  Name: 'cItalian',
  Actual: lng.cItalian,
  Expected: 'Italian'
}, {
  Name: 'cJapanese',
  Actual: lng.cJapanese,
  Expected: 'Japanese'
}, {
  Name: 'cKorean',
  Actual: lng.cKorean,
  Expected: 'Korean'
}, {
  Name: 'cMiscellaneous',
  Actual: lng.cMiscellaneous,
  Expected: 'Miscellaneous'
}, {
  Name: 'cPolish',
  Actual: lng.cPolish,
  Expected: 'Polish'
}, {
  Name: 'cPortuguese',
  Actual: lng.cPortuguese,
  Expected: 'Portuguese'
}, {
  Name: 'cRussian',
  Actual: lng.cRussian,
  Expected: 'Russian'
}, {
  Name: 'cSpanish',
  Actual: lng.cSpanish,
  Expected: 'Spanish'
}];
exports.languageConstantsValidation = languageConstantsValidation;