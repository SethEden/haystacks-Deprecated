"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var gen = _interopRequireWildcard(require("../constants/generic.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _loggers = _interopRequireDefault(require("./loggers.js"));

var _fs = _interopRequireDefault(require("fs"));

var _path = _interopRequireDefault(require("path"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // executrix.prompt.


var namespacePrefix = wr1.cexecutrix + bas.cDot + baseFileName + bas.cDot;
var term = 13; // carriage return

/**
 * @function prompt
 * @description Prompts the user for some input and returns the input.
 * @param {string} ask What the prompt should display when asking the user for input.
 * @return {string} A string of whatever input the user gave.
 * @author Seth Hollingsead
 * @date 2021/10/26
 */

function prompt(ask) {
  var functionName = prompt.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`ask is: ${JSON.stringify(ask)}`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.caskIs + JSON.stringify(ask));

  var input = '';

  if (ask) {
    process.stdout.write(ask);
  }

  var buffer = Buffer.alloc(1024),
      fd = process.platform === gen.cwin32 ? process.stdin.fd : _fs["default"].openSync(sys.cdevtty, bas.cr),
      //readSize = fs.readSync(fd, buffer, 0, 1024);
  readSize = _fs["default"].readSync(0, buffer, 0, 1024); // console.log('INPUT: ' + buffer.toString('utf8', 0, readSize));


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cINPUT + buffer.toString(gen.cUTF8, 0, readSize));

  input = buffer.toString(gen.cUTF8, 0, readSize);

  if (input.includes(String.fromCharCode(term))) {
    // console.log('Caught the case that the input string contains the global carriage return term.')
    // console.log('index of the carriage return character: ' + input.indexOf(String.fromCharCode(term)));
    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cprompt01);

    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cprompt02 + input.indexOf(String.fromCharCode(term)));

    input = input.slice(0, input.indexOf(String.fromCharCode(term)));
  } else if (input.includes(bas.cCarriageReturn + bas.cNewLine)) {
    // console.log('Caught the case that the string includes a carriage return and new line characters.');
    _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cprompt03);

    input = input.slice(0, input.indexOf(bas.cCarriageReturn + bas.cNewLine));
  }

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cinputIs + JSON.stringify(input));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function); // console.log(`input is: ${JSON.stringify(input)}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return input;
}

;

var _default = _defineProperty({}, fnc.cprompt, function (ask) {
  return prompt(ask);
});

exports["default"] = _default;