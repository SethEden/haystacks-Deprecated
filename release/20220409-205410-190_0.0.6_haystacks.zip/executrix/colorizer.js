"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _ruleBroker = _interopRequireDefault(require("../brokers/ruleBroker.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var clr = _interopRequireWildcard(require("../constants/color.constants.js"));

var cfg = _interopRequireWildcard(require("../constants/configuration.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _configurator = _interopRequireDefault(require("../executrix/configurator.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _chalk = _interopRequireDefault(require("chalk"));

var _path = _interopRequireDefault(require("path"));

var _fnc$ccolorizeMessage;

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // executrix.colorizer.


var namespacePrefix = wr1.cexecutrix + bas.cDot + baseFileName + bas.cDot;
/**
 * @function colorizeMessageSimple
 * @description Applies a color setting to an entire message, according to the inputs, background or foreground font color settings.
 * @param {string} message The message that should be formatted and returned according to the inputs, and controlled by the system configuration setting.
 * @param {array<integers>} colorArray The RGB color array that describes the color that should be applied to the message.
 * @param {boolean} isForeground A True or False to indicate if the color setting should be applied to the foreground or not.
 * If False, then apply to the background.
 * @return {string} The message with the color setting applied.
 * @author Seth Hollingsead
 * @date 2022/03/29
 */

function colorizeMessageSimple(message, colorArray, isForeground) {
  var functionName = colorizeMessageSimple.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`message is: ${message}`);
  // console.log(`colorArray is: ${JSON.stringify(colorArray)}`);
  // console.log(`isForeground is: ${isForeground}`);

  var colorizedMessage = message;

  var colorizeLogsEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableColorizedConsoleLogs);

  if (colorizeLogsEnabled === true) {
    var red = colorArray[0];
    var green = colorArray[1];
    var blue = colorArray[2];

    if (isForeground === true) {
      colorizedMessage = _chalk["default"].rgb(red, green, blue)(colorizedMessage);
    } else {
      colorizedMessage = _chalk["default"].bgRgb(red, green, blue)(colorizedMessage);
    }
  } // console.log('colorizedMessage is: ' + colorizedMessage);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return colorizedMessage;
}

;
/**
 * @function colorizeMessage
 * @description Applies color settings to various portions of the message according to the settings from the configuration system.
 * @param {string} message The message that should be formatted and returned to be logged to the console and/or logged to a log file.
 * @param {string} className The name of the module/file that made the log call.
 * @param {string} functionName The name of the function that made the log call.
 * @param {boolean} debugFilesSetting A True or False value to indicate if the log should happen according to the file/module name.
 * Setting is set in the configuration/settings system.
 * @param {boolean} debugFunctionsSetting A True or False value to indicate if the log should happen according to the function/method name.
 * Setting is set in the configuration/settings system.
 * @param {boolean} flatMessageLog A True or False value to indicate if we are logging a flat message or if we should do additional processing.
 * We will probably do some additional processing either way, but there is a difference in the workflows.
 * For one a non-flat message will certainly have to replace a "%%" ith the class path (className,functionName),
 * and the associated formatting that goes with that according to the settings.
 * @return {string} A colorized version of the message.
 * @author Seth Hollingsead
 * @date 2022/01/28
 */

function colorizeMessage(message, className, callerFunctionName, debugFilesSetting, debugFunctionsSetting, flatMessageLog) {
  var functionName = colorizeMessage.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`message is: ${message}`);
  // console.log(`className is: ${className}`);
  // console.log(`callerFunctionName is: ${callerFunctionName}`);
  // console.log(`debugFilesSetting is: ${debugFilesSetting}`);
  // console.log(`debugFunctionsSetting is: ${debugFunctionsSetting}`);
  // console.log(`flatMessageLog is: ${flatMessageLog}`);

  var classPath = className + bas.cDot + callerFunctionName;
  var colorizedMessage;
  var messageContent;
  var messageContentPrefix;
  var messageContentSuffix;
  var messageData;
  var processingMessageData = false;
  var debugFilesModuleFontStyleSetting = wr1.cDefault;
  var debugFilesFunctionFontStyleSetting = wr1.cDefault;
  var debugFilesMessageFontStyleSetting = wr1.cDefault;
  var debugFilesDataFontStyleSetting = wr1.cDefault;
  var debugFilesModuleFontColorSetting = wr1.cDefault;
  var debugFilesFunctionFontColorSetting = wr1.cDefault;
  var debugFilesMessageFontColorSetting = wr1.cDefault;
  var debugFilesDataFontColorSetting = wr1.cDefault;
  var debugFilesModuleFontBackgroundColorSetting = wr1.cDefault;
  var debugFilesFunctionFontBackgroundColorSetting = wr1.cDefault;
  var debugFilesMessageFontBackgroundColorSetting = wr1.cDefault;
  var debugFilesDataFontBackgroundColorSetting = wr1.cDefault;
  var debugFunctionsModuleFontStyleSetting = wr1.cDefault;
  var debugFunctionsFunctionFontStyleSetting = wr1.cDefault;
  var debugFunctionsMessageFontStyleSetting = wr1.cDefault;
  var debugFunctionsDataFontStyleSetting = wr1.cDefault;
  var debugFunctionsModuleFontColorSetting = wr1.cDefault;
  var debugFunctionsFunctionFontColorSetting = wr1.cDefault;
  var debugFunctionsMessageFontColorSetting = wr1.cDefaul;
  var debugFunctionsDataFontColorSetting = wr1.cDefault;
  var debugFunctionsModuleFontBackgroundColorSetting = wr1.cDefault;
  var debugFunctionsFunctionFontBackgroundColorSetting = wr1.cDefault;
  var debugFunctionsMessageFontBackgroundColorSetting = wr1.cDefault;
  var debugFunctionsDataFontBackgroundColorSetting = wr1.cDefault; // We need a 3rd set of variables because we wil need to aggregate these settings together to determine which ones are in effect.
  // One way is to aggregate each setting individually and let which ever one is defined be in effect.
  // Another way is to let the master debug functions and/or debug files setting be the controlling factor.
  // However, if both of them are set to true then we should default to deterien which one is in effect from either one.
  // This will also let us do additional processing on the values that come from the settings file.
  // Because some of those settings like the colros and the font styles might have multiple sub-settings.
  // The color setting will of course have R,G,B; And the style setting might have Bold|Underline, so we will of curse have to parse those out.

  var aggregateModuleFontStyleUnderline = false;
  var aggregateModuleFontStyleBold = false;
  var aggregateFunctionFontStyleUnderline = false;
  var aggregateFunctionFontStyleBold = false;
  var aggregateMessageFontStyleUnderline = false;
  var aggregateMessageFontStyleBold = false;
  var aggregateDataFontStyleUnderline = false;
  var aggregateDataFontStyleBold = false;
  var aggregateModuleFontColorSetting = {};
  var aggregateFunctionFontColorSetting = {};
  var aggregateMessageFontColorSetting = {};
  var aggregateDataFontColorSetting = {};
  var aggregateModuleFontBackgroundColorSetting = {};
  var aggregateFunctionFontBackgroundColorSetting = {};
  var aggregateMessageFontBackgroundColorSetting = {};
  var aggregateDataFontBackgroundColorSetting = {};
  var aggregateUnderlineBoldArray = [];
  var messageBrokenDown = []; // debugFunctionsSetting = configurator.getConfigurationSetting(cfg.cdebugSetting + bas.cDot + configurationNamespace, configurationName);

  debugFilesModuleFontStyleSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cModuleFontStyle); // console.log('debugFilesModuleFontStyleSetting is: ' + debugFilesModuleFontStyleSetting);

  debugFilesFunctionFontStyleSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cFunctionFontStyle); // console.log('debugFilesFunctionFontStyleSetting is: ' + debugFilesFunctionFontStyleSetting);

  debugFilesMessageFontStyleSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cMessageFontStyle); // console.log('debugFilesMessageFontStyleSetting is: ' + debugFilesMessageFontStyleSetting);

  debugFilesDataFontStyleSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cDataFontStyle); // console.log('debugFilesDataFontStyleSetting is: ' + debugFilesDataFontStyleSetting);

  debugFilesModuleFontColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cModuleFontColor); // console.log('debugFilesModuleFontColorSetting is: ' + debugFilesModuleFontColorSetting);

  debugFilesFunctionFontColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cFunctionFontColor); // console.log('debugFilesFunctionFontColorSetting is: ' + debugFilesFunctionFontColorSetting);

  debugFilesMessageFontColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cMessageFontColor); // console.log('debugFilesMessageFontColorSetting is: ' + debugFilesMessageFontColorSetting);

  debugFilesDataFontColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cDataFontColor); // console.log('debugFilesDataFontColorSetting is: ' + debugFilesDataFontColorSetting);

  debugFilesModuleFontBackgroundColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cModuleFontBackgroundColor); // console.log('debugFilesModuleFontBackgroundColorSetting is: ' + debugFilesModuleFontBackgroundColorSetting);

  debugFilesFunctionFontBackgroundColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cFunctionFontBackgroundColor); // console.log('debugFilesFunctionFontBackgroundColorSetting is: ' + debugFilesFunctionFontBackgroundColorSetting);

  debugFilesMessageFontBackgroundColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cMessageFontBackgroundColor); // console.log('debugFilesMessageFontBackgroundColorSetting is: ' + debugFilesMessageFontBackgroundColorSetting);

  debugFilesDataFontBackgroundColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, bas.cAt + sys.cDataFontBackgroundColor); // console.log('debugFilesDataFontBackgroundColorSetting is: ' + debugFilesDataFontBackgroundColorSetting);

  debugFunctionsModuleFontStyleSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cModuleFontStyle); // console.log('debugFunctionsModuleFontStyleSetting is: ' + debugFunctionsModuleFontStyleSetting);

  debugFunctionsFunctionFontStyleSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cFunctionFontStyle); // console.log('debugFunctionsFunctionFontStyleSetting is: ' + debugFunctionsFunctionFontStyleSetting);

  debugFunctionsMessageFontStyleSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cMessageFontStyle); // console.log('debugFunctionsMessageFontStyleSetting is: ' + debugFunctionsMessageFontStyleSetting);

  debugFunctionsDataFontStyleSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cDataFontStyle); // console.log('debugFunctionsDataFontStyleSetting is: ' + debugFunctionsDataFontStyleSetting);

  debugFunctionsModuleFontColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cModuleFontColor); // console.log('debugFunctionsModuleFontCoorSetting is: ' + debugFunctionsModuleFontColorSetting);

  debugFunctionsFunctionFontColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cFunctionFontColor); // console.log('debugFunctionsFunctionFontColorSetting is: ' + debugFunctionsFunctionFontColorSetting);

  debugFunctionsMessageFontColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cMessageFontColor); // console.log('debugFunctionsMessageFontColorSetting is: ' + debugFunctionsMessageFontColorSetting);

  debugFunctionsDataFontColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cDataFontColor); // console.log('debugFunctionsDataFontColorSetting is: ' + debugFunctionsDataFontColorSetting);

  debugFunctionsModuleFontBackgroundColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cModuleFontBackgroundColor); // console.log('debugFunctionsModuleFontBackgroundColorSetting is: ' + debugFunctionsModuleFontBackgroundColorSetting);

  debugFunctionsFunctionFontBackgroundColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cFunctionFontBackgroundColor); // console.log('debugFunctionsFunctionFontBackgroundColorSetting is: ' + debugFunctionsFunctionFontBackgroundColorSetting);

  debugFunctionsMessageFontBackgroundColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cMessageFontBackgroundColor); // console.log('debugFunctionsMessageFontBackgroundColorSetting is: ' + debugFunctionsMessageFontBackgroundColorSetting);

  debugFunctionsDataFontBackgroundColorSetting = _configurator["default"].getConfigurationSetting(cfg.cdebugSetting + bas.cDot + className, callerFunctionName + bas.cAt + sys.cDataFontBackgroundColor); // console.log('debugFunctionsDataFontBackgroundColorSetting is: ' + debugFunctionsDataFontBackgroundColorSetting);

  aggregateUnderlineBoldArray = aggregateStyleSetting(debugFilesModuleFontStyleSetting, debugFunctionsModuleFontStyleSetting, true);
  aggregateModuleFontStyleUnderline = aggregateUnderlineBoldArray[0];
  aggregateModuleFontStyleBold = aggregateUnderlineBoldArray[1];
  aggregateUnderlineBoldArray = [];
  aggregateUnderlineBoldArray = aggregateStyleSetting(debugFilesFunctionFontStyleSetting, debugFunctionsFunctionFontStyleSetting, true);
  aggregateFunctionFontStyleUnderline;
  aggregateFunctionFontStyleUnderline = aggregateUnderlineBoldArray[0];
  aggregateFunctionFontStyleBold = aggregateUnderlineBoldArray[1];
  aggregateUnderlineBoldArray = [];
  aggregateUnderlineBoldArray = aggregateStyleSetting(debugFilesMessageFontStyleSetting, debugFunctionsMessageFontStyleSetting, true);
  aggregateMessageFontStyleUnderline = aggregateUnderlineBoldArray[0];
  aggregateMessageFontStyleBold = aggregateUnderlineBoldArray[1];
  aggregateUnderlineBoldArray = [];
  aggregateUnderlineBoldArray = aggregateStyleSetting(debugFilesDataFontStyleSetting, debugFunctionsDataFontStyleSetting, true);
  aggregateDataFontStyleUnderline = aggregateUnderlineBoldArray[0];
  aggregateDataFontStyleBold = aggregateUnderlineBoldArray[1];
  aggregateUnderlineBoldArray = [];
  aggregateModuleFontColorSetting = aggregateStyleSetting(debugFilesModuleFontColorSetting, debugFunctionsModuleFontColorSetting, [0, 255, 255], false);
  aggregateFunctionFontColorSetting = aggregateStyleSetting(debugFilesFunctionFontColorSetting, debugFunctionsFunctionFontColorSetting, [0, 255, 255], false);
  aggregateMessageFontColorSetting = aggregateStyleSetting(debugFilesMessageFontColorSetting, debugFunctionsMessageFontColorSetting, [0, 255, 255], false);
  aggregateDataFontColorSetting = aggregateStyleSetting(debugFilesDataFontColorSetting, debugFunctionsDataFontColorSetting, [0, 255, 255], false);
  aggregateModuleFontBackgroundColorSetting = aggregateStyleSetting(debugFilesModuleFontBackgroundColorSetting, debugFunctionsModuleFontBackgroundColorSetting, [0, 0, 0], false);
  aggregateFunctionFontBackgroundColorSetting = aggregateStyleSetting(debugFilesFunctionFontBackgroundColorSetting, debugFunctionsFunctionFontBackgroundColorSetting, [0, 0, 0], false);
  aggregateMessageFontBackgroundColorSetting = aggregateStyleSetting(debugFilesMessageFontBackgroundColorSetting, debugFunctionsMessageFontBackgroundColorSetting, [0, 0, 0], false);
  aggregateDataFontBackgroundColorSetting = aggregateStyleSetting(debugFilesDataFontBackgroundColorSetting, debugFunctionsDataFontBackgroundColorSetting, [0, 0, 0], false);

  if (message.includes(bas.cColon) === true) {
    messageBrokenDown = message.split(/:(.+)/); // Use regular expression to split on the first isntance of ":" ONLY!

    messageContent = messageBrokenDown[0];
    messageData = messageBrokenDown[1];
    processingMessageData = true;
  } else {
    messageContent = message;
    processingMessageData = false;
  } // "good_luck_buddy".split(/_(.+)/)[1]
  // @see https://stackoverflow.com/questions/4607745/split-string-only-on-first-instance-of-specified-character


  if (flatMessageLog === false) {
    // console.log('processing flatMessageLot === false');
    if (messageContent.includes(bas.cDoublePercent) === true) {
      messageContentPrefix = messageContent.split(bas.cSpace)[0];
      messageContentSuffix = messageContent.split(bas.cSpace)[2];
    }

    className = setUnderlineFontStyleOnMessageComponentAccordingToSetting(className, aggregateModuleFontStyleUnderline);
    className = setBoldFontStyleOnMessageComponentAccordingToSetting(className, aggregateModuleFontStyleBold); // console.log('Done processing underline & bold settings: className is: ' + className);

    callerFunctionName = setUnderlineFontStyleOnMessageComponentAccordingToSetting(callerFunctionName, aggregateFunctionFontStyleUnderline);
    callerFunctionName = setBoldFontStyleOnMessageComponentAccordingToSetting(callerFunctionName, aggregateFunctionFontStyleBold); // console.log('Done processing underline & bold settings: callerFunctionName is: ' + callerFunctionName);

    if (messageContent.includes(bas.cDoublePercent) === true) {
      messageContent = setUnderlineFontStyleOnMessageComponentAccordingToSetting(messageContent, aggregateMessageFontStyleUnderline);
      messageContentPrefix = setBoldFontStyleOnMessageComponentAccordingToSetting(messageContentPrefix, aggregateMessageFontStyleBold);
      messageContentSuffix = setUnderlineFontStyleOnMessageComponentAccordingToSetting(messageContentSuffix, aggregateMessageFontStyleUnderline);
      messageContentSuffix = setBoldFontStyleOnMessageComponentAccordingToSetting(messageContentSuffix, aggregateMessageFontStyleBold);
      messageContentPrefix = setFontForegroundColorOnMessageComponentAccordingToSetting(messageContentPrefix, aggregateMessageFontColorSetting);
      messageContentSuffix = setFontForegroundColorOnMessageComponentAccordingToSetting(messageContentSuffix, aggregateMessageFontColorSetting);
      messageContentPrefix = setFontBackgroundColorOnMessageComponentAccordingToSetting(messageContentPrefix, aggregateMessageFontBackgroundColorSetting);
      messageContentSuffix = setFontBackgroundColorOnMessageComponentAccordingToSetting(messageContentSuffix, aggregateMessageFontBackgroundColorSetting);
    } else {
      messageContent = setUnderlineFontStyleOnMessageComponentAccordingToSetting(messageContent, aggregateMessageFontStyleUnderline);
      messageContent = setBoldFontStyleOnMessageComponentAccordingToSetting(messageContent, aggregateMessageFontStyleBold); // console.log('Done processing underline & bold settings: messageContent is: ' + messageContent);

      if (processingMessageData === true) {
        messageData = setUnderlineFontStyleOnMessageComponentAccordingToSetting(messageData, aggregateDataFontStyleUnderline);
        messageData = setBoldFontStyleOnMessageComponentAccordingToSetting(messageData, aggregateDataFontStyleBold);
      }

      messageContent = setFontForegroundColorOnMessageComponentAccordingToSetting(messageContent, aggregateMessageFontColorSetting); // console.log('Done processing foreground color settings: emssageContent is: ' + messageContent);

      messageContent = setFontBackgroundColorOnMessageComponentAccordingToSetting(messageContent, aggregateMessageFontBackgroundColorSetting); // console.log('Done processing background color settings: messageContent is: ' + messageContent);
    }

    className = setFontForegroundColorOnMessageComponentAccordingToSetting(className, aggregateModuleFontColorSetting); // console.log('Done processing foreground color settings: className is: ' + className);

    callerFunctionName = setFontForegroundColorOnMessageComponentAccordingToSetting(callerFunctionName, aggregateFunctionFontColorSetting); // console.log('Done processing foreground coor settings: callerFunctionName is: ' + callerFunctionName);

    className = setFontBackgroundColorOnMessageComponentAccordingToSetting(className, aggregateModuleFontBackgroundColorSetting); // console.log('Done processing background color settings: className is: ' + className);

    callerFunctionName = setFontBackgroundColorOnMessageComponentAccordingToSetting(callerFunctionName, aggregateFunctionFontBackgroundColorSetting); // console.log('Done processing background color settings: callerFunctionName is: ' + callerFunctionName);

    if (processingMessageData === true) {
      messageData = setFontForegroundColorOnMessageComponentAccordingToSetting(messageData, aggregateDataFontColorSetting);
      messageData = setFontBackgroundColorOnMessageComponentAccordingToSetting(messageData, aggregateDataFontBackgroundColorSetting);
    }

    if (messageContent.includes(bas.cDoublePercent) === true) {
      colorizedMessage = messageContentPrefix + bas.cSpace + className + bas.cDot + callerFunctionName + bas.cSpace + messageContentSuffix;
    } else if (messageData !== undefined) {
      colorizedMessage = messageContent + bas.cColon + messageData;
    } else {
      colorizedMessage = messageContent;
    }
  } else if (flatMessageLog === true) {
    messageContent = setUnderlineFontStyleOnMessageComponentAccordingToSetting(messageContent, aggregateMessageFontStyleUnderline);
    messageContent = setBoldFontStyleOnMessageComponentAccordingToSetting(messageContent, aggregateMessageFontStyleBold);

    if (processingMessageData === true) {
      // console.log('Attempting to format the message data componenet of the message: ' + messageData);
      messageData = setUnderlineFontStyleOnMessageComponentAccordingToSetting(messageData, aggregateDataFontStyleUnderline);
      messageData = setBoldFontStyleOnMessageComponentAccordingToSetting(messageData, aggregateDataFontStyleBold);
      messageData = setFontForegroundColorOnMessageComponentAccordingToSetting(messageData, aggregateDataFontColorSetting);
      messageData = setFontBackgroundColorOnMessageComponentAccordingToSetting(messageData, aggregateDoataFontBackgroundColorSetting); // console.log('Done formatting all of the messageData: ' + messageData);
    }

    messageContent = setFontForegroundColorOnMessageComponentAccordingToSetting(messageContent, aggregateMessageFontColorSetting);
    messageContent = setFontBackgroundColorOnMessageComponentAccordingToSetting(callerFunctionName, aggregateMessageFontBackgroundColorSetting);
    colorizedMessage = messageContent + bas.cColon + messageData;
  } else {
    // Just return the message as we got it and make sure it gets out!
    colorizedMessage = message; // Don't apply any colorizing to the default. We are not likely to hit this case anyway!!
  } // console.log('colorizedMessage is: ' + colorizedMessage);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return colorizedMessage;
}

;
/**
 * @function aggregateStyleSetting
 * @description Compares the two input settings and determines which one of them is valuable or not valuable.
 * @param {string} settingValue1 The file level setting from the configuration file.
 * @param {string} settingValue2 The function level setting from the configuration file.
 * @param {array<integer>} defaultColorArray The default color value that should be used.
 * @param {boolean} processAsFontSetting A True or False value to indicate if we are processing True = font setting, False = coor setting.
 * @return {array<boolean>} An array of booleans, [0] = underline setting True or False; [1] = bold setting True or False.
 * @author Seth Hollingsead
 * @date 2022/01/31
 */

function aggregateStyleSetting(settingValue1, settingValue2, defaultColorArray, processAsFontSetting) {
  var functionName = aggregateStyleSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`settingValue1 is: ${settingValue1}`);
  // console.log(`settingValue2 is: ${settingValue2}`);
  // console.log(`processAsFontSetting is: ${processAsFontSetting}`);

  var styles = [];

  if ((settingValue1 !== wr1.cDefault || settingValue2 !== wr1.cDefault) && (settingValue1 !== undefined || settingValue2 !== undefined)) {
    if (settingValue1 !== wr1.cDefault && settingValue2 === wr1.cDefault || settingValue1 !== undefined && settingValue2 === undefined) {
      if (processAsFontSetting === true) {
        styles = getFontStyleSettingsFromSetting(settingValue1);
      } else {
        styles = getColorStyleSettingFromSetting(settingValue1, defaultColorArray);
      }
    } else if (settingValue1 === wr1.cDefault && settingValue2 !== wr1.cDefault || settingValue1 === undefined && settingValue2 !== undefined) {
      if (processAsFontSetting === true) {
        styles = getFontStyleSettingsFromSetting(settingValue2);
      } else {
        styles = getColorStyleSettingFromSetting(settingValue2, defaultColorArray);
      }
    } else {
      // They both must be NOT default, so we set the aggregate value to the function setting.
      if (processAsFontSetting === true) {
        styles = getFontStyleSettingsFromSetting(settingValue2);
      } else {
        styles = getColorStyleSettingFromSetting(settingValue2, defaultColorArray);
      }
    }
  } // End-if ((settingValue1 !== wr1.cDefault || settingValue2 !== wr1.cDefault) && (settingValue1 !== undefined || settingValue2 !== undefined))
  // console.log('styles is: ' + JSON.stringify(styles));
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return styles;
}

;
/**
 * @function getFontStyleSettingsFromSetting
 * @description Parses the font setting to determine if values should be set for bold and/or underline.
 * @param {string} settingValue The setting value that should be parsed.
 * @return {array<boolean>} An array of booleans, [0] = underine setting True or False; [1] = bold setting True or False.
 * @author Seth Hollingsead
 * @date 2022/01/31
 */

function getFontStyleSettingsFromSetting(settingValue) {
  var functionName = getFontStyleSettingsFromSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`settingValue is: ${settingValue}`);

  var fontStyles = [false, false];
  var aggregateUnderlineBoldArray = [];

  if (settingValue.includes(bas.cPipe) === true) {
    if (settingValue.includes(bas.cPipe) === true) {
      aggregateUnderlineBoldArray = settingValue.split(bas.cPipe); // console.log('aggregateUnderlineBoldArray is: ' + JSON.stringify(aggregateUnderlineBoldArray));
      // console.log('aggregateUnderlineBoldArray[0] is: ' + aggregateUnderlineBoldArray[0]);
      // console.log('aggregateUnderlineBoldArray[1] is: ' + aggregateUnderlineBoldArray[1]);

      if (aggregateUnderlineBoldArray[0] === wr1.cUnderline && aggregateUnderlineBoldArray[1] === wr1.cBold) {
        // aggregateModuleFontStyleUnderline = true;
        // aggregateModuleFontStyleBold = true;
        fontStyles[(true, true)];
      } else if (aggregateUnderlineBoldArray[0] === wr1.cBold && aggregateUnderlineBoldArray[1] === wr1.cUnderline) {
        // aggregateModuleFontStyleUnderline = true;
        // aggregateModuleFontStyleBold = true;
        fontStyles[(true, true)];
      } else if (aggregateUnderlineBoldArray[0] === wr1.cUnderline && aggregateUnderlineBoldArray[1] !== wr1.cBold) {
        // aggregateModuleFontStyleUnderline = true;
        fontStyles[(true, false)];
      } else if (aggregateUnderlineBoldArray[0] === wr1.cBold && aggregateUnderlineBoldArray[1] !== wr1.cUnderline) {
        // aggregateModuleFontStyleBold = true;
        fontStyles[(false, true)];
      } else {
        console.log('ERROR: Did not find any matching style logic pattern!');
      }
    } else if (settingValue === wr1.cUnderline) {
      // aggregateModuleFontStyleUnderline = true;
      fontStyles[(true, false)];
    } else if (settingValue === wr1.cBold) {
      // aggregateModuleFontStyleBold = true;
      fontStyles[(false, true)];
    }
  } // End-if (settingValue.includes(bas.cPipe) === true)
  // console.log('fontStyles is: ' + JSON.stringify(fontStyles));
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return fontStyles;
}

;
/**
 * @function getColorStyleSettingFromSetting
 * @description Parses the color setting to determine if the alue should be parsed or loaded from the color data tables by unique color name.
 * @param {string} settingValue The setting value, which could be RGB as in R,G,B or it could be a string-name as in a unique color name.
 * @param {array<integer>} defaultColorArray The default color value that should be used.
 * @return {object} A JSON object with three integers that represent RGB values, labeled as "Red", "Green", "Blue".
 * @author Seth Hollingsead
 * @date 2022/01/31
 */

function getColorStyleSettingFromSetting(settingValue, defaultColorArray) {
  var functionName = getColorStyleSettingFromSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`settingValue is: ${settingValue}`);

  var colorStyle = {
    Red: 0,
    Green: 0,
    Blue: 0
  };
  var aggregateColorArray = [];

  if (settingValue !== undefined) {
    if (settingValue.includes(bas.cComa) === true) {
      aggregateColorArray = settingValue.split(bas.cComa);
      colorStyle[clr.cRed] = aggregateColorArray[0];
      colorStyle[clr.cGreen] = aggregateColorArray[1];
      colorStyle[clr.cBlue] = aggregateColorArray[2];
    } else if (settingValue === wr1.cDefault) {
      colorStyle = false; // Do not apply any color settings of any kind!
    } else {
      // It must be a named color.
      colorStyle = getNamedColorData(settingValue, defaultColorArray);
    }
  } else {
    colorStyle = false;
  } // console.log('colorStyle is: ' + JSON.stringify(colorStyle));
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return colorStyle;
}

;
/**
 * @function getNamedColorData
 * @description Queries the D-data structure for the named coor data.
 * All of this data should have been loaded from the Colors.csv file.
 * @param {string} colorName The name of the color who's RGB value we should look up from the color data structure.
 * @param {array<integer>} defaultColorArray The default color that should be used.
 * @return {array<integer>} An array of integers that represent RGB values.
 * @author Seth Hollingsead
 * @date 2022/01/31
 */

function getNamedColorData(colorName, defaultColorArray) {
  var functionName = getNamedColorData.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`colorName is: ${colorName}`);

  var returnColorData = defaultColorArray;

  if (_data["default"][wr1.ccolors] !== undefined) {
    if (_data["default"][wr1.ccolors][sys.cColorData] !== undefined) {
      if (_data["default"][wr1.ccolors][sys.cColorData][colorName] !== undefined) {
        returnColorData[clr.cRed] = _data["default"][wr1.ccolors][sys.cColorData][colorName][clr.cRed];
        returnColorData[clr.cGreen] = _data["default"][wr1.ccolors][sys.cColorData][colorName][clr.cGreen];
        returnColorData[clr.cBlue] = _data["default"][wr1.ccolors][sys.cColorData][colorName][clr.cBlue];
      } else {
        returnColorData = defaultColorArray;
      }
    } else {
      returnColorData = defaultColorArray;
    }
  } else {
    returnColorData = defaultColorArray;
  } // console.log('returnColorData is: ' + JSON.stringify(returnColorData));
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnColorData;
}

;
/**
 * @function setUnderlineFontStyleOnMessageComponentAccordingToSetting
 * @description Examins the underline setting value and determines if the underline font setting should be applied to the message component or not.
 * @param {string} messageComponent The message to which the underline font setting shoudl be applied if the setting value calls for it.
 * @param {boolean} underlineSettingValue A True or False value to indicate if the underline font setting should be applied or not applied.
 * @return {string} The same as the input string, except perhaps it might have an underline setting applied to it.
 * @author Seth Hollingsead
 * @date 2022/01/31
 */

function setUnderlineFontStyleOnMessageComponentAccordingToSetting(messageComponent, underlineSettingValue) {
  var functionName = setUnderlineFontStyleOnMessageComponentAccordingToSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`messageComponent is: ${messageComponent}`);
  // console.log(`underlineSettingValue is: ${underlineSettingValue}`);

  var returnMessageComponent = messageComponent;

  if (underlineSettingValue === true) {
    var colorizeLogsEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableColorizedConsoleLogs);

    if (colorizeLogsEnabled === true) {
      returnMessageComponent.chalk.underline(returnMessageComponent);
    }
  } // End-if (underlineSettingValue === true)
  // console.log('returnMessageComponent is: ' + returnMessageComponent);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnMessageComponent;
}

;
/**
 * @function setBoldFontStyleOnMessageComponentAccordingToSetting
 * @description Examins the bold setting value and determines if the bold font setting should be appied to the message component or not.
 * @param {strng} emssageComponent The message to which the bold font setting should be applied if the setting value calls for it.
 * @param {boolean} boldSettingValue A True or False value to indicate if the bold font setting should be applied or not applied.
 * @return {string} The same as the input string, except perhaps it might have a bold setting applied to it.
 * @author Seth Hollingsead
 * @date 2022/01/31
 */

function setBoldFontStyleOnMessageComponentAccordingToSetting(messageComponent, boldSettingValue) {
  var functionName = setBoldFontStyleOnMessageComponentAccordingToSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`messageComponent is: ${messageComponent}`);
  // console.log(`boldSettingValue is: ${boldSettingValue}`);

  var returnMessageComponent = messageComponent;

  if (boldSettingValue === true) {
    var colorizeLogsEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableColorizedConsoleLogs);

    if (coorizeLogsEnabled === true) {
      returnMessageComponent = _chalk["default"].bold(returnMessageComponent);
    }
  } // End-if (boldSettingValue === true)
  // console.log('returnMessageComponent is: ' + returnMessageComponent);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnMessageComponent;
}

;
/**
 * @function setFontForegroundColorOnMessageComponentAccordingToSetting
 * @description Examines the coor setting to determine if it is False,
 * if not False then it is assumed to be an array of RGB values which are assigned to the message foreground component using chalk.
 * @param {string} messageComponent The message to which the foreground coor setting should be appied if the coor setting value != false.
 * @param {boolean|array<integer>} colorSettingValue A value of False or an array of integers for RGB values. False if no color should be applied.
 * @return {string} The same as the input sring, except perhaps it might have a foreground color setting applied to it.
 * @author Seth Hollingsead
 * @date 2022/01/31
 */

function setFontForegroundColorOnMessageComponentAccordingToSetting(messageComponent, colorSettingValue) {
  var functionName = setFontForegroundColorOnMessageComponentAccordingToSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`messageComponent is: ${messageComponent}`);
  // console.log(`colorSettingValue is: ${JSON.stringify(colorSettingValue)}`);

  var returnMessageComponent = messageComponent;

  if (colorSettingValue !== false && colorSettingValue !== undefined) {
    // console.log('Red color setting value is: ' + colorSettingValue[clr.cRed]);
    // console.log('Green coor setting value is: ' + colorSettingValue[clr.cGreen]);
    // console.log('Blue coor setting value is: ' + colorSettingValue[clr.cBlue]);
    // console.log('Before using chalk, returnMessageComponent is: ' + returnMessageComponent);
    if (colorSettingValue[clr.cRed] !== undefined && colorSettingValue[clr.cGreen] !== undefined && colorSettingValue[clr.cBlue] !== undefined) {
      var colorizeLogsEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableColorizedConsoleLogs);

      if (colorizeLogsEnabled === true) {
        returnMessageComponent = _chalk["default"].rgb(colorSettingValue[clr.cRed], colorSettingValue[clr.cGreen], colorSettingValue[clr.cBlue])(returnMessageComponent);
      }
    } // End-if (colorSettingValue[clr.cRed] !== undefined && colorSettingValuep[clr.cGreen] !== undefined && colorSettingValue[clr.cBlue] !== undefined)

  } // End-if (colorSettingValue !== false && colorSettingValue !== undefined)
  // console.log('returnMessageComponent is: ' + returnMessageComponent);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnMessageComponent;
}

;
/**
 * @function setFontBackgroundColorOnMessageComponentAccordingToSetting
 * @description Examins the color setting to determien if it is False,
 * if not False then it is assumed to be an array of RGB values which are assigned to the message background using chalk.
 * @param {string} messageComponent The message to which the background color setting should be applied if the coor setting value != false.
 * @param {boolean|array<integer>} colorSettingValue A value of False or an array of integers for RGB values. False if not color should be applied.
 * @return {string} The same as the input string, except perhaps it might have a background color setting applied to it.
 * @author Seth Hollingsead
 * @date 2022/01/31
 */

function setFontBackgroundColorOnMessageComponentAccordingToSetting(messageComponent, colorSettingValue) {
  var functionName = setFontBackgroundColorOnMessageComponentAccordingToSetting.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`messageComponent is: ${messageComponent}`);
  // console.log(`colorSettingValue is: ${JSON.stringify(colorSettingValue)}`);

  var returnMessageComponent = messageComponent;

  if (colorSettingValue !== false && colorSettingValue !== undefined) {
    // console.log('Red color setting value is: ' + colorSettingValue[clr.cRed]);
    // console.log('Green coor setting value is: ' + colorSettingValue[clr.cGreen]);
    // console.log('Blue coor setting value is: ' + colorSettingValue[clr.cBlue]);
    // console.log('Before using chalk, returnMessageComponent is: ' + returnMessageComponent);
    if (colorSettingValue[clr.cRed] !== undefined && colorSettingValue[clr.cGreen] !== undefined && colorSettingValue[clr.cBlue] !== undefined) {
      var colorizeLogsEnabled = _configurator["default"].getConfigurationSetting(wr1.csystem, cfg.cenableColorizedConsoleLogs);

      if (colorizeLogsEnabled === true) {
        returnMessageComponent = _chalk["default"].bgRgb(colorSettingValue[clr.cRed], colorSettingValue[clr.cGreen], colorSettingValue[clr.cBlue])(returnMessageComponent);
      }
    } // End-if (colorSettingValue[clr.cRed] !== undefined && colorSettingValue[clr.cGreen] !== undfined && colorSettingValue[clr.cBlue] !== undefined)

  } // End-if (colorSettingValue !== false && colorSettingValue !== undefined)
  // console.log('returnMessageComponent is: ' + returnMessageComponent);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnMessageComponent;
}

;
/**
 * @function removeFontStyles
 * @description Removes all font styles and formatting from a string.
 * @param {string} message The string message that has formatting appied to it where the formatting should be removed:
 * Example: [48;2;255;255;255m[38;2;0;0;0mBEGIN main program loop[39m[49m
 * Return: BEGIN main program loop
 * @return {string} The string without all the extra formatting.
 * @author Seth Hollingsead
 * @date 2022/01/31
 * @reference: {@link https://stackoverflow.com/questions/25245716/remove-all-ansi-colors-styles-from-strings}
 */

function removeFontStyles(message) {
  var functionName = removeFontStyles.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`message is: ${message}`);

  var returnMessage = '';

  if (message) {
    // [48;2;255;255;255m[38;2;0;0;0mBEGIN main program loop[39m[49m
    returnMessage = message.replace(/\u001b[^m]*?m/g, '');
  } // End-if (message)
  // console.log('returnMessage is: ' + returnMessage);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnMessage;
}

;

var _default = (_fnc$ccolorizeMessage = {}, _defineProperty(_fnc$ccolorizeMessage, fnc.ccolorizeMessageSimple, function (message, colorArray, isForeground) {
  return colorizeMessageSimple(message, colorArray, isForeground);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.ccolorizeMessage, function (message, className, callerFunctionName, debugFilesSetting, debugFunctionsSetting, flatMessageLog) {
  return colorizeMessage(message, className, callerFunctionName, debugFilesSetting, debugFunctionsSetting, flatMessageLog);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.caggregateStyleSetting, function (settingValue1, settingValue2, defaultColorArray, processAsFontSetting) {
  return aggregateStyleSetting(settingValue1, settingValue2, defaultColorArray, processAsFontSetting);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.cgetFontStyleSettingsFromSetting, function (settingValue) {
  return getFontStyleSettingsFromSetting(settingValue);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.cgetColorStyleSettingFromSetting, function (settingValue, defaultColorArray) {
  return getColorStyleSettingFromSetting(settingValue, defaultColorArray);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.cgetNamedColorData, function (colorName, defaultColorArray) {
  return getNamedColorData(colorName, defaultColorArray);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.csetUnderlineFontStyleOnMessageComponentAccordingToSetting, function (messageComponent, underlineSettingValue) {
  return setUnderlineFontStyleOnMessageComponentAccordingToSetting(messageComponent, underlineSettingValue);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.csetBoldFontStyleOnMessageComponentAccordingToSetting, function (messageComponent, boldSettingValue) {
  return setBoldFontStyleOnMessageComponentAccordingToSetting(messageComponent, boldSettingValue);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.csetFontForegroundColorOnMessageComponentAccordingToSetting, function (messageComponent, colorSettingValue) {
  return setFontForegroundColorOnMessageComponentAccordingToSetting(messageComponent, colorSettingValue);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.csetFontBackgroundColorOnMessageComponentAccordingToSetting, function (messageComponent, colorSettingValue) {
  return setFontBackgroundColorOnMessageComponentAccordingToSetting(messageComponent, colorSettingValue);
}), _defineProperty(_fnc$ccolorizeMessage, fnc.cremoveFontStyles, function (message) {
  return removeFontStyles(message);
}), _fnc$ccolorizeMessage);

exports["default"] = _default;