"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var cfg = _interopRequireWildcard(require("../constants/configuration.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _timers = _interopRequireDefault(require("./timers.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _path = _interopRequireDefault(require("path"));

var _fnc$csetConfiguratio;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // executrix.configurator.


var namespacePrefix = wr1.cexecutrix + bas.cDot + baseFileName + bas.cDot;
/**
 * @function setConfigurationSetting
 * @description Sets a configuration setting on the configuration data structure stored on the D-data structure.
 * @param {string} configurationNamespace The path in the configuration JSON object
 * where the configuration setting should be set.
 * Ex: businessRules.rules.stringParsing.countCamelCaseWords
 * @param {string} configurationName The key of the configuration setting.
 * @param {string|integer|boolean|double} configurationValue The value of the configuration setting.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/10/13
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function setConfigurationSetting(configurationNamespace, configurationName, configurationValue) {
  // let functionName = setConfigurationSetting.name;
  // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`configurationNamespace is: ${configurationNamespace}`);
  // console.log(`configurationName is: ${configurationName}`);
  // console.log(`configurationValue is: ${configurationValue}`);
  var namespaceConfigObject = getConfigurationNamespaceObject(configurationNamespace.split(bas.cDot));

  if (namespaceConfigObject) {
    namespaceConfigObject["".concat(configurationNamespace, ".").concat(configurationName)] = configurationValue;
  } // console.log(`END ${namespacePrefix}${functionName} function`);

}

;
/**
 * @function getConfigurationSetting
 * @description Gets a configuration value based on the configuration name.
 * @param {string} configurationNamespace The path in the configuration JSON object
 * where the configuration setting should be found.
 * @param {string} configurationName The key of the configuration setting.
 * @return {string|integer|boolean|double} The value of whatever was stored in the D[configuration].
 * @author Seth Hollingsead
 * @date 2021/10/13
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function getConfigurationSetting(configurationNamespace, configurationName) {
  // let functionName = getConfigurationSetting.name;
  // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`configurationNamespace is: ${configurationNamespace}`);
  // console.log(`configurationName is: ${configurationName}`);
  var returnConfigurationValue;
  var namespaceConfigObject = undefined;
  namespaceConfigObject = getConfigurationNamespaceObject(configurationNamespace.split(bas.cDot));

  if (namespaceConfigObject) {
    if (configurationName) {
      if (configurationName.includes(bas.cAt) && configurationName.indexOf(bas.cAt) === 0) {
        returnConfigurationValue = getParentConfigurationNamespaceObject(configurationNamespace, configurationName);
      } else {
        returnConfigurationValue = namespaceConfigObject[configurationNamespace + bas.cDot + configurationName];
      }
    } else {
      returnConfigurationValue = getParentConfigurationNamespaceObject(configurationNamespace, '');
    }
  } // console.log(`returnConfigurationValue is: ${returnConfigurationValue}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnConfigurationValue;
}

;
/**
 * @function processConfigurationNameRules
 * @description Processes a fully qualified name and extracts the configuration name without the namespace.
 * @param {string} fullyQualifiedName The fully qualified name with the namespace included.
 * @return {string} The name of the configuration setting without the namespace.
 * @author Seth Hollingsead
 * @date 2021/10/26
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function processConfigurationNameRules(fullyQualifiedName) {
  var functionName = processConfigurationNameRules.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`fullyQualifiedName is: ${fullyQualifiedName}`);

  var returnValue;
  var fullyQualifiedNameArray = fullyQualifiedName.split(bas.cDot);
  returnValue = fullyQualifiedNameArray[fullyQualifiedNameArray.length - 1]; // console.log(`returnValue is: ${returnValue}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);

  return returnValue;
}

;
/**
 * @function processConfigurationNamespaceRules
 * @description Processes a fully qualified name and extracts the namespace.
 * @param {string} fullyQualifiedName The fully qualified name with the namespace included.
 * @return {string} The namespace of the configuration setting, without the configuration name.
 * @author Seth Hollingsead
 * @date 2021/10/26
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function processConfigurationNamespaceRules(fullyQualifiedName) {
  var functionName = processConfigurationNamespaceRules.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`fullyQualifiedName is: ${fullyQualifiedName}`);

  var returnValue;
  returnValue = fullyQualifiedName.substr(0, fullyQualifiedName.lastIndexOf(bas.cDot)); // console.log('returnValue is: ' + returnValue);

  if (returnValue.includes(cfg.cdebugFunctions) || returnValue.includes(cfg.cdebugFiles)) {
    // console.log('contains debugFunctions or debugFiles');
    // We need to strip off the "debugFunctions" & "debugFiles" prefixes along with the pipe that delimits them.
    // At some point we might need these separate designations, like for the colorizer logic, but for now,
    // until there is a business need I will keep them unified.
    // Everything to the right all falls under the designation of "debugSettings"
    // so that as the base for the namespace tree should work perfectly.
    var parsedDebugSettingsNamespace = returnValue.split(bas.cPipe); // console.log('parsedDebugSettingsNamespace is: ' + parsedDebugSettingsNamespace);

    returnValue = parsedDebugSettingsNamespace[1];
  } // console.log(`returnValue is: ${returnValue}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnValue;
}

;
/**
 * @function processConfigurationValueRules
 * @description Processes a name and value to execute required code and convert string values
 * to actual data objects needed by the configuration system.
 * @param {string} name The name of the configuration variable, without the namespace.
 * @param {string} value The value of the configuration variable.
 * @return {string|boolean|integer|float|object} A value that is appropriately processed.
 * @author Seth Hollingsead
 * @date 2021/10/26
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function processConfigurationValueRules(name, value) {
  // let functionName = processConfigurationValueRules.name;
  // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`name is: ${name}`);
  // console.log(`value is: ${value}`);
  var returnValue;

  switch (name) {
    case cfg.cdateTimeStamp:
    case cfg.cdateStamp:
    case cfg.ctimeStamp:
      // NOTE: All of these three configurations are processed exactly the same way.
      // As long as what is stored in the configuration file is correct, then they should be processed correctly here.
      returnValue = _timers["default"].getNowMoment(value);
      break;

    default:
      // We don't know what the value is.
      // We have to just return the value as it was passed in, no processing.
      // We don't want to corrupt the other data that may be passed into this function.
      returnValue = value;
      break;
  } // console.log(`returnValue is: ${JSON.stringify(returnValue)}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnValue;
}

;
/**
 * @function getParentConfigurationNamespaceObject
 * @description Navigates the configuration JSON data object tree to find the namespace of the configuration setting,
 * and then determines the parent and returns the entire tree of the configuration data
 * including that parent and all its top level contents.
 * @param {string} configurationNamespace The fully qualified path in the configuration JSON object
 * where the configuration setting should be found.
 * @param {string} optionalFunctionNameAppendix An optional function name appendix that could
 * potentially be added to the end of the function name.
 * Ex: @ModuleFontBackgroundColor
 * @return {object|boolean} The parent of the object found at the specified namespace address in the configuration data object,
 * or False if nothing was found.
 * @author Seth Hollingsead
 * @date 2021/10/26
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function getParentConfigurationNamespaceObject(configurationNamespace, optionalFunctionNameAppendix) {
  // let functionName = getParentConfigurationNamespaceObject.name;
  // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`configurationNamespace is: ${configurationNamespace}`);
  // console.log(`optionalFunctionNameAppendix is: ${optionalFunctionNameAppendix}`);
  var returnValue = true;
  var parentConfigurationNamespaceArray = configurationNamespace.split(bas.cDot);
  var newParentConfigurationName = parentConfigurationNamespaceArray.pop();
  var newParentConfigurationNamespace = parentConfigurationNamespaceArray.join(bas.cDot);
  var parentNamespaceConfigObject = getConfigurationNamespaceObject(parentConfigurationNamespaceArray);

  if (optionalFunctionNameAppendix !== '') {
    returnValue = parentNamespaceConfigObject[newParentConfigurationNamespace + bas.cDot + newParentConfigurationName + optionalFunctionNameAppendix];
  } else {
    returnValue = parentNamespaceConfigObject[newParentConfigurationNamespace + bas.cDot + newParentConfigurationName];
  } // console.log(`returnValue is: ${JSON.stringify(returnValue)}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnValue;
}

;
/**
 * @function getConfigurationNamespaceObject
 * @description Navigates the configuration JSON data object tree to find the namespace of configuration settings.
 * @param {array<string>} configurationNamespace The path in the configuration JSON object where the
 * configuration setting should be set, or returned.
 * @return {object|boolean} The object found at the specified namespace address in the configuration data object,
 * or False if nothing was found.
 * @author Seth Hollingsead
 * @date 2021/10/26
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function getConfigurationNamespaceObject(configurationNamespace) {
  // let functionName = getConfigurationNamespaceObject.name;
  // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`configurationNamespace is: ${configurationNamespace}`);
  var returnValue = true; // Assume there will be a return value.

  var configurationDataRoot = _data["default"][wr1.cconfiguration];
  var configurationPathObject = configurationDataRoot;

  if (!configurationPathObject) {
    // Need to handle the case that the configuration data object doesn't even exist at all!
    _data["default"][wr1.cconfiguration] = {};
    configurationDataRoot = _data["default"][wr1.cconfiguration];
    configurationPathObject = configurationDataRoot;
  }

  for (var i = 0; i < configurationNamespace.length; i++) {
    if (!configurationPathObject[configurationNamespace[i]]) {
      // It doesn't exist yet, so lets make it.
      configurationPathObject[configurationNamespace[i]] = {};
    }

    configurationPathObject = configurationPathObject[configurationNamespace[i]];
  } // End for-loop (let i = 0; i < configurationNamespace.length; i++)


  if (returnValue) {
    returnValue = configurationPathObject;
  } // console.log(`returnValue is: ${JSON.stringify(returnValue)}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnValue;
}

;

var _default = (_fnc$csetConfiguratio = {}, _defineProperty(_fnc$csetConfiguratio, fnc.csetConfigurationSetting, function (configurationNamespace, configurationName, configurationValue) {
  return setConfigurationSetting(configurationNamespace, configurationName, configurationValue);
}), _defineProperty(_fnc$csetConfiguratio, fnc.cgetConfigurationSetting, function (configurationNamespace, configurationName) {
  return getConfigurationSetting(configurationNamespace, configurationName);
}), _defineProperty(_fnc$csetConfiguratio, fnc.cprocessConfigurationNameRules, function (fullyQualifiedName) {
  return processConfigurationNameRules(fullyQualifiedName);
}), _defineProperty(_fnc$csetConfiguratio, fnc.cprocessConfigurationNamespaceRules, function (fullyQualifiedName) {
  return processConfigurationNamespaceRules(fullyQualifiedName);
}), _defineProperty(_fnc$csetConfiguratio, fnc.cprocessConfigurationValueRules, function (name, value) {
  return processConfigurationValueRules(name, value);
}), _fnc$csetConfiguratio);

exports["default"] = _default;