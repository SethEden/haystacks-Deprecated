"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var gen = _interopRequireWildcard(require("../constants/generic.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _loggers = _interopRequireDefault(require("./loggers.js"));

var _moment = _interopRequireDefault(require("moment"));

var _path = _interopRequireDefault(require("path"));

var _fnc$cgetNowMoment$fn;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // executrix.timers.


var namespacePrefix = wr1.cexecutrix + bas.cDot + baseFileName + bas.cDot;
/**
 * @function getNowMoment
 * @description Returns a time stamp string formatted according to the input formatting string.
 * @param {string} formatting The formatting string, that tells moment in what format to
 * return the value for the day, month, year, hour, minute, second and millisecond.
 * @return {string} A time stamp string that has been formatted accroding to the input format.
 * @author Seth Hollingsead
 * @date 2021/10/19
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function getNowMoment(formatting) {
  var functionName = getNowMoment.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`formatting is: ${formatting}`);

  var returnData = '';
  returnData = (0, _moment["default"])().format(formatting); // console.log(`returnData is: ${returnData}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);

  return returnData;
}

;
/**
 * @function computeDeltaTime
 * @description Computes the time difference between two different date-time stamps in milliseconds.
 * @param {string} startTime The start of the time period that should be computed.
 * @param {string} endTime The end of the time period that should be computed.
 * @return {integer} The difference between the beginning time and ending time in milliseconds.
 * @author Seth Hollingsead
 * @date 2021/10/19
 */

function computeDeltaTime(startTime, endTime) {
  var functionName = computeDeltaTime.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`startTime is: ${startTime}`);
  // console.log(`endTime is: ${endTime}`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cstartTimeIs + startTime);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cendTimeIs + endTime);

  var deltaTimeResult;
  startTime = (0, _moment["default"])(startTime, gen.cYYYYMMDD_HHmmss_SSS);
  endTime = (0, _moment["default"])(endTime, gen.cYYYYMMDD_HHmmss_SSS);
  deltaTimeResult = endTime.diff(startTime); // Should wok in milliseconds out of the box!

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdeltaTimeResultIs + deltaTimeResult);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function); // console.log(`deltaTimeResult is: ${deltaTimeResult}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return deltaTimeResult;
}

;
/**
 * @function reformatDeltaTime
 * @description Converts a time interval into a different kind of format.
 * @param {integer} deltaTime A time interval measured in milliseconds.
 * @param {string} format The formatting template that should be used to format the time interval.
 * @return {string} A time interval formatted according to the input format template string.
 * @author Seth Hollingsead
 * @date 2022/02/16
 */

function reformatDeltaTime(deltaTime, format) {
  var functionName = reformatDeltaTime.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // deltaTime is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cdeltaTimeIs + deltaTime); // format is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cformatIs + format);

  var returnDeltaTime = '';
  returnDeltaTime = _moment["default"].duration(deltaTime).format(format); // returnDeltaTime is:

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.creturnDeltaTimeIs + returnDeltaTime);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);

  return returnDeltaTime;
}

;
/**
 * @function sleep
 * @description Causes the JavaScript code to wait for a period of time defined by the input.
 * @param {integer} sleepTime The number of milliseconds that the system should sleep for.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2022/02/16
 * @reference {@link https://www.sitepoint.com/delay-sleep-pause-wait/}
 */

function sleep(sleepTime) {
  var functionName = sleep.name;

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function); // sleepTime is:


  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.csleepTimeIs + sleepTime);

  var date = (0, _moment["default"])();
  var currentDate = null;

  do {
    currentDate = (0, _moment["default"])();
  } while (currentDate - date < sleepTime);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;

var _default = (_fnc$cgetNowMoment$fn = {}, _defineProperty(_fnc$cgetNowMoment$fn, fnc.cgetNowMoment, function (formatting) {
  return getNowMoment(formatting);
}), _defineProperty(_fnc$cgetNowMoment$fn, fnc.ccomputeDeltaTime, function (startTime, endTime) {
  return computeDeltaTime(startTime, endTime);
}), _defineProperty(_fnc$cgetNowMoment$fn, fnc.creformatDeltaTime, function (deltaTime, format) {
  return reformatDeltaTime(deltaTime, format);
}), _defineProperty(_fnc$cgetNowMoment$fn, fnc.csleep, function (sleepTime) {
  return sleep(sleepTime);
}), _fnc$cgetNowMoment$fn);

exports["default"] = _default;