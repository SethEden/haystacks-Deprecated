"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _ruleBroker = _interopRequireDefault(require("../brokers/ruleBroker.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var biz = _interopRequireWildcard(require("../constants/business.constants.js"));

var cfg = _interopRequireWildcard(require("../constants/configuration.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _chiefData = _interopRequireDefault(require("./chiefData.js"));

var _configurator = _interopRequireDefault(require("../executrix/configurator.js"));

var _loggers = _interopRequireDefault(require("../executrix/loggers.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _path = _interopRequireDefault(require("path"));

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // controllers.chiefConfiguration.


var namespacePrefix = wr1.ccontrollers + bas.cDot + baseFileName + bas.cDot;
/**
 * @function setupConfiguration
 * @description Sets up all of the application and framework configuration data.
 * @param {string} appConfigPath The path of the configuration files for the application layer.
 * @param {string} frameworkConfigPath The path of the configuration files for the framework layer.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/10/13
 */

function setupConfiguration(appConfigPath, frameworkConfigPath) {
  var functionName = setupConfiguration.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`appConfigPath is: ${appConfigPath}`);
  // console.log(`frameworkConfigPath is: ${frameworkConfigPath}`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cBEGIN_Function);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cappConfigPathIs + appConfigPath);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cframeworkConfigPathIs + frameworkConfigPath);

  var rules = [];
  rules[0] = biz.cswapBackSlashToForwardSlash;
  appConfigPath = _ruleBroker["default"].processRules(appConfigPath, '', rules); // console.log(`appConfigPath after rule processing is: ${appConfigPath}`);

  frameworkConfigPath = _ruleBroker["default"].processRules(frameworkConfigPath, '', rules); // console.log(`frameworkConfigPath after rule processing is: ${frameworkConfigPath}`);

  _configurator["default"].setConfigurationSetting(wr1.csystem, sys.cappConfigPath, appConfigPath);

  _configurator["default"].setConfigurationSetting(wr1.csystem, sys.cframeworkConfigPath, frameworkConfigPath);

  var allAppConfigData = {};
  var allFrameworkConfigData = {};

  var universalDebugConfigSetting = _chiefData["default"].searchForUniversalDebugConfigSetting(sys.cappConfigPath, sys.cframeworkConfigPath);

  allFrameworkConfigData = _chiefData["default"].setupAllJsonConfigData(sys.cframeworkConfigPath, wr1.cconfiguration);
  allAppConfigData = _chiefData["default"].setupAllJsonConfigData(sys.cappConfigPath, wr1.cconfiguration);
  parseLoadedConfigurationData(allFrameworkConfigData);
  parseLoadedConfigurationData(allAppConfigData); // console.log('ALL DATA IS: ' + JSON.stringify(D));
  // console.log(`END ${namespacePrefix}${functionName} function`);

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cALL_DATA_IS + JSON.stringify(_data["default"]));

  _loggers["default"].consoleLog(namespacePrefix + functionName, msg.cEND_Function);
}

;
/**
 * @function parseLoadedConfigurationData
 * @description Parses through all of the configuration data that we just loaded from the XML files and
 * adds that data to the correct data-structures in the D.[configuration] data hive.
 * @param {object} allConfigurationData A JSON data structure object that contains all configuration meta-data.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/11/10
 * @NOTE Cannot use the loggers here, because dependency data will have never been loaded.
 */

function parseLoadedConfigurationData(allConfigurationData) {
  var functionName = parseLoadedConfigurationData.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`allConfigurationData is: ${JSON.stringify(allConfigurationData)}`);

  var highLevelSystemConfigurationContainer = {};
  var highLevelDebugConfigurationContainer = {};
  var rules = [];
  var configurationElement;
  var configurationSubElement;
  var fullyQualifiedName;
  var namespace;
  var name;
  var type;
  var value;
  var version;
  var advancedDebugSettingPrefix;
  rules[0] = biz.cstringToDataType;
  highLevelSystemConfigurationContainer = allConfigurationData[wr1.csystem]; // console.log('highLevelSystemConfigurationContainer is: ' + JSON.stringify(highLevelSystemConfigurationContainer));

  highLevelDebugConfigurationContainer = allConfigurationData[cfg.cdebugSettings]; // console.log('highLevelDebugConfigurationContainer is: ' + JSON.stringify(highLevelDebugConfigurationContainer));

  for (var key in highLevelSystemConfigurationContainer) {
    fullyQualifiedName = '';
    namespace = '';
    name = '';
    value = '';
    value = highLevelSystemConfigurationContainer[key]; // console.log('value is: ' + value);

    if (!!value || value === false) {
      fullyQualifiedName = key; // console.log('fullyQualifiedName is: ' + fullyQualifiedName);

      name = _configurator["default"].processConfigurationNameRules(fullyQualifiedName); // console.log('name is: ' + name);

      namespace = _configurator["default"].processConfigurationNamespaceRules(fullyQualifiedName); // console.log('namespace is: ' + namespace);

      value = _configurator["default"].processConfigurationValueRules(name, value); // console.log('value BEFORE rule processing is: ' + value);

      value = _ruleBroker["default"].processRules(value, '', rules); // console.log('value AFTER rule processing is: ' + value);

      if (namespace === wr1.csystem && name === cfg.cdebugSettings && _configurator["default"].getConfigurationSetting(namespace, name) === true) {// console.log('CAUGHT THE CASE THAT WE ARE SETTING A FALSE VALUE FOR DEBUG-SETTINGS');
        // NOTE: DO NOT over write the value because the base value is already saved as true.
        // Over writing it with true, doesn't do anything, and over writing it with false
        // destroys whatever setting the user may have set from the client application.
      } else {
        _configurator["default"].setConfigurationSetting(namespace, name, value);
      }
    }
  }

  for (var _key in highLevelDebugConfigurationContainer) {
    fullyQualifiedName = '';
    namespace = '';
    name = '';
    value = '';
    value = highLevelDebugConfigurationContainer[_key]; // console.log('value is: ' + value);

    if (!!value || value === false) {
      fullyQualifiedName = _key; // console.log('fullyQualifiedName is: ' + fullyQualifiedName);

      name = _configurator["default"].processConfigurationNameRules(fullyQualifiedName); // console.log('name is: ' + name);

      namespace = _configurator["default"].processConfigurationNamespaceRules(fullyQualifiedName); // console.log('namespace is: ' + namespace);

      value = _configurator["default"].processConfigurationValueRules(name, value); // console.log('value BEFORE rule processing is: ' + value);

      value = _ruleBroker["default"].processRules(value, '', rules); // console.log('value AFTER rule processing is: ' + value);

      _configurator["default"].setConfigurationSetting(namespace, name, value);
    }
  } // console.log(`END ${namespacePrefix}${functionName} function`);

}

;

var _default = _defineProperty({}, fnc.csetupConfiguration, function (appConfigPath, frameworkConfigPath) {
  return setupConfiguration(appConfigPath, frameworkConfigPath);
});

exports["default"] = _default;