"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _rulesLibrary = _interopRequireDefault(require("../businessRules/rulesLibrary.js"));

var bas = _interopRequireWildcard(require("../constants/basic.constants.js"));

var fnc = _interopRequireWildcard(require("../constants/function.constants.js"));

var msg = _interopRequireWildcard(require("../constants/message.constants.js"));

var sys = _interopRequireWildcard(require("../constants/system.constants.js"));

var wr1 = _interopRequireWildcard(require("../constants/word1.constants.js"));

var _data = _interopRequireDefault(require("../structures/data.js"));

var _path = _interopRequireDefault(require("path"));

var _fnc$cbootStrapBusine;

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var baseFileName = _path["default"].basename(import.meta.url, _path["default"].extname(import.meta.url)); // brokers.ruleBroker.


var namespacePrefix = wr1.cbrokers + bas.cDot + baseFileName + bas.cDot;
/**
 * @function bootStrapBusinessRules
 * @description Captures all of the business rule string-to-function call map data in
 * the rulesLibrary and migrates that data to the D-data structure.
 * This is important now because we are going to allow the client to define their own
 * business rules seperate from the system defined business rules.
 * So we need a way to merge all client defined and system defined business rules into one location.
 * Then the rule broker will execute business rules from the D-data structure and not the rules library per-say.
 * This will allow the system to expand much more dynamically and even be user-defined & flexible to client needs.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/10/27
 * @NOTE Cannot use the loggers here, because dependency data will have never been loaded.
 */

function bootStrapBusinessRules() {
  var functionName = bootStrapBusinessRules.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);

  _rulesLibrary["default"].initRulesLibrary(); // console.log(`END ${namespacePrefix}${functionName} function`);

}

;
/**
 * @function addClientRules
 * @description Merges client defined business rules with the system defined business rules.
 * @param {array<object>} clientRules The cient rules that should be merged with the system rules.
 * @return {void}
 * @author Seth Hollingsead
 * @date 2021/10/27
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function addClientRules(clientRules) {
  var functionName = bootStrapBusinessRules.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);

  Object.assign(_data["default"][sys.cbusinessRules], clientRules); // console.log(`END ${namespacePrefix}${functionName} function`);
}

;
/**
 * @function doesRuleExist
 * @description Determines if a specified named rule exists in the rules system or not.
 * @param {string} ruleName The rule name that should be validated as existing in the runtime rules data structure.
 * @return {boolean} A True or False value to indicate if the rule exists or does not exist.
 * @author Seth Hollingsead
 * @date 2022/02/24
 */

function doesRuleExist(ruleName) {
  var functionName = doesRuleExist.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`ruleName is: ${ruleName}`);

  var returnData = false;

  if (ruleName) {
    if (_data["default"][sys.cbusinessRules][ruleName]) {
      returnData = true;
    }
  } // End-if (ruleName)
  // console.log(`returnData is: ${returnData}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnData;
}

;
/**
 * @function doAllRulesExist
 * @description Determines if all the rules in an array of rule names all
 * exist in the runtime rules data structure or not.
 * @param {array<string>} ruleArray The array of rule names that should be
 * validated for existence in the runtime rules data structure.
 * @return {boolean} A True or False value to indicate if all the rules in the
 * input array exist or do not all exist.
 * @author Seth Hollingsead
 * @date 2022/02/24
 */

function doAllRulesExist(ruleArray) {
  var functionName = doAllRulesExist.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`ruleArray is: ${JSON.stringify(ruleArray)}`);

  var returnData = false;
  var tempValidationResult = true;

  if (ruleArray && ruleArray.length > 0) {
    for (var i = 0; i < ruleArray.length; i++) {
      if (doesRuleExist(ruleArray[i]) === false) {
        tempValidationResult = false;
      }
    } // End-for (let i = 0; i < ruleArray.length; i++)


    if (tempValidationResult === true) {
      returnData = true;
    }
  } // End-if (ruleArray && ruleArray.length > 0)
  // console.log(`returnData is: ${returnData}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnData;
}

;
/**
 * @function processRules
 * @description Parse the given input Object/String/Integer/Data/Function through a set of business rules,
 * (Some rules do not support chaining); where the rules are defined in the input rules array.
 * @param {string|integer|boolean|object|function} inputData The primary input data that should be processed by the business rule.
 * @param {string|integer|boolean|object|function} inputMetaData Additional meta-data that should be used when processing the business rule.
 * @param {array<string>} rulesToExecute The name(s) of the rule(s) that should be executed for modding the input data.
 * @return {string|integer|boolean|object|function} A modified data Object/String/Integer/Boolean/Function
 * where the data has been modified based on the input data, input meta-data, and business rule that was executed.
 * @author Seth Hollingsead
 * @date 2021/10/27
 * @NOTE Cannot use the loggers here, because of a circular dependency.
 */

function processRules(inputData, inputMetaData, rulesToExecute) {
  var functionName = processRules.name; // console.log(`BEGIN ${namespacePrefix}${functionName} function`);
  // console.log(`inputData is: ${JSON.stringify(inputData)}`);
  // console.log(`inputMetaData is: ${JSON.stringify(inputMetaData)}`);
  // console.log(`rulesToExecute is: ${JSON.stringify(rulesToExecute)}`);

  var returnData = inputData;

  if (rulesToExecute && doAllRulesExist(rulesToExecute)) {
    for (var rule in rulesToExecute) {
      if (rulesToExecute.hasOwnProperty(rule)) {
        var key = rule; // console.log(`key is: ${key}`);

        var value = rulesToExecute[key]; // console.log(`value is: ${value}`);

        returnData = _data["default"][sys.cbusinessRules][value](returnData, inputMetaData);
      } // End-if (rulesToExecute.hasOwnProperty(rule))

    } // End-for (let rule in rulesToExecute)

  } else {
    // WARNING: Some rules do not exist:
    console.log(msg.cProcessRulesWarningSomeRulesDoNotExist + JSON.stringify(rulesToExecute));
  } // End-if (rulesToExecute && doAllRulesExist(rulesToExecute))
  // console.log(`returnData is: ${JSON.stringify(returnData)}`);
  // console.log(`END ${namespacePrefix}${functionName} function`);


  return returnData;
}

;

var _default = (_fnc$cbootStrapBusine = {}, _defineProperty(_fnc$cbootStrapBusine, fnc.cbootStrapBusinessRules, function () {
  return bootStrapBusinessRules();
}), _defineProperty(_fnc$cbootStrapBusine, fnc.caddClientRules, function (clientRules) {
  return addClientRules(clientRules);
}), _defineProperty(_fnc$cbootStrapBusine, fnc.cdoesRuleExist, function (ruleName) {
  return doesRuleExist(ruleName);
}), _defineProperty(_fnc$cbootStrapBusine, fnc.cdoAllRulesExist, function (ruleArray) {
  return doAllRulesExist(ruleArray);
}), _defineProperty(_fnc$cbootStrapBusine, fnc.cprocessRules, function (inputData, inputMetaData, rulesToExecute) {
  return processRules(inputData, inputMetaData, rulesToExecute);
}), _fnc$cbootStrapBusine);

exports["default"] = _default;